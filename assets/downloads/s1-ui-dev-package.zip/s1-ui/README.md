# S1 UI 라이브러리 — 개발자·퍼블리셔 배포본

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> 필요한 것이 없으면 만들지 말고 디자인팀에 요청해 주세요.

- 버전: **0.1.0**
- 정본 지문: `fb8768fffd4c8af9710ae7db97a895bf3580cabb38afe443ae0197c580fbc3a3`
- 승인 컴포넌트: **22종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content)
- 토큰: **481개**

## 1. 웹(HTML·CSS·JS)에서 쓰기 — 3줄

```html
<link rel="stylesheet" href="s1-ui/assets/css/tokens.css">
<link rel="stylesheet" href="s1-ui/s1-ui.css">
<script type="module">
  import { autoInit } from "./s1-ui/s1-ui.auto.js";
  autoInit();
</script>
```

글꼴은 Pretendard 입니다: `https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css`

마크업은 상상하지 말고 `examples/` 안의 파일을 복사해서 쓰세요. 모바일용은 `*.mobile.html` 입니다.

## 2. 내 개발 툴에서 쓰기

| 툴 | 시작 파일 | 어디까지 쓰나 | 자가 검사 |
|---|---|---|---|
| html-css-js | s1-ui.css · s1-ui.auto.js | 컴포넌트까지 그대로 사용 | 가능 |
| react | platform/react/index.js | 컴포넌트까지 그대로 사용 | 가능 |
| vue | platform/vue/index.js | 컴포넌트까지 그대로 사용 | 가능 |
| kotlin | platform/kotlin/S1Tokens.kt | 토큰(색·크기) 값만 제공 | 해당 없음 |
| swift | platform/swift/S1Tokens.swift | 토큰(색·크기) 값만 제공 | 해당 없음 |
| cpp | platform/cpp/s1_tokens.h | 토큰(색·크기) 값만 제공 | 해당 없음 |

- **React**: `import { S1Button } from "./s1-ui/platform/react/index.js"` — 승인된 마크업을 그대로 마운트하는 껍데기입니다. JSX 빌드 도구가 필요하고, **JSX 런타임은 automatic 이어야 합니다**(요즘 기본값입니다. `tsconfig` 의 `"jsx": "react-jsx"`, Babel 의 `runtime: "automatic"`). 옛 classic 설정이면 컴파일되지 않습니다.
- **Vue**: `import { S1Button } from "./s1-ui/platform/vue/index.js"` — SFC(.vue) 빌드 도구가 필요합니다.
- **이벤트 받는 모양이 둘이 다릅니다**: React 는 핸들러가 **이벤트 객체**를 받고(`event.detail` 로 값을 꺼냅니다), Vue 는 emit 이 **detail 값 자체**를 바로 넘깁니다.
- **화면 크기별 마크업**: PC·Mobile 마크업이 다른 컴포넌트는 `breakName` 으로 고릅니다(`"pc"` / `"mobile"`). 값을 바꾸면 마크업이 다시 마운트됩니다.
- **Kotlin·Swift·C++**: 컴포넌트는 각자 구현해야 합니다. 대신 색·크기 값(`platform/`)과 동작 명세(`platform/behavior.json`)를 그대로 쓰세요. **값을 눈으로 보고 옮겨 적지 마세요.**

## 3. 내가 만든 것이 규칙에 맞는지 검사하기

```bash
node s1-ui/tools/s1-ui-lint.mjs <내 소스 폴더>
```

직접 적은 색, 승인되지 않은 variant·size, 빠진 필수 속성, 없는 토큰 이름을 찾아 줍니다.

## 4. 내 배포본이 최신인지 확인하기

```bash
node s1-ui/tools/s1-ui-lint.mjs --version
```

여기 나오는 정본 지문이 디자인가이드 다운로드 화면의 지문과 같아야 최신입니다.

## 5. 폴더 안내

| 폴더 | 내용 |
|---|---|
| `s1-ui.css` · `s1-ui.auto.js` | 전체 묶음 (한 번에 설치) |
| `components/` | 컴포넌트별 개별 설치용 CSS·JS·계약 |
| `examples/` | 복사해서 쓰는 마크업 (PC·Mobile) |
| `assets/` | 토큰 CSS·타이포 CSS·아이콘 SVG |
| `platform/` | 툴별 산출물 (React·Vue 껍데기, Kotlin·Swift·C++ 값, 계약·동작 명세) |
| `tools/` | 자가 검사기 |
