# S1 UI 라이브러리 — HTML · CSS · JavaScript 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **HTML · CSS · JavaScript 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.20.0**
- 정본 지문: `783486db3584b2bbee00a5fc50150916a1ce3b48c92369ccf8d0e6c6a6d0fd8c`
- 승인 컴포넌트: **32종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, gnb, gnb-sub-menu-item, gnb-sub-menu, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet, list-row, expandable-card, data-tag, divider, lnb)
- 토큰: **499개**

## 이 묶음에 들어있는 것

컴포넌트 32종 전부 · 복사해서 쓰는 마크업(examples/) · 겉모습 한 벌(s1-ui.css) · 동작 스크립트(s1-ui.auto.js) · 아이콘.

## 시작하기

1. 압축을 풀면 나오는 `s1-ui` 폴더를 프로젝트에 그대로 넣습니다.
2. **`preview.html` 을 더블클릭하면 컴포넌트 32종이 실제 모습으로 보입니다**(서버 없이 열립니다) — 무엇을 쓸지 여기서 고르세요.
3. 내 페이지 `<head>` 에 글꼴·`assets/css/tokens.css`·`s1-ui.css` 를 읽힙니다(아래 「내 페이지에 붙이기」 코드 그대로).
4. 페이지 끝에 `<script type="module">` 로 `s1-ui.auto.js` 를 불러 `autoInit()` 을 한 번 부르면 동작이 전부 붙습니다. 일반 `<script src>` 로는 동작하지 않습니다.
5. 마크업은 `examples/` 폴더의 파일을 복사해서 씁니다(모바일용은 `*.mobile.html`). 부품마다 쓰는 법은 `components/` 폴더의 같은 이름 `.md` 설명서에 있습니다.

## 자세한 사용법

### 내 페이지에 붙이기

```html
<!doctype html>
<html lang="ko">                       <!-- 다크 모드: <html lang="ko" data-theme="dark"> -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- 글꼴 Pretendard (묶음에 들어 있지 않습니다 — 아래 링크로 받습니다) -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css">
  <link rel="stylesheet" href="s1-ui/assets/css/tokens.css">
  <link rel="stylesheet" href="s1-ui/assets/css/typography.css">   <!-- 선택: typo-* 글자 클래스를 쓸 때 -->
  <link rel="stylesheet" href="s1-ui/s1-ui.base.css">            <!-- 선택: 페이지 바탕·기본 글자색 (다크 모드에서 바탕이 따라옵니다) -->
  <link rel="stylesheet" href="s1-ui/s1-ui.css">
</head>
<body>
  <!-- examples/ 에서 복사한 마크업 -->
  <script type="module">
    import { autoInit } from "./s1-ui/s1-ui.auto.js";
    autoInit();
  </script>
</body>
</html>
```

- **`<script type="module">` 이어야 합니다.** 일반 `<script src="…s1-ui.auto.js">` 로 넣으면 오류가 나고 아무 동작도 붙지 않습니다.
- 모듈 스크립트는 파일을 더블클릭(`file://`)해서 연 내 페이지에서는 브라우저가 막습니다 — 로컬 서버(예: `npx serve`)로 여세요. (`preview.html` 은 서버 없이 열리도록 따로 만들어 둔 파일입니다.)
- 글꼴은 위 Pretendard 링크가 있어야 설계한 모양 그대로 나옵니다. 링크가 없으면 부품은 글꼴이 깔린 컴퓨터에서만 그대로 보입니다.

### 다크 모드

`<html>` 에 `data-theme="dark"` 를 달면 부품 전체가 다크로 바뀝니다(끄려면 속성을 지웁니다). 페이지 바탕과 기본 글자색은 부품이 아니라 내 페이지의 몫이라 그냥 두면 흰색 그대로입니다 — `s1-ui.base.css` 를 읽거나, 직접 `background: var(--color-bg-level-0)` 를 칠하세요.

### 나중에 넣은 마크업에 동작 붙이기

`autoInit()` 은 부른 시점에 있는 마크업에만 동작을 붙입니다. 목록을 불러와 그린 화면처럼 나중에 넣은 조각은 그 조각을 감싼 요소를 넘겨 다시 부르세요 — 두 번 불러도 겹치지 않습니다.

```js
autoInit(document.getElementById("late-area"));
```

부품 하나만 직접 붙이려면(자동 연결 없이):

```js
import { toggle } from "./s1-ui/s1-ui.js";
const api = toggle.init(document.querySelector('[data-s1-component="toggle"]'));
```

### 모달·바텀시트 열고 닫기

처음에는 숨겨져 있습니다. **속성 한 줄로** 엽니다 — 열 버튼에 창의 id 를, 창 안에서 닫을 요소에 `data-s1-close` 를 답니다(값은 닫힌 이유: `cancel`·`confirm` 등).

```html
<button type="button" data-s1-open="my-modal">열기</button>
<div id="my-modal" data-s1-component="modal" data-break="pc" data-footer="dual" hidden> … <button type="button" data-s1-close="cancel">취소</button> … </div>
```

스크립트로 열려면 `import { modal } from "./s1-ui/s1-ui.js"; modal.init(요소).open()`, 닫으려면 `.close()` 입니다. 창 안에서 달력·시간·드롭다운이 열려 있을 때 Esc 는 그것만 닫고 창은 남깁니다. 자세한 것은 `components/modal.md` · `components/modal-content.md` · `components/bottom-sheet.md`.

### 값 넣기·읽기·폼 전송

셀렉트·달력·시간 선택은 `data-name="이름"` 을 주면 숨은 입력이 만들어져 `<form>` 으로 함께 전송됩니다. 셀렉트는 `data-value`(처음 값)·`api.value`·`api.setValue()`, 달력은 `data-value`(단일)·`data-range-start`/`data-range-end`(기간)·`api.value`·`api.setValue()`, 페이지네이션은 총 쪽수만 `api.setTotalPages(n)` 으로 주면 번호 줄을 다시 그립니다.

### 모바일

모바일용 마크업은 `*.mobile.html` 입니다(비밀번호·검색 입력도 `examples/input.password.mobile.html` · `examples/input.search.mobile.html` 처럼 같은 규칙입니다). 모바일에만 쓰는 부품은 PC 용 파일이 따로 없고 파일 이름에 `.mobile` 이 붙습니다: **mobile-bottom-nav · mobile-header · bottom-sheet**.

### 부품 목록 (32종)

부품마다 마크업·고르는 속성·옵션·이벤트·여닫기를 적은 설명서가 있습니다. 쓰려는 부품의 `components/<이름>.md` 를 먼저 읽으세요. 쓸 수 있는 종류·크기 값도 거기 있습니다.

| 이름 | React·Vue 이름 | 마크업 예시 | 설명서 |
|---|---|---|---|
| input | S1Input | `examples/input.html` `examples/input.mobile.html` `examples/input.password.html` `examples/input.password.mobile.html` `examples/input.search.html` `examples/input.search.mobile.html` | `components/input.md` |
| button | S1Button | `examples/button.html` `examples/button.mobile.html` | `components/button.md` |
| checkbox | S1Checkbox | `examples/checkbox.html` | `components/checkbox.md` |
| radio | S1Radio | `examples/radio.html` | `components/radio.md` |
| toggle | S1Toggle | `examples/toggle.html` | `components/toggle.md` |
| chip | S1Chip | `examples/chip.html` `examples/chip.mobile.html` | `components/chip.md` |
| dropdown | S1Dropdown | `examples/dropdown.html` | `components/dropdown.md` |
| select | S1Select | `examples/select.html` `examples/select.mobile.html` | `components/select.md` |
| filter-chip | S1FilterChip | `examples/filter-chip.html` `examples/filter-chip.mobile.html` | `components/filter-chip.md` |
| tab | S1Tab | `examples/tab.html` `examples/tab.mobile.html` | `components/tab.md` |
| pagination | S1Pagination | `examples/pagination.html` | `components/pagination.md` |
| textarea | S1Textarea | `examples/textarea.html` `examples/textarea.mobile.html` | `components/textarea.md` |
| multi-toggle | S1MultiToggle | `examples/multi-toggle.html` | `components/multi-toggle.md` |
| modal | S1Modal | `examples/modal.html` `examples/modal.mobile.html` | `components/modal.md` |
| table | S1Table | `examples/table.html` | `components/table.md` |
| mobile-bottom-nav | S1MobileBottomNav | `examples/mobile-bottom-nav.mobile.html` | `components/mobile-bottom-nav.md` |
| mobile-header | S1MobileHeader | `examples/mobile-header.mobile.html` | `components/mobile-header.md` |
| time-picker | S1TimePicker | `examples/time-picker.html` `examples/time-picker.mobile.html` | `components/time-picker.md` |
| date-picker | S1DatePicker | `examples/date-picker.html` `examples/date-picker.mobile.html` | `components/date-picker.md` |
| gnb | S1Gnb | `examples/gnb.html` | `components/gnb.md` |
| gnb-sub-menu-item | S1GnbSubMenuItem | `examples/gnb-sub-menu-item.html` | `components/gnb-sub-menu-item.md` |
| gnb-sub-menu | S1GnbSubMenu | `examples/gnb-sub-menu.html` | `components/gnb-sub-menu.md` |
| assist-button | S1AssistButton | `examples/assist-button.html` | `components/assist-button.md` |
| text-button | S1TextButton | `examples/text-button.html` | `components/text-button.md` |
| modal-content | S1ModalContent | `examples/modal-content.html` | `components/modal-content.md` |
| bottom-sheet-option | S1BottomSheetOption | `examples/bottom-sheet-option.html` | `components/bottom-sheet-option.md` |
| bottom-sheet | S1BottomSheet | `examples/bottom-sheet.mobile.html` | `components/bottom-sheet.md` |
| list-row | S1ListRow | `examples/list-row.html` | `components/list-row.md` |
| expandable-card | S1ExpandableCard | `examples/expandable-card.html` | `components/expandable-card.md` |
| data-tag | S1DataTag | `examples/data-tag.html` | `components/data-tag.md` |
| divider | S1Divider | `examples/divider.html` | `components/divider.md` |
| lnb | S1Lnb | `examples/lnb.html` | `components/lnb.md` |

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.

```bash
node s1-ui/tools/s1-ui-lint.mjs --version          # 지문 확인
node s1-ui/tools/s1-ui-lint.mjs <내 소스 폴더>      # 규칙 검사
```
