# S1 UI 라이브러리 — HTML · CSS · JavaScript 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **HTML · CSS · JavaScript 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.24.1**
- 정본 지문: `53db1bd8eb3a824ca156e744fe04866dce887b81f21bad0194a061f7f608e83d`
- 승인 컴포넌트: **32종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, gnb, gnb-sub-menu-item, gnb-sub-menu, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet, list-row, expandable-card, data-tag, divider, lnb)
- 토큰: **504개**

## 이 묶음에 들어있는 것

컴포넌트 32종 전부 · 복사해서 쓰는 마크업(examples/) · 겉모습 한 벌(s1-ui.css) · 동작 스크립트(s1-ui.auto.js) · 아이콘.

## 시작하기

1. 압축을 풀면 나오는 `s1-ui` 폴더를 프로젝트에 그대로 넣습니다.
2. **`preview.html` 을 더블클릭하면 컴포넌트 32종이 실제 모습으로 보입니다**(서버 없이 열립니다) — 무엇을 쓸지 여기서 고르세요.
3. 내 페이지 `<head>` 에 글꼴·`assets/css/tokens.css`·`s1-ui.css` 를 읽힙니다(아래 「내 페이지에 붙이기」 코드 그대로).
4. 페이지 끝에 `<script type="module">` 로 `s1-ui.auto.js` 를 불러 `autoInit()` 을 한 번 부르면 동작이 전부 붙습니다. 일반 `<script src>` 로는 동작하지 않습니다.
5. 마크업은 `examples/` 폴더의 파일을 복사해서 씁니다(모바일용은 `*.mobile.html`). 부품마다 쓰는 법은 `components/` 폴더의 같은 이름 `.md` 설명서에 있습니다.

## 자세한 사용법

### 내 페이지에 붙이기

```html
<!doctype html>
<html lang="ko">                       <!-- 다크 모드: <html lang="ko" data-theme="dark"> -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- 글꼴 Pretendard (묶음에 들어 있지 않습니다 — 아래 링크로 받습니다) -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css">
  <link rel="stylesheet" href="s1-ui/assets/css/tokens.css">
  <link rel="stylesheet" href="s1-ui/assets/css/typography.css">   <!-- 선택: typo-* 글자 클래스를 쓸 때 -->
  <link rel="stylesheet" href="s1-ui/s1-ui.base.css">            <!-- 선택: 페이지 바탕·기본 글자색 (다크 모드에서 바탕이 따라옵니다) -->
  <link rel="stylesheet" href="s1-ui/s1-ui.css">
</head>
<body>
  <!-- examples/ 에서 복사한 마크업 -->
  <script type="module">
    import { autoInit } from "./s1-ui/s1-ui.auto.js";
    autoInit();
  </script>
</body>
</html>
```

- **`<script type="module">` 이어야 합니다.** 일반 `<script src="…s1-ui.auto.js">` 로 넣으면 오류가 나고 아무 동작도 붙지 않습니다.
- 모듈 스크립트는 파일을 더블클릭(`file://`)해서 연 내 페이지에서는 브라우저가 막습니다 — 로컬 서버(예: `npx serve`)로 여세요. (`preview.html` 은 서버 없이 열리도록 따로 만들어 둔 파일입니다.)
- 글꼴은 위 Pretendard 링크가 있어야 설계한 모양 그대로 나옵니다. 링크가 없으면 부품은 글꼴이 깔린 컴퓨터에서만 그대로 보입니다.

### 다크 모드

`<html>` 에 `data-theme="dark"` 를 달면 부품 전체가 다크로 바뀝니다(끄려면 속성을 지웁니다). 페이지 바탕과 기본 글자색은 부품이 아니라 내 페이지의 몫이라 그냥 두면 흰색 그대로입니다 — `s1-ui.base.css` 를 읽거나, 직접 `background: var(--color-bg-level-0)` 를 칠하세요.

### 나중에 넣은 마크업에 동작 붙이기

`autoInit()` 은 부른 시점에 있는 마크업에만 동작을 붙입니다. 목록을 불러와 그린 화면처럼 나중에 넣은 조각은 그 조각을 감싼 요소를 넘겨 다시 부르세요 — 두 번 불러도 겹치지 않습니다.

```js
autoInit(document.getElementById("late-area"));
```

부품 하나만 직접 붙이려면(자동 연결 없이):

```js
import { toggle } from "./s1-ui/s1-ui.js";
const api = toggle.init(document.querySelector('[data-s1-component="toggle"]'));
```

### 모달·바텀시트 열고 닫기

처음에는 숨겨져 있습니다. **속성 한 줄로** 엽니다 — 열 버튼에 창의 id 를, 창 안에서 닫을 요소에 `data-s1-close` 를 답니다(값은 닫힌 이유: `cancel`·`confirm` 등).

```html
<button type="button" data-s1-open="my-modal">열기</button>
<div id="my-modal" data-s1-component="modal" data-break="pc" data-footer="dual" hidden> … <button type="button" data-s1-close="cancel">취소</button> … </div>
```

스크립트로 열려면 `import { modal } from "./s1-ui/s1-ui.js"; modal.init(요소).open()`, 닫으려면 `.close()` 입니다. 창 안에서 달력·시간·드롭다운이 열려 있을 때 Esc 는 그것만 닫고 창은 남깁니다. 자세한 것은 `components/modal.md` · `components/modal-content.md` · `components/bottom-sheet.md`.

### 값 넣기·읽기·폼 전송

셀렉트·달력·시간 선택은 `data-name="이름"` 을 주면 숨은 입력이 만들어져 `<form>` 으로 함께 전송됩니다. 셀렉트는 `data-value`(처음 값)·`api.value`·`api.setValue()`, 달력은 `data-value`(단일)·`data-range-start`/`data-range-end`(기간)·`api.value`·`api.setValue()`, 페이지네이션은 총 쪽수만 `api.setTotalPages(n)` 으로 주면 번호 줄을 다시 그립니다.

### 고르기는 부품이 알아서 (표시만 달면 됩니다)

칩·시트 목록·하단 탭은 고르는 동작을 스크립트로 짜지 않아도 됩니다. **표시가 없으면 종전과 똑같이 아무것도 바뀌지 않습니다.**

| 부품 | 표시 | 하는 일 | 이벤트(`element.addEventListener`) |
|---|---|---|---|
| chip | 칩을 감싼 요소에 `data-s1-select="single"` | 하나만 켜진다(켜진 칩을 다시 눌러도 꺼지지 않음). 표시가 없으면 칩마다 따로 켜고 끈다 | `s1:chip:beforechange` → `s1:chip:change` |
| bottom-sheet-option | 목록 묶음(시트 본문)에 `data-s1-select="single"`, 고른 뒤 닫으려면 `data-s1-close-on-select` | 줄을 누르면 고르고 나머지는 풀림 · ↑↓·Home·End 이동, Enter/Space 선택 · 시트를 연 요소(`data-s1-open`) 안 `[data-s1-part="value"]` 글자가 고른 라벨로 바뀜 | `s1:bottom-sheet-option:beforechange` → `s1:bottom-sheet-option:change` |
| mobile-bottom-nav | (표시 없이 기본 동작) | 탭을 누르면 활성 탭과 `aria-current` 가 옮겨감 · ←→ 로 탭 사이 초점 이동 | `s1:mobile-bottom-nav:beforechange` → `s1:mobile-bottom-nav:change` |

- **막고 싶을 때**: `beforechange` 에서 `event.preventDefault()` 하면 모양이 바뀌지 않습니다(로그인 확인·저장 안 한 변경 등). 막은 뒤 화면이 직접 정합니다 — 탭은 `mobileBottomNav.init(탭).setActive()`, 칩 묶음은 `chip.setGroupValue(묶음, 값)`, 시트 목록은 `bottomSheetOption.init(줄).setValue(값)`(모두 이벤트 없음).
- **React 껍데기로 탭을 여러 개 놓을 때**: 예시 마크업이 탭마다 켜진 모양이라 `selected`/`defaultSelected` 를 안 주면 처음엔 모두 켜진 모양으로 시작합니다(처음 모습은 그대로 둡니다). 첫 탭을 누르면 눌린 탭 하나만 남습니다. 처음부터 맞추려면 `defaultSelected`(또는 `selected`)를 주세요.
- **라우팅이 정하는 화면**: 활성 탭을 `aria-selected` 로 직접 정해도 그대로 읽힙니다.
- **React·Vue·React Native**: 제어형/비제어형을 모두 지원합니다. React·RN 은 `selected`(제어형) · `defaultSelected` · `onSelectedChange(selected)`(RN 은 `onBeforechange(event)` 에서 `event.preventDefault()` 로 막고, 칩 하나만 켜기는 `<S1ChipGroup value onChange>`), Vue 는 `v-model`(제어형) · `defaultSelected`. 값을 주면(제어형) 눌러도 부품이 스스로 바뀌지 않고, 값이 바뀔 때만 모양이 바뀝니다.

### 모바일

모바일용 마크업은 `*.mobile.html` 입니다(비밀번호·검색 입력도 `examples/input.password.mobile.html` · `examples/input.search.mobile.html` 처럼 같은 규칙입니다). 모바일에만 쓰는 부품은 PC 용 파일이 따로 없고 파일 이름에 `.mobile` 이 붙습니다: **mobile-bottom-nav · mobile-header · bottom-sheet**.

### 종류(모양)를 고르는 속성 — 부품마다 이름이 다릅니다

부품의 종류를 고르는 속성 이름은 정본의 어휘 그대로라 하나로 통일하지 않았습니다. 아래 표에서 부품의 속성과 값을 찾으세요(부품별 설명서 `components/<이름>.md` 에도 같은 표가 있습니다).

| 속성 | 쓰는 부품 |
|---|---|
| `data-mode` | input, date-picker |
| `data-variant` | button, chip, filter-chip, mobile-header, gnb, text-button, lnb |
| `data-type` | dropdown, time-picker, gnb-sub-menu, bottom-sheet-option, list-row |
| `data-footer` | modal, modal-content, bottom-sheet |
| `data-icon` | mobile-bottom-nav |
| `data-tone` | data-tag |
| `data-axis` | divider |

> 보조 축: divider 는 선 방향(`data-axis`) 말고도 `data-tone`·`data-weight`·`data-inset` 으로 선 색·굵기·들여쓰기를 고릅니다. 위 표의 `data-tone` 은 data-tag 의 색입니다.

| 부품 | 속성 | 값 | 모양·쓰임 |
|---|---|---|---|
| input | `data-mode` | `search` | 오른쪽에 지우기 + 돋보기 아이콘이 붙는 검색 입력칸 |
| input | `data-mode` | `password` | 오른쪽에 눈(표시 전환) + 지우기 아이콘이 붙는 비밀번호 입력칸 |
| button | `data-variant` | `primary` | 채운 배경에 흰 글자 — 화면에서 가장 중요한 행동 하나 |
| button | `data-variant` | `secondary` | 바탕이 옅고 테두리가 있는 보조 버튼 — 취소·이전 같은 덜 중요한 행동 |
| button | `data-variant` | `blue-line` | 흰 바탕에 파란 테두리·파란 글자 — 강조는 하되 가벼운 행동 |
| chip | `data-variant` | `line` | 흰 바탕에 테두리만 있는 칩 — 기본형, 선택하면 테두리가 파랗게 |
| chip | `data-variant` | `solid` | 배경을 채운 칩 |
| dropdown | `data-type` | `text` | 글자만 있는 목록 — 하나를 골라 표시 |
| dropdown | `data-type` | `checkbox` | 각 줄 왼쪽에 체크박스가 붙는 목록 — 여러 개를 고르고, 맨 위에 '전체 선택' 줄을 둘 수 있음 |
| filter-chip | `data-variant` | `line` | 테두리형 — 흰 바탕, 선택하면 테두리·글자가 파랗게 |
| filter-chip | `data-variant` | `solid` | 배경을 채운 형태 |
| modal | `data-footer` | `single` | 버튼 1개(확인) — 알림·설명 팝업 |
| modal | `data-footer` | `dual` | 버튼 2개(취소 + 확인) — 확인·질문 팝업 |
| mobile-bottom-nav | `data-icon` | `home` | 홈 탭 아이콘 |
| mobile-bottom-nav | `data-icon` | `search` | 검색 탭 아이콘 |
| mobile-bottom-nav | `data-icon` | `notification` | 알림 탭 아이콘 |
| mobile-bottom-nav | `data-icon` | `settings` | 설정 탭 아이콘 |
| mobile-header | `data-variant` | `home-title` | 홈 화면용 — 왼쪽 정렬 굵은 제목 |
| mobile-header | `data-variant` | `home-title-subtitle` | 홈 화면용 — 왼쪽 제목 + 부제 + 오른쪽 알림 아이콘 1개 |
| mobile-header | `data-variant` | `standard-title` | 일반 화면용 — 가운데 제목, 왼쪽 뒤로가기 |
| mobile-header | `data-variant` | `standard-title-close` | 일반 화면용 — 가운데 제목 + 오른쪽 닫기 |
| mobile-header | `data-variant` | `standard-no-title` | 제목 없이 뒤로가기만 있는 일반 화면용 |
| mobile-header | `data-variant` | `standard-no-title-close` | 제목 없이 뒤로가기 + 오른쪽 닫기 |
| time-picker | `data-type` | `24h` | 0~23시 24시간 표기 — 시·분 두 칸 |
| time-picker | `data-type` | `12h` | 오전/오후 + 1~12시 12시간 표기 — 칸이 하나 더 있어 목록이 더 넓음 |
| date-picker | `data-mode` | `single` | 날짜 하나를 고름 — 입력칸에 '26.10.15' 같은 표기 |
| date-picker | `data-mode` | `range` | 시작일~종료일 기간을 고름 — 입력칸에 '시작 ~ 끝' 표기 |
| gnb | `data-variant` | `center-between` | 로고·메뉴·유틸 아이콘 세 덩어리가 양 끝과 가운데로 벌어져 놓임 |
| gnb | `data-variant` | `start` | 로고와 메뉴가 왼쪽에 함께 붙고, 유틸 아이콘만 오른쪽 끝 |
| gnb-sub-menu | `data-type` | `regular` | 카테고리 제목 + 항목 목록이 있는 기본 판(컬럼 4개 기준) |
| gnb-sub-menu | `data-type` | `compact-1` | 제목 없이 항목 6개가 한 줄로 나열되는 판 |
| gnb-sub-menu | `data-type` | `compact-2` | 제목 없이 묶음마다 항목 2개씩 놓이는 판(컬럼 5개 기준) |
| text-button | `data-variant` | `primary` | 파란(강조) 글자만 있는 버튼 — 링크처럼 쓰는 주 행동 |
| text-button | `data-variant` | `secondary` | 옅은 회색 글자만 있는 버튼 — 덜 중요한 보조 행동 |
| modal-content | `data-footer` | `single` | 버튼 1개(확인) |
| modal-content | `data-footer` | `dual` | 버튼 2개(취소 + 확인) |
| bottom-sheet-option | `data-type` | `text` | 글자만 있는 한 줄 — 고른 줄 오른쪽에 파란 체크 |
| bottom-sheet-option | `data-type` | `checkbox` | 왼쪽에 체크박스 — 여러 개 고르기 |
| bottom-sheet-option | `data-type` | `radio` | 왼쪽에 동그라미 라디오 — 하나만 고르기 |
| bottom-sheet-option | `data-type` | `list` | 왼쪽 아바타 + 제목/서브 두 줄 + 오른쪽 화살표(비활성이면 자물쇠) — 사람·항목 목록 |
| bottom-sheet | `data-footer` | `none` | 하단 버튼 없음 — 고르는 즉시 적용되는 목록 |
| bottom-sheet | `data-footer` | `single` | '적용' 버튼 1개 |
| bottom-sheet | `data-footer` | `dual` | '취소 + 적용' 버튼 2개 |
| list-row | `data-type` | `nav` | 누르면 다른 화면으로 가는 줄 — 오른쪽 화살표 |
| list-row | `data-type` | `value` | 현재 값을 보여 주고 누르면 바꾸는 줄 — 오른쪽에 값 |
| list-row | `data-type` | `read` | 읽기만 하는 줄 — 정보 표시용 |
| list-row | `data-type` | `pick` | 왼쪽 체크박스로 고르는 줄 |
| list-row | `data-type` | `agree` | 약관 동의처럼 체크박스 + 설명이 붙는 줄 |
| list-row | `data-type` | `switch` | 오른쪽 토글 스위치가 있는 줄 |
| list-row | `data-type` | `thumb` | 왼쪽에 사진·아이콘 자리(40각)가 있는 줄 |
| data-tag | `data-tone` | `blue` | 파란 — 승인·확인 |
| data-tag | `data-tone` | `red` | 빨간 — 주의·에러 |
| data-tag | `data-tone` | `gray` | 회색 — 그 밖의 중립 상태(대기 등) |
| divider | `data-axis` | `x` | 가로선(폭 100%) |
| divider | `data-axis` | `y` | 세로선(높이는 놓인 자리가 정함, 14가 기본) |
| lnb | `data-variant` | `menu` | 메뉴만 있는 왼쪽 메뉴 |
| lnb | `data-variant` | `brand` | 맨 위에 로고 자리가 있고 아래에 구분선이 붙는 왼쪽 메뉴 |

### 부품 목록 (32종)

부품마다 마크업·고르는 속성·옵션·이벤트·여닫기를 적은 설명서가 있습니다. 쓰려는 부품의 `components/<이름>.md` 를 먼저 읽으세요. 쓸 수 있는 종류·크기 값도 거기 있습니다.

| 이름 | React·Vue 이름 | 마크업 예시 | 설명서 |
|---|---|---|---|
| input | S1Input | `examples/input.html` `examples/input.mobile.html` `examples/input.password.html` `examples/input.password.mobile.html` `examples/input.search.html` `examples/input.search.mobile.html` | `components/input.md` |
| button | S1Button | `examples/button.html` `examples/button.mobile.html` | `components/button.md` |
| checkbox | S1Checkbox | `examples/checkbox.html` | `components/checkbox.md` |
| radio | S1Radio | `examples/radio.html` | `components/radio.md` |
| toggle | S1Toggle | `examples/toggle.html` | `components/toggle.md` |
| chip | S1Chip | `examples/chip.html` `examples/chip.mobile.html` | `components/chip.md` |
| dropdown | S1Dropdown | `examples/dropdown.html` | `components/dropdown.md` |
| select | S1Select | `examples/select.html` `examples/select.mobile.html` | `components/select.md` |
| filter-chip | S1FilterChip | `examples/filter-chip.html` `examples/filter-chip.mobile.html` | `components/filter-chip.md` |
| tab | S1Tab | `examples/tab.html` `examples/tab.mobile.html` | `components/tab.md` |
| pagination | S1Pagination | `examples/pagination.html` | `components/pagination.md` |
| textarea | S1Textarea | `examples/textarea.html` `examples/textarea.mobile.html` | `components/textarea.md` |
| multi-toggle | S1MultiToggle | `examples/multi-toggle.html` | `components/multi-toggle.md` |
| modal | S1Modal | `examples/modal.html` `examples/modal.mobile.html` | `components/modal.md` |
| table | S1Table | `examples/table.html` | `components/table.md` |
| mobile-bottom-nav | S1MobileBottomNav | `examples/mobile-bottom-nav.mobile.html` | `components/mobile-bottom-nav.md` |
| mobile-header | S1MobileHeader | `examples/mobile-header.mobile.html` | `components/mobile-header.md` |
| time-picker | S1TimePicker | `examples/time-picker.html` `examples/time-picker.mobile.html` | `components/time-picker.md` |
| date-picker | S1DatePicker | `examples/date-picker.html` `examples/date-picker.mobile.html` | `components/date-picker.md` |
| gnb | S1Gnb | `examples/gnb.html` | `components/gnb.md` |
| gnb-sub-menu-item | S1GnbSubMenuItem | `examples/gnb-sub-menu-item.html` | `components/gnb-sub-menu-item.md` |
| gnb-sub-menu | S1GnbSubMenu | `examples/gnb-sub-menu.html` | `components/gnb-sub-menu.md` |
| assist-button | S1AssistButton | `examples/assist-button.html` | `components/assist-button.md` |
| text-button | S1TextButton | `examples/text-button.html` | `components/text-button.md` |
| modal-content | S1ModalContent | `examples/modal-content.html` | `components/modal-content.md` |
| bottom-sheet-option | S1BottomSheetOption | `examples/bottom-sheet-option.html` | `components/bottom-sheet-option.md` |
| bottom-sheet | S1BottomSheet | `examples/bottom-sheet.mobile.html` | `components/bottom-sheet.md` |
| list-row | S1ListRow | `examples/list-row.html` | `components/list-row.md` |
| expandable-card | S1ExpandableCard | `examples/expandable-card.html` | `components/expandable-card.md` |
| data-tag | S1DataTag | `examples/data-tag.html` | `components/data-tag.md` |
| divider | S1Divider | `examples/divider.html` | `components/divider.md` |
| lnb | S1Lnb | `examples/lnb.html` | `components/lnb.md` |

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.

```bash
node s1-ui/tools/s1-ui-lint.mjs --version          # 지문 확인
node s1-ui/tools/s1-ui-lint.mjs <내 소스 폴더>      # 규칙 검사
```
