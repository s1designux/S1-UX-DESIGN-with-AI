# S1 UI 라이브러리 — Swift (iOS) 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **Swift (iOS) 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.18.0**
- 정본 지문: `a3a23a25de11dac6a6470f9a9e4bb9b6c84999d37590f09083adce159d20ee18`
- 승인 컴포넌트: **28종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet, expandable-card, data-tag, divider, lnb)
- 토큰: **499개**

## 이 묶음에 들어있는 것

SwiftUI 부품 23종(button · input · checkbox · radio · toggle · chip · dropdown · select · tab · modal · mobile-header · mobile-bottom-nav · textarea · text-button · assist-button · filter-chip · bottom-sheet-option · bottom-sheet · date-picker · time-picker · expandable-card · divider · data-tag) · 이름 붙은 텍스트 스타일 21종(S1Type) · 아이콘 21개(S1Icons) · 색 499개(라이트·다크) · 크기·간격·반경 값 · Swift Package 선언(Package.swift) · 부품을 한 화면에 늘어놓은 미리보기(preview/S1Gallery.swift) · 컴포넌트 동작 명세(behavior.json).

## 시작하기

1. `platform/swift` 폴더가 곧 Swift Package(`S1DesignSystem`)입니다 — Xcode 에서 Add Package Dependencies ▸ Add Local 로 고르거나 폴더째 프로젝트에 넣습니다(iOS 16+).
2. 부품은 이름으로 부릅니다 — `S1Button` 처럼 `S1` 로 시작합니다. 쓸 수 있는 조합은 `S1*Spec.swift` 에 있습니다. 모바일 한 벌만 들어 있습니다(iPad 도 같습니다).
3. 글자는 이름 붙은 스타일(`S1Type`)로 부릅니다 — 크기·굵기를 따로 적지 마세요. 서체 Pretendard 는 앱이 등록하고 이름만 `S1Theme(fontFamily:)` 에 넘깁니다.
4. 색·크기는 `S1Palette`·`S1Tokens` 상수를 부릅니다 — 값을 눈으로 보고 옮겨 적지 마세요.
5. 부품에 없는 화면을 직접 그릴 때만 상태 변화를 `platform/behavior.json` 으로 맞춥니다.

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
