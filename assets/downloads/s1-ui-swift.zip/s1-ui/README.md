# S1 UI 라이브러리 — Swift (iOS) 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **Swift (iOS) 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.8.6**
- 정본 지문: `2634c38fea9d96a128922aca3a5a758a12c6c61d9af1ffa630523862cb417fea`
- 승인 컴포넌트: **24종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet)
- 토큰: **489개**

## 이 묶음에 들어있는 것

색 489개(라이트·다크) · 크기·간격·반경 값 · 컴포넌트 동작 명세(behavior.json). 화면 부품은 들어있지 않습니다 — 직접 그려야 합니다.

## 시작하기

1. `platform/swift/S1Tokens.swift` 를 프로젝트에 넣습니다.
2. 색은 `0xAARRGGBB` 정수입니다.
3. 상태 변화는 `platform/behavior.json` 을 그대로 따릅니다.
4. **화면 부품은 들어있지 않습니다 — 직접 그려야 합니다.**

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
