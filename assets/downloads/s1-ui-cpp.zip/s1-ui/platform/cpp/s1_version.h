// 자동 생성물 — 손으로 고치지 마세요. 정본을 고치고 `npm run tokens:reconcile` 또는 `npm run ui:build` 를 실행하세요.

// 이 파일 묶음이 나온 배포본 번호. 디자인가이드가 공개한 번호와 다르면 낡은 것이다.
#ifndef S1_VERSION_H
#define S1_VERSION_H

#define S1_UI_VERSION "0.8.6"
#define S1_UI_RELEASED_AT "2026-09-21"
#define S1_UI_CANONICAL_FINGERPRINT "2634c38fea9d96a128922aca3a5a758a12c6c61d9af1ffa630523862cb417fea"

#endif // S1_VERSION_H
