# S1 UI 라이브러리 — C++ 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **C++ 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.8.0**
- 정본 지문: `f8f738913d5f57d2603d93603202c02b126b8d6932aed4c2e229c538a5feaf34`
- 승인 컴포넌트: **24종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet)
- 토큰: **489개**

## 이 묶음에 들어있는 것

색 489개(라이트·다크) · 크기·간격·반경 값 · 같은 값의 JSON 사본(tokens.json). 화면 부품은 들어있지 않습니다 — 직접 그려야 합니다.

## 시작하기

1. `platform/cpp/s1_tokens.h` 를 프로젝트에 넣고 `#include` 합니다.
2. 색은 `0xAARRGGBB` 정수입니다.
3. 값을 다른 형태로 쓰려면 `platform/tokens.json` 을 읽어 씁니다.
4. **화면 부품은 들어있지 않습니다 — 직접 그려야 합니다.**

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
