package com.s1.designsystem

/* 자동 생성물 — 손으로 고치지 마세요. 정본을 고치고 `npm run tokens:reconcile` 또는 `npm run ui:build` 를 실행하세요. */

/** 이 파일 묶음이 나온 배포본 번호. 디자인가이드가 공개한 번호와 다르면 낡은 것이다. */
public object S1Version {
    public const val VERSION: String = "0.17.1"
    public const val RELEASED_AT: String = "2026-10-02"
    public const val CANONICAL_FINGERPRINT: String = "c706873aa79e37877a3f693a2d8cbd466a62a9eface7e4a1911a8506bdd3ab03"
}
