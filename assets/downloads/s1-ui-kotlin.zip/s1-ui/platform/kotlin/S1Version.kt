package com.s1.designsystem

/* 자동 생성물 — 손으로 고치지 마세요. 정본을 고치고 `npm run tokens:reconcile` 또는 `npm run ui:build` 를 실행하세요. */

/** 이 파일 묶음이 나온 배포본 번호. 디자인가이드가 공개한 번호와 다르면 낡은 것이다. */
public object S1Version {
    public const val VERSION: String = "0.14.6"
    public const val RELEASED_AT: String = "2026-09-30"
    public const val CANONICAL_FINGERPRINT: String = "02a63fe2444545e7f2ff7a247389bb09bcf2278cb56b1447f439870b98e0cd54"
}
