# S1 UI 라이브러리 — Kotlin (Android) 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **Kotlin (Android) 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.1.0**
- 정본 지문: `77dd585a59eb492cc1952a786e5b033becea126e531d9d1092b6f7bbd5d3efae`
- 승인 컴포넌트: **22종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content)
- 토큰: **481개**

## 시작하기

1. `platform/kotlin/S1Tokens.kt` 를 프로젝트 소스에 넣습니다(패키지 `com.s1.designsystem`).
2. 색·크기는 이 상수를 부릅니다 — 값을 눈으로 보고 옮겨 적지 마세요.
3. 상태 변화(눌림·꺼짐 등)는 `platform/behavior.json` 을 그대로 따릅니다.
4. **화면 부품은 들어있지 않습니다 — 직접 그려야 합니다.**

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
