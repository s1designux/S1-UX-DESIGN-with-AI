# S1 UI 라이브러리 — Kotlin (Android) 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **Kotlin (Android) 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.5.0**
- 정본 지문: `5a96654ece28dec43ed8454b0fe138008e64cf190c2909b2c71a355114d4bb26`
- 승인 컴포넌트: **22종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content)
- 토큰: **488개**

## 이 묶음에 들어있는 것

Jetpack Compose 부품 16종(button · input · checkbox · radio · toggle · chip · dropdown · select · tab · modal · mobile-header · mobile-bottom-nav · textarea · text-button · assist-button · filter-chip) · 이름 붙은 텍스트 스타일 20종(S1Type) · 아이콘 16개(S1Icons) · 색 488개(라이트·다크) · 크기·간격·반경 값 · 바로 돌려 보는 예제 앱(platform/kotlin-sample) · 부품을 한 화면에 늘어놓은 미리보기(preview/S1Gallery.kt) · 컴포넌트 동작 명세(behavior.json).

## 시작하기

1. `platform/kotlin` 폴더를 프로젝트 소스에 통째로 넣습니다(패키지 `com.s1.designsystem`).
2. 부품은 이름으로 부릅니다 — `S1Button` 처럼 `S1` 로 시작합니다. 쓸 수 있는 조합은 `S1*Spec.kt` 에 있습니다.
3. 글자는 이름 붙은 스타일(`S1Type`)로 부릅니다 — 크기·굵기를 따로 적지 마세요.
4. 색·크기는 `S1Palette`·`S1Tokens` 상수를 부릅니다 — 값을 눈으로 보고 옮겨 적지 마세요.
5. 부품에 없는 화면을 직접 그릴 때만 상태 변화를 `platform/behavior.json` 으로 맞춥니다.

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
