"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };

  // plugins/figma-vars-installer/src/vars-data.ts
  var FOUNDATION_COLLECTION = "Foundation V2";
  var SEMANTIC_COLOR_COLLECTION = "Semantic Color V2";
  var SEMANTIC_NUMBER_COLLECTION = "Semantic Number V2";
  var LIGHT_MODE = "Light";
  var DARK_MODE = "Dark";
  var FOUNDATION_COLOR = {
    // ── Base ──────────────────────────────────────────
    "base/white": "#FFFFFF",
    "base/black": "#000000",
    // ── Brand ─────────────────────────────────────────
    "brand/blue": "#0072CE",
    "brand/red": "#FF312C",
    "brand/gray": "#DFDEDE",
    "brand/ci": "#004097",
    // ── Gray (Light scale) ────────────────────────────
    "gray/0": "#FAFAFA",
    "gray/50": "#F5F5F5",
    "gray/100": "#E9E9E9",
    "gray/200": "#D9D9D9",
    "gray/300": "#C4C4C4",
    "gray/400": "#9D9D9D",
    "gray/500": "#757575",
    "gray/600": "#555555",
    "gray/700": "#434343",
    "gray/800": "#353535",
    "gray/900": "#202020",
    // ── Gray Dark (Dark scale) ────────────────────────
    "gray-dark/0": "#0D0E12",
    "gray-dark/50": "#131418",
    "gray-dark/100": "#1C1D23",
    "gray-dark/200": "#24252C",
    "gray-dark/300": "#2E2F38",
    "gray-dark/400": "#35363F",
    "gray-dark/500": "#3E4049",
    "gray-dark/600": "#55575F",
    "gray-dark/700": "#8A8C96",
    "gray-dark/800": "#B8BABF",
    "gray-dark/900": "#ECEDF0",
    // ── Blue ──────────────────────────────────────────
    "blue/50": "#E2F1FF",
    "blue/100": "#C8E4FF",
    "blue/150": "#A4D4FF",
    "blue/200": "#8BC6FF",
    "blue/250": "#5BB2FF",
    "blue/300": "#2B9EFF",
    "blue/350": "#268CF8",
    "blue/400": "#1D6CEB",
    "blue/450": "#2158C8",
    "blue/500": "#2747B9",
    "blue-dark/50": "#0C1D38",
    "blue-dark/100": "#112B55",
    "blue-dark/150": "#1A3D72",
    "blue-dark/200": "#214EA0",
    "blue-dark/250": "#2A65C8",
    "blue-dark/300": "#3070D8",
    "blue-dark/350": "#4285E8",
    "blue-dark/400": "#6FA5F8",
    "blue-dark/450": "#96BEF9",
    "blue-dark/500": "#C0D8FC",
    // ── Red ───────────────────────────────────────────
    "red/50": "#FFEBEF",
    "red/100": "#FFCCD6",
    "red/150": "#FBB2BA",
    "red/200": "#F8979E",
    "red/250": "#FC6E79",
    "red/300": "#FF4554",
    "red/350": "#F22544",
    "red/400": "#E50533",
    "red/450": "#D60228",
    "red/500": "#C8001E",
    "red-dark/50": "#2A0F14",
    "red-dark/100": "#3D1520",
    "red-dark/150": "#5C1E2E",
    "red-dark/200": "#8A2A3E",
    "red-dark/250": "#C03850",
    "red-dark/300": "#E04860",
    "red-dark/350": "#F06070",
    "red-dark/400": "#F48890",
    "red-dark/450": "#F8A8B0",
    "red-dark/500": "#FCD0D5",
    // ── Orange ────────────────────────────────────────
    "orange/50": "#FFEDE0",
    "orange/100": "#FDDBBF",
    "orange/150": "#FEC6A0",
    "orange/200": "#FFB482",
    "orange/250": "#FF954E",
    "orange/300": "#FF761A",
    "orange/350": "#EE680D",
    "orange/400": "#DA4C00",
    "orange/450": "#B63C00",
    "orange/500": "#8E2E00",
    "orange-dark/50": "#2E1505",
    "orange-dark/100": "#42200A",
    "orange-dark/150": "#6B3512",
    "orange-dark/200": "#A05020",
    "orange-dark/250": "#D06828",
    "orange-dark/300": "#E88038",
    "orange-dark/350": "#F09548",
    "orange-dark/400": "#F5AA68",
    "orange-dark/450": "#F8C090",
    "orange-dark/500": "#FCD8B8",
    // ── Yellow ────────────────────────────────────────
    "yellow/50": "#FFF4CE",
    "yellow/100": "#FEE89A",
    "yellow/150": "#FEDE6C",
    "yellow/200": "#FFD53D",
    "yellow/250": "#FFCC1E",
    "yellow/300": "#FFC200",
    "yellow/350": "#F5B900",
    "yellow/400": "#DBA400",
    "yellow/450": "#BA8900",
    "yellow/500": "#8F6A00",
    "yellow-dark/50": "#2A2005",
    "yellow-dark/100": "#3D2E08",
    "yellow-dark/150": "#605010",
    "yellow-dark/200": "#907818",
    "yellow-dark/250": "#C09828",
    "yellow-dark/300": "#D8B038",
    "yellow-dark/350": "#E8C048",
    "yellow-dark/400": "#F0D068",
    "yellow-dark/450": "#F5DE90",
    "yellow-dark/500": "#FAEAB8",
    // ── Green ─────────────────────────────────────────
    "green/50": "#E3F2EA",
    "green/100": "#CAECDA",
    "green/150": "#9CD8BD",
    "green/200": "#6FC4A2",
    "green/250": "#47BB8E",
    "green/300": "#1FB279",
    "green/350": "#10A86C",
    "green/400": "#009E5E",
    "green/450": "#008650",
    "green/500": "#006F42",
    "green-dark/50": "#0A2018",
    "green-dark/100": "#102E22",
    "green-dark/150": "#184530",
    "green-dark/200": "#206840",
    "green-dark/250": "#288A55",
    "green-dark/300": "#30A868",
    "green-dark/350": "#3FBE7E",
    "green-dark/400": "#68D098",
    "green-dark/450": "#98E0B8",
    "green-dark/500": "#C5F0D8",
    // ── Skyblue ───────────────────────────────────────
    "skyblue/50": "#C4EEF7",
    "skyblue/100": "#A5E5F3",
    "skyblue/150": "#7BD6EA",
    "skyblue/200": "#51C7E1",
    "skyblue/250": "#3BC0DD",
    "skyblue/300": "#25B9DA",
    "skyblue/350": "#1DAACB",
    "skyblue/400": "#159BBC",
    "skyblue/450": "#1284A0",
    "skyblue/500": "#0F6C84",
    "skyblue-dark/50": "#081E28",
    "skyblue-dark/100": "#102A38",
    "skyblue-dark/150": "#184050",
    "skyblue-dark/200": "#205A70",
    "skyblue-dark/250": "#287890",
    "skyblue-dark/300": "#3090A8",
    "skyblue-dark/350": "#40A8C0",
    "skyblue-dark/400": "#68C0D8",
    "skyblue-dark/450": "#98D8E8",
    "skyblue-dark/500": "#C0E8F0",
    // ── Purple ────────────────────────────────────────
    "purple/50": "#E8E9FC",
    "purple/100": "#CFD1F9",
    "purple/150": "#C0C0FC",
    "purple/200": "#B0B0FF",
    "purple/250": "#8B8BEE",
    "purple/300": "#6666DD",
    "purple/350": "#4E4EC3",
    "purple/400": "#3535A8",
    "purple/450": "#2D2D8F",
    "purple/500": "#252576",
    "purple-dark/50": "#14142A",
    "purple-dark/100": "#1E1E3D",
    "purple-dark/150": "#2A2A58",
    "purple-dark/200": "#383878",
    "purple-dark/250": "#4848A0",
    "purple-dark/300": "#5858B8",
    "purple-dark/350": "#7070D0",
    "purple-dark/400": "#9090E0",
    "purple-dark/450": "#B0B0EA",
    "purple-dark/500": "#D0D0F5",
    // ── Brown ─────────────────────────────────────────
    "brown/50": "#F6EEE9",
    "brown/100": "#E4D5C8",
    "brown/150": "#DBC6B3",
    "brown/200": "#D1B69F",
    "brown/250": "#A68C75",
    "brown/300": "#7C614A",
    "brown/350": "#685240",
    "brown/400": "#554435",
    "brown/450": "#483A2D",
    "brown/500": "#3B3025",
    "brown-dark/50": "#1E1610",
    "brown-dark/100": "#2A2018",
    "brown-dark/150": "#3D3025",
    "brown-dark/200": "#584535",
    "brown-dark/250": "#786050",
    "brown-dark/300": "#907868",
    "brown-dark/350": "#A89080",
    "brown-dark/400": "#C0A898",
    "brown-dark/450": "#D8C0B0",
    "brown-dark/500": "#E8D8C8",
    // ── Visual Gray (Light 전용 스케일) ───────────────
    "visual-gray/50": "#F3F5F7",
    "visual-gray/100": "#E8EBEF",
    "visual-gray/150": "#DADEE5",
    "visual-gray/200": "#CDD2DE",
    "visual-gray/250": "#ABB2BF",
    "visual-gray/300": "#808796",
    "visual-gray/350": "#646A74",
    "visual-gray/400": "#3E4347",
    "visual-gray/450": "#2B2F32",
    "visual-gray/500": "#1B1D1F",
    // ── Cool Gray Dark (Dark 전용 스케일) ─────────────
    "visual-gray-dark/50": "#12141A",
    "visual-gray-dark/100": "#1A1D25",
    "visual-gray-dark/150": "#252830",
    "visual-gray-dark/200": "#353840",
    "visual-gray-dark/250": "#484C58",
    "visual-gray-dark/300": "#606470",
    "visual-gray-dark/350": "#787C88",
    "visual-gray-dark/400": "#989CA8",
    "visual-gray-dark/450": "#B8BCC5",
    "visual-gray-dark/500": "#D8DBE0"
  };
  var FOUNDATION_NUMBER = {
    // ── Spacing ─────────────────────────────
    "spacing/2": 2,
    "spacing/4": 4,
    "spacing/6": 6,
    "spacing/8": 8,
    "spacing/10": 10,
    "spacing/12": 12,
    "spacing/14": 14,
    "spacing/16": 16,
    "spacing/20": 20,
    "spacing/24": 24,
    "spacing/28": 28,
    "spacing/32": 32,
    "spacing/36": 36,
    "spacing/40": 40,
    "spacing/44": 44,
    "spacing/48": 48,
    "spacing/56": 56,
    "spacing/64": 64,
    "spacing/80": 80,
    "spacing/96": 96,
    "spacing/128": 128,
    // ── Radius ──────────────────────────────
    "radius/0": 0,
    "radius/2": 2,
    "radius/4": 4,
    "radius/6": 6,
    "radius/8": 8,
    "radius/10": 10,
    "radius/12": 12,
    "radius/16": 16,
    "radius/20": 20,
    "radius/full": 9999,
    // ── Border Width ───────────────────────
    "border-width/1": 1,
    "border-width/2": 2,
    // ── Font Size ──────────────────────────
    "font-size/10": 10,
    "font-size/12": 12,
    "font-size/14": 14,
    "font-size/16": 16,
    "font-size/18": 18,
    "font-size/20": 20,
    "font-size/24": 24,
    "font-size/32": 32,
    // ── Font Weight ────────────────────────
    "font-weight/regular": 400,
    "font-weight/medium": 500,
    "font-weight/bold": 700,
    // ── Line Height (배수) ─────────────────
    "line-height/130": 1.3
  };
  var SEMANTIC_COLOR = {
    // ── button ────────────────────────────────
    "color/button/bg/assist--default": { light: "base/white", dark: "base/white" },
    "color/button/bg/assist--hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/button/bg/blue-line--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/blue-line--hover": { light: "blue/50", dark: "gray-dark/200" },
    "color/button/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/button/bg/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/bg/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/bg/secondary--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/secondary--hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/button/border/assist--default": { light: "gray/200", dark: "gray-dark/300" },
    "color/button/border/assist--hover": { light: "gray/200", dark: "gray-dark/300" },
    "color/button/border/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/blue-line--hover": { light: "blue/500", dark: "blue-dark/300" },
    "color/button/border/disabled": { light: "gray/200", dark: "gray-dark/300" },
    "color/button/border/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/border/secondary--default": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/border/secondary--hover": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/label/assist--default": { light: "gray/800", dark: "gray-dark/800" },
    "color/button/label/assist--hover": { light: "gray/800", dark: "gray-dark/800" },
    "color/button/label/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/label/blue-line--hover": { light: "blue/500", dark: "blue-dark/300" },
    "color/button/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/button/label/primary--default": { light: "base/white", dark: "base/white" },
    "color/button/label/primary--hover": { light: "base/white", dark: "base/white" },
    "color/button/label/secondary--default": { light: "gray/800", dark: "gray-dark/800" },
    "color/button/label/secondary--hover": { light: "gray/800", dark: "gray-dark/800" },
    // ── chip ────────────────────────────────
    "color/chip/line/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/line/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/chip/line/bg/selected": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/border/default": { light: "gray/300", dark: "gray-dark/500" },
    "color/chip/line/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/chip/line/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/line/label/default": { light: "gray/500", dark: "gray-dark/700" },
    "color/chip/line/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/line/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/chip/solid/bg/default": { light: "gray/50", dark: "gray-dark/300" },
    "color/chip/solid/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/bg/hover": { light: "gray/100", dark: "gray-dark/400" },
    "color/chip/solid/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/border/default": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/label/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/chip/solid/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/solid/label/selected": { light: "base/white", dark: "base/white" },
    // ── control ────────────────────────────────
    "color/control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/control/bg/default-alt": { light: "gray/50", dark: "gray-dark/600" },
    "color/control/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/control/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/bg/selected-alt": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/control/border/default-alt": { light: "gray/100", dark: "gray-dark/300" },
    "color/control/border/disabled": { light: "gray/300", dark: "gray-dark/300" },
    "color/control/border/disabled-alt1": { light: "gray/200", dark: "gray-dark/300" },
    "color/control/border/disabled-alt2": { light: "gray/100", dark: "gray-dark/300" },
    "color/control/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/control/indicator/selected": { light: "base/white", dark: "base/white" },
    "color/control/indicator/selected-alt": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/unselected": { light: "gray/300", dark: "gray-dark/400" },
    "color/control/indicator/unselected-alt": { light: "gray/200", dark: "gray-dark/300" },
    "color/control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/control/text/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/control/text/selected": { light: "base/white", dark: "base/white" },
    "color/control/text/unselected": { light: "gray/800", dark: "gray-dark/800" },
    // ── data ────────────────────────────────
    "color/data/border/light": { light: "gray/100", dark: "gray-dark/300" },
    "color/data/border/strong": { light: "gray/300", dark: "gray-dark/400" },
    "color/data/header/bg": { light: "gray/50", dark: "gray-dark/200" },
    "color/data/state/default": { light: "base/white", dark: "gray-dark/100" },
    "color/data/state/hover": { light: "blue/50", dark: "gray-dark/200" },
    "color/data/state/selected": { light: "blue/100", dark: "blue-dark/100" },
    // ── dropdown ────────────────────────────────
    "color/dropdown/list/bg": { light: "base/white", dark: "gray-dark/100" },
    "color/dropdown/list/border": { light: "gray/200", dark: "gray-dark/500" },
    "color/dropdown/option/bg/default": { light: "base/white", dark: "gray-dark/400" },
    "color/dropdown/option/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/dropdown/option/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/dropdown/option/bg/selected": { light: "blue/50", dark: "blue-dark/100" },
    "color/dropdown/option/border/default": { light: "gray/100", dark: "gray-dark/300" },
    "color/dropdown/option/border/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/dropdown/option/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/dropdown/option/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/dropdown/option/label/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/dropdown/option/label/hover": { light: "gray/900", dark: "gray-dark/900" },
    "color/dropdown/option/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    // ── form-control ────────────────────────────────
    "color/form-control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/form-control/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/form-control/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/form-control/bg/selected": { light: "base/white", dark: "gray-dark/200" },
    "color/form-control/border/correct": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/form-control/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/form-control/border/error": { light: "red/400", dark: "red-dark/350" },
    "color/form-control/border/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/text/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/placeholder": { light: "gray/500", dark: "gray-dark/600" },
    "color/form-control/text/selected": { light: "gray/900", dark: "gray-dark/800" },
    // ── icon ────────────────────────────────
    "color/icon/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/icon/gray": { light: "gray/500", dark: "gray-dark/700" },
    "color/icon/gray-dark": { light: "gray/800", dark: "gray-dark/800" },
    "color/icon/gray-light": { light: "gray/300", dark: "gray-dark/400" },
    "color/icon/red": { light: "red/300", dark: "red-dark/350" },
    "color/icon/white": { light: "base/white", dark: "base/white" },
    // ── line ────────────────────────────────
    "color/line/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/line/gray/default": { light: "gray/200", dark: "gray-dark/300" },
    "color/line/gray/strong": { light: "gray/300", dark: "gray-dark/400" },
    "color/line/gray/subtle": { light: "gray/100", dark: "gray-dark/300" },
    "color/line/white": { light: "base/white", dark: "base/white" },
    // ── navigation ────────────────────────────────
    "color/navigation/background": { light: "base/white", dark: "gray-dark/100" },
    "color/navigation/indicator/default": { light: "gray/200", dark: "gray-dark/300" },
    "color/navigation/indicator/default-alt": { light: "gray/100", dark: "gray-dark/200" },
    "color/navigation/indicator/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/indicator/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/default": { light: "gray/600", dark: "gray-dark/600" },
    "color/navigation/label/default-alt": { light: "gray/700", dark: "gray-dark/700" },
    "color/navigation/label/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/selected": { light: "blue/400", dark: "blue-dark/300" },
    // ── overlay ────────────────────────────────
    "color/overlay": { light: "rgba(0,0,0,0.5)", dark: "rgba(0,0,0,0.75)" },
    // ── date-picker ────────────────────────────────
    // 신설: components.html 의 .s1-date-picker__* CSS 토큰 사용 기반
    // 레거시 semantic 컬렉션에 없던 그룹 — 우리 코드의 datepicker 디자인 정합
    "color/date-picker/bg/panel": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/date-picker/bg/today": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/border/panel": { light: "gray/300", dark: "gray-dark/500" },
    "color/date-picker/border/today": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/date-picker/text/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/date-picker/text/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/date-picker/text/other-month": { light: "gray/300", dark: "gray-dark/400" },
    "color/date-picker/text/sunday": { light: "red/400", dark: "red-dark/350" },
    "color/date-picker/text/saturday": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/today": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/selected": { light: "base/white", dark: "base/white" },
    // ── pagination ────────────────────────────────
    "color/pagination/control/bg/default": { light: "base/white", dark: "base/white" },
    "color/pagination/control/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/pagination/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/pagination/control/border/default": { light: "gray/100", dark: "gray-dark/300" },
    "color/pagination/control/border/disabled": { light: "gray/100", dark: "gray-dark/300" },
    "color/pagination/control/border/hover": { light: "gray/200", dark: "gray-dark/300" },
    // ── status-card ────────────────────────────────
    "color/status-card/text/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/status-card/text/error": { light: "red/400", dark: "red-dark/350" },
    "color/status-card/text/primary--default": { light: "gray/900", dark: "gray-dark/900" },
    "color/status-card/text/primary--sub": { light: "gray/800", dark: "gray-dark/800" },
    "color/status-card/text/secondary--default": { light: "gray/600", dark: "gray-dark/700" },
    "color/status-card/text/secondary--sub": { light: "gray/500", dark: "gray-dark/700" },
    "color/status-card/text/tertiary--default": { light: "gray/400", dark: "gray-dark/600" },
    "color/status-card/text/tertiary--sub": { light: "gray/300", dark: "gray-dark/400" },
    // ── text ────────────────────────────────
    "color/text/body/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/text/body/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/text/body/tertiary": { light: "gray/500", dark: "gray-dark/700" },
    "color/text/state/accent": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/accent-alt": { light: "base/white", dark: "base/white" },
    "color/text/state/caption": { light: "gray/500", dark: "gray-dark/800" },
    "color/text/state/caution": { light: "red/300", dark: "red-dark/350" },
    "color/text/state/correct": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/text/state/helper": { light: "gray/400", dark: "gray-dark/600" },
    "color/text/state/placeholder": { light: "gray/500", dark: "gray-dark/700" },
    "color/text/title/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/text/title/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/text/title/tertiary": { light: "gray/600", dark: "gray-dark/700" },
    "color/form-control/icon/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/form-control/icon/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/scroll/bg": { light: "gray/200", dark: "gray-dark/600" },
    "color/form-control/text-caret": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/text/read-only": { light: "gray/500", dark: "gray-dark/700" }
  };
  var SEMANTIC_NUMBER = {
    // ── spacing/padding-block ─────────────
    "spacing/padding-block/xxs": "spacing/8",
    "spacing/padding-block/xs": "spacing/12",
    "spacing/padding-block/sm": "spacing/16",
    "spacing/padding-block/md": "spacing/20",
    "spacing/padding-block/lg": "spacing/24",
    // ── spacing/padding-inline ────────────
    "spacing/padding-inline/xxs": "spacing/8",
    "spacing/padding-inline/xs": "spacing/12",
    "spacing/padding-inline/sm": "spacing/16",
    "spacing/padding-inline/md": "spacing/20",
    "spacing/padding-inline/lg": "spacing/24",
    // ── spacing/section ───────────────────
    "spacing/section/xs": "spacing/16",
    "spacing/section/sm": "spacing/20",
    "spacing/section/md": "spacing/24",
    "spacing/section/lg": "spacing/32",
    "spacing/section/xl": "spacing/40",
    "spacing/section/xxl": "spacing/48",
    // ── spacing/stack ─────────────────────
    "spacing/stack/xs": "spacing/12",
    "spacing/stack/sm": "spacing/16",
    "spacing/stack/md": "spacing/20",
    "spacing/stack/lg": "spacing/24",
    // ── spacing/cluster ───────────────────
    "spacing/cluster/xxs": "spacing/8",
    "spacing/cluster/xs": "spacing/12",
    "spacing/cluster/sm": "spacing/16",
    "spacing/cluster/md": "spacing/20",
    // ── spacing/label-gap ─────────────────
    "spacing/label-gap-inline/sm": "spacing/8",
    "spacing/label-gap-inline/md": "spacing/12",
    "spacing/label-gap-inline/lg": "spacing/16",
    "spacing/label-gap-block/sm": "spacing/4",
    "spacing/label-gap-block/md": "spacing/8",
    // ── sizing/form-control-height ────────
    "sizing/form-control-height/xxs": "spacing/28",
    "sizing/form-control-height/xs": 34,
    // Foundation step 없음
    "sizing/form-control-height/md": "spacing/44",
    "sizing/form-control-height/lg": "spacing/48",
    "sizing/form-control-dataview-height/sm": "spacing/28",
    "sizing/form-control-dataview-height/md": 32,
    // Foundation step 없음
    // ── sizing/button-height ──────────────
    "sizing/button-height/xxs": "spacing/28",
    "sizing/button-height/xs": 34,
    // Foundation step 없음
    "sizing/button-height/sm": "spacing/40",
    "sizing/button-height/md": "spacing/44",
    "sizing/button-height/lg": "spacing/48",
    "sizing/button-min-width": 80,
    // Foundation step 없음
    // ── sizing/chip-height ────────────────
    "sizing/chip-height/sm": "spacing/28",
    "sizing/chip-height/md": 30,
    // Foundation step 없음
    "sizing/chip-height/lg": 34,
    // Foundation step 없음
    // ── sizing/table-row-height ───────────
    "sizing/table-row-height/xs": 34,
    // Foundation step 없음
    "sizing/table-row-height/sm": 38,
    // Foundation step 없음
    "sizing/table-row-height/md": "spacing/44",
    // ── sizing/dropdown-item-height ───────
    "sizing/dropdown-item-height/md": "spacing/44",
    // 44 — Select 옵션
    "sizing/dropdown-item-height/xs": 34,
    // 34 — 컴팩트 (TimePicker)
    // ── sizing/icon ───────────────────────
    "sizing/icon/10": 10,
    // Foundation step 없음
    "sizing/icon/16": "spacing/16",
    "sizing/icon/18": 18,
    // Foundation step 없음
    "sizing/icon/20": "spacing/20",
    "sizing/icon/24": "spacing/24",
    "sizing/icon/28": "spacing/28",
    "sizing/icon/32": "spacing/32",
    // ── radius semantic ───────────────────
    "radius/control/xs": "radius/2",
    "radius/control/sm": "radius/4",
    "radius/button/md": "radius/4",
    "radius/card/md": "radius/10",
    "radius/modal/md": "radius/8"
  };

  // plugins/figma-vars-installer/src/textstyles-data.ts
  var TEXT_STYLE_FONT_FAMILY = "Pretendard";
  var TEXT_STYLES = [
    // ── 최상위 (그룹 없음) ──────────────────────────────
    { name: "caption", fontStyle: "Regular", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "helper", fontStyle: "Regular", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // ── title ───────────────────────────────────────────
    { name: "title/32B", fontStyle: "Bold", fontSize: 32, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/24B", fontStyle: "Bold", fontSize: 24, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20B", fontStyle: "Bold", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20R", fontStyle: "Regular", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/16B", fontStyle: "Bold", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/14B", fontStyle: "Bold", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // ── body ────────────────────────────────────────────
    { name: "body/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16R", fontStyle: "Regular", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14M", fontStyle: "Medium", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14R", fontStyle: "Regular", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/12M", fontStyle: "Medium", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/12R", fontStyle: "Regular", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/10M", fontStyle: "Medium", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 },
    { name: "body/10R", fontStyle: "Regular", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 }
  ];

  // plugins/figma-vars-installer/src/install-textstyles.ts
  async function getOrCreateTextStyle(name) {
    const all = await figma.getLocalTextStylesAsync();
    const existing = all.find((s) => s.name === name);
    if (existing) return existing;
    return figma.createTextStyle();
  }
  async function loadRequiredFonts() {
    const styles = Array.from(new Set(TEXT_STYLES.map((s) => s.fontStyle)));
    for (const style of styles) {
      try {
        await figma.loadFontAsync({ family: TEXT_STYLE_FONT_FAMILY, style });
      } catch (e) {
        throw new Error(
          `\uD3F0\uD2B8 \uB85C\uB4DC \uC2E4\uD328: ${TEXT_STYLE_FONT_FAMILY} ${style}. \uC774 Figma \uD30C\uC77C/\uD658\uACBD\uC5D0 Pretendard ${style} \uAC00 \uC124\uCE58\uB418\uC5B4 \uC788\uB294\uC9C0 \uD655\uC778\uD558\uC138\uC694.`
        );
      }
    }
  }
  async function installTextStyles(onProgress, pctFrom = 70, pctTo = 85) {
    await loadRequiredFonts();
    const map = {};
    for (let i = 0; i < TEXT_STYLES.length; i++) {
      const def = TEXT_STYLES[i];
      const ts = await getOrCreateTextStyle(def.name);
      ts.name = def.name;
      ts.fontName = { family: TEXT_STYLE_FONT_FAMILY, style: def.fontStyle };
      ts.fontSize = def.fontSize;
      ts.lineHeight = { unit: "PERCENT", value: def.lineHeightPercent };
      ts.letterSpacing = { unit: "PERCENT", value: def.letterSpacingPercent };
      map[def.name] = ts;
      if (onProgress) {
        const pct = pctFrom + Math.round(i / TEXT_STYLES.length * (pctTo - pctFrom));
        onProgress(`Text Style: ${def.name}`, pct);
      }
    }
    return map;
  }

  // plugins/figma-vars-installer/src/build-components.ts
  function setMode(node, maps, modeId) {
    try {
      node.setExplicitVariableModeForCollection(maps.semanticColorCollectionId, modeId);
    } catch (e) {
      console.warn("[SW Installer] \uBAA8\uB4DC \uC5F0\uACB0 \uC2E4\uD328:", e);
    }
  }
  function setLightMode(node, maps) {
    setMode(node, maps, maps.semanticLightModeId);
  }
  var PLATFORMS = [
    { name: "PC", sizes: ["medium", "xsmall", "xxsmall"] },
    { name: "Mobile", sizes: ["large"] }
  ];
  var VARIANTS = ["primary", "secondary", "blue-line"];
  var VARIANT_LABEL = {
    primary: "Primary",
    secondary: "Secondary",
    "blue-line": "Blue-Line"
  };
  var SIZE_CONFIG = {
    medium: { break: "PC", height: 44, padPath: "spacing/16", textStyle: "body/14M", minWidth: 80 },
    xsmall: { break: "PC", height: 34, padPath: "spacing/8", textStyle: "body/14M", minWidth: 64 },
    xxsmall: { break: "PC", height: 28, padPath: "spacing/8", textStyle: "body/14M", minWidth: 64 },
    large: { break: "Mobile", height: 48, padPath: "spacing/16", textStyle: "body/16M", minWidth: 80 }
  };
  var SIZES = ["medium", "xsmall", "xxsmall", "large"];
  var STATES = ["Default", "Hover", "Pressed", "Disabled"];
  var CELL_W = 132;
  var CELL_H = 60;
  var GRID_PAD = 20;
  function variantSlots(variant, state) {
    if (state === "Disabled") {
      return {
        bg: "color/button/bg/disabled",
        border: "color/button/border/disabled",
        label: "color/button/label/disabled"
      };
    }
    const suffix = state === "Default" ? "default" : "hover";
    return {
      bg: `color/button/bg/${variant}--${suffix}`,
      border: `color/button/border/${variant}--${suffix}`,
      label: `color/button/label/${variant}--${suffix}`
    };
  }
  function boundPaint(variable) {
    const paint = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
    return figma.variables.setBoundVariableForPaint(paint, "color", variable);
  }
  function requireVar(map, key, kind) {
    const v = map[key];
    if (!v) throw new Error(`${kind} \uBCC0\uC218 \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Variables \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return v;
  }
  function requireStyle(map, key) {
    const s = map[key];
    if (!s) throw new Error(`Text Style \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Text Styles \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return s;
  }
  async function buildOne(variant, size, state, maps) {
    const cfg = SIZE_CONFIG[size];
    const slots = variantSlots(variant, state);
    const comp = figma.createComponent();
    comp.name = `Size=${size}, State=${state}, Variant=${VARIANT_LABEL[variant]}, Break=${cfg.break}`;
    comp.layoutMode = "HORIZONTAL";
    comp.primaryAxisAlignItems = "CENTER";
    comp.counterAxisAlignItems = "CENTER";
    comp.primaryAxisSizingMode = "AUTO";
    comp.counterAxisSizingMode = "FIXED";
    const padVar = requireVar(maps.foundationNumber, cfg.padPath, "Foundation Number");
    comp.paddingTop = 0;
    comp.paddingBottom = 0;
    comp.setBoundVariable("paddingLeft", padVar);
    comp.setBoundVariable("paddingRight", padVar);
    comp.minWidth = cfg.minWidth;
    await figma.loadFontAsync({ family: "Pretendard", style: "Medium" });
    const text = figma.createText();
    text.fontName = { family: "Pretendard", style: "Medium" };
    text.characters = "\uBC84\uD2BC";
    const ts = requireStyle(maps.textStyles, cfg.textStyle);
    await text.setTextStyleIdAsync(ts.id);
    text.fills = [boundPaint(requireVar(maps.semanticColor, slots.label, "Semantic Color"))];
    comp.appendChild(text);
    comp.fills = [boundPaint(requireVar(maps.semanticColor, slots.bg, "Semantic Color"))];
    comp.strokes = [boundPaint(requireVar(maps.semanticColor, slots.border, "Semantic Color"))];
    comp.strokeAlign = "INSIDE";
    const bwVar = requireVar(maps.foundationNumber, "border-width/1", "Foundation Number");
    comp.setBoundVariable("strokeWeight", bwVar);
    const radiusVar = requireVar(maps.foundationNumber, "radius/4", "Foundation Number");
    comp.setBoundVariable("topLeftRadius", radiusVar);
    comp.setBoundVariable("topRightRadius", radiusVar);
    comp.setBoundVariable("bottomLeftRadius", radiusVar);
    comp.setBoundVariable("bottomRightRadius", radiusVar);
    comp.resize(comp.width, cfg.height);
    setLightMode(comp, maps);
    return comp;
  }
  async function makeLabel(text, fontSize, style, x, y, w, align, color) {
    await figma.loadFontAsync({ family: "Pretendard", style });
    const t = figma.createText();
    t.fontName = { family: "Pretendard", style };
    t.fontSize = fontSize;
    t.characters = text;
    t.textAutoResize = "HEIGHT";
    t.resize(w, t.height);
    t.textAlignHorizontal = align;
    t.x = x;
    t.y = y;
    t.fills = [{ type: "SOLID", color }];
    return t;
  }
  async function buildDocFrame(grid, maps, originX, opts) {
    const PAD = 24, TITLE_H = 34, PLATFORM_GAP = 18, PLATFORM_TITLE_H = 24, SIZE_GAP = 14, SIZE_TITLE_H = 22, HEADER_H = 24, ROW_LABEL_W = 88;
    const gridLeft = PAD + ROW_LABEL_W;
    const W = PAD * 2 + ROW_LABEL_W + STATES.length * CELL_W;
    const bg = opts.dark ? { r: 0.075, g: 0.078, b: 0.094 } : { r: 1, g: 1, b: 1 };
    const titleColor = opts.dark ? { r: 0.95, g: 0.95, b: 0.96 } : { r: 0.07, g: 0.07, b: 0.09 };
    const platformColor = opts.dark ? { r: 0.9, g: 0.9, b: 0.92 } : { r: 0.13, g: 0.13, b: 0.13 };
    const sizeColor = opts.dark ? { r: 0.78, g: 0.8, b: 0.84 } : { r: 0.25, g: 0.27, b: 0.3 };
    const labelColor = opts.dark ? { r: 0.6, g: 0.62, b: 0.67 } : { r: 0.42, g: 0.45, b: 0.5 };
    const frame = figma.createFrame();
    frame.name = `Button \u2014 Spec ${opts.dark ? "Dark" : "Light"}`;
    frame.fills = [{ type: "SOLID", color: bg }];
    frame.cornerRadius = 8;
    frame.resize(W, 2400);
    frame.x = originX;
    frame.y = 0;
    let y = PAD;
    frame.appendChild(await makeLabel(`Button \xB7 ${opts.dark ? "Dark" : "Light"}`, 14, "Bold", PAD, y, 320, "LEFT", titleColor));
    y += TITLE_H;
    for (const plat of PLATFORMS) {
      y += PLATFORM_GAP;
      frame.appendChild(await makeLabel(plat.name, 13, "Bold", PAD, y, 200, "LEFT", platformColor));
      y += PLATFORM_TITLE_H;
      for (const size of plat.sizes) {
        y += SIZE_GAP;
        frame.appendChild(await makeLabel(size, 12, "Bold", PAD, y, 200, "LEFT", sizeColor));
        y += SIZE_TITLE_H;
        for (let c = 0; c < STATES.length; c++) {
          frame.appendChild(await makeLabel(STATES[c], 12, "Medium", gridLeft + c * CELL_W, y, CELL_W, "CENTER", labelColor));
        }
        y += HEADER_H;
        for (const variant of VARIANTS) {
          frame.appendChild(await makeLabel(VARIANT_LABEL[variant], 12, "Medium", PAD, y + CELL_H / 2 - 8, ROW_LABEL_W, "LEFT", labelColor));
          for (let c = 0; c < STATES.length; c++) {
            const cell = grid.find((g) => g.variant === variant && g.size === size && g.state === STATES[c]);
            if (!cell) continue;
            const inst = cell.comp.createInstance();
            frame.appendChild(inst);
            inst.x = gridLeft + c * CELL_W + (CELL_W - inst.width) / 2;
            inst.y = y + (CELL_H - inst.height) / 2;
            setMode(inst, maps, opts.modeId);
          }
          y += CELL_H;
        }
      }
    }
    y += PAD;
    frame.resize(W, y);
    setMode(frame, maps, opts.modeId);
    return frame;
  }
  async function buildButtonSet(maps, onProgress, pctFrom = 85, pctTo = 100) {
    const grid = [];
    let i = 0;
    const total = VARIANTS.length * SIZES.length * STATES.length;
    let rowIdx = 0;
    for (const variant of VARIANTS) {
      for (const size of SIZES) {
        for (let c = 0; c < STATES.length; c++) {
          const comp = await buildOne(variant, size, STATES[c], maps);
          grid.push({ comp, variant, size, state: STATES[c], row: rowIdx, col: c });
          i++;
          if (onProgress) {
            const pct = pctFrom + Math.round(i / total * (pctTo - pctFrom));
            onProgress(`Button: ${VARIANT_LABEL[variant]}/${size}/${STATES[c]}`, pct);
          }
        }
        rowIdx++;
      }
    }
    const set = figma.combineAsVariants(grid.map((g) => g.comp), figma.currentPage);
    set.name = "Button";
    for (const g of grid) {
      g.comp.x = GRID_PAD + g.col * CELL_W + (CELL_W - g.comp.width) / 2;
      g.comp.y = GRID_PAD + g.row * CELL_H + (CELL_H - g.comp.height) / 2;
    }
    const rows = VARIANTS.length * SIZES.length;
    set.resize(GRID_PAD * 2 + STATES.length * CELL_W, GRID_PAD * 2 + rows * CELL_H);
    set.x = 0;
    set.y = 0;
    setLightMode(set, maps);
    try {
      const light = await buildDocFrame(grid, maps, set.width + 80, { modeId: maps.semanticLightModeId, dark: false });
      const dark = await buildDocFrame(grid, maps, light.x + light.width + 40, { modeId: maps.semanticDarkModeId, dark: true });
      figma.viewport.scrollAndZoomIntoView([set, light, dark]);
    } catch (e) {
      console.warn("[SW Installer] Spec frame \uC0DD\uC131 \uC2E4\uD328 (\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8\uB294 \uC815\uC0C1):", e);
      figma.viewport.scrollAndZoomIntoView([set]);
    }
    return set;
  }

  // plugins/figma-vars-installer/src/code.ts
  figma.showUI(__html__, { width: 440, height: 600, title: "\uC5D0\uC2A4\uC6D0 \uB514\uC790\uC778\uC2DC\uC2A4\uD15C \uC124\uCE58" });
  figma.ui.onmessage = async (msg) => {
    if (msg.type === "install") {
      await runInstall({
        foundation: msg.foundation === true,
        semantic: msg.semantic === true,
        textStyles: msg.textStyles === true,
        components: msg.components === true
      });
    } else if (msg.type === "cancel") {
      figma.closePlugin();
    }
  };
  function hexToRgb(hex) {
    const n = parseInt(hex.replace("#", ""), 16);
    return {
      r: (n >> 16 & 255) / 255,
      g: (n >> 8 & 255) / 255,
      b: (n & 255) / 255,
      a: 1
    };
  }
  function rgbaStringToRgb(rgba) {
    const m = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return { r: 0, g: 0, b: 0, a: 1 };
    return {
      r: parseInt(m[1]) / 255,
      g: parseInt(m[2]) / 255,
      b: parseInt(m[3]) / 255,
      a: m[4] !== void 0 ? parseFloat(m[4]) : 1
    };
  }
  function post(type, payload) {
    figma.ui.postMessage(__spreadValues({ type }, payload));
  }
  async function getOrCreateCollection(name) {
    const all = await figma.variables.getLocalVariableCollectionsAsync();
    const existing = all.find((c) => c.name === name);
    if (existing) return existing;
    return figma.variables.createVariableCollection(name);
  }
  async function getOrCreateVariable(name, collection, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const existing = all.find(
      (v) => v.name === name && v.variableCollectionId === collection.id
    );
    if (existing) return existing;
    return figma.variables.createVariable(name, collection, resolvedType);
  }
  async function pruneCollection(collection, validNames, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const removed = [];
    for (const v of all) {
      if (v.variableCollectionId !== collection.id) continue;
      if (validNames.has(v.name)) continue;
      removed.push(v.name);
      try {
        v.remove();
      } catch (e) {
      }
    }
    return removed;
  }
  function ensureMode(collection, modeName) {
    const found = collection.modes.find((m) => m.name === modeName);
    if (found) return found.modeId;
    return collection.addMode(modeName);
  }
  function setupLightDarkModes(collection) {
    const first = collection.modes[0];
    if (first.name !== LIGHT_MODE && first.name !== DARK_MODE) {
      collection.renameMode(first.modeId, LIGHT_MODE);
    }
    const lightId = ensureMode(collection, LIGHT_MODE);
    const darkId = ensureMode(collection, DARK_MODE);
    const allowed = /* @__PURE__ */ new Set([lightId, darkId]);
    const extras = collection.modes.filter((m) => !allowed.has(m.modeId));
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return { lightId, darkId };
  }
  function colorScopes(path) {
    if (/^color\/[a-z-]+\/bg\//.test(path)) return ["FRAME_FILL", "SHAPE_FILL"];
    if (/^color\/[a-z-]+\/border\//.test(path)) return ["STROKE_COLOR"];
    if (/^color\/[a-z-]+\/label\//.test(path)) return ["TEXT_FILL"];
    if (/^color\/[a-z-]+\/icon\//.test(path)) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/bg/") || path.startsWith("color/surface/")) {
      return ["FRAME_FILL", "SHAPE_FILL"];
    }
    if (path.startsWith("color/text/")) return ["TEXT_FILL"];
    if (path.startsWith("color/border/")) return ["STROKE_COLOR"];
    if (path.startsWith("color/icon/")) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/action/")) return ["FRAME_FILL", "SHAPE_FILL", "TEXT_FILL"];
    if (path.startsWith("color/status/")) return ["FRAME_FILL", "TEXT_FILL", "STROKE_COLOR"];
    if (path === "color/overlay") return ["FRAME_FILL"];
    return ["ALL_SCOPES"];
  }
  function numberScopes(path) {
    if (path.startsWith("spacing/")) return ["GAP"];
    if (path.startsWith("sizing/icon")) return ["WIDTH_HEIGHT"];
    if (path.startsWith("sizing/")) return ["WIDTH_HEIGHT"];
    if (path.startsWith("radius/")) return ["CORNER_RADIUS"];
    if (path.startsWith("border-width/")) return ["STROKE_FLOAT"];
    if (path.startsWith("font-size/")) return ["FONT_SIZE"];
    if (path.startsWith("font-weight/")) return ["FONT_WEIGHT"];
    if (path.startsWith("line-height/")) return ["LINE_HEIGHT"];
    return ["ALL_SCOPES"];
  }
  function resolveColorRef(ref, foundationColorMap) {
    if (ref.startsWith("rgba")) return rgbaStringToRgb(ref);
    if (ref.startsWith("#")) return hexToRgb(ref);
    const target = foundationColorMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation color alias not found: ${ref}`);
      return { r: 1, g: 0, b: 1, a: 1 };
    }
    return figma.variables.createVariableAlias(target);
  }
  function resolveNumberRef(ref, foundationNumberMap) {
    if (typeof ref === "number") return ref;
    const target = foundationNumberMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation number alias not found: ${ref}`);
      return 0;
    }
    return figma.variables.createVariableAlias(target);
  }
  function setupSingleMode(collection, modeName) {
    const first = collection.modes[0];
    if (first.name !== modeName) {
      collection.renameMode(first.modeId, modeName);
    }
    const extras = collection.modes.filter((m) => m.modeId !== first.modeId);
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return first.modeId;
  }
  async function loadExistingVarMap(collectionName, resolvedType) {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const col = cols.find((c) => c.name === collectionName);
    const map = {};
    if (!col) return map;
    const vars = await figma.variables.getLocalVariablesAsync(resolvedType);
    for (const v of vars) {
      if (v.variableCollectionId === col.id) map[v.name] = v;
    }
    return map;
  }
  async function installFoundation() {
    post("progress", { step: "Foundation collection \uC900\uBE44 \uC911\u2026", pct: 3 });
    const fc = await getOrCreateCollection(FOUNDATION_COLLECTION);
    const fDefaultId = setupSingleMode(fc, "Default");
    const colorMap = {};
    const fcColorKeys = Object.keys(FOUNDATION_COLOR);
    for (let i = 0; i < fcColorKeys.length; i++) {
      const path = fcColorKeys[i];
      const v = await getOrCreateVariable(path, fc, "COLOR");
      v.setValueForMode(fDefaultId, hexToRgb(FOUNDATION_COLOR[path]));
      v.scopes = colorScopes(path);
      colorMap[path] = v;
      if (i % 20 === 0) {
        post("progress", { step: `Foundation Color: ${path}`, pct: 3 + Math.round(i / fcColorKeys.length * 22) });
      }
    }
    const removedColor = await pruneCollection(fc, new Set(fcColorKeys), "COLOR");
    post("progress", { step: "Foundation Number \uC900\uBE44 \uC911\u2026", pct: 28 });
    const numberMap = {};
    const fcNumberKeys = Object.keys(FOUNDATION_NUMBER);
    for (let i = 0; i < fcNumberKeys.length; i++) {
      const path = fcNumberKeys[i];
      const v = await getOrCreateVariable(path, fc, "FLOAT");
      v.setValueForMode(fDefaultId, FOUNDATION_NUMBER[path]);
      v.scopes = numberScopes(path);
      numberMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Foundation Number: ${path}`, pct: 28 + Math.round(i / fcNumberKeys.length * 15) });
      }
    }
    const removedNumber = await pruneCollection(fc, new Set(fcNumberKeys), "FLOAT");
    return {
      colorMap,
      numberMap,
      removed: [...removedColor, ...removedNumber],
      count: fcColorKeys.length + fcNumberKeys.length
    };
  }
  async function installSemantic(foundationColorMap, foundationNumberMap) {
    post("progress", { step: "Semantic Color collection \uC900\uBE44 \uC911\u2026", pct: 50 });
    const scc = await getOrCreateCollection(SEMANTIC_COLOR_COLLECTION);
    const { lightId: sLightId, darkId: sDarkId } = setupLightDarkModes(scc);
    const scColorKeys = Object.keys(SEMANTIC_COLOR);
    const semanticColorMap = {};
    for (let i = 0; i < scColorKeys.length; i++) {
      const path = scColorKeys[i];
      const entry = SEMANTIC_COLOR[path];
      const v = await getOrCreateVariable(path, scc, "COLOR");
      v.setValueForMode(sLightId, resolveColorRef(entry.light, foundationColorMap));
      v.setValueForMode(sDarkId, resolveColorRef(entry.dark, foundationColorMap));
      v.scopes = colorScopes(path);
      semanticColorMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Color: ${path}`, pct: 50 + Math.round(i / scColorKeys.length * 22) });
      }
    }
    const removedSemanticColor = await pruneCollection(scc, new Set(scColorKeys), "COLOR");
    post("progress", { step: "Semantic Number collection \uC900\uBE44 \uC911\u2026", pct: 73 });
    const scn = await getOrCreateCollection(SEMANTIC_NUMBER_COLLECTION);
    const scnDefaultId = setupSingleMode(scn, "Default");
    const scNumberKeys = Object.keys(SEMANTIC_NUMBER);
    for (let i = 0; i < scNumberKeys.length; i++) {
      const path = scNumberKeys[i];
      const v = await getOrCreateVariable(path, scn, "FLOAT");
      v.setValueForMode(scnDefaultId, resolveNumberRef(SEMANTIC_NUMBER[path], foundationNumberMap));
      v.scopes = numberScopes(path);
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Number: ${path}`, pct: 73 + Math.round(i / scNumberKeys.length * 13) });
      }
    }
    const removedSemanticNumber = await pruneCollection(scn, new Set(scNumberKeys), "FLOAT");
    return {
      semanticColorMap,
      scc,
      lightModeId: sLightId,
      darkModeId: sDarkId,
      removed: [...removedSemanticColor, ...removedSemanticNumber],
      count: scColorKeys.length + scNumberKeys.length
    };
  }
  async function loadExistingSemantic() {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const scc = cols.find((c) => c.name === SEMANTIC_COLOR_COLLECTION);
    if (!scc) return null;
    const light = scc.modes.find((m) => m.name === LIGHT_MODE);
    const dark = scc.modes.find((m) => m.name === DARK_MODE);
    const lightModeId = light ? light.modeId : scc.modes[0].modeId;
    const darkModeId = dark ? dark.modeId : lightModeId;
    const semanticColorMap = await loadExistingVarMap(SEMANTIC_COLOR_COLLECTION, "COLOR");
    return { semanticColorMap, scc, lightModeId, darkModeId };
  }
  async function runInstall(sel) {
    try {
      if (!sel.foundation && !sel.semantic && !sel.textStyles && !sel.components) {
        throw new Error("\uC124\uCE58\uD560 \uD56D\uBAA9\uC744 \uD558\uB098 \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694.");
      }
      post("progress", { step: "\uC900\uBE44 \uC911\u2026", pct: 2 });
      const removedAll = [];
      let foundationCount = 0;
      let semanticCount = 0;
      let textStyleCount = 0;
      let componentCount = 0;
      let foundationColorMap = {};
      let foundationNumberMap = {};
      if (sel.foundation) {
        const r = await installFoundation();
        foundationColorMap = r.colorMap;
        foundationNumberMap = r.numberMap;
        foundationCount = r.count;
        removedAll.push(...r.removed);
      } else if (sel.semantic || sel.components) {
        foundationColorMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "COLOR");
        foundationNumberMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "FLOAT");
      }
      let semanticColorMap = {};
      let scc = null;
      let lightModeId = "";
      let darkModeId = "";
      if (sel.semantic) {
        if (Object.keys(foundationColorMap).length === 0) {
          throw new Error("Semantic \uC124\uCE58\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        const r = await installSemantic(foundationColorMap, foundationNumberMap);
        semanticColorMap = r.semanticColorMap;
        scc = r.scc;
        lightModeId = r.lightModeId;
        darkModeId = r.darkModeId;
        semanticCount = r.count;
        removedAll.push(...r.removed);
      } else if (sel.components) {
        const loaded = await loadExistingSemantic();
        if (loaded) {
          semanticColorMap = loaded.semanticColorMap;
          scc = loaded.scc;
          lightModeId = loaded.lightModeId;
          darkModeId = loaded.darkModeId;
        }
      }
      let textStyleMap = {};
      if (sel.textStyles || sel.components) {
        post("progress", { step: "Text Styles \uC124\uCE58 \uC911\u2026", pct: 88 });
        textStyleMap = await installTextStyles((step, pct) => post("progress", { step, pct }), 88, 94);
        textStyleCount = Object.keys(textStyleMap).length;
      }
      if (sel.components) {
        if (!scc || !lightModeId) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Semantic Color V2 \uAC00 \uD544\uC694\uD569\uB2C8\uB2E4. Semantic \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        if (Object.keys(foundationNumberMap).length === 0) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        post("progress", { step: "Button \uCEF4\uD3EC\uB10C\uD2B8 \uC0DD\uC131 \uC911\u2026", pct: 94 });
        const set = await buildButtonSet(
          {
            semanticColor: semanticColorMap,
            foundationNumber: foundationNumberMap,
            textStyles: textStyleMap,
            semanticColorCollectionId: scc.id,
            semanticLightModeId: lightModeId,
            semanticDarkModeId: darkModeId
          },
          (step, pct) => post("progress", { step, pct }),
          94,
          100
        );
        componentCount = set.children.length;
        figma.currentPage.selection = [set];
      }
      post("progress", { step: "\uC644\uB8CC", pct: 100 });
      post("done", {
        foundationCount,
        semanticCount,
        textStyleCount,
        componentCount,
        removedCount: removedAll.length,
        removedNames: removedAll
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: msg });
    }
  }
})();
