# S1 UI 라이브러리 — React · Next.js 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **React · Next.js 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.1.0**
- 정본 지문: `789e183460b0f76d2d9cbf2b8cc9be98570202138980da1b4541e9d9ad4a69c5`
- 승인 컴포넌트: **22종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, assist-button, text-button, modal-content)
- 토큰: **488개**

## 이 묶음에 들어있는 것

컴포넌트 22종 전부 · 사용 설명서(README.md) · 타입 정의(index.d.ts).

## 시작하기

1. 압축을 풀면 나오는 `s1-ui` 폴더를 프로젝트에 그대로 넣습니다.
2. **`preview.html` 을 브라우저로 열면 컴포넌트 22종이 실제 모습으로 보입니다** — 무엇을 쓸지 여기서 고르세요.
3. 앱 진입 파일에서 `assets/css/tokens.css` 와 `s1-ui.css` 를 한 번 읽힙니다.
4. `import { S1Button } from "./s1-ui/platform/react";` 처럼 쓸 것만 꺼내 씁니다.
5. 받는 값과 쓰는 법은 `platform/react/README.md` 에 있습니다.

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.

```bash
node s1-ui/tools/s1-ui-lint.mjs --version          # 지문 확인
node s1-ui/tools/s1-ui-lint.mjs <내 소스 폴더>      # 규칙 검사
```
