# S1 UI 라이브러리 — React · Next.js 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **React · Next.js 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.27.0**
- 정본 지문: `57ed600226cd783560beb8ed0a2b5d53ab848da5b8ecdc9d0a4e23e5132096ee`
- 승인 컴포넌트: **35종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, gnb, gnb-sub-menu-item, gnb-sub-menu, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet, list-row, expandable-card, data-tag, divider, lnb, footer, ci, login-gnb)
- 토큰: **504개**

## 이 묶음에 들어있는 것

컴포넌트 35종 전부 · 사용 설명서(README.md) · 타입 정의(index.d.ts).

## 시작하기

1. 압축을 풀면 나오는 `s1-ui` 폴더를 프로젝트의 `src/` 안에 그대로 넣습니다.
2. **`preview.html` 을 브라우저로 열면 컴포넌트 35종이 실제 모습으로 보입니다** — 무엇을 쓸지 여기서 고르세요.
3. 앱 진입 파일(Vite `src/main.jsx` · Next.js `app/layout.tsx`)에서 CSS 를 한 번, 이 순서로 읽힙니다: `assets/css/tokens.css`(필수) · `assets/css/typography.css`(선택) · `s1-ui.base.css`(선택 — 페이지 바탕·기본 글자색) · `s1-ui.css`(필수).
4. 글꼴 Pretendard 는 묶음에 들어 있지 않습니다 — `index.html` 의 `<head>` 에 `<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css">` 를 넣습니다. 다크 모드는 `<html data-theme="dark">` 입니다.
5. `import { S1Button } from "./s1-ui/platform/react";` 처럼 쓸 것만 꺼내 씁니다(Next.js 에서도 그대로 — 부품 파일마다 "use client" 가 들어 있습니다).
6. 받는 값과 쓰는 법·예시는 `platform/react/README.md` 에 있습니다.

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.

```bash
node s1-ui/tools/s1-ui-lint.mjs --version          # 지문 확인
node s1-ui/tools/s1-ui-lint.mjs <내 소스 폴더>      # 규칙 검사
```
