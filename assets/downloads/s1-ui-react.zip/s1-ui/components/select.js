import { init as initDropdown, destroy as destroyDropdown } from "./dropdown.js";

export const componentId = "select";
export const jsRequired = true;

const instances = new WeakMap();

/* ── 팝오버 띄우기 (date-picker·time-picker·select·filter-chip 공통 배선, 2026-09-28) ──────────────
   패널은 기본적으로 컴포넌트 안에 position:absolute 로 붙는다. 소비자가 컴포넌트를 스크롤 상자
   (overflow:auto|scroll|hidden) 안에 넣으면 그 상자가 패널을 잘라낸다 — 특히 위로 뒤집을 때 상자
   윗변에서 잘린다(안내 페이지 Date Picker XXSM 실측: 위쪽 165px 잘림).
   그래서 **열려 있는 동안만** position:fixed 로 띄우고 트리거 좌표로 직접 붙인다 — 어떤 조상도
   자르지 못한다. 닫으면 인라인 값을 전부 지워 원래(absolute) 계약으로 되돌린다(정적 Open 표본 불변).
   width:100% / min-width:100% 를 쓰는 패널은 fixed 가 되면 기준이 뷰포트로 바뀌므로, 띄우는 동안
   따라갈 요소의 실제 폭을 px 로 고정해 준다. */
const PANEL_VIEWPORT_MARGIN = 8;

function floatPanel(trigger, panel, { gap = 8, widthFrom = null, minWidthFrom = null } = {}) {
  if (widthFrom) panel.style.width = `${widthFrom.getBoundingClientRect().width}px`;
  if (minWidthFrom) panel.style.minWidth = `${minWidthFrom.getBoundingClientRect().width}px`;
  panel.setAttribute("data-s1-float", "fixed");
  // 재계산 전에 좌표를 0,0 으로 되돌려야 이전 위치가 크기 측정에 섞이지 않는다.
  panel.style.top = "0px";
  panel.style.left = "0px";
  const t = trigger.getBoundingClientRect();
  const p = panel.getBoundingClientRect();
  const vw = document.documentElement.clientWidth;
  const vh = document.documentElement.clientHeight;
  const roomBelow = vh - t.bottom - gap;
  const roomAbove = t.top - gap;
  /* 위로 뒤집는 건 **위에 온전히 들어갈 때만** 이다. 양쪽 다 모자라면 아래로 둔다 —
     아래로 넘친 부분은 스크롤로 볼 수 있지만, 위로 넘친 부분은 볼 방법이 없다. */
  const flipUp = p.height > roomBelow && p.height <= roomAbove;
  /* 세로는 트리거에 그대로 붙인다(화면 안으로 끌어당기지 않는다) — 끌어당기면 트리거가 화면 밖으로
     스크롤됐을 때 패널만 화면 끝에 홀로 남는다. 가로만 화면 밖으로 나가지 않게 당겨 준다. */
  const maxLeft = Math.max(PANEL_VIEWPORT_MARGIN, vw - PANEL_VIEWPORT_MARGIN - p.width);
  const top = flipUp ? t.top - gap - p.height : t.bottom + gap;
  const left = Math.min(Math.max(PANEL_VIEWPORT_MARGIN, t.left), maxLeft);
  panel.style.top = `${Math.round(top)}px`;
  panel.style.left = `${Math.round(left)}px`;
  if (flipUp) panel.setAttribute("data-flip", "up");
  else panel.removeAttribute("data-flip");
}

function unfloatPanel(panel) {
  panel.removeAttribute("data-s1-float");
  panel.removeAttribute("data-flip");
  panel.style.top = "";
  panel.style.left = "";
  panel.style.width = "";
  panel.style.minWidth = "";
}

function getParts(root) {
  return {
    trigger: root.querySelector('[data-s1-part="trigger"]'),
    value: root.querySelector('[data-s1-part="value"]'),
    panel: root.querySelector('[data-s1-part="panel"]'),
    dropdownRoot: root.querySelector('[data-s1-component="dropdown"]')
  };
}

function isOpen(trigger) {
  return trigger.getAttribute("aria-expanded") === "true";
}

/* ── 값 읽기·넣기·폼 전송 (2026-10-12) ──────────────────────────────────────────────
   값은 옵션의 data-value 이고, 없으면 옵션 글자다. root 에 data-value 를 주면 처음부터 그 값이 골라진다.
   root 에 data-name 을 주면 숨은 <input type="hidden" name> 이 만들어져 <form> 으로 같이 전송된다. */
const optionLabel = (option) => option.querySelector('[data-s1-part="option-label"]')?.textContent?.trim() ?? option.textContent.trim();
const optionValue = (option) => option.dataset.value ?? optionLabel(option);

export function init(root) {
  if (!(root instanceof Element) || root.dataset.s1Component !== componentId) return null;
  if (instances.has(root)) return instances.get(root);

  const { trigger, value, panel, dropdownRoot } = getParts(root);
  if (!trigger || !panel || !dropdownRoot) return null;

  if (!trigger.hasAttribute("aria-haspopup")) trigger.setAttribute("aria-haspopup", "listbox");
  if (!trigger.hasAttribute("aria-expanded")) trigger.setAttribute("aria-expanded", "false");
  panel.hidden = true;

  const dropdownApi = initDropdown(dropdownRoot);

  const optionsOf = () => [...dropdownRoot.querySelectorAll('[data-s1-part="option"]')];
  /* 처음 글자가 이미 고른 값의 라벨일 수 있다(서버가 값을 알고 그렸을 때) — 비웠을 때 돌아갈 글자는 data-placeholder 로 따로 받는다. */
  const placeholderText = root.dataset.placeholder ?? (value ? value.textContent : "");
  const hiddenName = root.dataset.name;
  let hidden = null;
  if (hiddenName) {
    hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = hiddenName;
    root.appendChild(hidden);
  }
  const selectedOption = () => optionsOf().find((option) => option.getAttribute("aria-selected") === "true") ?? null;
  const readValue = () => { const option = selectedOption(); return option ? optionValue(option) : ""; };
  const syncHidden = () => { if (hidden) hidden.value = readValue(); };
  const setValue = (next) => {
    const wanted = next == null ? "" : String(next);
    const match = wanted === "" ? null : optionsOf().find((option) => optionValue(option) === wanted || optionLabel(option) === wanted) ?? null;
    for (const option of optionsOf()) option.setAttribute("aria-selected", String(option === match));
    if (value) value.textContent = match ? optionLabel(match) : placeholderText;
    if (match) trigger.dataset.filled = "true"; else delete trigger.dataset.filled;
    syncHidden();
    return Boolean(match) || wanted === "";
  };
  if (root.dataset.value) setValue(root.dataset.value); else syncHidden();

  // behavior 계약(component-behavior.pc.json "Select Box": on disable → close and block trigger clicks).
  // 클릭 차단은 open() 의 disabled 가드가 이미 담당한다 — 여기서는 열린 채로 비활성화될 때 자동으로 닫는다.
  // 인스턴스마다 자기 trigger 만 관찰하므로 누적되지 않고, destroy() 가 disconnect 한다.
  const disabledObserver = new MutationObserver(() => {
    if (trigger.disabled && isOpen(trigger)) close({ returnFocus: false });
  });
  disabledObserver.observe(trigger, { attributes: true, attributeFilter: ["disabled"] });

  // 패널은 열려 있는 동안 화면 고정 층으로 띄운다 — 스크롤 상자 안에서도 잘리지 않는다.
  // 폭은 CSS 가 width:100%(= 트리거 칸 폭)로 잡으므로, 띄우는 동안 root 의 실제 폭을 px 로 넘겨준다.
  const positionPanel = () => { if (!panel.hidden) floatPanel(trigger, panel, { gap: 8, widthFrom: root }); };
  const handleReposition = () => positionPanel();

  const close = ({ returnFocus = true } = {}) => {
    if (!isOpen(trigger)) return;
    trigger.setAttribute("aria-expanded", "false");
    panel.hidden = true;
    unfloatPanel(panel);
    document.removeEventListener("pointerdown", handleOutsidePointer, true);
    window.removeEventListener("scroll", handleReposition, true);
    window.removeEventListener("resize", handleReposition);
    if (returnFocus) trigger.focus();
    root.dispatchEvent(new CustomEvent("s1:select:close", { bubbles: true, detail: {} }));
  };

  const open = () => {
    if (trigger.disabled || isOpen(trigger)) return;
    trigger.setAttribute("aria-expanded", "true");
    panel.hidden = false;
    positionPanel();
    document.addEventListener("pointerdown", handleOutsidePointer, true);
    window.addEventListener("scroll", handleReposition, true);
    window.addEventListener("resize", handleReposition);
    dropdownApi?.focusActive();
    root.dispatchEvent(new CustomEvent("s1:select:open", { bubbles: true, detail: {} }));
  };

  const handleOutsidePointer = (event) => {
    if (!root.contains(event.target)) close({ returnFocus: false });
  };

  const handleTriggerClick = () => {
    if (isOpen(trigger)) close();
    else open();
  };

  // role=listbox 표준 패턴 — 열린 패널 어디에 포커스가 있어도(트리거·옵션 모두) Esc 로 닫고 트리거로 복귀한다.
  const handleRootKeydown = (event) => {
    if (event.key === "Escape" && isOpen(trigger)) {
      event.preventDefault();
      close();
    }
  };

  const handleDropdownChange = (event) => {
    if (event.detail?.type !== "text") return;
    if (value) {
      value.textContent = event.detail.option?.querySelector('[data-s1-part="option-label"]')?.textContent ?? event.detail.value ?? "";
    }
    trigger.dataset.filled = "true";
    syncHidden();
    close();
    root.dispatchEvent(new CustomEvent("s1:select:change", { bubbles: true, detail: { value: event.detail.value, option: event.detail.option } }));
  };

  trigger.addEventListener("click", handleTriggerClick);
  root.addEventListener("keydown", handleRootKeydown);
  root.addEventListener("s1:dropdown:change", handleDropdownChange);

  const api = Object.freeze({
    get open() { return isOpen(trigger); },
    get value() { return readValue(); },
    setValue,
    openPanel: open,
    closePanel: close,
    destroy() {
      hidden?.remove();
      trigger.removeEventListener("click", handleTriggerClick);
      root.removeEventListener("keydown", handleRootKeydown);
      root.removeEventListener("s1:dropdown:change", handleDropdownChange);
      document.removeEventListener("pointerdown", handleOutsidePointer, true);
      window.removeEventListener("scroll", handleReposition, true);
      window.removeEventListener("resize", handleReposition);
      unfloatPanel(panel);
      disabledObserver.disconnect();
      destroyDropdown(dropdownRoot);
      instances.delete(root);
    }
  });
  instances.set(root, api);
  return api;
}

export function destroy(root) {
  instances.get(root)?.destroy();
}

export const runtime = Object.freeze({ init, destroy });
