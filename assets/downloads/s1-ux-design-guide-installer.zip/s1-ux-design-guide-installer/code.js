"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // plugins/figma-vars-installer/src/vars-data.ts
  var FOUNDATION_COLLECTION = "Foundation V2";
  var SEMANTIC_COLOR_COLLECTION = "Semantic Color V2";
  var SEMANTIC_NUMBER_COLLECTION = "Semantic Number V2";
  var SEMANTIC_SHADOW_COLLECTION = "Semantic Shadow V2";
  var LIGHT_MODE = "Light";
  var DARK_MODE = "Dark";
  var FOUNDATION_COLOR = {
    // ── Base ──────────────────────────────────────────
    "base/white": "#FFFFFF",
    "base/black": "#000000",
    // ── Brand ─────────────────────────────────────────
    "brand/blue": "#0072CE",
    "brand/red": "#FF312C",
    "brand/gray": "#DFDEDE",
    "brand/ci": "#004097",
    // ── Gray (Light scale) ────────────────────────────
    "gray/0": "#FAFAFA",
    "gray/50": "#F5F5F5",
    "gray/100": "#E9E9E9",
    "gray/200": "#D9D9D9",
    "gray/300": "#C4C4C4",
    "gray/400": "#9D9D9D",
    "gray/500": "#757575",
    "gray/600": "#555555",
    "gray/700": "#434343",
    "gray/800": "#353535",
    "gray/900": "#202020",
    // ── Gray Dark (Dark scale) ────────────────────────
    "gray-dark/0": "#0D0E12",
    "gray-dark/50": "#131418",
    "gray-dark/100": "#1C1D23",
    "gray-dark/200": "#24252C",
    "gray-dark/300": "#2E2F38",
    "gray-dark/400": "#35363F",
    "gray-dark/500": "#3E4049",
    "gray-dark/600": "#55575F",
    "gray-dark/700": "#8A8C96",
    "gray-dark/800": "#B8BABF",
    "gray-dark/900": "#ECEDF0",
    // ── Blue ──────────────────────────────────────────
    "blue/50": "#E2F1FF",
    "blue/100": "#C8E4FF",
    "blue/150": "#A4D4FF",
    "blue/200": "#8BC6FF",
    "blue/250": "#5BB2FF",
    "blue/300": "#2B9EFF",
    "blue/350": "#268CF8",
    "blue/400": "#1D6CEB",
    "blue/450": "#2158C8",
    "blue/500": "#2747B9",
    "blue-dark/50": "#0C1D38",
    "blue-dark/100": "#112B55",
    "blue-dark/150": "#1A3D72",
    "blue-dark/200": "#214EA0",
    "blue-dark/250": "#2A65C8",
    "blue-dark/300": "#3070D8",
    "blue-dark/350": "#4285E8",
    "blue-dark/400": "#6FA5F8",
    "blue-dark/450": "#96BEF9",
    "blue-dark/500": "#C0D8FC",
    // ── Red ───────────────────────────────────────────
    "red/50": "#FFEBEF",
    "red/100": "#FFCCD6",
    "red/150": "#FBB2BA",
    "red/200": "#F8979E",
    "red/250": "#FC6E79",
    "red/300": "#FF4554",
    "red/350": "#F22544",
    "red/400": "#E50533",
    "red/450": "#D60228",
    "red/500": "#C8001E",
    "red-dark/50": "#2A0F14",
    "red-dark/100": "#3D1520",
    "red-dark/150": "#5C1E2E",
    "red-dark/200": "#8A2A3E",
    "red-dark/250": "#C03850",
    "red-dark/300": "#E04860",
    "red-dark/350": "#F06070",
    "red-dark/400": "#F48890",
    "red-dark/450": "#F8A8B0",
    "red-dark/500": "#FCD0D5",
    // ── Orange ────────────────────────────────────────
    "orange/50": "#FFEDE0",
    "orange/100": "#FDDBBF",
    "orange/150": "#FEC6A0",
    "orange/200": "#FFB482",
    "orange/250": "#FF954E",
    "orange/300": "#FF761A",
    "orange/350": "#EE680D",
    "orange/400": "#DA4C00",
    "orange/450": "#B63C00",
    "orange/500": "#8E2E00",
    "orange-dark/50": "#2E1505",
    "orange-dark/100": "#42200A",
    "orange-dark/150": "#6B3512",
    "orange-dark/200": "#A05020",
    "orange-dark/250": "#D06828",
    "orange-dark/300": "#E88038",
    "orange-dark/350": "#F09548",
    "orange-dark/400": "#F5AA68",
    "orange-dark/450": "#F8C090",
    "orange-dark/500": "#FCD8B8",
    // ── Yellow ────────────────────────────────────────
    "yellow/50": "#FFF4CE",
    "yellow/100": "#FEE89A",
    "yellow/150": "#FEDE6C",
    "yellow/200": "#FFD53D",
    "yellow/250": "#FFCC1E",
    "yellow/300": "#FFC200",
    "yellow/350": "#F5B900",
    "yellow/400": "#DBA400",
    "yellow/450": "#BA8900",
    "yellow/500": "#8F6A00",
    "yellow-dark/50": "#2A2005",
    "yellow-dark/100": "#3D2E08",
    "yellow-dark/150": "#605010",
    "yellow-dark/200": "#907818",
    "yellow-dark/250": "#C09828",
    "yellow-dark/300": "#D8B038",
    "yellow-dark/350": "#E8C048",
    "yellow-dark/400": "#F0D068",
    "yellow-dark/450": "#F5DE90",
    "yellow-dark/500": "#FAEAB8",
    // ── Green ─────────────────────────────────────────
    "green/50": "#E3F2EA",
    "green/100": "#CAECDA",
    "green/150": "#9CD8BD",
    "green/200": "#6FC4A2",
    "green/250": "#47BB8E",
    "green/300": "#1FB279",
    "green/350": "#10A86C",
    "green/400": "#009E5E",
    "green/450": "#008650",
    "green/500": "#006F42",
    "green-dark/50": "#0A2018",
    "green-dark/100": "#102E22",
    "green-dark/150": "#184530",
    "green-dark/200": "#206840",
    "green-dark/250": "#288A55",
    "green-dark/300": "#30A868",
    "green-dark/350": "#3FBE7E",
    "green-dark/400": "#68D098",
    "green-dark/450": "#98E0B8",
    "green-dark/500": "#C5F0D8",
    // ── Skyblue ───────────────────────────────────────
    "skyblue/50": "#C4EEF7",
    "skyblue/100": "#A5E5F3",
    "skyblue/150": "#7BD6EA",
    "skyblue/200": "#51C7E1",
    "skyblue/250": "#3BC0DD",
    "skyblue/300": "#25B9DA",
    "skyblue/350": "#1DAACB",
    "skyblue/400": "#159BBC",
    "skyblue/450": "#1284A0",
    "skyblue/500": "#0F6C84",
    "skyblue-dark/50": "#081E28",
    "skyblue-dark/100": "#102A38",
    "skyblue-dark/150": "#184050",
    "skyblue-dark/200": "#205A70",
    "skyblue-dark/250": "#287890",
    "skyblue-dark/300": "#3090A8",
    "skyblue-dark/350": "#40A8C0",
    "skyblue-dark/400": "#68C0D8",
    "skyblue-dark/450": "#98D8E8",
    "skyblue-dark/500": "#C0E8F0",
    // ── Purple ────────────────────────────────────────
    "purple/50": "#E8E9FC",
    "purple/100": "#CFD1F9",
    "purple/150": "#C0C0FC",
    "purple/200": "#B0B0FF",
    "purple/250": "#8B8BEE",
    "purple/300": "#6666DD",
    "purple/350": "#4E4EC3",
    "purple/400": "#3535A8",
    "purple/450": "#2D2D8F",
    "purple/500": "#252576",
    "purple-dark/50": "#14142A",
    "purple-dark/100": "#1E1E3D",
    "purple-dark/150": "#2A2A58",
    "purple-dark/200": "#383878",
    "purple-dark/250": "#4848A0",
    "purple-dark/300": "#5858B8",
    "purple-dark/350": "#7070D0",
    "purple-dark/400": "#9090E0",
    "purple-dark/450": "#B0B0EA",
    "purple-dark/500": "#D0D0F5",
    // ── Brown ─────────────────────────────────────────
    "brown/50": "#F6EEE9",
    "brown/100": "#E4D5C8",
    "brown/150": "#DBC6B3",
    "brown/200": "#D1B69F",
    "brown/250": "#A68C75",
    "brown/300": "#7C614A",
    "brown/350": "#685240",
    "brown/400": "#554435",
    "brown/450": "#483A2D",
    "brown/500": "#3B3025",
    "brown-dark/50": "#1E1610",
    "brown-dark/100": "#2A2018",
    "brown-dark/150": "#3D3025",
    "brown-dark/200": "#584535",
    "brown-dark/250": "#786050",
    "brown-dark/300": "#907868",
    "brown-dark/350": "#A89080",
    "brown-dark/400": "#C0A898",
    "brown-dark/450": "#D8C0B0",
    "brown-dark/500": "#E8D8C8",
    // ── Visual Gray (Light 전용 스케일) ───────────────
    "visual-gray/50": "#F3F5F7",
    "visual-gray/100": "#E8EBEF",
    "visual-gray/150": "#DADEE5",
    "visual-gray/200": "#CDD2DE",
    "visual-gray/250": "#ABB2BF",
    "visual-gray/300": "#808796",
    "visual-gray/350": "#646A74",
    "visual-gray/400": "#3E4347",
    "visual-gray/450": "#2B2F32",
    "visual-gray/500": "#1B1D1F",
    // ── Cool Gray Dark (Dark 전용 스케일) ─────────────
    "visual-gray-dark/50": "#12141A",
    "visual-gray-dark/100": "#1A1D25",
    "visual-gray-dark/150": "#252830",
    "visual-gray-dark/200": "#353840",
    "visual-gray-dark/250": "#484C58",
    "visual-gray-dark/300": "#606470",
    "visual-gray-dark/350": "#787C88",
    "visual-gray-dark/400": "#989CA8",
    "visual-gray-dark/450": "#B8BCC5",
    "visual-gray-dark/500": "#D8DBE0"
  };
  var FOUNDATION_NUMBER = {
    // ── Spacing ─────────────────────────────
    "spacing/2": 2,
    "spacing/4": 4,
    "spacing/6": 6,
    "spacing/8": 8,
    "spacing/10": 10,
    "spacing/12": 12,
    "spacing/14": 14,
    "spacing/16": 16,
    "spacing/20": 20,
    "spacing/24": 24,
    "spacing/28": 28,
    "spacing/32": 32,
    "spacing/36": 36,
    "spacing/40": 40,
    "spacing/44": 44,
    "spacing/48": 48,
    "spacing/56": 56,
    "spacing/64": 64,
    "spacing/80": 80,
    "spacing/96": 96,
    "spacing/128": 128,
    // ── Radius ──────────────────────────────
    "radius/0": 0,
    "radius/2": 2,
    "radius/4": 4,
    "radius/6": 6,
    "radius/8": 8,
    "radius/10": 10,
    "radius/12": 12,
    "radius/16": 16,
    "radius/20": 20,
    "radius/full": 9999,
    // ── Border Width ───────────────────────
    "border-width/1": 1,
    "border-width/2": 2,
    // ── Font Size ──────────────────────────
    "font-size/10": 10,
    "font-size/12": 12,
    "font-size/14": 14,
    "font-size/16": 16,
    "font-size/18": 18,
    "font-size/20": 20,
    "font-size/24": 24,
    "font-size/32": 32,
    // ── Font Weight ────────────────────────
    "font-weight/regular": 400,
    "font-weight/medium": 500,
    "font-weight/bold": 700,
    // ── Line Height (배수) ─────────────────
    "line-height/130": 1.3,
    "line-height/140": 1.4,
    // ── Sizing (Foundation primitive — 컴포넌트 높이·치수) ──
    "sizing/10": 10,
    "sizing/16": 16,
    "sizing/18": 18,
    "sizing/20": 20,
    "sizing/24": 24,
    "sizing/28": 28,
    "sizing/30": 30,
    "sizing/32": 32,
    "sizing/34": 34,
    "sizing/38": 38,
    "sizing/40": 40,
    "sizing/44": 44,
    "sizing/48": 48,
    "sizing/56": 56,
    "sizing/60": 60,
    "sizing/64": 64,
    "sizing/80": 80,
    "sizing/128": 128,
    // ── Opacity ──
    "opacity/0": 0,
    "opacity/25": 0.25,
    "opacity/50": 0.5,
    "opacity/75": 0.75,
    "opacity/100": 1,
    // ── Breakpoint (px) ──
    "breakpoint/xs": 320,
    "breakpoint/sm": 600,
    "breakpoint/md": 768,
    "breakpoint/lg": 1024,
    "breakpoint/xl": 1280,
    "breakpoint/2xl": 1440
  };
  var SEMANTIC_SHADOW = {
    // 딤 위에 떠있는 패널(Modal). 라이트·다크 **모두 2겹** — 겹 수는 테마가 아니라 표면 위계를 나타낸다.
    //   양쪽 겹 수를 맞춘 이유: Figma 는 그림자 겹 수를 변수 모드로 바꿀 수 없다. 겹 수가 같아야
    //   겹당 속성(색·offset·blur·spread)을 변수에 바인딩해 모드 전환을 표현할 수 있다.
    //   테마 차이는 겹 수가 아니라 alpha 와 기하다(라이트 .06/.10 · 다크 1.0).
    "shadow/raised": { light: "0 4px 6px -2px rgba(0,0,0,0.06), 0 12px 20px -4px rgba(0,0,0,0.10)", dark: "0 8px 8px -4px rgba(0,0,0,1), 0 20px 24px -4px rgba(0,0,0,1)" },
    // 하단에서 올라오는 표면(Bottom Sheet). y 부호가 반전된다.
    // TODO(shadow-dark): 미확정. Figma 다크 스펙 실측 후 교체 — 지금은 다크에서 그림자가 사라지는 회귀를 막으려 light 값 동일.
    "shadow/raised-up": { light: "0 -4px 16px rgba(0,0,0,0.15)", dark: "0 -4px 16px rgba(0,0,0,0.15)" },
    // 작은 팝오버 패널(Dropdown·Calendar·Time Picker Dropdown). 표면이 작아 blur 8.
    // TODO(shadow-dark): 미확정. Figma 다크 스펙 실측 후 교체 — 지금은 다크에서 그림자가 사라지는 회귀를 막으려 light 값 동일.
    "shadow/dropdown": { light: "0 4px 8px 0 rgba(0,0,0,0.15)", dark: "0 4px 8px 0 rgba(0,0,0,0.15)" }
  };
  var SEMANTIC_COLOR = {
    // ── bg (페이지·레이아웃 배경 — 깊이 스케일) ────
    // level-0(가장 위, 흰/카드) → level-3(가장 깊은 배경). 라이트는 기존 값 보존, 다크는 깊이 위계로 재정렬.
    // (옛 default/subtle/muted/selected, surface/* 는 깊이 스케일로 통합·드롭. bg/selected→테이블 자체 토큰, surface→드롭)
    "color/bg/level-0": { light: "base/white", dark: "gray-dark/0" },
    "color/bg/level-1": { light: "gray/0", dark: "gray-dark/50" },
    "color/bg/level-2": { light: "gray/50", dark: "gray-dark/100" },
    "color/bg/level-3": { light: "gray/100", dark: "gray-dark/200" },
    // ── surface (딤 위에 떠있는 패널 표면 — 모달·바텀시트·팝오버 공용) ────
    // bg/level 은 라이트/다크가 고정 쌍이라 "라이트=흰색 + 다크=올라온 회색" 조합을 표현 못 한다.
    // raised = 딤 위 떠있는 패널(모달·바텀시트·팝오버 공용): 라이트 흰색 / 다크 gray-dark/100.
    // 모달 스펙(chip·button 과 동일 raised 패턴)과 일치. 컴포넌트별 전용 토큰 대신 공용 표면.
    // (사용자 결정: 2026-07-03 신설 → 2026-07-06 다크값 gray-dark/400 → gray-dark/100 정정)
    "color/surface/raised": { light: "base/white", dark: "gray-dark/100" },
    // ── button ────────────────────────────────
    "color/button/bg/blue-line--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/blue-line--hover": { light: "blue/50", dark: "gray-dark/200" },
    "color/button/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/button/bg/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/bg/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/bg/secondary--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/secondary--hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/button/border/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/blue-line--hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/disabled": { light: "gray/200", dark: "gray-dark/300" },
    "color/button/border/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/border/secondary--default": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/border/secondary--hover": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/label/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/label/blue-line--hover": { light: "blue/500", dark: "blue-dark/300" },
    "color/button/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/button/label/primary--default": { light: "base/white", dark: "base/white" },
    "color/button/label/primary--hover": { light: "base/white", dark: "base/white" },
    "color/button/label/secondary--default": { light: "gray/800", dark: "gray-dark/800" },
    "color/button/label/secondary--hover": { light: "gray/800", dark: "gray-dark/800" },
    // ── chip ────────────────────────────────
    "color/chip/line/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/line/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/chip/line/bg/selected": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/border/default": { light: "gray/300", dark: "gray-dark/500" },
    "color/chip/line/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/chip/line/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/line/label/default": { light: "gray/500", dark: "gray-dark/700" },
    "color/chip/line/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/line/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/chip/solid/bg/default": { light: "gray/50", dark: "gray-dark/300" },
    "color/chip/solid/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/bg/hover": { light: "gray/100", dark: "gray-dark/400" },
    "color/chip/solid/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/bg/selected-hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/chip/solid/border/default": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/label/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/chip/solid/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/solid/label/selected": { light: "base/white", dark: "base/white" },
    // ── control ────────────────────────────────
    "color/control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/control/bg/disabled": { light: "gray/100", dark: "gray-dark/300" },
    "color/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/control/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/control/border/disabled": { light: "gray/200", dark: "gray-dark/300" },
    "color/control/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/control/indicator/selected": { light: "base/white", dark: "base/white" },
    "color/control/indicator/selected-alt": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/unselected": { light: "gray/300", dark: "gray-dark/400" },
    "color/control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    // ── table (구 data — 2026-06-15 그룹명 변경: data→table, state→cell) ──
    "color/table/border/default": { light: "gray/100", dark: "gray-dark/300" },
    // border/strong = 테이블 세트 외곽 프레임선(상단 2px·하단 1px), #353535(light gray/800·dark gray-dark/700). 셀선(default)과 구분되는 가장 진한 보더.
    //   2026-06-30: 구 border/emphasis 통합·삭제 → strong 으로 일원화(strong 슬롯은 헤더밑줄이 default 로 바뀌며 비어 있었음). 값은 외곽선 #353535 유지.
    "color/table/border/strong": { light: "gray/800", dark: "gray-dark/700" },
    "color/table/header/bg": { light: "gray/0", dark: "gray-dark/200" },
    "color/table/cell/default": { light: "base/white", dark: "gray-dark/100" },
    "color/table/cell/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/table/cell/selected": { light: "blue/50", dark: "blue-dark/100" },
    // ── dropdown ────────────────────────────────
    "color/dropdown/list/bg": { light: "base/white", dark: "gray-dark/100" },
    "color/dropdown/list/border": { light: "gray/200", dark: "gray-dark/500" },
    "color/dropdown/option/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/dropdown/option/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/dropdown/option/bg/selected": { light: "blue/50", dark: "blue-dark/100" },
    "color/dropdown/option/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/dropdown/option/label/hover": { light: "gray/900", dark: "gray-dark/900" },
    "color/dropdown/option/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    // ── form-control ────────────────────────────────
    "color/form-control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/form-control/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/form-control/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/form-control/bg/selected": { light: "base/white", dark: "gray-dark/200" },
    "color/form-control/border/correct": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/form-control/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/form-control/border/error": { light: "red/300", dark: "red-dark/350" },
    "color/form-control/border/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/text/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/placeholder": { light: "gray/500", dark: "gray-dark/600" },
    "color/form-control/text/selected": { light: "gray/900", dark: "gray-dark/800" },
    // ── icon ────────────────────────────────
    "color/icon/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/icon/gray": { light: "gray-dark/600", dark: "gray-dark/700" },
    "color/icon/gray-dark": { light: "gray/800", dark: "gray-dark/800" },
    "color/icon/gray-light": { light: "gray/300", dark: "gray-dark/400" },
    "color/icon/red": { light: "red/300", dark: "red-dark/350" },
    "color/icon/white": { light: "base/white", dark: "base/white" },
    // ── line ────────────────────────────────
    "color/line/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/line/gray/subtle": { light: "gray/100", dark: "gray-dark/300" },
    // ── navigation ────────────────────────────────
    "color/navigation/bg": { light: "base/white", dark: "gray-dark/100" },
    "color/navigation/indicator/default": { light: "gray/200", dark: "gray-dark/300" },
    "color/navigation/indicator/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/indicator/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/default": { light: "gray/600", dark: "gray-dark/600" },
    "color/navigation/label/default-alt": { light: "gray/700", dark: "gray-dark/700" },
    "color/navigation/label/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/selected": { light: "blue/400", dark: "blue-dark/300" },
    // ── overlay ────────────────────────────────
    "color/overlay": { light: "rgba(0,0,0,0.5)", dark: "rgba(0,0,0,0.75)" },
    // wheel-fade: Time Picker Mobile Bottom Sheet 휠 위/아래 흐림 마스크의 '표면색 베이스'.
    //   alpha 그라데이션은 별도 마스크(구조적 alpha)로 구현하고, 이 토큰은 solid 표면색만 담당한다.
    //   → 다크모드에서 시트 표면색(gray-dark/100)으로 자연스럽게 fade(흰색 누출 방지). Figma 정본 VariableID:916:2.
    "color/overlay/wheel-fade": { light: "base/white", dark: "gray-dark/100" },
    // ── date-picker ────────────────────────────────
    // 신설: components.html 의 .s1-date-picker__* CSS 토큰 사용 기반
    // 레거시 semantic 컬렉션에 없던 그룹 — 우리 코드의 datepicker 디자인 정합
    // panel(패널 배경·테두리) / cell(날짜칸 배경·테두리) 분리 + icon(헤더 < >) 신설 — 사용자 결정 2026-06-26 (값 보존, 이름만 이동)
    "color/date-picker/panel/bg": { light: "base/white", dark: "gray-dark/100" },
    // 2026-07-29: 라이트를 gray/300 → gray/200 으로 변경. 패널 보더 4종(Modal·Dropdown·
    //   Time Picker Dropdown·Date Picker)을 같은 값으로 통일(사용자 결정). 다크는 불변.
    "color/date-picker/panel/border": { light: "gray/200", dark: "gray-dark/500" },
    "color/date-picker/cell/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/date-picker/cell/bg/today": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/cell/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/cell/bg/selected-hover": { light: "blue/500", dark: "blue-dark/250" },
    // (B)유형: 선택된 파란 칸의 hover는 회색 아닌 더 진한 파랑. chip-solid selected-hover 와 동일 단계.
    "color/date-picker/cell/bg/range": { light: "blue/50", dark: "blue-dark/100" },
    "color/date-picker/cell/border/today": { light: "blue/400", dark: "blue-dark/300" },
    // icon(헤더 이전/다음 < > — 현재 적용색 gray/900 보존, hover/disabled 신규)
    "color/date-picker/icon/default": { light: "gray/900", dark: "gray-dark/900" },
    "color/date-picker/icon/hover": { light: "gray/800", dark: "gray-dark/800" },
    "color/date-picker/icon/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/date-picker/text/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/date-picker/text/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/date-picker/text/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/date-picker/text/other-month": { light: "gray/300", dark: "gray-dark/400" },
    "color/date-picker/text/sunday": { light: "red/300", dark: "red-dark/350" },
    "color/date-picker/text/saturday": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/today": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/selected": { light: "base/white", dark: "base/white" },
    "color/date-picker/tile/bg/default": { light: "base/white", dark: "gray-dark/100" },
    // tile hover = Secondary 버튼 hover foundation 동일(gray/50·gray-dark/200) — Calendar Tile Hover variant, 사용자 결정 2026-06-25
    "color/date-picker/tile/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/date-picker/tile/bg/selected": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/tile/bg/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/date-picker/tile/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/date-picker/tile/border/disabled": { light: "gray/100", dark: "gray-dark/300" },
    // ── modal ────────────────────────────────
    // 딤 위 팝업 셸(buildModalShell)의 패널 테두리. 2026-07-29 신설(사용자 결정).
    //   컴포넌트별 그룹으로 둔 이유: semantic.md 2026-06-23 정리가 "테두리는 color-line-* 및
    //   컴포넌트별 *-border-* 로 분산"이라 명시했고(보더 33건 중 28건이 컴포넌트별),
    //   color/surface/* 는 2026-06-30 에 의도적으로 드롭돼 raised 하나만 남은 그룹이라 확장 대상이 아니다.
    //   값이 같아도 별도 키를 두는 것이 이 저장소 관례(gray/200+gray-dark/500 조합을 이미 8키가 각자 보유).
    //   배경은 color/surface/raised 를 그대로 쓴다(이 그룹에 bg 를 만들지 않는다).
    "color/modal/panel/border": { light: "gray/200", dark: "gray-dark/500" },
    // ── pagination ────────────────────────────────
    "color/pagination/control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/pagination/control/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/pagination/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    // control(화살표/edge 버튼 박스) = Secondary 버튼과 동일 foundation (bg=base/white·hover=gray/50·border=gray/200) — 사용자 결정 2026-06-25
    "color/pagination/control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/pagination/control/border/disabled": { light: "gray/100", dark: "gray-dark/300" },
    "color/pagination/control/border/hover": { light: "gray/200", dark: "gray-dark/500" },
    // control/icon(화살표·edge 글리프) = Secondary 버튼 라벨과 동일 foundation (active=gray/800·disabled=gray/300) — 사용자 결정 2026-06-26
    "color/pagination/control/icon/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/hover": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/selected": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/disabled": { light: "gray/300", dark: "gray-dark/600" },
    // number(페이지 번호) = 기존 적용 색 보존: default·hover=text/state/helper(gray/400)·selected=text/body/secondary(gray/800) — 사용자 결정 2026-06-26
    "color/pagination/number/default": { light: "gray/400", dark: "gray-dark/600" },
    "color/pagination/number/hover": { light: "gray/400", dark: "gray-dark/600" },
    "color/pagination/number/selected": { light: "gray/800", dark: "gray-dark/800" },
    // ── status-card ────────────────────────────────
    "color/status-card/text/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/status-card/text/error": { light: "red/300", dark: "red-dark/350" },
    "color/status-card/text/primary--default": { light: "gray/900", dark: "gray-dark/900" },
    "color/status-card/text/primary--sub": { light: "gray/800", dark: "gray-dark/800" },
    "color/status-card/text/secondary--default": { light: "gray/600", dark: "gray-dark/700" },
    "color/status-card/text/secondary--sub": { light: "gray/500", dark: "gray-dark/700" },
    "color/status-card/text/tertiary--default": { light: "gray/400", dark: "gray-dark/600" },
    "color/status-card/text/tertiary--sub": { light: "gray/300", dark: "gray-dark/400" },
    // ── text ────────────────────────────────
    "color/text/body/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/text/body/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/text/body/tertiary": { light: "gray/500", dark: "gray-dark/700" },
    "color/text/state/accent": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/accent-inverse": { light: "base/white", dark: "base/white" },
    "color/text/state/caption": { light: "gray/500", dark: "gray-dark/800" },
    "color/text/state/caution": { light: "red/300", dark: "red-dark/350" },
    "color/text/state/correct": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/text/state/helper": { light: "gray/400", dark: "gray-dark/600" },
    "color/text/title/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/text/title/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/icon/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/form-control/icon/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/scroll/bg": { light: "gray/200", dark: "gray-dark/600" },
    "color/form-control/text-cursor": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/text/read-only": { light: "gray/500", dark: "gray-dark/700" }
  };
  var SEMANTIC_NUMBER = {
    // ── spacing/label-gap ─────────────────
    "spacing/label-gap-inline/sm": "spacing/8",
    "spacing/label-gap-inline/md": "spacing/12",
    "spacing/label-gap-inline/lg": "spacing/16",
    "spacing/label-gap-block/sm": "spacing/4",
    "spacing/label-gap-block/md": "spacing/8",
    // ── sizing (semantic) ─────────────────
    // 2026-06-12 폐지: 컴포넌트별 사이징(form-control-height·button-height·chip-height·
    //   table-row-height·dropdown-item-height·icon·button-min-width)을 전부 제거하고
    //   컴포넌트가 Foundation --sizing-N 을 직접 참조하도록 전환(사용자 결정).
    //   값 보존: 모든 옛 토큰이 Foundation sizing step과 1:1 매핑됨.
    // ── radius semantic ───────────────────
    "radius/control/xs": "radius/2",
    "radius/control/sm": "radius/4",
    "radius/button/md": "radius/4",
    "radius/card/md": "radius/10",
    "radius/modal/md": "radius/8"
  };

  // plugins/figma-vars-installer/src/shadow-parse.ts
  function shadowVarName(token, layerIndex, field) {
    const letters = "abcdefghijklmnopqrstuvwxyz";
    if (layerIndex < 0 || layerIndex >= letters.length) {
      throw new Error(`[shadow-parse] \uACB9 \uC778\uB371\uC2A4\uAC00 \uBC94\uC704\uB97C \uBC97\uC5B4\uB0AC\uC2B5\uB2C8\uB2E4: ${layerIndex}`);
    }
    return `${token}/layer-${letters[layerIndex]}/${field}`;
  }
  function splitShadowLayers(css) {
    const out = [];
    let depth = 0;
    let buf = "";
    for (let i = 0; i < css.length; i++) {
      const ch = css[i];
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
      if (ch === "," && depth === 0) {
        out.push(buf.trim());
        buf = "";
        continue;
      }
      buf += ch;
    }
    if (buf.trim()) out.push(buf.trim());
    if (depth !== 0) throw new Error(`[shadow-parse] \uAD04\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    return out;
  }
  function parseRgba(token, ctx) {
    const m = token.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/i);
    if (!m) throw new Error(`[shadow-parse] \uC0C9\uC744 \uD574\uC11D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
    const a = m[4] === void 0 ? 1 : Number(m[4]);
    for (const [name, v, max] of [["r", r, 255], ["g", g, 255], ["b", b, 255], ["a", a, 1]]) {
      if (!isFinite(v) || v < 0 || v > max) {
        throw new Error(`[shadow-parse] \uC0C9 \uC131\uBD84 ${name}=${v} \uC774 \uBC94\uC704\uB97C \uBC97\uC5B4\uB0AC\uC2B5\uB2C8\uB2E4 (\uACB9: ${ctx})`);
      }
    }
    return { r: r / 255, g: g / 255, b: b / 255, a };
  }
  function parseLength(token, ctx) {
    const m = token.match(/^(-?[\d.]+)(px)?$/i);
    if (!m) throw new Error(`[shadow-parse] \uAE38\uC774\uAC12\uC744 \uD574\uC11D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    const n = Number(m[1]);
    if (!isFinite(n)) throw new Error(`[shadow-parse] \uAE38\uC774\uAC12\uC774 \uC22B\uC790\uAC00 \uC544\uB2D9\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    return n;
  }
  function parseShadowLayer(layer) {
    const src = layer.trim();
    if (!src) throw new Error("[shadow-parse] \uBE48 \uACB9 \uBB38\uC790\uC5F4\uC785\uB2C8\uB2E4.");
    if (/\binset\b/i.test(src)) {
      throw new Error(`[shadow-parse] inset \uC740 DropShadow \uAC00 \uC544\uB2C8\uB77C InnerShadow \uC785\uB2C8\uB2E4(\uBBF8\uC9C0\uC6D0): ${JSON.stringify(src)}`);
    }
    const colorMatch = src.match(/rgba?\([^)]*\)/i);
    if (!colorMatch) {
      throw new Error(`[shadow-parse] \uC0C9(rgb/rgba)\uC774 \uC5C6\uC2B5\uB2C8\uB2E4: ${JSON.stringify(src)} \u2014 \uADF8\uB9BC\uC790 \uC0C9\uC740 rgba \uB85C \uC801\uB294\uB2E4(EX07).`);
    }
    const color = parseRgba(colorMatch[0], src);
    const rest = (src.slice(0, colorMatch.index) + " " + src.slice((colorMatch.index || 0) + colorMatch[0].length)).trim();
    const lengths = rest.split(/\s+/).filter(Boolean);
    if (lengths.length < 3 || lengths.length > 4) {
      throw new Error(
        `[shadow-parse] \uAE38\uC774\uAC12\uC774 ${lengths.length}\uAC1C\uC785\uB2C8\uB2E4(3 \uB610\uB294 4\uC5EC\uC57C \uD568: x y blur [spread]): ${JSON.stringify(src)}`
      );
    }
    const offsetX = parseLength(lengths[0], src);
    const offsetY = parseLength(lengths[1], src);
    const blur = parseLength(lengths[2], src);
    const spread = lengths.length === 4 ? parseLength(lengths[3], src) : 0;
    if (blur < 0) throw new Error(`[shadow-parse] blur \uB294 0 \uC774\uC0C1\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4(Figma \uC81C\uC57D): ${JSON.stringify(src)}`);
    return { offsetX, offsetY, blur, spread, color };
  }
  function parseCssShadow(css) {
    if (typeof css !== "string" || !css.trim()) {
      throw new Error(`[shadow-parse] \uBE48 \uAC12\uC785\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    }
    if (css.trim() === "none") {
      throw new Error("[shadow-parse] 'none' \uC740 Effect \uB85C \uBCC0\uD658\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD638\uCD9C\uBD80\uC5D0\uC11C \uAC78\uB7EC\uC57C \uD569\uB2C8\uB2E4.");
    }
    const layers = splitShadowLayers(css).map(parseShadowLayer);
    if (layers.length === 0) throw new Error(`[shadow-parse] \uACB9\uC744 \uD558\uB098\uB3C4 \uCD94\uCD9C\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    return layers;
  }
  function toDropShadowEffects(css) {
    return parseCssShadow(css).map((l) => ({
      type: "DROP_SHADOW",
      color: l.color,
      offset: { x: l.offsetX, y: l.offsetY },
      radius: l.blur,
      spread: l.spread,
      visible: true,
      blendMode: "NORMAL"
    }));
  }

  // plugins/figma-vars-installer/src/textstyles-data.ts
  var TEXT_STYLE_FONT_FAMILY = "Pretendard";
  var TEXT_STYLES = [
    // caption·helper 폐기(2026-06-12): body/12R와 값 동일 → body/12R 사용. (D4)
    // ── title ───────────────────────────────────────────
    { name: "title/32B", fontStyle: "Bold", fontSize: 32, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // title/32R: V2.4 패널엔 없던 신규 추가(2026-07-07). Time Picker Mobile Bottom Sheet 휠(32px accent 숫자)이
    //   Pretendard Regular 32 를 named 텍스트 스타일로 바인딩(setTextStyleIdAsync)할 수 있게 하기 위함.
    //   MCP(use_figma)는 폰트 직접 로드 불가 → named 스타일이 있어야 폰트 로드 없이 Pretendard 유지 가능.
    //   geometry 는 title/32B(32·130·0) 와 동일, weight 만 Regular. (title/20R 선례와 동일 계열.)
    { name: "title/32R", fontStyle: "Regular", fontSize: 32, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/24B", fontStyle: "Bold", fontSize: 24, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20B", fontStyle: "Bold", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20R", fontStyle: "Regular", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/16B", fontStyle: "Bold", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/14B", fontStyle: "Bold", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // ── body ────────────────────────────────────────────
    { name: "body/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16R", fontStyle: "Regular", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14M", fontStyle: "Medium", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14R", fontStyle: "Regular", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/12M", fontStyle: "Medium", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/12R", fontStyle: "Regular", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/10M", fontStyle: "Medium", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 },
    { name: "body/10R", fontStyle: "Regular", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 }
  ];

  // plugins/figma-vars-installer/src/install-textstyles.ts
  async function getOrCreateTextStyle(name) {
    const all = await figma.getLocalTextStylesAsync();
    const existing = all.find((s) => s.name === name);
    if (existing) return existing;
    return figma.createTextStyle();
  }
  async function loadRequiredFonts() {
    const styles = Array.from(new Set(TEXT_STYLES.map((s) => s.fontStyle)));
    for (const style of styles) {
      try {
        await figma.loadFontAsync({ family: TEXT_STYLE_FONT_FAMILY, style });
      } catch (e) {
        throw new Error(
          `\uD3F0\uD2B8 \uB85C\uB4DC \uC2E4\uD328: ${TEXT_STYLE_FONT_FAMILY} ${style}. \uC774 Figma \uD30C\uC77C/\uD658\uACBD\uC5D0 Pretendard ${style} \uAC00 \uC124\uCE58\uB418\uC5B4 \uC788\uB294\uC9C0 \uD655\uC778\uD558\uC138\uC694.`
        );
      }
    }
  }
  async function installTextStyles(onProgress, pctFrom = 70, pctTo = 85) {
    await loadRequiredFonts();
    const map = {};
    for (let i = 0; i < TEXT_STYLES.length; i++) {
      const def = TEXT_STYLES[i];
      const ts = await getOrCreateTextStyle(def.name);
      ts.name = def.name;
      ts.fontName = { family: TEXT_STYLE_FONT_FAMILY, style: def.fontStyle };
      ts.fontSize = def.fontSize;
      ts.lineHeight = { unit: "PERCENT", value: def.lineHeightPercent };
      ts.letterSpacing = { unit: "PERCENT", value: def.letterSpacingPercent };
      map[def.name] = ts;
      if (onProgress) {
        const pct = pctFrom + Math.round(i / TEXT_STYLES.length * (pctTo - pctFrom));
        onProgress(`Text Style: ${def.name}`, pct);
      }
    }
    return map;
  }

  // plugins/figma-vars-installer/src/build-components.ts
  var BUILT_SETS = {};
  var BUILT_COMPS = {};
  var TEXT_STYLES2 = {};
  function textStyleKey(fontSize, style) {
    const letter = style === "Bold" ? "B" : style === "Medium" ? "M" : "R";
    let size = fontSize;
    if (size === 13) size = 14;
    if (size === 9) size = 10;
    if (size === 20 && letter === "M") size = 18;
    if (size === 32 && letter === "R") return "title/32R";
    return `${letter === "B" ? "title" : "body"}/${size}${letter}`;
  }
  async function getBuiltSet(name) {
    if (BUILT_SETS[name]) return BUILT_SETS[name];
    try {
      const f = figma.currentPage.findOne((n) => n.type === "COMPONENT_SET" && n.name === name);
      return f || null;
    } catch (e) {
      return null;
    }
  }
  function setMode(node, maps, modeId) {
    try {
      node.setExplicitVariableModeForCollection(maps.semanticColorCollectionId, modeId);
    } catch (e) {
      console.warn("[SW Installer] \uBAA8\uB4DC \uC5F0\uACB0 \uC2E4\uD328:", e);
    }
    const sCid = maps.semanticShadowCollectionId;
    if (sCid) {
      const isDark = modeId === maps.semanticDarkModeId;
      const sMid = isDark ? maps.semanticShadowDarkModeId : maps.semanticShadowLightModeId;
      if (sMid) {
        try {
          node.setExplicitVariableModeForCollection(sCid, sMid);
        } catch (e) {
        }
      }
    }
  }
  function shadowEffects(token) {
    const entry = SEMANTIC_SHADOW[token];
    if (!entry) throw new Error(`[build-components] SEMANTIC_SHADOW \uC5D0 '${token}' \uC774 \uC5C6\uC2B5\uB2C8\uB2E4.`);
    return toDropShadowEffects(entry.light);
  }
  function boundShadowEffects(maps, token) {
    const base = shadowEffects(token);
    const vars = maps.shadowVars;
    if (!vars) return base;
    return base.map((eff, i) => {
      let out = eff;
      const bind = (field, name) => {
        const v = vars[name];
        if (!v) return;
        try {
          out = figma.variables.setBoundVariableForEffect(out, field, v);
        } catch (e) {
        }
      };
      bind("color", shadowVarName(token, i, "color"));
      bind("offsetY", shadowVarName(token, i, "offset-y"));
      bind("radius", shadowVarName(token, i, "blur"));
      bind("spread", shadowVarName(token, i, "spread"));
      return out;
    });
  }
  function setLightMode(node, maps) {
    setMode(node, maps, maps.semanticLightModeId);
  }
  var PLATFORMS = [
    { name: "PC", sizes: ["MD", "XSM", "XXSM"] },
    { name: "Mobile", sizes: ["LG"] }
  ];
  var VARIANTS = ["primary", "secondary", "blue-line"];
  var VARIANT_LABEL = {
    primary: "Primary",
    secondary: "Secondary",
    "blue-line": "Blue-Line"
  };
  var SIZE_CONFIG = {
    MD: { break: "PC", height: 44, padPath: "spacing/16", textStyle: "body/14M", minWidth: 80 },
    XSM: { break: "PC", height: 34, padPath: "spacing/8", textStyle: "body/14M", minWidth: 64 },
    XXSM: { break: "PC", height: 28, padPath: "spacing/8", textStyle: "body/12M", minWidth: 64 },
    LG: { break: "Mobile", height: 48, padPath: "spacing/16", textStyle: "body/16M", minWidth: 80 }
  };
  var SIZES = ["MD", "XSM", "XXSM", "LG"];
  var STATES = ["Default", "Hover", "Pressed", "Disabled"];
  var CELL_W = 132;
  var CELL_H = 60;
  var SPEC_LIGHT_X = 1040;
  var SPEC_DARK_X = 2080;
  var INPUT_SHEET_X = 4200;
  function variantSlots(variant, state) {
    if (state === "Disabled") {
      return {
        bg: "color/button/bg/disabled",
        border: "color/button/border/disabled",
        label: "color/button/label/disabled"
      };
    }
    const suffix = state === "Default" ? "default" : "hover";
    return {
      bg: `color/button/bg/${variant}--${suffix}`,
      border: `color/button/border/${variant}--${suffix}`,
      label: `color/button/label/${variant}--${suffix}`
    };
  }
  function boundPaint(variable) {
    const paint = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
    return figma.variables.setBoundVariableForPaint(paint, "color", variable);
  }
  function requireVar(map, key, kind) {
    const v = map[key];
    if (!v) throw new Error(`${kind} \uBCC0\uC218 \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Variables \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return v;
  }
  function requireStyle(map, key) {
    const s = map[key];
    if (!s) throw new Error(`Text Style \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Text Styles \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return s;
  }
  async function buildOne(variant, size, state, maps) {
    const cfg = SIZE_CONFIG[size];
    const slots = variantSlots(variant, state);
    const comp = figma.createComponent();
    comp.name = `Size=${size}, State=${state}, Variant=${VARIANT_LABEL[variant]}, Break=${cfg.break}`;
    comp.layoutMode = "HORIZONTAL";
    comp.primaryAxisAlignItems = "CENTER";
    comp.counterAxisAlignItems = "CENTER";
    comp.primaryAxisSizingMode = "AUTO";
    comp.counterAxisSizingMode = "FIXED";
    const padVar = requireVar(maps.foundationNumber, cfg.padPath, "Foundation Number");
    comp.paddingTop = 0;
    comp.paddingBottom = 0;
    comp.setBoundVariable("paddingLeft", padVar);
    comp.setBoundVariable("paddingRight", padVar);
    comp.minWidth = cfg.minWidth;
    await figma.loadFontAsync({ family: "Pretendard", style: "Medium" });
    const text = figma.createText();
    text.fontName = { family: "Pretendard", style: "Medium" };
    text.characters = "\uBC84\uD2BC";
    const ts = requireStyle(maps.textStyles, cfg.textStyle);
    await text.setTextStyleIdAsync(ts.id);
    text.fills = [boundPaint(requireVar(maps.semanticColor, slots.label, "Semantic Color"))];
    comp.appendChild(text);
    comp.fills = [boundPaint(requireVar(maps.semanticColor, slots.bg, "Semantic Color"))];
    comp.strokes = [boundPaint(requireVar(maps.semanticColor, slots.border, "Semantic Color"))];
    comp.strokeAlign = "INSIDE";
    const bwVar = requireVar(maps.foundationNumber, "border-width/1", "Foundation Number");
    comp.setBoundVariable("strokeWeight", bwVar);
    const radiusVar = requireVar(maps.foundationNumber, "radius/4", "Foundation Number");
    comp.setBoundVariable("topLeftRadius", radiusVar);
    comp.setBoundVariable("topRightRadius", radiusVar);
    comp.setBoundVariable("bottomLeftRadius", radiusVar);
    comp.setBoundVariable("bottomRightRadius", radiusVar);
    comp.resize(comp.width, cfg.height);
    setLightMode(comp, maps);
    return comp;
  }
  async function makeLabel(text, fontSize, style, x, y, w, align, color) {
    await figma.loadFontAsync({ family: "Pretendard", style });
    const t = figma.createText();
    t.fontName = { family: "Pretendard", style };
    t.fontSize = fontSize;
    t.characters = text;
    t.textAutoResize = "HEIGHT";
    t.resize(w, t.height);
    t.textAlignHorizontal = align;
    t.x = x;
    t.y = y;
    t.fills = [{ type: "SOLID", color }];
    return t;
  }
  function specPalette(dark) {
    return {
      bg: dark ? { r: 0.075, g: 0.078, b: 0.094 } : { r: 1, g: 1, b: 1 },
      title: dark ? { r: 0.95, g: 0.95, b: 0.96 } : { r: 0.07, g: 0.07, b: 0.09 },
      platform: dark ? { r: 0.9, g: 0.9, b: 0.92 } : { r: 0.13, g: 0.13, b: 0.13 },
      size: dark ? { r: 0.78, g: 0.8, b: 0.84 } : { r: 0.25, g: 0.27, b: 0.3 },
      label: dark ? { r: 0.6, g: 0.62, b: 0.67 } : { r: 0.42, g: 0.45, b: 0.5 },
      band: dark ? { r: 0.14, g: 0.15, b: 0.18 } : { r: 0.93, g: 0.94, b: 0.96 }
    };
  }
  function specWidth(rowLabelW, cols, cellW) {
    return 24 * 2 + rowLabelW + cols * cellW;
  }
  async function renderGrouped(opts, dark, emit) {
    const PAD = 24, TITLE_H = 34, PLATFORM_GAP = 20, BAND_H = 32, SIZE_GAP = 14, SIZE_TITLE_H = 22, HEADER_H = 24;
    const gridLeft = PAD + opts.rowLabelW;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const c = specPalette(dark);
    let y = PAD;
    await emit.text(`${opts.title} \xB7 ${dark ? "Dark" : "Light"}`, PAD, y, 320, "LEFT", c.title, 14, "Bold");
    y += TITLE_H;
    for (const plat of opts.platforms) {
      y += PLATFORM_GAP;
      emit.band(PAD, y, W - PAD * 2, BAND_H, c.band);
      await emit.text(plat.name, PAD + 12, y + 8, 200, "LEFT", c.platform, 13, "Bold");
      y += BAND_H + 4;
      for (const size of plat.sizes) {
        y += SIZE_GAP;
        if (size) {
          await emit.text(size, PAD, y, 200, "LEFT", c.size, 12, "Bold");
          y += SIZE_TITLE_H;
        }
        for (let col = 0; col < opts.colHeaders.length; col++) {
          if (opts.colHeaders[col]) await emit.text(opts.colHeaders[col], gridLeft + col * opts.cellW, y, opts.cellW, "CENTER", c.label, 12, "Medium");
        }
        y += HEADER_H;
        for (let ri = 0; ri < opts.rowLabels.length; ri++) {
          let rowH = 0;
          for (let ci = 0; ci < opts.colHeaders.length; ci++) {
            const cp = opts.cellAt(plat.name, size, ri, ci);
            if (cp && cp.height > rowH) rowH = cp.height;
          }
          rowH = (rowH || opts.cellH) + 16;
          const top = y + 4;
          if (opts.rowLabels[ri]) await emit.text(opts.rowLabels[ri], PAD, top, opts.rowLabelW, "LEFT", c.label, 12, "Medium");
          for (let ci = 0; ci < opts.colHeaders.length; ci++) {
            const comp = opts.cellAt(plat.name, size, ri, ci);
            if (comp) emit.cell(comp, gridLeft + ci * opts.cellW + (opts.cellW - comp.width) / 2, top);
          }
          y += rowH;
        }
      }
    }
    return y + PAD;
  }
  function frameEmit(frame, maps, modeId) {
    return {
      text: async (s, x, y, w, al, col, fs, st) => {
        frame.appendChild(await makeLabel(s, fs, st, x, y, w, al, col));
      },
      band: (x, y, w, h, col) => {
        const b = figma.createRectangle();
        b.x = x;
        b.y = y;
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [{ type: "SOLID", color: col }];
        frame.appendChild(b);
      },
      cell: (comp, x, y) => {
        const inst = comp.createInstance();
        frame.appendChild(inst);
        inst.x = x;
        inst.y = y;
        setMode(inst, maps, modeId);
        try {
          inst.findAll((n) => n.type === "INSTANCE").forEach((d) => setMode(d, maps, modeId));
        } catch (e) {
        }
      }
    };
  }
  function floatingEmit(oy, ox = 0) {
    return {
      text: async (s, x, y, w, al, col, fs, st) => {
        await makeLabel(s, fs, st, ox + x, oy + y, w, al, col);
      },
      band: (x, y, w, h, col) => {
        const b = figma.createRectangle();
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [{ type: "SOLID", color: col }];
        b.x = ox + x;
        b.y = oy + y;
      },
      cell: (comp, x, y) => {
        comp.x = x;
        comp.y = y;
      }
    };
  }
  async function buildGroupedSpec(opts, maps) {
    var _a, _b, _c, _d, _e;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const modeId = maps.semanticDarkModeId;
    const frame = figma.createFrame();
    frame.name = `${opts.title} \u2014 Spec Dark`;
    frame.fills = [{ type: "SOLID", color: specPalette(true).bg }];
    frame.cornerRadius = 8;
    frame.resize(W, 2400);
    frame.x = (_c = (_a = opts.darkOffset) == null ? void 0 : _a.x) != null ? _c : ((_b = opts.offsetX) != null ? _b : 0) + W + 80;
    frame.y = (_e = (_d = opts.darkOffset) == null ? void 0 : _d.y) != null ? _e : opts.originY;
    const H = await renderGrouped(opts, true, frameEmit(frame, maps, modeId));
    frame.resize(W, H);
    setMode(frame, maps, modeId);
    return Math.max(opts.originY, frame.y + H);
  }
  async function decorateSetGrouped(set, opts, maps) {
    var _a;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const ox = (_a = opts.offsetX) != null ? _a : 0;
    set.x = ox;
    set.y = opts.originY;
    try {
      set.fills = [{ type: "SOLID", color: specPalette(false).bg }];
    } catch (e) {
    }
    const H = await renderGrouped(opts, false, floatingEmit(opts.originY, ox));
    set.resize(W, H);
    setLightMode(set, maps);
    return opts.originY + H;
  }
  async function buildButtonSet(maps, onProgress, pctFrom = 85, pctTo = 100, originY = 0) {
    const grid = [];
    let i = 0;
    const total = VARIANTS.length * SIZES.length * STATES.length;
    let rowIdx = 0;
    for (const variant of VARIANTS) {
      for (const size of SIZES) {
        for (let c = 0; c < STATES.length; c++) {
          const comp = await buildOne(variant, size, STATES[c], maps);
          grid.push({ comp, variant, size, state: STATES[c], row: rowIdx, col: c });
          i++;
          if (onProgress) {
            const pct = pctFrom + Math.round(i / total * (pctTo - pctFrom));
            onProgress(`Button: ${VARIANT_LABEL[variant]}/${size}/${STATES[c]}`, pct);
          }
        }
        rowIdx++;
      }
    }
    const set = figma.combineAsVariants(grid.map((g) => g.comp), figma.currentPage);
    set.name = "Button";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Button"] = set;
    grid.forEach((g) => {
      BUILT_COMPS[`Button:${g.variant}:${g.size}:${g.state}`] = g.comp;
    });
    const opts = {
      title: "Button",
      platforms: PLATFORMS,
      rowLabels: VARIANTS.map((v) => VARIANT_LABEL[v]),
      colHeaders: STATES,
      cellAt: (_p, size, ri, ci) => {
        var _a, _b;
        return (_b = (_a = grid.find((g) => g.variant === VARIANTS[ri] && g.size === size && g.state === STATES[ci])) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: CELL_W,
      cellH: CELL_H,
      rowLabelW: 88
    };
    const setH = await decorateSetGrouped(set, opts, maps);
    setLightMode(set, maps);
    let bottomY = set.y + setH;
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn("[SW Installer] Dark \uC2A4\uD399 \uD504\uB808\uC784 \uC2E4\uD328 (\uC138\uD2B8\uB294 \uC815\uC0C1):", e);
    }
    figma.viewport.scrollAndZoomIntoView([set]);
    return { set, bottomY };
  }
  function scv(maps, key) {
    return requireVar(maps.semanticColor, key, "Semantic Color");
  }
  async function makeBoundText(chars, fontSize, style, colorVar) {
    await figma.loadFontAsync({ family: "Pretendard", style });
    const t = figma.createText();
    t.fontName = { family: "Pretendard", style };
    t.fontSize = fontSize;
    t.characters = chars;
    const ts = TEXT_STYLES2[textStyleKey(fontSize, style)];
    if (ts) {
      try {
        await t.setTextStyleIdAsync(ts.id);
      } catch (e) {
      }
    }
    t.fills = [boundPaint(colorVar)];
    return t;
  }
  async function makeCheckIcon(strokeVar) {
    const svg = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2.9375 8L6.13252 11.375L13.0625 4.625" stroke="#FFFFFF" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
    return makeIconInstance("check", strokeVar, 16, svg);
  }
  async function renderFlat(opts, dark, emit) {
    var _a;
    const PAD = 24, TITLE_H = 30, HEADER_H = 24;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const gridLeft = PAD + rowLabelW;
    const c = specPalette(dark);
    let y = PAD;
    await emit.text(`${opts.title} \xB7 ${dark ? "Dark" : "Light"}`, PAD, y, 320, "LEFT", c.title, 14, "Bold");
    y += TITLE_H;
    for (let col = 0; col < opts.colHeaders.length; col++) {
      if (opts.colHeaders[col]) await emit.text(opts.colHeaders[col], gridLeft + col * opts.cellW, y, opts.cellW, "CENTER", c.label, 11, "Medium");
    }
    y += HEADER_H;
    for (let r = 0; r < opts.rowLabels.length; r++) {
      let rowH = 0;
      for (let cc = 0; cc < opts.colHeaders.length; cc++) {
        const cp = opts.cellAt(r, cc);
        if (cp && cp.height > rowH) rowH = cp.height;
      }
      rowH = (rowH || opts.cellH) + 16;
      const top = y + 4;
      if (opts.rowLabels[r]) await emit.text(opts.rowLabels[r], PAD, top, rowLabelW, "LEFT", c.label, 11, "Medium");
      for (let cc = 0; cc < opts.colHeaders.length; cc++) {
        const comp = opts.cellAt(r, cc);
        if (comp) {
          const cellX = opts.leftAlignCells ? gridLeft + cc * opts.cellW : gridLeft + cc * opts.cellW + (opts.cellW - comp.width) / 2;
          emit.cell(comp, cellX, top);
        }
      }
      y += rowH;
    }
    return y + PAD;
  }
  async function buildSpec(opts, maps) {
    var _a, _b, _c, _d, _e;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const W = specWidth(rowLabelW, opts.colHeaders.length, opts.cellW);
    const modeId = maps.semanticDarkModeId;
    const frame = figma.createFrame();
    frame.name = `${opts.title} \u2014 Spec Dark`;
    frame.fills = [{ type: "SOLID", color: specPalette(true).bg }];
    frame.cornerRadius = 8;
    frame.resize(W, 1600);
    frame.x = (_c = (_b = opts.darkOffset) == null ? void 0 : _b.x) != null ? _c : W + 80;
    frame.y = (_e = (_d = opts.darkOffset) == null ? void 0 : _d.y) != null ? _e : opts.originY;
    const H = await renderFlat(opts, true, frameEmit(frame, maps, modeId));
    frame.resize(W, H);
    setMode(frame, maps, modeId);
    return Math.max(opts.originY, frame.y + H);
  }
  async function decorateSetFlat(set, opts, maps) {
    var _a;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const W = specWidth(rowLabelW, opts.colHeaders.length, opts.cellW);
    set.x = 0;
    set.y = opts.originY;
    try {
      set.fills = [{ type: "SOLID", color: specPalette(false).bg }];
    } catch (e) {
    }
    const H = await renderFlat(opts, false, floatingEmit(opts.originY));
    set.resize(W, H);
    setLightMode(set, maps);
    return opts.originY + H;
  }
  async function buildCheckbox(maps, originY) {
    const states = [
      { name: "Default", bg: "color/control/bg/default", border: "color/control/border/default" },
      { name: "Hover", bg: "color/control/bg/hover", border: "color/control/border/default" },
      { name: "Checked", bg: "color/control/bg/selected", border: "color/control/border/selected", check: "color/control/indicator/selected" },
      { name: "Disabled", bg: "color/control/bg/disabled", border: "color/control/border/disabled" },
      { name: "Dis+Checked", bg: "color/control/bg/disabled", border: "color/control/border/disabled", check: "color/control/indicator/disabled" }
    ];
    const comps = [];
    for (const s of states) {
      const comp = figma.createComponent();
      comp.name = `State=${s.name}`;
      comp.resize(18, 18);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, s.bg))];
      comp.strokes = [boundPaint(scv(maps, s.border))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      if (s.check) {
        const icon = await makeCheckIcon(scv(maps, s.check));
        comp.appendChild(icon);
        icon.x = 1;
        icon.y = 1;
      }
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Checkbox";
    set.x = 0;
    set.y = originY;
    states.forEach((s, i) => {
      BUILT_COMPS[`Checkbox:${s.name}`] = comps[i];
    });
    BUILT_SETS["Checkbox"] = set;
    const opts = {
      title: "Checkbox",
      colHeaders: states.map((s) => s.name),
      rowLabels: [""],
      cellAt: (_r, c) => comps[c],
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 64,
      cellH: 44
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildRadio(maps, originY) {
    const states = [
      { name: "Default", bg: "color/control/bg/default", border: "color/control/border/default" },
      { name: "Hover", bg: "color/control/bg/hover", border: "color/control/border/default" },
      { name: "Selected", bg: "color/control/bg/default", border: "color/control/border/selected", dot: "color/control/indicator/selected-alt" },
      { name: "Disabled", bg: "color/control/bg/disabled", border: "color/control/border/disabled" },
      { name: "Dis+Selected", bg: "color/control/bg/disabled", border: "color/control/border/disabled", dot: "color/control/indicator/disabled" }
    ];
    const labels = ["Off", "On"];
    const comps = [];
    const cells = [];
    for (let row = 0; row < labels.length; row++) {
      for (let col = 0; col < states.length; col++) {
        const s = states[col];
        const lab = labels[row];
        const comp = figma.createComponent();
        comp.name = `State=${s.name}, Label=${lab}`;
        comp.layoutMode = "HORIZONTAL";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        const circle = figma.createFrame();
        circle.name = "circle";
        circle.resize(18, 18);
        circle.cornerRadius = 9;
        circle.fills = [boundPaint(scv(maps, s.bg))];
        circle.strokes = [boundPaint(scv(maps, s.border))];
        circle.strokeWeight = 1;
        circle.strokeAlign = "INSIDE";
        if (s.dot) {
          const dot = figma.createEllipse();
          dot.resize(10, 10);
          dot.fills = [boundPaint(scv(maps, s.dot))];
          circle.appendChild(dot);
          dot.x = 4;
          dot.y = 4;
        }
        comp.appendChild(circle);
        if (lab === "On") {
          const isDis = s.name.indexOf("Dis") === 0 || s.name === "Disabled";
          const labelVar = scv(maps, isDis ? "color/control/label/disabled" : "color/control/label/default");
          comp.appendChild(await makeBoundText("\uB77C\uB514\uC624", 14, "Medium", labelVar));
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Radio";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Radio",
      colHeaders: states.map((s) => s.name),
      rowLabels: labels.map((l) => `Label=${l}`),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 116,
      cellH: 34
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildToggle(maps, originY) {
    const press = ["Off", "On"];
    const sts = ["Default", "Disabled"];
    const comps = [];
    const cells = [];
    for (let row = 0; row < sts.length; row++) {
      for (let col = 0; col < press.length; col++) {
        const st = sts[row];
        const p = press[col];
        const on = p === "On";
        const dis = st === "Disabled";
        const trackKey = dis ? "color/control/bg/disabled" : on ? "color/control/bg/selected" : "color/control/indicator/unselected";
        const comp = figma.createComponent();
        comp.name = `Pressed=${p}, State=${st}`;
        comp.resize(40, 20);
        comp.cornerRadius = 10;
        comp.fills = [boundPaint(scv(maps, trackKey))];
        const knob = figma.createEllipse();
        knob.resize(16, 16);
        const knobKey = dis ? "color/control/indicator/disabled" : "color/control/indicator/selected";
        knob.fills = [boundPaint(scv(maps, knobKey))];
        comp.appendChild(knob);
        knob.y = 2;
        knob.x = on ? 22 : 2;
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Toggle";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Toggle",
      colHeaders: press.map((p) => `Pressed=${p}`),
      rowLabels: sts.map((s) => `State=${s}`),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 72,
      cellH: 36
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildChip(maps, originY) {
    var _a;
    const sizes = [
      { size: "SM", brk: "PC", h: 28, font: 12, pad: 16 },
      { size: "SM", brk: "Mobile", h: 30, font: 14, pad: 12 },
      { size: "MD", brk: "PC", h: 34, font: 14, pad: 16 }
    ];
    const states = ["Default", "Hover", "Selected", "Disabled"];
    const variants = ["Line", "Solid"];
    const slot = (st, v) => st === "Default" ? { bg: "default", bd: "default", lb: "default" } : st === "Hover" ? v === "line" ? { bg: "hover", bd: "default", lb: "default" } : { bg: "hover", bd: "hover", bdGroup: "bg", lb: "default" } : st === "Selected" ? { bg: "selected", bd: "selected", lb: "selected" } : { bg: "disabled", bd: "disabled", lb: "disabled" };
    const comps = [];
    const cells = [];
    let row = 0;
    for (const variant of variants) {
      const v = variant.toLowerCase();
      for (const sc of sizes) {
        for (let col = 0; col < states.length; col++) {
          const ss = slot(states[col], v);
          const comp = figma.createComponent();
          comp.name = `Size=${sc.size}, State=${states[col]}, Variant=${variant}, Break=${sc.brk}`;
          comp.layoutMode = "HORIZONTAL";
          comp.primaryAxisAlignItems = "CENTER";
          comp.counterAxisAlignItems = "CENTER";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "FIXED";
          comp.paddingLeft = sc.pad;
          comp.paddingRight = sc.pad;
          comp.cornerRadius = 999;
          comp.fills = [boundPaint(scv(maps, `color/chip/${v}/bg/${ss.bg}`))];
          comp.strokes = [boundPaint(scv(maps, `color/chip/${v}/${(_a = ss.bdGroup) != null ? _a : "border"}/${ss.bd}`))];
          comp.strokeWeight = 1;
          comp.strokeAlign = "INSIDE";
          comp.appendChild(await makeBoundText("\uB77C\uBCA8", sc.font, "Medium", scv(maps, `color/chip/${v}/label/${ss.lb}`)));
          comp.resize(comp.width, sc.h);
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, row, col, variant, size: sc.size, brk: sc.brk, state: states[col] });
        }
        row++;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Chip";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Chip",
      platforms: [{ name: "PC", sizes: ["SM", "MD"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: variants,
      // Line / Solid
      colHeaders: states,
      cellAt: (platName, size, ri, ci) => {
        var _a2, _b;
        return (_b = (_a2 = cells.find((x) => x.variant === variants[ri] && x.size === size && x.brk === platName && x.state === states[ci])) == null ? void 0 : _a2.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 96,
      cellH: 48,
      rowLabelW: 96
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildInput(maps, originY, originX = INPUT_SHEET_X) {
    const fc = (k) => `color/form-control/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC785\uB825", tc: "text/placeholder" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Editing", bg: "bg/selected", border: "border/selected", txt: "\uD14D\uC2A4\uD2B8", tc: "text/selected" },
      { name: "Error", bg: "bg/default", border: "border/error", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Correct", bg: "bg/default", border: "border/correct", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Read-Only", bg: "bg/disabled", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/read-only" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uC785\uB825", tc: "text/disabled" }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, padL: 12, padR: 8, font: 12, head: "XXSM" },
      { size: "XSM", brk: "PC", h: 34, padL: 12, padR: 8, font: 14, head: "XSM" },
      { size: "MD", brk: "PC", h: 44, padL: 16, padR: 12, font: 14, head: "MD" },
      { size: "MD", brk: "Mobile", h: 48, padL: 16, padR: 12, font: 14, head: "MD\xB7M" }
    ];
    const labels = ["Off", "On"];
    const messages = ["Off", "On"];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        for (const lab of labels) {
          for (const msg of messages) {
            const dis = st.name === "Disabled";
            const field = figma.createFrame();
            field.name = "field";
            field.layoutMode = "HORIZONTAL";
            field.counterAxisAlignItems = "CENTER";
            field.primaryAxisSizingMode = "FIXED";
            field.counterAxisSizingMode = "FIXED";
            field.paddingLeft = sc.padL;
            field.paddingRight = sc.padR;
            field.paddingTop = 0;
            field.paddingBottom = 0;
            field.cornerRadius = 4;
            field.fills = [boundPaint(scv(maps, fc(st.bg)))];
            field.strokes = [boundPaint(scv(maps, fc(st.border)))];
            field.strokeWeight = 1;
            field.strokeAlign = "INSIDE";
            const textNode = await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc)));
            field.primaryAxisAlignItems = "MIN";
            let clearIcon = null;
            if (st.name === "Editing") {
              const lead = figma.createFrame();
              lead.name = "lead";
              lead.fills = [];
              lead.layoutMode = "HORIZONTAL";
              lead.counterAxisAlignItems = "CENTER";
              lead.primaryAxisSizingMode = "AUTO";
              lead.counterAxisSizingMode = "AUTO";
              lead.itemSpacing = 4;
              lead.appendChild(textNode);
              lead.appendChild(makeCaret(scv(maps, fc("text-cursor"))));
              field.appendChild(lead);
              lead.layoutGrow = 1;
              lead.layoutSizingHorizontal = "FILL";
              clearIcon = await makeClearIcon(scv(maps, fc("icon/default")), fcIconPx(sc.h, 0));
            } else {
              textNode.layoutGrow = 1;
              field.appendChild(textNode);
            }
            const eye = await makeIconInstance("eye", scv(maps, fc("icon/default")), sc.size === "XXSM" ? 20 : 24, EYE_OFF_SVG);
            eye.name = "eye";
            eye.visible = false;
            const trail = figma.createFrame();
            trail.name = "trail";
            trail.fills = [];
            trail.layoutMode = "HORIZONTAL";
            trail.counterAxisAlignItems = "CENTER";
            trail.primaryAxisSizingMode = "AUTO";
            trail.counterAxisSizingMode = "AUTO";
            trail.itemSpacing = 2;
            trail.appendChild(eye);
            if (clearIcon) trail.appendChild(clearIcon);
            field.appendChild(trail);
            field.resize(200, sc.h);
            const comp = figma.createComponent();
            comp.name = `Size=${sc.size}, State=${st.name}, Label=${lab}, Message=${msg}, Break=${sc.brk}`;
            comp.layoutMode = "VERTICAL";
            comp.primaryAxisSizingMode = "AUTO";
            comp.counterAxisSizingMode = "AUTO";
            comp.itemSpacing = 6;
            comp.fills = [];
            if (lab === "On") comp.appendChild(await makeBoundText("\uB77C\uBCA8", 14, "Medium", scv(maps, fc(dis ? "label/disabled" : "label/default"))));
            comp.appendChild(field);
            if (msg === "On") {
              const msgColor = dis ? "color/text/state/disabled" : st.name === "Error" ? "color/text/state/caution" : st.name === "Correct" ? "color/text/state/correct" : "color/text/state/caption";
              comp.appendChild(await makeBoundText("\uC548\uB0B4 \uBA54\uC138\uC9C0", 12, "Regular", scv(maps, msgColor)));
            }
            setLightMode(comp, maps);
            comps.push(comp);
            cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name, label: lab, message: msg });
          }
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Input";
    const pwIconPropId = set.addComponentProperty("Password Icon", "BOOLEAN", false);
    for (const c of comps) {
      const f = c.findChild((n) => n.name === "field");
      const eyeLayer = f ? f.findOne((n) => n.name === "eye") : null;
      if (eyeLayer) eyeLayer.componentPropertyReferences = { visible: pwIconPropId };
    }
    const OX = originX;
    set.x = OX;
    set.y = originY;
    const groups = [
      { name: "\uB77C\uBCA8 \uC5C6\uC74C", lab: "Off", msg: "Off" },
      { name: "\uB77C\uBCA8 \uC5C6\uC74C \xB7 \uC548\uB0B4\uBA54\uC2DC\uC9C0", lab: "Off", msg: "On" },
      { name: "\uB77C\uBCA8 \uC788\uC74C", lab: "On", msg: "Off" },
      { name: "\uB77C\uBCA8 \uC788\uC74C \xB7 \uC548\uB0B4\uBA54\uC2DC\uC9C0", lab: "On", msg: "On" }
    ];
    const opts = {
      title: "Input",
      // 플랫폼(PC/Mobile) → 사이즈 → 라벨/메시지 그룹(rowLabels)으로 구분 (Button·SelectBox 패턴과 동일)
      platforms: [
        // cellAt 이 sizeName 으로 cells.size 를 직매칭(x.size === sizeName)하므로
        // cells 의 실제 키(XXSM/XSM/MD)와 동일해야 한다. Issue 8 리네임 잔재(XSMALL/SMALL/MEDIUM)였음 — PC·Mobile 스펙 시트 빈칸 유발.
        { name: "PC", sizes: ["XXSM", "XSM", "MD"] },
        { name: "Mobile", sizes: ["MD"] }
      ],
      rowLabels: groups.map((g) => g.name),
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, sizeName, ri, ci) => {
        var _a, _b;
        const g = groups[ri];
        if (!g) return null;
        return (_b = (_a = cells.find((x) => x.size === sizeName && x.brk === platName && x.state === states[ci].name && x.label === g.lab && x.message === g.msg)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      // 세트(원본) → Light → Dark 를 OX 기준 가로로 나란히. specWidth(110,7,224)=1726, 컬럼 간 80 gap.
      offsetX: OX,
      lightX: OX + 1726 + 80,
      darkX: OX + (1726 + 80) * 2,
      originY,
      cellW: 224,
      cellH: 100,
      rowLabelW: 110
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  function makeStrokeIcon(svg, strokeVar) {
    const node = figma.createNodeFromSvg(svg);
    node.name = "icon";
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      v.strokes = [boundPaint(strokeVar)];
      v.fills = [];
    });
    return node;
  }
  function makeCaret(colorVar) {
    const caret = figma.createRectangle();
    caret.name = "caret";
    caret.resize(1, 16);
    caret.fills = [boundPaint(colorVar)];
    caret.strokes = [];
    return caret;
  }
  var ICON_KEYS = {
    remove: "24b2df622d341e0af21cd4b23b4a7d23b97a5ea7",
    // 삭제(원+X) 439:84
    close: "2a1abbd3597b536e34fd9523fb61eade3afe9934",
    // 닫기(plain-X, 원 없음) ic_닫기 89:4927 — 바텀시트/모달 닫기. remove(원+X)와 구분
    check: "5ab251e0d90adb555ee2fa316f84e86041f19916",
    // 확인(체크마크 ✓) 97:167 — 체크박스 내부용(ic_체크는 박스형이라 ic_확인 사용)
    search: "6b764af642b8883e892754281950da0e971224d7",
    // 찾기/조회(돋보기) 97:127
    clock: "ca1d043ac09be07f827e939be3d8c3c7af8a8dd9",
    // 시간,시계 97:271
    calendar: "ea0ffc118c38048f2cdfb5620be31c120426bb7a",
    // 날짜,달력 70:664
    menu: "5157e9edc76358e2e6bc1a5ebc1539ccf5f2e787",
    // 메뉴(햄버거) 97:227
    account: "a423e2e05cfff2f93062d6a83d6f3bdf79ca9647",
    // 계정/사용자 86:58
    chevron: "e1ac97aa82f4e52f257ac1c0ea77fd09d0e5f581",
    // 화살표,더보기(쉐브론 › 우향 기준) 419:69 — 방향은 rotation 으로(우0·하90·좌180·상270)
    globe: "dee16df7e4ccddbd5dd7aa1d2fbf93f841f5dee2",
    // 인터넷(지구본) 35:3317 — GNB 언어(사용자 지정)
    eye: "d4e9eb5b7e193ee291aa2a7e04396c8de2d2dae7",
    // 비밀번호 미표시(눈+슬래시 ic_비밀번호미표시 Line) — Input Password Icon boolean 기본값. 표시 눈은 인스턴스 스왑으로 교체
    home: "6bf422c937034ce15f6814e5c430d8f85953ed4e"
    // 홈(ic_홈 Solid) 97:292 — V2.2 아이콘 라이브러리. Mobile Bottom Nav
  };
  var EYE_OFF_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" stroke="#353535" stroke-width="1.5"/><circle cx="12" cy="12" r="2.5" stroke="#353535" stroke-width="1.5"/><path d="M4 4l16 16" stroke="#353535" stroke-width="1.5"/></svg>`;
  var HOME_SVG = `<svg width="32" height="32" viewBox="0 0 32 32" fill="none"><path d="M16 5 28 15v11a1 1 0 0 1-1 1h-6v-8h-10v8H5a1 1 0 0 1-1-1V15L16 5Z" fill="#757575"/></svg>`;
  function rebindIconColor(node, colorVar) {
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "BOOLEAN_OPERATION"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      try {
        if (v.isMask) return;
        if (Array.isArray(v.strokes) && v.strokes.some((p) => p.visible !== false)) v.strokes = [boundPaint(colorVar)];
        if (Array.isArray(v.fills) && v.fills.some((p) => p.visible !== false)) v.fills = [boundPaint(colorVar)];
      } catch (e) {
      }
    });
  }
  async function makeIconInstance(role, colorVar, size, fallbackSvg, rotation = 0, opts = {}) {
    const useWrap = opts.wrap !== false;
    try {
      const comp = await figma.importComponentByKeyAsync(ICON_KEYS[role]);
      const inst = comp.createInstance();
      if (!opts.keepName) inst.name = role;
      if (size && size !== inst.width) inst.resize(size, size);
      rebindIconColor(inst, colorVar);
      if (rotation) {
        inst.rotation = rotation;
        if (!useWrap) return inst;
        const wrap = figma.createFrame();
        wrap.name = role;
        wrap.fills = [];
        wrap.clipsContent = false;
        wrap.layoutMode = "HORIZONTAL";
        wrap.primaryAxisAlignItems = "CENTER";
        wrap.counterAxisAlignItems = "CENTER";
        wrap.primaryAxisSizingMode = "FIXED";
        wrap.counterAxisSizingMode = "FIXED";
        wrap.resize(size || inst.width, size || inst.height);
        wrap.appendChild(inst);
        return wrap;
      }
      return inst;
    } catch (e) {
      console.warn(`icon ${role} import \uC2E4\uD328 \u2192 \uBCA1\uD130 \uD3F4\uBC31:`, e);
      const node = figma.createNodeFromSvg(fallbackSvg);
      node.name = role;
      rebindIconColor(node, colorVar);
      return node;
    }
  }
  function centerIconInBox(node, box, sz) {
    const bb = node.absoluteBoundingBox;
    const pb = box.absoluteBoundingBox;
    if (!bb || !pb) {
      node.x = (sz - node.width) / 2;
      node.y = (sz - node.height) / 2;
      return;
    }
    node.x += pb.x + (sz - bb.width) / 2 - bb.x;
    node.y += pb.y + (sz - bb.height) / 2 - bb.y;
  }
  var REMOVE_ICON_SVG = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M16 8C16 3.58588 12.4141 0 8 0C3.58588 0 0 3.58588 0 8C0 12.4141 3.58588 16 8 16C12.4141 16 16 12.4141 16 8ZM8 15.0588C4.10353 15.0588 0.941176 11.8965 0.941176 8C0.941176 4.10353 4.10353 0.941176 8 0.941176C11.8965 0.941176 15.0588 4.10353 15.0588 8C15.0588 11.8965 11.8965 15.0588 8 15.0588Z" fill="#353535"/><path d="M5.5 5.5L10.8333 10.8333" stroke="#353535" stroke-width="1.5" stroke-linejoin="round"/><path d="M10.8333 5.5L5.5 10.8333" stroke="#353535" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
  var CLOSE_ICON_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M6 6L18 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round"/><path d="M18 6L6 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round"/></svg>`;
  async function makeClearIcon(colorVar, size = 0) {
    return makeIconInstance("remove", colorVar, size, REMOVE_ICON_SVG);
  }
  var fcIconPx = (h, _base) => h <= 28 ? 20 : 24;
  async function buildSearch(maps, originY) {
    const fc = (k) => `color/form-control/${k}`;
    const MAG = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="#000" stroke-width="1.3"/><path d="M10.6 10.6L14 14" stroke="#000" stroke-width="1.3" stroke-linecap="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uAC80\uC0C9", tc: "text/placeholder", icon: "icon/default" },
      { name: "Focus", bg: "bg/selected", border: "border/selected", txt: "\uAC80\uC0C9\uC5B4", tc: "text/selected", icon: "icon/default" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uAC80\uC0C9\uC5B4", tc: "text/default", icon: "icon/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uAC80\uC0C9", tc: "text/disabled", icon: "icon/disabled" }
    ];
    const sizes = [
      { size: "XXSM", h: 28, font: 12, padL: 12, padR: 8 },
      { size: "XSM", h: 34, font: 14, padL: 12, padR: 8 },
      { size: "MD", h: 44, font: 14, padL: 16, padR: 12 }
    ];
    const comps = [];
    const cells = [];
    for (let row = 0; row < sizes.length; row++) {
      for (let col = 0; col < states.length; col++) {
        const sc = sizes[row], st = states[col];
        const comp = figma.createComponent();
        comp.name = `State=${st.name}, Size=${sc.size}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.paddingLeft = sc.padL;
        comp.paddingRight = sc.padR;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.cornerRadius = 4;
        comp.fills = [boundPaint(scv(maps, fc(st.bg)))];
        comp.strokes = [boundPaint(scv(maps, fc(st.border)))];
        comp.strokeWeight = 1;
        comp.strokeAlign = "INSIDE";
        const textNode = await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc)));
        if (st.name === "Focus") {
          const lead = figma.createFrame();
          lead.name = "lead";
          lead.fills = [];
          lead.layoutMode = "HORIZONTAL";
          lead.counterAxisAlignItems = "CENTER";
          lead.primaryAxisSizingMode = "AUTO";
          lead.counterAxisSizingMode = "AUTO";
          lead.itemSpacing = 4;
          lead.appendChild(textNode);
          lead.appendChild(makeCaret(scv(maps, fc("text-cursor"))));
          comp.appendChild(lead);
          const trail = figma.createFrame();
          trail.name = "trail";
          trail.fills = [];
          trail.layoutMode = "HORIZONTAL";
          trail.counterAxisAlignItems = "CENTER";
          trail.primaryAxisSizingMode = "AUTO";
          trail.counterAxisSizingMode = "AUTO";
          trail.itemSpacing = 4;
          trail.appendChild(await makeClearIcon(scv(maps, fc("icon/default")), fcIconPx(sc.h, 0)));
          trail.appendChild(await makeIconInstance("search", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), MAG));
          comp.appendChild(trail);
        } else {
          comp.appendChild(textNode);
          comp.appendChild(await makeIconInstance("search", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), MAG));
        }
        comp.resize(160, sc.h);
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Search Input";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Search Input",
      colHeaders: states.map((s) => s.name),
      rowLabels: sizes.map((s) => s.size),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 176,
      cellH: 60
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTextarea(maps, originY) {
    const fc = (k) => `color/form-control/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC785\uB825", tc: "text/placeholder" },
      { name: "Focus", bg: "bg/selected", border: "border/selected", txt: "\uD14D\uC2A4\uD2B8", tc: "text/selected" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uC785\uB825", tc: "text/disabled" },
      { name: "Readonly", bg: "bg/disabled", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/read-only" }
    ];
    const comps = [];
    const cells = [];
    for (let row = 0; row < states.length; row++) {
      const st = states[row];
      const comp = figma.createComponent();
      comp.name = `State=${st.name}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "MIN";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(240, 80);
      comp.paddingLeft = 12;
      comp.paddingRight = 12;
      comp.paddingTop = 10;
      comp.paddingBottom = 10;
      comp.cornerRadius = 4;
      comp.fills = [boundPaint(scv(maps, fc(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, fc(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const textNode = await makeBoundText(st.txt, 14, "Regular", scv(maps, fc(st.tc)));
      if (st.name === "Focus") {
        const lead = figma.createFrame();
        lead.name = "lead";
        lead.fills = [];
        lead.layoutMode = "HORIZONTAL";
        lead.counterAxisAlignItems = "CENTER";
        lead.primaryAxisSizingMode = "AUTO";
        lead.counterAxisSizingMode = "AUTO";
        lead.itemSpacing = 4;
        lead.appendChild(textNode);
        lead.appendChild(makeCaret(scv(maps, fc("text-cursor"))));
        comp.appendChild(lead);
      } else {
        comp.appendChild(textNode);
      }
      setLightMode(comp, maps);
      comps.push(comp);
      cells.push({ comp, row, col: 0 });
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Text Area";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Text Area",
      colHeaders: ["Field"],
      rowLabels: states.map((s) => s.name),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 264,
      cellH: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildSelect(maps, originY) {
    var _a, _b, _c;
    const fc = (k) => `color/form-control/${k}`;
    const chevDown = (c) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 6L8 10L12 6" stroke="${c}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const chevUp = (c) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 10L8 6L12 10" stroke="${c}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", tc: "text/placeholder", icon: "icon/default", up: false },
      { name: "Hover", bg: "bg/hover", border: "border/default", tc: "text/placeholder", icon: "icon/default", up: false },
      { name: "Open", bg: "bg/selected", border: "border/selected", tc: "text/placeholder", icon: "icon/default", up: true },
      { name: "Filled", bg: "bg/default", border: "border/default", tc: "text/selected", icon: "icon/default", up: false },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", tc: "text/disabled", icon: "icon/disabled", up: false }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12 },
      { size: "XSM", brk: "PC", h: 34, font: 14 },
      { size: "MD", brk: "PC", h: 44, font: 14 },
      { size: "MD", brk: "Mobile", h: 48, font: 14 }
    ];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const trigger = figma.createFrame();
        trigger.name = "trigger";
        trigger.layoutMode = "HORIZONTAL";
        trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
        trigger.counterAxisAlignItems = "CENTER";
        trigger.primaryAxisSizingMode = "FIXED";
        trigger.counterAxisSizingMode = "FIXED";
        trigger.paddingLeft = 16;
        trigger.paddingRight = 8;
        trigger.paddingTop = 0;
        trigger.paddingBottom = 0;
        trigger.cornerRadius = 4;
        trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
        trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
        trigger.strokeWeight = 1;
        trigger.strokeAlign = "INSIDE";
        trigger.appendChild(await makeBoundText("\uC120\uD0DD", sc.font, "Regular", scv(maps, fc(st.tc))));
        trigger.appendChild(await makeIconInstance("chevron", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), (st.up ? chevUp : chevDown)("#000"), st.up ? 90 : 270));
        trigger.resize(140, sc.h);
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        comp.fills = [];
        comp.appendChild(trigger);
        if (st.name === "Open") {
          const ddKey = `Dropdown:${sc.size}:Default`;
          let ddComp = (_b = (_a = BUILT_COMPS[ddKey]) != null ? _a : BUILT_COMPS["Dropdown:MD:Default"]) != null ? _b : BUILT_COMPS["Dropdown:Default"];
          if (!ddComp) {
            const ddSet = await getBuiltSet("Dropdown");
            if (ddSet) {
              ddComp = (_c = ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${sc.size}`))) != null ? _c : ddSet.children.find((c) => c.type === "COMPONENT");
            }
          }
          if (ddComp) {
            const ddInst = ddComp.createInstance();
            ddInst.name = "dropdown";
            comp.appendChild(ddInst);
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Select Box";
    set.x = 0;
    set.y = originY;
    cells.forEach(({ comp, size, brk, state }) => {
      BUILT_COMPS[`SelectBox:${size}:${brk}:${state}`] = comp;
    });
    BUILT_SETS["Select Box"] = set;
    const opts = {
      title: "Select Box",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a2, _b2;
        return (_b2 = (_a2 = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 156,
      cellH: 220,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDropdownList(maps, originY) {
    const dd = (k) => `color/dropdown/${k}`;
    const states = [
      { name: "Default", bg: "option/bg/default", label: "option/label/default" },
      { name: "Hover", bg: "option/bg/hover", label: "option/label/hover" },
      // 2026-07-08 사용자 결정: 선택 배경=default와 동일 토큰(강조는 텍스트색만). option/bg/selected(하늘색)는
      // 더 이상 여기서 안 쓰지만 Time Picker Cell(별도 컴포넌트, buildTimePickerCell)은 계속 사용 — 그대로 둠.
      { name: "Selected", bg: "option/bg/default", label: "option/label/selected" }
    ];
    const sizes = [
      { size: "XXSM", h: 28, font: 12 },
      { size: "XSM", h: 34, font: 14 },
      { size: "MD", h: 44, font: 14 }
    ];
    const comps = [];
    const cells = [];
    for (const sz of sizes) {
      for (let col = 0; col < states.length; col++) {
        const st = states[col];
        const comp = figma.createComponent();
        comp.name = `Size=${sz.size}, State=${st.name}`;
        comp.layoutMode = "HORIZONTAL";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.paddingLeft = 12;
        comp.paddingRight = 12;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.fills = [boundPaint(scv(maps, dd(st.bg)))];
        comp.appendChild(await makeBoundText("\uC635\uC158", sz.font, "Regular", scv(maps, dd(st.label))));
        comp.resize(140, sz.h);
        comps.push(comp);
        cells.push({ comp, size: sz.size, colIdx: col });
        BUILT_COMPS[`DropdownList:${sz.size}:${st.name}`] = comp;
        if (sz.size === "MD") BUILT_COMPS[`DropdownList:${st.name}`] = comp;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Dropdown List";
    set.x = 0;
    set.y = originY;
    setLightMode(set, maps);
    BUILT_SETS["Dropdown List"] = set;
    const opts = {
      title: "Dropdown List",
      platforms: [{ name: "PC", sizes: sizes.map((s) => s.size) }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (_p, size, _ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === size && x.colIdx === ci)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 160,
      cellH: 60,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDropdown(maps, originY) {
    var _a;
    const dd = (k) => `color/dropdown/${k}`;
    const sizes = [
      { size: "XXSM", h: 28 },
      { size: "XSM", h: 34 },
      { size: "MD", h: 44 }
    ];
    const comps = [];
    const cells = [];
    for (const sz of sizes) {
      const comp = figma.createComponent();
      comp.name = `Size=${sz.size}, State=Default`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.paddingTop = 4;
      comp.paddingBottom = 4;
      comp.itemSpacing = 0;
      comp.cornerRadius = 4;
      comp.clipsContent = false;
      comp.fills = [boundPaint(scv(maps, "color/dropdown/list/bg"))];
      comp.strokes = [boundPaint(scv(maps, "color/dropdown/list/border"))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "OUTSIDE";
      const ddEffects = shadowEffects("shadow/dropdown");
      try {
        comp.effects = ddEffects;
      } catch (e) {
      }
      comp.resize(140, 4 * sz.h + 8);
      for (const stateName of ["Default", "Hover", "Selected", "Default"]) {
        const ddComp = (_a = BUILT_COMPS[`DropdownList:${sz.size}:${stateName}`]) != null ? _a : BUILT_COMPS[`DropdownList:${stateName}`];
        if (ddComp) {
          const inst = ddComp.createInstance();
          inst.name = "ddl-row";
          comp.appendChild(inst);
          inst.layoutAlign = "STRETCH";
        } else {
          const sn = stateName.toLowerCase();
          const row = figma.createFrame();
          row.name = "ddl-row";
          row.layoutMode = "HORIZONTAL";
          row.counterAxisAlignItems = "CENTER";
          row.primaryAxisSizingMode = "FIXED";
          row.counterAxisSizingMode = "FIXED";
          row.resize(140, sz.h);
          row.paddingLeft = 12;
          row.paddingRight = 12;
          row.paddingTop = 0;
          row.paddingBottom = 0;
          row.fills = [boundPaint(scv(maps, dd(`option/bg/${sn}`)))];
          row.appendChild(await makeBoundText("\uC635\uC158", sz.h <= 28 ? 12 : 14, "Regular", scv(maps, dd(`option/label/${sn}`))));
          comp.appendChild(row);
        }
      }
      comps.push(comp);
      cells.push({ comp, size: sz.size });
      BUILT_COMPS[`Dropdown:${sz.size}:Default`] = comp;
    }
    BUILT_COMPS["Dropdown:Default"] = BUILT_COMPS["Dropdown:MD:Default"];
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Dropdown";
    set.x = 0;
    set.y = originY;
    setLightMode(set, maps);
    BUILT_SETS["Dropdown"] = set;
    const opts = {
      title: "Dropdown",
      colHeaders: ["Default"],
      rowLabels: cells.map((c) => c.size),
      cellAt: (r, _c) => {
        var _a2, _b;
        return (_b = (_a2 = cells[r]) == null ? void 0 : _a2.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 220
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLineTab(maps, originY) {
    const nav = (k) => `color/navigation/${k}`;
    const states = [
      { name: "Unselected", label: "label/default", ind: "indicator/default" },
      { name: "Hover", label: "label/hover", ind: "indicator/hover" },
      { name: "Selected", label: "label/selected", ind: "indicator/selected" }
    ];
    const sizes = [
      { size: "SM", brk: "PC", h: 42, font: 16 },
      { size: "MD", brk: "PC", h: 44, font: 20 },
      { size: "SM", brk: "Mobile", h: 32, font: 16 }
    ];
    const MIN_W = 76;
    const PAD_X = 16;
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "AUTO";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.itemSpacing = 0;
        comp.paddingLeft = 0;
        comp.paddingRight = 0;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.fills = [];
        comp.clipsContent = false;
        comp.minWidth = MIN_W;
        const indH = st.name === "Unselected" ? 1 : 2;
        const t = await makeBoundText("\uBA54\uB274", sc.font, "Medium", scv(maps, nav(st.label)));
        try {
          t.textAutoResize = "WIDTH_AND_HEIGHT";
        } catch (e) {
        }
        const labelWrap = figma.createFrame();
        labelWrap.name = "label";
        labelWrap.fills = [];
        labelWrap.layoutMode = "HORIZONTAL";
        labelWrap.primaryAxisSizingMode = "AUTO";
        labelWrap.counterAxisSizingMode = "AUTO";
        labelWrap.primaryAxisAlignItems = "CENTER";
        labelWrap.counterAxisAlignItems = "CENTER";
        labelWrap.paddingLeft = PAD_X;
        labelWrap.paddingRight = PAD_X;
        labelWrap.appendChild(t);
        comp.appendChild(labelWrap);
        try {
          labelWrap.layoutGrow = 1;
          labelWrap.layoutAlign = "STRETCH";
        } catch (e) {
        }
        const ind = figma.createRectangle();
        ind.resize(MIN_W, indH);
        ind.fills = [boundPaint(scv(maps, nav(st.ind)))];
        comp.appendChild(ind);
        try {
          ind.layoutAlign = "STRETCH";
        } catch (e) {
        }
        try {
          comp.resize(MIN_W, sc.h);
        } catch (e) {
        }
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    cells.forEach((c) => {
      BUILT_COMPS[`LineTab:${c.brk}-${c.size}-${c.state}`] = c.comp;
    });
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Line Tab";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Line Tab",
      platforms: [{ name: "PC", sizes: ["SM", "MD"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 110,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLineTabSet(maps, originY) {
    const TAB_LABELS = ["\uD0ED \uBA54\uB274 1", "\uD0ED \uBA54\uB274 2", "\uD0ED \uBA54\uB274 3"];
    const sizeDefs = [
      { name: "MD", brk: "PC", size: "MD" },
      { name: "SM", brk: "PC", size: "SM" },
      { name: "SM", brk: "Mobile", size: "SM" }
    ];
    const pickCell = async (brk, size, state) => {
      let c = BUILT_COMPS[`LineTab:${brk}-${size}-${state}`];
      if (!c) {
        const s = await getBuiltSet("Line Tab");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name.includes(`Size=${size}`) && x.name.includes(`Break=${brk}`) && x.name.includes(`State=${state}`));
      }
      return c;
    };
    const comps = [];
    const cellByKey = /* @__PURE__ */ new Map();
    for (const sd of sizeDefs) {
      const comp = figma.createComponent();
      comp.name = `Size=${sd.size}, Break=${sd.brk}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.counterAxisAlignItems = "MIN";
      comp.itemSpacing = 0;
      comp.fills = [];
      comp.clipsContent = false;
      const tabInsts = [];
      for (let i = 0; i < TAB_LABELS.length; i++) {
        const state = i === 0 ? "Selected" : "Unselected";
        const cell = await pickCell(sd.brk, sd.size, state);
        if (cell) {
          const inst = cell.createInstance();
          inst.name = `tab-${i + 1}`;
          const txt = inst.findOne((n) => n.type === "TEXT");
          if (txt) {
            try {
              txt.characters = TAB_LABELS[i];
            } catch (e) {
            }
          }
          comp.appendChild(inst);
          tabInsts.push(inst);
        }
      }
      if (tabInsts.length) {
        const maxW = Math.max(...tabInsts.map((n) => {
          try {
            return n.width;
          } catch (e) {
            return 0;
          }
        }));
        for (const inst of tabInsts) {
          try {
            inst.layoutSizingHorizontal = "FIXED";
          } catch (e) {
          }
          try {
            inst.resize(maxW, inst.height);
          } catch (e) {
          }
        }
      }
      setLightMode(comp, maps);
      comps.push(comp);
      cellByKey.set(`${sd.brk}/${sd.size}`, comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Line Tab Set";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Line Tab Set"] = set;
    const opts = {
      title: "Line Tab Set",
      platforms: [{ name: "PC", sizes: ["MD", "SM"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: [""],
      colHeaders: [""],
      cellAt: (platName, size, _ri, _ci) => {
        var _a;
        return (_a = cellByKey.get(`${platName}/${size}`)) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 360,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTableCell(maps, originY) {
    const variants = [
      { type: "Cell", state: "Default", bg: "color/table/cell/default", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Default" },
      { type: "Cell", state: "Hover", bg: "color/table/cell/hover", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Hover" },
      { type: "Cell", state: "Selected", bg: "color/table/cell/selected", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Selected" },
      { type: "Header", state: "Default", bg: "color/table/header/bg", border: "color/table/border/default", text: "color/text/body/secondary", head: "Header" }
    ];
    const sizes = [
      { size: "SMALL", h: 38, font: 13 },
      { size: "MEDIUM", h: 44, font: 14 }
    ];
    const W = 130;
    const comps = [];
    const cells = [];
    for (let row = 0; row < sizes.length; row++) {
      for (let col = 0; col < variants.length; col++) {
        const sc = sizes[row], v = variants[col];
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, Type=${v.type}, Variant=${v.state}`;
        comp.resize(W, sc.h);
        comp.fills = [boundPaint(scv(maps, v.bg))];
        const t = await makeBoundText("1\uCE35 \uC815\uBB38", sc.font, "Regular", scv(maps, v.text));
        comp.appendChild(t);
        t.x = 16;
        t.y = (sc.h - 1 - t.height) / 2;
        const border = figma.createRectangle();
        border.resize(W, 1);
        border.fills = [boundPaint(scv(maps, v.border))];
        comp.appendChild(border);
        border.x = 0;
        border.y = sc.h - 1;
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Table Cell";
    set.x = 0;
    set.y = originY;
    for (const { comp, row, col } of cells) {
      const size = sizes[row].size;
      const v = variants[col];
      BUILT_COMPS[`TableCell:${size}:${v.type}:${v.state}`] = comp;
    }
    BUILT_SETS["Table Cell"] = set;
    const opts = {
      title: "Table Cell",
      colHeaders: variants.map((v) => v.head),
      rowLabels: sizes.map((s) => s.size),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 152,
      cellH: 60,
      rowLabelW: 80
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTable(maps, originY) {
    const COL = [48, 360, 200, 110, 110];
    const W = 828;
    const FOOTER_H = 44;
    async function makeTableRow(h, sizeKey, isHeader, state, ri) {
      const row = figma.createFrame();
      row.name = isHeader ? "header" : `row-${ri + 1}`;
      row.resize(W, h);
      row.fills = [];
      const colTexts = isHeader ? ["\uD56D\uBAA9\uBA85", "\uD56D\uBAA9\uBA85 (\uC815\uB82C)", "\uC218\uB7C9", "\uAD00\uB9AC"] : state === "Hover" ? ["Hover \uD589", "\uCE74\uD14C\uACE0\uB9AC A", "56", "\uAC80\uD1A0\uC911"] : state === "Selected" ? ["Selected \uD589", "\uCE74\uD14C\uACE0\uB9AC B", "33", "\uC644\uB8CC"] : [`\uD56D\uBAA9 ${ri + 1}`, "\uCE74\uD14C\uACE0\uB9AC C", `${(ri + 1) * 10}`, "\uD65C\uC131"];
      const cellType = isHeader ? "Header" : "Cell";
      const cellState = isHeader ? "Default" : state;
      const chkBg = isHeader ? "color/table/header/bg" : state === "Hover" ? "color/table/cell/hover" : state === "Selected" ? "color/table/cell/selected" : "color/table/cell/default";
      const chkFrame = figma.createFrame();
      chkFrame.name = "col-check";
      chkFrame.resize(COL[0], h);
      chkFrame.fills = [boundPaint(scv(maps, chkBg))];
      const chkState = isHeader ? "Default" : state === "Selected" ? "Checked" : state === "Hover" ? "Hover" : "Default";
      const chkComp = BUILT_COMPS[`Checkbox:${chkState}`];
      if (chkComp) {
        const ci = chkComp.createInstance();
        chkFrame.appendChild(ci);
        ci.x = (COL[0] - ci.width) / 2;
        ci.y = (h - ci.height) / 2;
      }
      const chkBdr = figma.createRectangle();
      chkBdr.resize(COL[0], 1);
      chkBdr.fills = [boundPaint(scv(maps, "color/table/border/default"))];
      chkFrame.appendChild(chkBdr);
      chkBdr.x = 0;
      chkBdr.y = h - 1;
      row.appendChild(chkFrame);
      chkFrame.x = 0;
      chkFrame.y = 0;
      const font = sizeKey === "MEDIUM" ? 14 : 13;
      let xOff = COL[0];
      for (let k = 0; k < 4; k++) {
        const colW = COL[k + 1];
        const cellComp = BUILT_COMPS[`TableCell:${sizeKey}:${cellType}:${cellState}`];
        if (cellComp) {
          const cellInst = cellComp.createInstance();
          cellInst.resize(colW, h);
          try {
            const tn = cellInst.findOne((n) => n.type === "TEXT");
            if (tn) {
              await figma.loadFontAsync(tn.fontName);
              tn.characters = colTexts[k];
            }
          } catch (_) {
          }
          row.appendChild(cellInst);
          cellInst.x = xOff;
          cellInst.y = 0;
        } else {
          const cf = figma.createFrame();
          cf.name = `col-${k + 1}`;
          cf.resize(colW, h);
          const bgKey = isHeader ? "color/table/header/bg" : state === "Hover" ? "color/table/cell/hover" : state === "Selected" ? "color/table/cell/selected" : "color/table/cell/default";
          cf.fills = [boundPaint(scv(maps, bgKey))];
          const textKey = isHeader ? "color/text/body/secondary" : "color/text/body/primary";
          const t = await makeBoundText(colTexts[k], font, isHeader ? "Medium" : "Regular", scv(maps, textKey));
          cf.appendChild(t);
          t.x = 16;
          t.y = Math.max(0, (h - t.height) / 2);
          const bdr = figma.createRectangle();
          bdr.resize(colW, 1);
          bdr.fills = [boundPaint(scv(maps, "color/table/border/default"))];
          cf.appendChild(bdr);
          bdr.x = 0;
          bdr.y = h - 1;
          row.appendChild(cf);
          cf.x = xOff;
          cf.y = 0;
        }
        xOff += colW;
      }
      return row;
    }
    async function makeTableFooter() {
      var _a;
      const footer = figma.createFrame();
      footer.name = "table-footer";
      footer.resize(W, FOOTER_H);
      footer.fills = [boundPaint(scv(maps, "color/table/cell/default"))];
      let barComp = BUILT_COMPS["Pagination:Bar/Middle"];
      if (!barComp) {
        const barSet = await getBuiltSet("Pagination");
        if (barSet) barComp = (_a = barSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Middle"))) != null ? _a : barSet.children.find((c) => c.type === "COMPONENT");
      }
      if (barComp) {
        const barInst = barComp.createInstance();
        barInst.name = "pagination";
        footer.appendChild(barInst);
        barInst.x = Math.round((W - barInst.width) / 2);
        barInst.y = Math.round((FOOTER_H - barInst.height) / 2);
      }
      const selComp = BUILT_COMPS["SelectBox:XXSM:PC:Default"];
      if (selComp) {
        const selInst = selComp.createInstance();
        selInst.name = "select-box";
        footer.appendChild(selInst);
        selInst.x = W - selInst.width - 8;
        selInst.y = (FOOTER_H - selInst.height) / 2;
      }
      return footer;
    }
    const sizes = [
      { size: "MD", sizeKey: "MEDIUM", h: 44 },
      { size: "SM", sizeKey: "SMALL", h: 38 }
    ];
    const ROW_STATES = ["Default", "Hover", "Selected", "Default", "Default", "Default", "Default", "Default"];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      const comp = figma.createComponent();
      comp.name = `Size=${sc.size}`;
      comp.resize(W, 10);
      comp.fills = [];
      let y = 0;
      const header = await makeTableRow(sc.h, sc.sizeKey, true, "Header", 0);
      comp.appendChild(header);
      header.x = 0;
      header.y = y;
      y += sc.h;
      for (let ri = 0; ri < 8; ri++) {
        const row = await makeTableRow(sc.h, sc.sizeKey, false, ROW_STATES[ri], ri);
        comp.appendChild(row);
        row.x = 0;
        row.y = y;
        y += sc.h;
      }
      const footer = await makeTableFooter();
      const footerY = y;
      comp.appendChild(footer);
      footer.x = 0;
      footer.y = footerY;
      y += FOOTER_H;
      comp.resize(W, y);
      const edgeTop = figma.createRectangle();
      edgeTop.name = "edge-top";
      edgeTop.resize(W, 2);
      edgeTop.fills = [boundPaint(scv(maps, "color/table/border/strong"))];
      comp.appendChild(edgeTop);
      edgeTop.x = 0;
      edgeTop.y = 0;
      const edgeBottom = figma.createRectangle();
      edgeBottom.name = "edge-bottom";
      edgeBottom.resize(W, 1);
      edgeBottom.fills = [boundPaint(scv(maps, "color/table/border/strong"))];
      comp.appendChild(edgeBottom);
      edgeBottom.x = 0;
      edgeBottom.y = footerY - 1;
      setLightMode(comp, maps);
      comps.push(comp);
      cells.push({ comp, size: sc.size });
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Table";
    set.x = 0;
    set.y = originY;
    const cellH = sizes[0].h * 9 + FOOTER_H + 40;
    const opts = {
      title: "Table",
      colHeaders: [""],
      rowLabels: sizes.map((s) => s.size),
      cellAt: (r, _c) => {
        var _a, _b;
        return (_b = (_a = cells[r]) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildFilterChip(maps, originY) {
    var _a, _b, _c, _d, _e;
    const arrowDown = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="#000" stroke-width="2" stroke-linecap="square"/></svg>`;
    const arrowUp = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M18 15L12 9L6 15" stroke="#000" stroke-width="2" stroke-linecap="square"/></svg>`;
    const variants = ["Line", "Solid"];
    const titles = [
      { key: "Off", name: "Label only" },
      { key: "On", name: "With title" }
    ];
    const states = ["Default", "Hover", "Selected", "Complete", "Disabled"];
    const sizes = [
      { size: "SM", brk: "PC", h: 28, font: 14, padL: 12, padR: 6 },
      { size: "MD", brk: "PC", h: 34, font: 14, padL: 16, padR: 8 },
      { size: "MD", brk: "Mobile", h: 30, font: 14, padL: 12, padR: 6 }
    ];
    function chipSlot(v, st) {
      if (v === "line") {
        switch (st) {
          case "Hover":
            return { bg: "hover", bd: "default", lb: "default", open: false };
          case "Selected":
            return { bg: "selected", bd: "selected", lb: "default", open: true };
          case "Disabled":
            return { bg: "disabled", bd: "disabled", lb: "disabled", open: false };
          default:
            return { bg: "default", bd: "default", lb: "default", open: false };
        }
      }
      switch (st) {
        case "Hover":
          return { bg: "hover", bd: "hover", bdGroup: "bg", lb: "default", open: false };
        case "Selected":
          return { bg: "selected", bd: "selected", lb: "selected", open: true };
        case "Disabled":
          return { bg: "disabled", bd: "disabled", lb: "disabled", open: false };
        default:
          return { bg: "default", bd: "default", lb: "default", open: false };
      }
    }
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const variant of variants) {
        const v = variant.toLowerCase();
        for (const t of titles) {
          for (const st of states) {
            const ss = chipSlot(v, st);
            const dis = st === "Disabled";
            const chip = figma.createFrame();
            chip.name = "chip";
            chip.layoutMode = "HORIZONTAL";
            chip.counterAxisAlignItems = "CENTER";
            chip.primaryAxisSizingMode = "AUTO";
            chip.counterAxisSizingMode = "FIXED";
            chip.itemSpacing = 4;
            chip.paddingLeft = sc.padL;
            chip.paddingRight = sc.padR;
            chip.cornerRadius = 999;
            chip.fills = [boundPaint(scv(maps, `color/chip/${v}/bg/${ss.bg}`))];
            chip.strokes = [boundPaint(scv(maps, `color/chip/${v}/${(_a = ss.bdGroup) != null ? _a : "border"}/${ss.bd}`))];
            chip.strokeWeight = 1;
            chip.strokeAlign = "INSIDE";
            if (t.key === "On") {
              chip.appendChild(await makeBoundText("\uC815\uB82C", sc.font, "Medium", scv(maps, `color/chip/${v}/label/${ss.lb}`)));
            }
            const valLbSlot = t.key === "On" && v === "line" && !dis ? "selected" : ss.lb;
            const valText = st === "Complete" ? "\uACFC\uAC70\uC21C" : "\uCD5C\uC2E0\uC21C";
            chip.appendChild(await makeBoundText(valText, sc.font, "Medium", scv(maps, `color/chip/${v}/label/${valLbSlot}`)));
            const arrowSlot = ss.lb;
            chip.appendChild(await makeIconInstance("chevron", scv(maps, `color/chip/${v}/label/${arrowSlot}`), 20, ss.open ? arrowUp : arrowDown, ss.open ? 90 : 270));
            chip.resize(chip.width, sc.h);
            const comp = figma.createComponent();
            comp.name = `Size=${sc.size}, Break=${sc.brk}, Variant=${variant}, Title=${t.key}, State=${st}`;
            comp.layoutMode = "VERTICAL";
            comp.primaryAxisSizingMode = "AUTO";
            comp.counterAxisSizingMode = "AUTO";
            comp.itemSpacing = 8;
            comp.fills = [];
            comp.appendChild(chip);
            if (ss.open) {
              const chipToDd = { SM: "XXSM", MD: "XSM" };
              const ddSize = (_b = chipToDd[sc.size]) != null ? _b : "MD";
              const ddKey = `Dropdown:${ddSize}:Default`;
              let ddComp = (_d = (_c = BUILT_COMPS[ddKey]) != null ? _c : BUILT_COMPS["Dropdown:MD:Default"]) != null ? _d : BUILT_COMPS["Dropdown:Default"];
              if (!ddComp) {
                const ddSet = await getBuiltSet("Dropdown");
                if (ddSet) {
                  ddComp = (_e = ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${ddSize}`))) != null ? _e : ddSet.children.find((c) => c.type === "COMPONENT");
                }
              }
              if (ddComp) {
                const ddInst = ddComp.createInstance();
                ddInst.name = "dropdown";
                const selectedRow = ddInst.children[2];
                const defaultRowComp = BUILT_COMPS[`DropdownList:${ddSize}:Default`];
                if (selectedRow && selectedRow.type === "INSTANCE" && defaultRowComp) {
                  selectedRow.swapComponent(defaultRowComp);
                }
                comp.appendChild(ddInst);
              }
            }
            setLightMode(comp, maps);
            comps.push(comp);
            cells.push({ comp, variant, title: t.key, state: st, size: sc.size, brk: sc.brk });
          }
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Filter Chip";
    set.x = 0;
    set.y = originY;
    const groups = [
      { name: "Line \xB7 Label only", variant: "Line", title: "Off" },
      { name: "Line \xB7 With title", variant: "Line", title: "On" },
      { name: "Solid \xB7 Label only", variant: "Solid", title: "Off" },
      { name: "Solid \xB7 With title", variant: "Solid", title: "On" }
    ];
    const opts = {
      title: "Filter Chip",
      platforms: [
        { name: "PC", sizes: ["SM", "MD"] },
        { name: "Mobile", sizes: ["MD"] }
      ],
      rowLabels: groups.map((g) => g.name),
      colHeaders: states,
      cellAt: (platName, sizeLabel, ri, ci) => {
        var _a2, _b2;
        const g = groups[ri];
        if (!g) return null;
        const brk = platName === "Mobile" ? "Mobile" : "PC";
        return (_b2 = (_a2 = cells.find((x) => x.variant === g.variant && x.title === g.title && x.state === states[ci] && x.size === sizeLabel && x.brk === brk)) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 160,
      cellH: 160,
      rowLabelW: 120
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTimePicker(maps, originY) {
    const fc = (k) => `color/form-control/${k}`;
    const CLOCK = `<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7.5" stroke="#000" stroke-width="1.2"/><path d="M9 5v4l2.5 2.5" stroke="#000" stroke-width="1.2" stroke-linecap="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/default" },
      { name: "Hover", bg: "bg/hover", border: "border/default", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/default" },
      { name: "Focus", bg: "bg/default", border: "border/selected", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/default" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "09:30", tc: "text/default", icon: "icon/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "00:00", tc: "text/disabled", icon: "icon/disabled" }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12, padL: 10, padR: 6 },
      { size: "XSM", brk: "PC", h: 34, font: 14, padL: 12, padR: 8 },
      { size: "MD", brk: "PC", h: 44, font: 14, padL: 16, padR: 8 },
      { size: "MD", brk: "Mobile", h: 48, font: 14, padL: 16, padR: 8 }
    ];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const trigger = figma.createFrame();
        trigger.name = "trigger";
        trigger.layoutMode = "HORIZONTAL";
        trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
        trigger.counterAxisAlignItems = "CENTER";
        trigger.primaryAxisSizingMode = "FIXED";
        trigger.counterAxisSizingMode = "FIXED";
        trigger.paddingLeft = sc.padL;
        trigger.paddingRight = sc.padR;
        trigger.paddingTop = 0;
        trigger.paddingBottom = 0;
        trigger.itemSpacing = 8;
        trigger.cornerRadius = 4;
        trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
        trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
        trigger.strokeWeight = 1;
        trigger.strokeAlign = "INSIDE";
        trigger.appendChild(await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc))));
        trigger.appendChild(await makeIconInstance("clock", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), CLOCK));
        trigger.resize(150, sc.h);
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 4;
        comp.appendChild(trigger);
        if (st.name === "Focus") {
          const tpdComp = BUILT_COMPS["TPD:focus-default"];
          if (tpdComp) {
            const tpdInst = tpdComp.createInstance();
            tpdInst.name = "tpd";
            comp.appendChild(tpdInst);
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Time Picker",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 168,
      cellH: 250,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var TPC_W = 44;
  var TPC_H = 32;
  async function buildTimePickerCell(maps) {
    const opt = (k) => `color/dropdown/option/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", lb: "label/default" },
      { name: "Hover", bg: "bg/hover", lb: "label/hover" },
      { name: "Selected", bg: "bg/selected", lb: "label/selected" }
    ];
    const comps = [];
    const variants = {};
    for (const st of states) {
      const comp = figma.createComponent();
      comp.name = `State=${st.name}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.paddingLeft = 12;
      comp.paddingRight = 12;
      comp.cornerRadius = 4;
      comp.resize(TPC_W, TPC_H);
      comp.fills = [boundPaint(scv(maps, opt(st.bg)))];
      comp.appendChild(await makeBoundText("00", 14, "Regular", scv(maps, opt(st.lb))));
      comps.push(comp);
      variants[st.name] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker Cell";
    return { set, variants };
  }
  var TPD_COLS_H = 192;
  var TPD_PAD_TOP = 12;
  var TPD_PANEL_W = (n) => n >= 3 ? 194 : 121;
  async function buildTimePickerDropdown(maps, originY) {
    var _a;
    const cell = await buildTimePickerCell(maps);
    async function makeCol(items, selIdx, hoverIdx) {
      const col = figma.createFrame();
      col.name = "col";
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "FIXED";
      col.counterAxisSizingMode = "FIXED";
      col.itemSpacing = 0;
      col.clipsContent = true;
      col.fills = [];
      col.resize(44, TPD_COLS_H);
      for (let i = 0; i < items.length; i++) {
        const state = i === selIdx ? "Selected" : i === hoverIdx ? "Hover" : "Default";
        const inst = cell.variants[state].createInstance();
        const txt = inst.findOne((n) => n.type === "TEXT");
        if (txt) {
          await figma.loadFontAsync(txt.fontName);
          txt.characters = items[i];
        }
        col.appendChild(inst);
        inst.layoutAlign = "STRETCH";
      }
      return col;
    }
    function makeColSep() {
      const sep = figma.createRectangle();
      sep.name = "sep";
      sep.resize(1, TPD_COLS_H);
      sep.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
      return sep;
    }
    async function fillPanel(node, cols, confirmActive) {
      const panelW = TPD_PANEL_W(cols.length);
      node.layoutMode = "VERTICAL";
      node.counterAxisAlignItems = "CENTER";
      node.itemSpacing = 0;
      node.paddingTop = TPD_PAD_TOP;
      node.paddingBottom = 0;
      node.cornerRadius = 4;
      node.clipsContent = true;
      node.fills = [boundPaint(scv(maps, "color/dropdown/list/bg"))];
      node.strokes = [boundPaint(scv(maps, "color/dropdown/list/border"))];
      node.strokeWeight = 1;
      node.strokeAlign = "INSIDE";
      node.effects = shadowEffects("shadow/dropdown");
      node.resize(panelW, 100);
      node.primaryAxisSizingMode = "AUTO";
      node.counterAxisSizingMode = "FIXED";
      const colsFrame = figma.createFrame();
      colsFrame.name = "cols";
      colsFrame.layoutMode = "HORIZONTAL";
      colsFrame.counterAxisAlignItems = "MIN";
      colsFrame.primaryAxisSizingMode = "FIXED";
      colsFrame.counterAxisSizingMode = "FIXED";
      colsFrame.itemSpacing = 8;
      colsFrame.paddingLeft = 8;
      colsFrame.paddingRight = 8;
      colsFrame.fills = [];
      colsFrame.resize(panelW, TPD_COLS_H);
      for (let i = 0; i < cols.length; i++) {
        if (i > 0) {
          const sep = makeColSep();
          colsFrame.appendChild(sep);
          sep.layoutAlign = "STRETCH";
        }
        const col = await makeCol(cols[i].items, cols[i].selIdx, cols[i].hoverIdx);
        colsFrame.appendChild(col);
        col.layoutGrow = 1;
        col.layoutAlign = "STRETCH";
      }
      node.appendChild(colsFrame);
      colsFrame.layoutAlign = "STRETCH";
      const fdivWrap = figma.createFrame();
      fdivWrap.name = "footer-sep";
      fdivWrap.layoutMode = "VERTICAL";
      fdivWrap.primaryAxisSizingMode = "AUTO";
      fdivWrap.counterAxisSizingMode = "FIXED";
      fdivWrap.paddingLeft = 8;
      fdivWrap.paddingRight = 8;
      fdivWrap.fills = [];
      fdivWrap.resize(panelW, 1);
      const fdiv = figma.createRectangle();
      fdiv.name = "line";
      fdiv.resize(panelW - 16, 1);
      fdiv.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
      fdivWrap.appendChild(fdiv);
      fdiv.layoutAlign = "STRETCH";
      node.appendChild(fdivWrap);
      fdivWrap.layoutAlign = "STRETCH";
      const footer = figma.createFrame();
      footer.name = "Option";
      footer.layoutMode = "HORIZONTAL";
      footer.primaryAxisAlignItems = "MAX";
      footer.counterAxisAlignItems = "CENTER";
      footer.primaryAxisSizingMode = "FIXED";
      footer.counterAxisSizingMode = "AUTO";
      footer.paddingLeft = 16;
      footer.paddingRight = 16;
      footer.paddingTop = 12;
      footer.paddingBottom = 12;
      footer.fills = [];
      footer.appendChild(await makeBoundText("\uD655\uC778", 14, "Medium", scv(maps, confirmActive ? "color/text/state/accent" : "color/text/state/disabled")));
      node.appendChild(footer);
      footer.layoutAlign = "STRETCH";
    }
    const hours = ["1", "2", "3", "4", "5", "6", "7"];
    const mins = ["00", "01", "02", "03", "04", "05", "06"];
    const ampm = ["\uC624\uC804", "\uC624\uD6C4"];
    const colsOf = (type, cfg) => {
      var _a2, _b, _c, _d, _e;
      const h = { items: hours, selIdx: (_a2 = cfg.hSel) != null ? _a2 : -1, hoverIdx: (_b = cfg.hHov) != null ? _b : -1 };
      const m = { items: mins, selIdx: (_c = cfg.mSel) != null ? _c : -1, hoverIdx: (_d = cfg.mHov) != null ? _d : -1 };
      if (type === "12h") return [{ items: ampm, selIdx: (_e = cfg.ampm) != null ? _e : -1, hoverIdx: -1 }, h, m];
      return [h, m];
    };
    const tpdStates = [
      { state: "\uC2DC Hover", cfg: { hHov: 1 }, confirm: false },
      { state: "\uC2DC Selected", cfg: { hSel: 2 }, confirm: false },
      { state: "\uBD84 Hover", cfg: { hSel: 2, mHov: 3 }, confirm: false },
      { state: "\uBD84 Selected", cfg: { hSel: 2, mSel: 3 }, confirm: true }
    ];
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const type of ["24h", "12h"]) {
      for (const ts of tpdStates) {
        const panel = figma.createComponent();
        panel.name = `Type=${type}, State=${ts.state}`;
        await fillPanel(panel, colsOf(type, __spreadProps(__spreadValues({}, ts.cfg), { ampm: type === "12h" ? 0 : void 0 })), ts.confirm);
        comps.push(panel);
        byKey.set(`${type}/${ts.state}`, panel);
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker Dropdown";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Time Picker Dropdown"] = set;
    for (const [k, c] of byKey) BUILT_COMPS[`TPD:${k}`] = c;
    BUILT_COMPS["TPD:focus-default"] = (_a = byKey.get("24h/\uC2DC Selected")) != null ? _a : comps[0];
    const opts = {
      title: "Time Picker Dropdown",
      colHeaders: tpdStates.map((ts) => ts.state),
      rowLabels: ["24h", "12h"],
      cellAt: (r, c) => {
        var _a2;
        return (_a2 = byKey.get(`${["24h", "12h"][r]}/${tpdStates[c].state}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 300,
      rowLabelW: 40
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    const cellTop = bottomY + 80;
    const cellComps = [cell.variants.Default, cell.variants.Hover, cell.variants.Selected];
    const cellOpts = {
      title: "Time Picker Cell",
      colHeaders: ["Default", "Hover", "Selected"],
      rowLabels: [""],
      cellAt: (_r, c) => cellComps[c],
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY: cellTop,
      cellW: 120,
      cellH: 56
    };
    bottomY = Math.max(bottomY, await decorateSetFlat(cell.set, cellOpts, maps));
    try {
      bottomY = Math.max(bottomY, await buildSpec(cellOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildPaginationCell(maps, originY) {
    var _a;
    const pg = (k) => `color/pagination/${k}`;
    const CHEV_PREV = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 3.5L5 7l4 3.5" stroke="#000" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const CHEV_EDGE = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M10 3.5L6.5 7l3.5 3.5M3.5 3.5v7" stroke="#000" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const SZ = 28;
    const arrowStates = [
      { state: "Default", bg: "control/bg/default", border: "control/border/default", icon: "color/pagination/control/icon/default" },
      { state: "Hover", bg: "control/bg/hover", border: "control/border/default", icon: "color/pagination/control/icon/hover" },
      { state: "Disabled", bg: "control/bg/disabled", border: "control/border/disabled", icon: "color/pagination/control/icon/disabled" }
    ];
    const numStates = [
      { state: "Default", bg: null, text: "color/pagination/number/default" },
      { state: "Hover", bg: "control/bg/hover", text: "color/pagination/number/hover" },
      { state: "Selected", bg: null, text: "color/pagination/number/selected" }
    ];
    const byKey = /* @__PURE__ */ new Map();
    const comps = [];
    const EDGE_SET_KEY = "606d0de897175059f133427bf62bb3635d18a860";
    let edgeLineComp;
    try {
      const edgeSet = await figma.importComponentSetByKeyAsync(EDGE_SET_KEY);
      edgeLineComp = (_a = edgeSet.children.find(
        (c) => c.type === "COMPONENT" && c.name.toLowerCase().includes("line")
      )) != null ? _a : edgeSet.defaultVariant;
    } catch (_) {
    }
    const ICON_PX = edgeLineComp ? Math.round(edgeLineComp.height) : 24;
    for (const st of arrowStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Arrow, State=${st.state}`;
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, pg(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, pg(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const icon = await makeIconInstance("chevron", scv(maps, st.icon), ICON_PX, CHEV_PREV, 180, { wrap: false, keepName: true });
      comp.appendChild(icon);
      centerIconInBox(icon, comp, SZ);
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Arrow/${st.state}`, comp);
    }
    for (const st of arrowStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Edge, State=${st.state}`;
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, pg(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, pg(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      let icon;
      let edgeRotated = false;
      if (edgeLineComp) {
        const inst = edgeLineComp.createInstance();
        if (ICON_PX && ICON_PX !== inst.width) inst.resize(ICON_PX, ICON_PX);
        rebindIconColor(inst, scv(maps, st.icon));
        try {
          inst.rotation = 180;
          edgeRotated = true;
        } catch (e) {
        }
        icon = inst;
      } else {
        icon = makeStrokeIcon(CHEV_EDGE, scv(maps, st.icon));
      }
      comp.appendChild(icon);
      if (edgeRotated) centerIconInBox(icon, comp, SZ);
      else {
        icon.x = (SZ - icon.width) / 2;
        icon.y = (SZ - icon.height) / 2;
      }
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Edge/${st.state}`, comp);
    }
    for (const st of numStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Number, State=${st.state}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = st.bg ? [boundPaint(scv(maps, pg(st.bg)))] : [];
      const t = await makeBoundText("3", 14, "Medium", scv(maps, st.text));
      comp.appendChild(t);
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Number/${st.state}`, comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Pagination Cell";
    set.x = 0;
    set.y = originY;
    for (const [k, v] of byKey) BUILT_COMPS[`Pagination:${k}`] = v;
    BUILT_SETS["Pagination Cell"] = set;
    const cols = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Pagination Cell",
      colHeaders: cols,
      rowLabels: ["Arrow", "Number", "Edge"],
      cellAt: (r, c) => {
        var _a2;
        return (_a2 = byKey.get(`${["Arrow", "Number", "Edge"][r]}/${cols[c]}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 72,
      cellH: 48,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildPaginationBar(maps, originY) {
    const SZ = 28, GAP_GROUP = 4, GAP_SECTION = 8;
    const pick = async (key, variantName) => {
      let c = BUILT_COMPS[`Pagination:${key}`];
      if (!c) {
        const s = await getBuiltSet("Pagination Cell");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name.includes(variantName));
      }
      return c;
    };
    const arrowDef = await pick("Arrow/Default", "Element=Arrow, State=Default");
    const arrowDis = await pick("Arrow/Disabled", "Element=Arrow, State=Disabled");
    const edgeDef = await pick("Edge/Default", "Element=Edge, State=Default");
    const edgeDis = await pick("Edge/Disabled", "Element=Edge, State=Disabled");
    const numDef = await pick("Number/Default", "Element=Number, State=Default");
    const numSel = await pick("Number/Selected", "Element=Number, State=Selected");
    const cases = [
      // 1) 원페이지(리스트 15개까지) — 이동버튼 전체 비활성, "1"만 selected.
      { state: "Single", pages: [1], selected: 1, first: false, prev: false, next: false, last: false },
      // 2) 맨앞 페이지 — 맨앞·이전 비활성, 1 selected, 다음·맨뒤 활성.
      { state: "First", pages: [1, 2, 3, 4, 5, 6], selected: 1, first: false, prev: false, next: true, last: true },
      // 3) 맨뒤 페이지 — 맨앞·이전 활성, 마지막(6) selected, 다음·맨뒤 비활성.
      { state: "Last", pages: [1, 2, 3, 4, 5, 6], selected: 6, first: true, prev: true, next: false, last: false },
      // 4) 중간 페이지 — 전부 활성, 가운데(4) selected.
      { state: "Middle", pages: [1, 2, 3, 4, 5, 6], selected: 4, first: true, prev: true, next: true, last: true }
    ];
    const comps = [];
    let maxW = 0;
    for (const cs of cases) {
      const comp = figma.createComponent();
      comp.name = `State=${cs.state}`;
      comp.fills = [];
      let x = 0;
      const add = (cell, name, rotate, num) => {
        if (cell) {
          const inst = cell.createInstance();
          inst.name = name;
          if (num != null) {
            const txt = inst.findOne((n) => n.type === "TEXT");
            if (txt) {
              try {
                txt.characters = String(num);
              } catch (e) {
              }
            }
          }
          comp.appendChild(inst);
          if (rotate) {
            try {
              inst.rotation = 180;
            } catch (e) {
            }
            try {
              inst.x = x + SZ;
              inst.y = SZ;
            } catch (e) {
              inst.x = x;
              inst.y = 0;
            }
          } else {
            inst.x = x;
            inst.y = 0;
          }
        }
        x += SZ;
      };
      add(cs.first ? edgeDef : edgeDis, "pg-first", false);
      x += GAP_GROUP;
      add(cs.prev ? arrowDef : arrowDis, "pg-prev", false);
      x += GAP_SECTION;
      for (const n of cs.pages) add(n === cs.selected ? numSel : numDef, `pg-num-${n}`, false, n);
      x += GAP_SECTION;
      add(cs.next ? arrowDef : arrowDis, "pg-next", true);
      x += GAP_GROUP;
      add(cs.last ? edgeDef : edgeDis, "pg-last", true);
      try {
        comp.resize(x, SZ);
      } catch (e) {
      }
      if (x > maxW) maxW = x;
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Pagination";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Pagination"] = set;
    BUILT_COMPS["Pagination:Bar/Middle"] = comps[3];
    const opts = {
      title: "Pagination",
      colHeaders: [""],
      rowLabels: cases.map((c) => c.state),
      cellAt: (r, _c) => {
        var _a;
        return (_a = comps[r]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: maxW + 40,
      cellH: SZ + 24,
      rowLabelW: 80
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var GNB_MENU_SIZE = {
    md: { h: 56, font: 18, padX: 40, inset: 24 },
    sm: { h: 48, font: 18, padX: 32, inset: 20 },
    xsm: { h: 36, font: 14, padX: 32, inset: 20 }
  };
  var GNB_UTIL_SVGS = {
    // 원본 글리프(components.html). currentColor fill → icon/gray-dark 바인딩. viewBox 비율 보존(max side ≈ 24).
    lang: `<svg width="24" height="24" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18C13.9659 18 18 13.9659 18 9C18 4.03412 13.9659 0 9 0C4.03412 0 0 4.03412 0 9C0 13.9659 4.03412 18 9 18ZM2.97529 3.84353C3.56824 4.09765 4.18235 4.32 4.81765 4.5C4.42588 5.80235 4.20353 7.13647 4.16118 8.47059H1.09059C1.20706 6.71294 1.89529 5.10353 2.97529 3.84353ZM5.99294 1.65176C5.67529 2.25529 5.4 2.86941 5.16706 3.49412C4.69059 3.35647 4.22471 3.20824 3.78 3.02824C4.43647 2.45647 5.17765 1.99059 5.99294 1.65176ZM8.47059 1.09059V4.01294C7.71882 3.98118 6.95647 3.89647 6.20471 3.73765C6.53294 2.88 6.93529 2.03294 7.43294 1.21765C7.77177 1.15412 8.12118 1.11176 8.47059 1.09059ZM10.5671 1.21765C11.0647 2.03294 11.4671 2.88 11.7953 3.73765C11.0435 3.88588 10.2918 3.98118 9.52941 4.01294V1.09059C9.87882 1.11176 10.2282 1.15412 10.5671 1.21765ZM14.22 3.02824C13.7753 3.20824 13.3094 3.36706 12.8329 3.49412C12.6 2.86941 12.3247 2.25529 12.0071 1.65176C12.8224 1.99059 13.5635 2.45647 14.22 3.02824ZM16.9094 8.47059H13.8388C13.7965 7.13647 13.5741 5.80235 13.1824 4.5C13.8282 4.32 14.4424 4.09765 15.0247 3.84353C16.1047 5.10353 16.7929 6.71294 16.9094 8.47059ZM15.0247 14.1565C14.4424 13.9024 13.8176 13.68 13.1824 13.5C13.5741 12.1976 13.7965 10.8635 13.8388 9.52941H16.9094C16.7929 11.2871 16.1047 12.8965 15.0247 14.1565ZM12.0071 16.3482C12.3247 15.7447 12.6 15.1306 12.8329 14.5059C13.3094 14.6435 13.7753 14.7918 14.22 14.9718C13.5635 15.5435 12.8224 16.0094 12.0071 16.3482ZM9.52941 16.9094V13.9871C10.2812 14.0188 11.0435 14.1035 11.7953 14.2624C11.4671 15.12 11.0647 15.9671 10.5671 16.7824C10.2282 16.8459 9.87882 16.8882 9.52941 16.9094ZM7.43294 16.7824C6.93529 15.9671 6.53294 15.12 6.20471 14.2624C6.95647 14.1141 7.70824 14.0188 8.47059 13.9871V16.9094C8.12118 16.8882 7.77177 16.8459 7.43294 16.7824ZM3.78 14.9718C4.22471 14.7918 4.69059 14.6329 5.16706 14.5059C5.4 15.1306 5.67529 15.7447 5.99294 16.3482C5.17765 16.0094 4.43647 15.5435 3.78 14.9718ZM5.84471 4.74353C6.71294 4.92353 7.59177 5.04 8.47059 5.07176V8.47059H5.22C5.26235 7.22118 5.47412 5.97177 5.85529 4.74353H5.84471ZM12.1553 4.74353C12.5259 5.97177 12.7376 7.22118 12.7906 8.47059H9.54V5.07176C10.4188 5.04 11.2871 4.93412 12.1659 4.74353H12.1553ZM12.1553 13.2565C11.2871 13.0765 10.4082 12.96 9.52941 12.9388V9.54H12.78C12.7376 10.7894 12.5259 12.0388 12.1447 13.2671L12.1553 13.2565ZM8.47059 9.52941V12.9282C7.59177 12.96 6.72353 13.0659 5.84471 13.2459C5.47412 12.0176 5.26235 10.7682 5.20941 9.51882H8.46L8.47059 9.52941ZM4.16118 9.52941C4.20353 10.8635 4.42588 12.1976 4.81765 13.5C4.17177 13.68 3.55765 13.9024 2.97529 14.1565C1.89529 12.8965 1.20706 11.2871 1.09059 9.52941H4.16118Z" fill="currentColor"/></svg>`,
    account: `<svg width="24" height="21.58" viewBox="0 0 24 21.5816" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.561 13.7324H7.43901C5.67118 13.7324 4.00236 14.3971 2.84266 15.5568C0.494991 17.9186 0.0141426 21.2704 0 21.3977L1.37183 21.5816C1.37183 21.5816 1.81025 18.5409 3.8185 16.5185C4.72363 15.6134 6.03889 15.1042 7.43901 15.1042H16.561C17.9611 15.1042 19.2764 15.6275 20.1815 16.5185C22.1897 18.5409 22.6282 21.5391 22.6282 21.5816L24 21.3977C23.9859 21.2563 23.505 17.9045 21.1573 15.5568C19.9976 14.3971 18.3288 13.7324 16.561 13.7324Z" fill="currentColor"/><path d="M5.9968 6.01061C5.9968 9.31998 8.69803 12.0212 12.0074 12.0212C15.3168 12.0212 18.018 9.31998 18.018 6.01061C18.018 2.70124 15.3168 0 12.0074 0C8.69803 0 5.9968 2.70124 5.9968 6.01061ZM16.6037 6.01061C16.6037 8.54213 14.5389 10.607 12.0074 10.607C9.47588 10.607 7.41106 8.54213 7.41106 6.01061C7.41106 3.47908 9.47588 1.41426 12.0074 1.41426C14.5389 1.41426 16.6037 3.47908 16.6037 6.01061Z" fill="currentColor"/></svg>`,
    menu: `<svg width="24" height="16.93" viewBox="0 0 24 16.9274" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0 1.41176H24V0.705882V0H0V1.41176Z" fill="currentColor"/><path d="M0 9.17647H24V8.47059V7.76471H0V9.17647Z" fill="currentColor"/><path d="M0 16.9274H24V16.2215V15.5156H0V16.9274Z" fill="currentColor"/></svg>`
  };
  async function fillGnbMenu(node, maps, sizeKey, state) {
    const navc = (k) => `color/navigation/${k}`;
    const S = GNB_MENU_SIZE[sizeKey];
    const active = state !== "Default";
    node.fills = [];
    const t = await makeBoundText("\uBA54\uB274\uD0C0\uC774\uD2C0", S.font, "Medium", scv(maps, navc(active ? "label/selected" : "label/default-alt")));
    node.appendChild(t);
    const W = Math.max(116, Math.ceil(t.width) + S.padX * 2);
    node.resize(W, S.h);
    t.x = (W - t.width) / 2;
    t.y = (S.h - t.height) / 2;
    const ul = figma.createRectangle();
    ul.resize(W - S.inset * 2, 2);
    ul.x = S.inset;
    ul.y = S.h - 2;
    ul.fills = active ? [boundPaint(scv(maps, navc("indicator/selected")))] : [];
    node.appendChild(ul);
    return W;
  }
  async function buildGNBUtilIcon(maps, originY) {
    var _a;
    const iconBox = async (role, svg) => {
      const box = figma.createFrame();
      box.name = role;
      box.resize(32, 32);
      box.fills = [];
      box.layoutMode = "HORIZONTAL";
      box.primaryAxisSizingMode = "FIXED";
      box.counterAxisSizingMode = "FIXED";
      box.primaryAxisAlignItems = "CENTER";
      box.counterAxisAlignItems = "CENTER";
      box.appendChild(await makeIconInstance(role, scv(maps, "color/icon/gray-dark"), 24, svg));
      return box;
    };
    const defs = [
      { language: "on", menu: "on", user: "on", label: "\uC5B8\uC5B4\xB7\uACC4\uC815\xB7\uBA54\uB274" },
      { language: "on", menu: "off", user: "on", label: "\uC5B8\uC5B4\xB7\uACC4\uC815" },
      { language: "on", menu: "off", user: "off", label: "\uC5B8\uC5B4" },
      { language: "off", menu: "on", user: "on", label: "\uACC4\uC815\xB7\uBA54\uB274" },
      { language: "off", menu: "off", user: "on", label: "\uACC4\uC815" }
    ];
    const comps = [];
    for (const d of defs) {
      const comp = figma.createComponent();
      comp.name = `language=${d.language}, full menu=${d.menu}, user=${d.user}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.itemSpacing = 8;
      comp.fills = [];
      if (d.language === "on") {
        const langComp = (_a = BUILT_COMPS["LanguageIcon:Korean"]) != null ? _a : BUILT_COMPS["LanguageIcon:English"];
        if (langComp) comp.appendChild(langComp.createInstance());
      }
      if (d.user === "on") comp.appendChild(await iconBox("account", GNB_UTIL_SVGS.account));
      if (d.menu === "on") comp.appendChild(await iconBox("menu", GNB_UTIL_SVGS.menu));
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "GNB Utility Icon";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["GNB Utility Icon"] = set;
    BUILT_COMPS["GNBUtil:full"] = comps[0];
    const opts = {
      title: "GNB Utility Icon",
      colHeaders: [""],
      rowLabels: defs.map((d) => d.label),
      cellAt: (r, _c) => {
        var _a2;
        return (_a2 = comps[r]) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 40,
      rowLabelW: 120
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLanguageIcon(maps, originY) {
    const variants = [
      { lang: "English", text: "English" },
      { lang: "Korean", text: "\uD55C\uAD6D\uC5B4" }
    ];
    const comps = [];
    for (const v of variants) {
      const comp = figma.createComponent();
      comp.name = `Language=${v.lang}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.itemSpacing = 4;
      comp.paddingRight = 8;
      comp.fills = [];
      const globe = figma.createFrame();
      globe.name = "globe";
      globe.resize(32, 32);
      globe.fills = [];
      const gi = await makeIconInstance("globe", scv(maps, "color/icon/gray-dark"), 24, GNB_UTIL_SVGS.lang);
      globe.appendChild(gi);
      gi.x = (32 - gi.width) / 2;
      gi.y = (32 - gi.height) / 2;
      comp.appendChild(globe);
      const t = await makeBoundText(v.text, 14, "Medium", scv(maps, "color/text/body/primary"));
      comp.appendChild(t);
      setLightMode(comp, maps);
      comps.push(comp);
      BUILT_COMPS[`LanguageIcon:${v.lang}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Language Icon";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Language Icon"] = set;
    const opts = {
      title: "Language Icon",
      colHeaders: variants.map((v) => v.lang),
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = comps[c]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildMobileBottomNav(maps, originY) {
    const variants = [
      { state: "unselected", icon: "color/icon/gray", label: "color/navigation/label/default" },
      { state: "selected", icon: "color/icon/blue", label: "color/navigation/label/selected" }
    ];
    const comps = [];
    for (const v of variants) {
      const comp = figma.createComponent();
      comp.name = `state=${v.state}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.itemSpacing = 4;
      comp.fills = [];
      comp.resize(60, 60);
      const icon = await makeIconInstance("home", scv(maps, v.icon), 32, HOME_SVG);
      comp.appendChild(icon);
      const label = await makeBoundText("\uB77C\uBCA8", 12, "Medium", scv(maps, v.label));
      comp.appendChild(label);
      setLightMode(comp, maps);
      comps.push(comp);
      BUILT_COMPS[`MobileBottomNav:${v.state}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Mobile Bottom Nav";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Mobile Bottom Nav"] = set;
    const opts = {
      title: "Mobile Bottom Nav",
      colHeaders: ["Unselected", "Selected"],
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = comps[c]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 60,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildGNB(maps, originY) {
    var _a, _b;
    const navc = (k) => `color/navigation/${k}`;
    const sizeKeys = ["md", "sm", "xsm"];
    const menuStates = ["Default", "Hover", "Selected"];
    const menuComps = [];
    const menuCellByKey = /* @__PURE__ */ new Map();
    for (const sk of sizeKeys) {
      for (const ms of menuStates) {
        const comp = figma.createComponent();
        comp.name = `Size=${sk}, State=${ms}`;
        await fillGnbMenu(comp, maps, sk, ms);
        setLightMode(comp, maps);
        menuComps.push(comp);
        menuCellByKey.set(`${sk}/${ms}`, comp);
      }
    }
    const menuSet = figma.combineAsVariants(menuComps, figma.currentPage);
    menuSet.name = "GNB Menu";
    const menuOpts = {
      title: "GNB Menu",
      platforms: [{ name: "PC", sizes: sizeKeys }],
      rowLabels: [""],
      colHeaders: menuStates,
      cellAt: (_p, size, _ri, ci) => {
        var _a2;
        return (_a2 = menuCellByKey.get(`${size}/${menuStates[ci]}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 72,
      rowLabelW: 16
    };
    let bottomY = originY;
    const BAR_W = 1920;
    const barH = { md: 56, sm: 48, xsm: 36 };
    const aligns = [
      { name: "Center-Between", key: "center-between" },
      { name: "Start", key: "start" }
    ];
    const barComps = [];
    const barCellByKey = /* @__PURE__ */ new Map();
    for (const al of aligns) {
      for (const sk of sizeKeys) {
        const h = barH[sk];
        const padL = sk === "xsm" ? 20 : 24;
        const padR = sk === "xsm" ? 24 : 20;
        const comp = figma.createComponent();
        comp.name = `Align=${al.name}, Size=${sk}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.paddingLeft = padL;
        comp.paddingRight = padR;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.itemSpacing = 0;
        comp.fills = [boundPaint(scv(maps, navc("bg")))];
        comp.clipsContent = true;
        comp.resize(BAR_W, h);
        const logo = await makeBoundText("SAMPLE LOGO", 20, "Bold", scv(maps, "color/text/title/primary"));
        const menus = figma.createFrame();
        menus.name = "menus";
        menus.fills = [];
        menus.layoutMode = "HORIZONTAL";
        menus.itemSpacing = 0;
        menus.counterAxisAlignItems = "CENTER";
        menus.primaryAxisSizingMode = "AUTO";
        menus.counterAxisSizingMode = "AUTO";
        for (let mi = 0; mi < 3; mi++) {
          const state = mi === 0 ? "Selected" : "Default";
          const menuComp = menuCellByKey.get(`${sk}/${state}`);
          if (menuComp) {
            menus.appendChild(menuComp.createInstance());
          } else {
            const slot = figma.createFrame();
            slot.name = "menu";
            menus.appendChild(slot);
            await fillGnbMenu(slot, maps, sk, state);
          }
        }
        let utilComp = BUILT_COMPS["GNBUtil:full"];
        if (!utilComp) {
          const us = await getBuiltSet("GNB Utility Icon");
          if (us) utilComp = (_a = (us.children || []).find((c) => c.type === "COMPONENT" && c.name.includes("language=on, full menu=on, user=on"))) != null ? _a : (us.children || []).find((c) => c.type === "COMPONENT");
        }
        const util = utilComp ? utilComp.createInstance() : null;
        if (al.key === "center-between") {
          comp.appendChild(logo);
          comp.appendChild(menus);
          if (util) comp.appendChild(util);
        } else {
          const leading = figma.createFrame();
          leading.name = "leading";
          leading.fills = [];
          leading.layoutMode = "HORIZONTAL";
          leading.itemSpacing = 64;
          leading.counterAxisAlignItems = "CENTER";
          leading.primaryAxisSizingMode = "AUTO";
          leading.counterAxisSizingMode = "AUTO";
          leading.appendChild(logo);
          leading.appendChild(menus);
          comp.appendChild(leading);
          if (util) comp.appendChild(util);
        }
        const border = figma.createRectangle();
        border.name = "border";
        border.resize(BAR_W, 1);
        border.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
        try {
          comp.insertChild(0, border);
        } catch (e) {
          comp.appendChild(border);
        }
        try {
          border.layoutPositioning = "ABSOLUTE";
        } catch (e) {
        }
        border.x = 0;
        border.y = h - 1;
        setLightMode(comp, maps);
        barComps.push(comp);
        barCellByKey.set(`${al.name}/${sk}`, comp);
      }
    }
    const barSet = figma.combineAsVariants(barComps, figma.currentPage);
    barSet.name = "GNB";
    const barTop = originY;
    const barOrder = [];
    for (const a of aligns) for (const sk of sizeKeys) barOrder.push({ comp: (_b = barCellByKey.get(`${a.name}/${sk}`)) != null ? _b : null, label: `${a.name} \xB7 ${sk}` });
    const barOpts = {
      title: "GNB",
      colHeaders: [""],
      rowLabels: barOrder.map((b) => b.label),
      cellAt: (r, _c) => barOrder[r].comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY: barTop,
      cellW: BAR_W + 40,
      cellH: 96,
      rowLabelW: 160
    };
    const barLightBottomY = await decorateSetFlat(barSet, barOpts, maps);
    bottomY = Math.max(bottomY, barLightBottomY);
    barOpts.darkOffset = { x: 0, y: barLightBottomY + 80 };
    try {
      bottomY = Math.max(bottomY, await buildSpec(barOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    menuOpts.originY = bottomY + 80;
    bottomY = Math.max(bottomY, await decorateSetGrouped(menuSet, menuOpts, maps));
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(menuOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set: barSet, bottomY };
  }
  var DP = (k) => `color/date-picker/${k}`;
  async function buildCalendarCell(maps) {
    const STD = {
      Default: ["cell/bg/today", "cell/bg/today", "text/secondary"],
      Hover: ["cell/bg/hover", "cell/bg/hover", "text/secondary"],
      Today: ["cell/bg/today", "cell/border/today", "text/today"],
      Selected: ["cell/bg/selected", "cell/border/today", "text/selected"],
      Disabled: ["cell/bg/today", "cell/bg/today", "text/disabled"]
    };
    const RNG = {
      Default: [0, 44, "cell/bg/range", "cell/bg/range", "text/secondary"],
      Start: [22, 22, "cell/bg/today", "cell/border/today", "text/today"],
      End: [0, 22, "cell/bg/selected", "cell/border/today", "text/selected"],
      Disabled: [0, 44, "cell/bg/range", "cell/bg/range", "text/disabled"]
    };
    async function makeInner(fillKey, strokeKey, textKey, bold) {
      const inner = figma.createFrame();
      inner.name = "inner";
      inner.cornerRadius = 999;
      inner.layoutMode = "HORIZONTAL";
      inner.primaryAxisAlignItems = "CENTER";
      inner.counterAxisAlignItems = "CENTER";
      inner.primaryAxisSizingMode = "FIXED";
      inner.counterAxisSizingMode = "FIXED";
      inner.resize(30, 30);
      inner.fills = [boundPaint(scv(maps, DP(fillKey)))];
      inner.strokes = [boundPaint(scv(maps, DP(strokeKey)))];
      inner.strokeWeight = 1;
      inner.strokeAlign = "INSIDE";
      const t = await makeBoundText("1", 16, bold ? "Medium" : "Medium", scv(maps, DP(textKey)));
      t.name = "num";
      inner.appendChild(t);
      return inner;
    }
    const comps = [];
    const variants = {};
    function makeOuter(name) {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(44, 44);
      comp.fills = [];
      comp.clipsContent = true;
      return comp;
    }
    for (const state of ["Default", "Hover", "Today", "Selected", "Disabled"]) {
      const [f, s, txt] = STD[state];
      const comp = makeOuter(`Type=Standard, State=${state}`);
      comp.appendChild(await makeInner(f, s, txt, state === "Selected"));
      comps.push(comp);
      variants[`Standard:${state}`] = comp;
    }
    for (const state of ["Default", "Start", "End", "Disabled"]) {
      const [bx, bw, f, s, txt] = RNG[state];
      const comp = makeOuter(`Type=Range, State=${state}`);
      const band = figma.createRectangle();
      band.name = "band";
      band.resize(bw, 30);
      band.fills = [boundPaint(scv(maps, DP("cell/bg/range")))];
      band.strokes = [];
      comp.appendChild(band);
      try {
        band.layoutPositioning = "ABSOLUTE";
      } catch (e) {
      }
      try {
        band.x = bx;
        band.y = 7;
      } catch (e) {
      }
      comp.appendChild(await makeInner(f, s, txt, state === "End"));
      comps.push(comp);
      variants[`Range:${state}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Calendar Cell";
    return { set, variants };
  }
  async function buildCalendarTile(maps) {
    const TILE = {
      Default: ["tile/bg/default", "tile/border/default", "text/primary", "2022"],
      // Hover bg = Secondary 버튼 hover foundation 동일(gray/50·gray-dark/200) → tile/bg/hover 신규(사용자 결정 2026-06-25).
      Hover: ["tile/bg/hover", "tile/border/default", "text/primary", "2023"],
      Selected: ["tile/bg/selected", "cell/border/today", "text/today", "2025"],
      Disabled: ["tile/bg/disabled", "tile/border/disabled", "text/disabled", "2021"]
    };
    const comps = [];
    const variants = {};
    for (const state of ["Default", "Hover", "Selected", "Disabled"]) {
      const [bg, bd, txt, label] = TILE[state];
      const comp = figma.createComponent();
      comp.name = `State=${state}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(88, 56);
      comp.cornerRadius = 4;
      comp.clipsContent = true;
      comp.fills = [boundPaint(scv(maps, DP(bg)))];
      comp.strokes = [boundPaint(scv(maps, DP(bd)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const t = await makeBoundText(label, 16, "Medium", scv(maps, DP(txt)));
      t.name = "label";
      comp.appendChild(t);
      comps.push(comp);
      variants[state] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Calendar Tile";
    return { set, variants };
  }
  var _calCell = null;
  var _calTile = null;
  function variantProp(comp, prop) {
    const m = comp.name.match(new RegExp(`(?:^|, )${prop}=([^,]+)`));
    return m ? m[1].trim() : null;
  }
  function reconstructCalCellVariants(set) {
    const variants = {};
    for (const ch of set.children) {
      if (ch.type !== "COMPONENT") continue;
      const t = variantProp(ch, "Type"), s = variantProp(ch, "State");
      if (t && s) variants[`${t}:${s}`] = ch;
    }
    return variants;
  }
  function reconstructCalTileVariants(set) {
    const variants = {};
    for (const ch of set.children) {
      if (ch.type !== "COMPONENT") continue;
      const s = variantProp(ch, "State");
      if (s) variants[s] = ch;
    }
    return variants;
  }
  async function getOrBuildCalendarCell(maps) {
    if (_calCell && !_calCell.set.removed) return _calCell;
    const existing = await getBuiltSet("Calendar Cell");
    if (existing && !existing.removed && existing.children.some((c) => c.type === "COMPONENT")) {
      _calCell = { set: existing, variants: reconstructCalCellVariants(existing) };
    } else {
      _calCell = await buildCalendarCell(maps);
    }
    BUILT_SETS["Calendar Cell"] = _calCell.set;
    for (const [k, c] of Object.entries(_calCell.variants)) BUILT_COMPS[`CalendarCell:${k}`] = c;
    return _calCell;
  }
  async function getOrBuildCalendarTile(maps) {
    if (_calTile && !_calTile.set.removed) return _calTile;
    const existing = await getBuiltSet("Calendar Tile");
    if (existing && !existing.removed && existing.children.some((c) => c.type === "COMPONENT")) {
      _calTile = { set: existing, variants: reconstructCalTileVariants(existing) };
    } else {
      _calTile = await buildCalendarTile(maps);
    }
    BUILT_SETS["Calendar Tile"] = _calTile.set;
    for (const [k, c] of Object.entries(_calTile.variants)) BUILT_COMPS[`CalendarTile:${k}`] = c;
    return _calTile;
  }
  async function calCellInstance(cell, key, day) {
    var _a, _b;
    const master = (_a = cell.variants[key]) != null ? _a : cell.variants["Standard:Default"];
    const inst = master.createInstance();
    const t = (_b = inst.findOne((n) => n.name === "num" && n.type === "TEXT")) != null ? _b : inst.findOne((n) => n.type === "TEXT");
    if (t) {
      await figma.loadFontAsync(t.fontName);
      t.characters = String(day);
    }
    return inst;
  }
  async function calTileInstance(tile, state, label) {
    var _a, _b;
    const master = (_a = tile.variants[state]) != null ? _a : tile.variants["Default"];
    const inst = master.createInstance();
    const t = (_b = inst.findOne((n) => n.name === "label" && n.type === "TEXT")) != null ? _b : inst.findOne((n) => n.type === "TEXT");
    if (t) {
      await figma.loadFontAsync(t.fontName);
      t.characters = label;
    }
    return inst;
  }
  function dayKindToCellKey(kind) {
    if (kind === "today") return "Standard:Today";
    if (kind === "selected") return "Standard:Selected";
    if (kind === "disabled" || kind === "other") return "Standard:Disabled";
    return "Standard:Default";
  }
  async function buildCalendar(maps, originY) {
    const dp = (k) => `color/date-picker/${k}`;
    const calCell = await getOrBuildCalendarCell(maps);
    const calTile = await getOrBuildCalendarTile(maps);
    const CHEV_L = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 12L6 8l4-4" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const CHEV_R = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M6 4l4 4-4 4" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const PANEL_W = 356, PANEL_H = 352;
    const CW = 308 / 7;
    function initComp(compName, vGap) {
      const comp = figma.createComponent();
      comp.name = compName;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.resize(PANEL_W, PANEL_H);
      comp.paddingLeft = 24;
      comp.paddingRight = 24;
      comp.paddingTop = 20;
      comp.paddingBottom = 20;
      comp.itemSpacing = 0;
      comp.cornerRadius = 4;
      comp.fills = [boundPaint(scv(maps, dp("panel/bg")))];
      comp.strokes = [boundPaint(scv(maps, dp("panel/border")))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.clipsContent = true;
      const calEffects = shadowEffects("shadow/dropdown");
      try {
        comp.effects = calEffects;
      } catch (_) {
      }
      const inner = figma.createFrame();
      inner.name = "content";
      inner.fills = [];
      inner.layoutMode = "VERTICAL";
      inner.primaryAxisSizingMode = "AUTO";
      inner.counterAxisSizingMode = "AUTO";
      inner.counterAxisAlignItems = "CENTER";
      inner.itemSpacing = vGap;
      comp.appendChild(inner);
      inner.layoutAlign = "STRETCH";
      return [comp, inner];
    }
    async function makeCalHdr(label) {
      const hdr = figma.createFrame();
      hdr.name = "header";
      hdr.fills = [];
      hdr.layoutMode = "HORIZONTAL";
      hdr.primaryAxisSizingMode = "FIXED";
      hdr.counterAxisSizingMode = "FIXED";
      hdr.primaryAxisAlignItems = "SPACE_BETWEEN";
      hdr.counterAxisAlignItems = "CENTER";
      hdr.resize(308, 32);
      hdr.appendChild(await makeIconInstance("chevron", scv(maps, dp("icon/default")), 0, CHEV_L, 180, { wrap: false }));
      hdr.appendChild(await makeBoundText(label, 24, "Bold", scv(maps, dp("text/primary"))));
      hdr.appendChild(await makeIconInstance("chevron", scv(maps, dp("icon/default")), 0, CHEV_R, 0));
      return hdr;
    }
    async function makeYMTile(label, disabled) {
      return calTileInstance(calTile, disabled ? "Disabled" : "Default", label);
    }
    async function makeYMRow(labels, dis) {
      var _a;
      const row = figma.createFrame();
      row.name = "tile-row";
      row.fills = [];
      row.layoutMode = "HORIZONTAL";
      row.primaryAxisSizingMode = "AUTO";
      row.counterAxisSizingMode = "AUTO";
      row.counterAxisAlignItems = "CENTER";
      row.itemSpacing = 12;
      for (let i = 0; i < labels.length; i++) row.appendChild(await makeYMTile(labels[i], (_a = dis[i]) != null ? _a : false));
      return row;
    }
    const [dateComp, dateInner] = initComp("State=Date", 16);
    dateInner.appendChild(await makeCalHdr("2025.01"));
    const calBody = figma.createFrame();
    calBody.name = "cal-body";
    calBody.fills = [];
    calBody.layoutMode = "VERTICAL";
    calBody.primaryAxisSizingMode = "AUTO";
    calBody.counterAxisSizingMode = "AUTO";
    calBody.counterAxisAlignItems = "MIN";
    calBody.itemSpacing = 0;
    dateInner.appendChild(calBody);
    const wkRow = figma.createFrame();
    wkRow.name = "weekdays";
    wkRow.fills = [];
    wkRow.layoutMode = "HORIZONTAL";
    wkRow.itemSpacing = 0;
    wkRow.primaryAxisSizingMode = "AUTO";
    wkRow.counterAxisSizingMode = "AUTO";
    calBody.appendChild(wkRow);
    for (const ch of ["\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0", "\uC77C"]) {
      const cell = figma.createFrame();
      cell.name = "wk";
      cell.fills = [];
      cell.layoutMode = "HORIZONTAL";
      cell.primaryAxisAlignItems = "CENTER";
      cell.counterAxisAlignItems = "CENTER";
      cell.primaryAxisSizingMode = "FIXED";
      cell.counterAxisSizingMode = "FIXED";
      cell.resize(CW, 44);
      cell.appendChild(await makeBoundText(ch, 16, "Medium", scv(maps, dp("text/primary"))));
      wkRow.appendChild(cell);
    }
    const calGrid = [{ day: 30, kind: "other" }, { day: 31, kind: "other" }];
    for (let d = 1; d <= 31; d++) {
      calGrid.push({ day: d, kind: d === 10 ? "today" : d === 17 ? "selected" : d === 25 ? "disabled" : "normal" });
    }
    let nm = 1;
    while (calGrid.length < 35) calGrid.push({ day: nm++, kind: "other" });
    for (let r = 0; r < 5; r++) {
      const weekRow = figma.createFrame();
      weekRow.name = "week";
      weekRow.fills = [];
      weekRow.layoutMode = "HORIZONTAL";
      weekRow.itemSpacing = 0;
      weekRow.primaryAxisSizingMode = "AUTO";
      weekRow.counterAxisSizingMode = "AUTO";
      calBody.appendChild(weekRow);
      for (let c = 0; c < 7; c++) {
        const g = calGrid[r * 7 + c];
        const inst = await calCellInstance(calCell, dayKindToCellKey(g.kind), g.day);
        weekRow.appendChild(inst);
      }
    }
    setLightMode(dateComp, maps);
    const [yearComp, yearInner] = initComp("State=Year", 20);
    yearInner.appendChild(await makeCalHdr("2025"));
    const yearGrid = figma.createFrame();
    yearGrid.name = "year-grid";
    yearGrid.fills = [];
    yearGrid.layoutMode = "VERTICAL";
    yearGrid.primaryAxisSizingMode = "AUTO";
    yearGrid.counterAxisSizingMode = "AUTO";
    yearGrid.counterAxisAlignItems = "CENTER";
    yearGrid.itemSpacing = 12;
    for (const [ls, ds] of [
      [["2021", "2022", "2023"], [true, false, false]],
      [["2024", "2025", "2026"], [false, false, false]],
      [["2027", "2028", "2029"], [false, false, false]],
      [["2030", "2031", "2032"], [true, true, true]]
    ]) yearGrid.appendChild(await makeYMRow(ls, ds));
    yearInner.appendChild(yearGrid);
    setLightMode(yearComp, maps);
    const [monthComp, monthInner] = initComp("State=Month", 20);
    monthInner.appendChild(await makeCalHdr("2025"));
    const monthGrid = figma.createFrame();
    monthGrid.name = "month-grid";
    monthGrid.fills = [];
    monthGrid.layoutMode = "VERTICAL";
    monthGrid.primaryAxisSizingMode = "AUTO";
    monthGrid.counterAxisSizingMode = "AUTO";
    monthGrid.counterAxisAlignItems = "CENTER";
    monthGrid.itemSpacing = 12;
    for (const ls of [["1\uC6D4", "2\uC6D4", "3\uC6D4"], ["4\uC6D4", "5\uC6D4", "6\uC6D4"], ["7\uC6D4", "8\uC6D4", "9\uC6D4"], ["10\uC6D4", "11\uC6D4", "12\uC6D4"]]) {
      monthGrid.appendChild(await makeYMRow(ls, [false, false, false]));
    }
    monthInner.appendChild(monthGrid);
    setLightMode(monthComp, maps);
    const set = figma.combineAsVariants([dateComp, yearComp, monthComp], figma.currentPage);
    set.name = "Calendar";
    set.x = 0;
    set.y = originY;
    BUILT_COMPS["Calendar:Date"] = dateComp;
    BUILT_COMPS["Calendar:Year"] = yearComp;
    BUILT_COMPS["Calendar:Month"] = monthComp;
    BUILT_SETS["Calendar"] = set;
    const opts = {
      title: "Calendar",
      colHeaders: ["Date", "Year", "Month"],
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = [dateComp, yearComp, monthComp][c]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 380
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDatePicker(maps, originY) {
    var _a;
    const fc = (k) => `color/form-control/${k}`;
    const CAL_ICON = `<svg width="16" height="16" viewBox="0 0 16.2581 16.8" fill="none"><path d="M0 1.08387V16.2581C0 16.5615 0.238452 16.8 0.541936 16.8H15.7161C16.0196 16.8 16.2581 16.5615 16.2581 16.2581V1.08387C16.2581 0.780387 16.0196 0.541935 15.7161 0.541935H13.0065V0H11.9226V0.541935H4.33548V0H3.25161V0.541935H0.541936C0.238452 0.541935 0 0.780387 0 1.08387ZM4.33548 2.16774V1.62581H11.9226V2.16774H13.0065V1.62581H15.1742V3.79355H1.08387V1.62581H3.25161V2.16774H4.33548ZM15.1742 15.7161H1.08387V4.87742H15.1742V15.7161Z" fill="#000"/><path d="M5.14859 9.21302H3.52279V10.8388H5.14859V9.21302Z" fill="#000"/><path d="M8.94208 9.21302H7.31628V10.8388H8.94208V9.21302Z" fill="#000"/><path d="M12.7356 9.21302H11.1098V10.8388H12.7356V9.21302Z" fill="#000"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "YY.MM.DD", tc: "text/placeholder", icon: "icon/default", open: false },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "26.06.17", tc: "text/default", icon: "icon/default", open: false },
      { name: "Open", bg: "bg/selected", border: "border/selected", txt: "26.06.17", tc: "text/selected", icon: "icon/default", open: true },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "YY.MM.DD", tc: "text/disabled", icon: "icon/disabled", open: false }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12 },
      { size: "XSM", brk: "PC", h: 34, font: 14 },
      { size: "MD", brk: "PC", h: 44, font: 14 },
      { size: "MD", brk: "Mobile", h: 48, font: 14 }
    ];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const trigger = figma.createFrame();
        trigger.name = "trigger";
        trigger.layoutMode = "HORIZONTAL";
        trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
        trigger.counterAxisAlignItems = "CENTER";
        trigger.primaryAxisSizingMode = "FIXED";
        trigger.counterAxisSizingMode = "FIXED";
        trigger.paddingLeft = 16;
        trigger.paddingRight = 8;
        trigger.paddingTop = 0;
        trigger.paddingBottom = 0;
        trigger.cornerRadius = 4;
        trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
        trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
        trigger.strokeWeight = 1;
        trigger.strokeAlign = "INSIDE";
        trigger.appendChild(await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc))));
        trigger.appendChild(await makeIconInstance("calendar", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), CAL_ICON));
        trigger.resize(180, sc.h);
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        comp.fills = [];
        comp.appendChild(trigger);
        if (st.open && sc.brk === "PC") {
          let calComp = BUILT_COMPS["Calendar:Date"];
          if (!calComp) {
            const calSet = await getBuiltSet("Calendar");
            if (calSet) {
              calComp = (_a = calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Date"))) != null ? _a : calSet.children.find((c) => c.type === "COMPONENT");
            }
          }
          if (calComp) {
            const calInst = calComp.createInstance();
            calInst.name = "calendar";
            comp.appendChild(calInst);
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Date Picker";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Date Picker",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a2, _b;
        return (_b = (_a2 = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a2.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 440,
      rowLabelW: 16
      // cellW≥캘린더356 → Open 패널이 Disabled 열 침범 방지
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDatePickerBottomSheet(maps, originY) {
    var _a, _b;
    const SHEET_W = 360;
    const comp = figma.createComponent();
    comp.name = "Platform=Mobile";
    comp.layoutMode = "VERTICAL";
    comp.primaryAxisSizingMode = "AUTO";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(SHEET_W, 100);
    comp.itemSpacing = 32;
    comp.paddingTop = 20;
    comp.paddingBottom = 20;
    comp.paddingLeft = 0;
    comp.paddingRight = 0;
    comp.counterAxisAlignItems = "CENTER";
    comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
    try {
      comp.topLeftRadius = 8;
      comp.topRightRadius = 8;
      comp.bottomLeftRadius = 0;
      comp.bottomRightRadius = 0;
    } catch (e) {
    }
    comp.clipsContent = false;
    const header = figma.createFrame();
    header.name = "header";
    header.fills = [];
    header.layoutMode = "HORIZONTAL";
    header.primaryAxisSizingMode = "FIXED";
    header.counterAxisSizingMode = "AUTO";
    header.primaryAxisAlignItems = "SPACE_BETWEEN";
    header.counterAxisAlignItems = "CENTER";
    header.paddingLeft = 20;
    header.paddingRight = 20;
    comp.appendChild(header);
    try {
      header.layoutAlign = "STRETCH";
    } catch (e) {
    }
    const title = await makeBoundText("\uB0A0\uC9DC \uC120\uD0DD", 20, "Bold", scv(maps, "color/text/title/primary"));
    title.name = "title";
    header.appendChild(title);
    const closeIcon = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
    closeIcon.name = "close";
    header.appendChild(closeIcon);
    const calWrap = figma.createFrame();
    calWrap.name = "calendar-wrap";
    calWrap.fills = [];
    calWrap.layoutMode = "VERTICAL";
    calWrap.primaryAxisSizingMode = "AUTO";
    calWrap.counterAxisSizingMode = "FIXED";
    calWrap.primaryAxisAlignItems = "CENTER";
    calWrap.counterAxisAlignItems = "CENTER";
    calWrap.paddingLeft = 24;
    calWrap.paddingRight = 24;
    comp.appendChild(calWrap);
    try {
      calWrap.layoutAlign = "STRETCH";
    } catch (e) {
    }
    let calComp = BUILT_COMPS["Calendar:Date"];
    if (!calComp) {
      const calSet = await getBuiltSet("Calendar");
      if (calSet) {
        calComp = (_a = calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Date"))) != null ? _a : calSet.children.find((c) => c.type === "COMPONENT");
      }
    }
    if (calComp) {
      const calInst = calComp.createInstance();
      calInst.name = "calendar";
      try {
        calInst.strokes = [];
        calInst.effects = [];
      } catch (e) {
      }
      calWrap.appendChild(calInst);
    }
    const actionWrap = figma.createFrame();
    actionWrap.name = "action";
    actionWrap.fills = [];
    actionWrap.layoutMode = "HORIZONTAL";
    actionWrap.primaryAxisSizingMode = "FIXED";
    actionWrap.counterAxisSizingMode = "AUTO";
    actionWrap.primaryAxisAlignItems = "CENTER";
    actionWrap.counterAxisAlignItems = "CENTER";
    actionWrap.paddingLeft = 20;
    actionWrap.paddingRight = 20;
    comp.appendChild(actionWrap);
    try {
      actionWrap.layoutAlign = "STRETCH";
    } catch (e) {
    }
    let btnComp = BUILT_COMPS["Button:primary:LG:Default"];
    if (!btnComp) {
      const btnSet = await getBuiltSet("Button");
      if (btnSet) {
        btnComp = (_b = btnSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Variant=Primary") && c.name.includes("Size=LG") && c.name.includes("State=Default"))) != null ? _b : btnSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Variant=Primary"));
      }
    }
    if (btnComp) {
      const applyBtn = btnComp.createInstance();
      applyBtn.name = "apply";
      const txt = applyBtn.findOne((n) => n.type === "TEXT");
      if (txt) {
        try {
          txt.characters = "\uC801\uC6A9";
        } catch (e) {
        }
      }
      actionWrap.appendChild(applyBtn);
      try {
        applyBtn.layoutSizingHorizontal = "FILL";
      } catch (e) {
      }
    }
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "Date Picker Mobile Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Date Picker Mobile Bottom Sheet"] = set;
    const opts = {
      title: "Date Picker Mobile Bottom Sheet",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: SHEET_W + 40,
      cellH: 500,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildTimePickerMobileBottomSheet(maps, originY) {
    const SHEET_W = 360;
    const FADE_H = 110;
    const ACCENT = "color/text/state/accent";
    const makeWheelCol = async (name, labels, gap, align) => {
      const col = figma.createFrame();
      col.name = name;
      col.fills = [];
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "AUTO";
      col.counterAxisSizingMode = "AUTO";
      col.primaryAxisAlignItems = "CENTER";
      col.counterAxisAlignItems = align;
      col.itemSpacing = gap;
      for (const lb of labels) {
        const t = await makeBoundText(lb, 32, "Regular", scv(maps, ACCENT));
        col.appendChild(t);
      }
      return col;
    };
    const makeWheelFade = (position) => {
      const fade = figma.createFrame();
      fade.name = position === "top" ? "fade-top" : "fade-bottom";
      fade.fills = [];
      fade.clipsContent = true;
      fade.resize(SHEET_W, FADE_H);
      const A = 0.9;
      const mask = figma.createRectangle();
      mask.name = "fade-mask";
      mask.resize(SHEET_W, FADE_H);
      const stops = position === "top" ? [{ position: 0, color: { r: 1, g: 1, b: 1, a: A } }, { position: 1, color: { r: 1, g: 1, b: 1, a: 0 } }] : [{ position: 0, color: { r: 1, g: 1, b: 1, a: 0 } }, { position: 1, color: { r: 1, g: 1, b: 1, a: A } }];
      mask.fills = [{ type: "GRADIENT_LINEAR", gradientTransform: [[0, 1, 0], [-1, 0, 1]], gradientStops: stops }];
      mask.isMask = true;
      fade.appendChild(mask);
      const fill = figma.createRectangle();
      fill.name = "fade-fill";
      fill.resize(SHEET_W, FADE_H);
      fill.fills = [boundPaint(scv(maps, "color/overlay/wheel-fade"))];
      fade.appendChild(fill);
      return fade;
    };
    const pickLineTab = async (state) => {
      let c = BUILT_COMPS[`LineTab:Mobile-SM-${state}`];
      if (!c) {
        const s = await getBuiltSet("Line Tab");
        if (s) c = s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Size=SM") && x.name.includes("Mobile") && x.name.includes(`State=${state}`));
      }
      return c;
    };
    const getApplyBtn = async () => {
      var _a;
      let c = BUILT_COMPS["Button:primary:LG:Default"];
      if (!c) {
        const s = await getBuiltSet("Button");
        if (s) c = (_a = s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Variant=Primary") && x.name.includes("Size=LG") && x.name.includes("State=Default"))) != null ? _a : s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Variant=Primary"));
      }
      return c;
    };
    const buildVariant = async (content) => {
      const comp = figma.createComponent();
      comp.name = `Content=${content}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SHEET_W, 100);
      comp.itemSpacing = 32;
      comp.paddingTop = 20;
      comp.paddingBottom = 20;
      comp.paddingLeft = 0;
      comp.paddingRight = 0;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      try {
        comp.topLeftRadius = 8;
        comp.topRightRadius = 8;
        comp.bottomLeftRadius = 0;
        comp.bottomRightRadius = 0;
      } catch (e) {
      }
      comp.clipsContent = false;
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "CENTER";
      header.paddingLeft = 20;
      header.paddingRight = 20;
      comp.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const titleText = content === "TimeOnly" ? "\uC2DC\uAC04 \uC120\uD0DD" : "\uC2DC\uC791 \uC77C\uC2DC";
      const title = await makeBoundText(titleText, 20, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon.name = "close";
      header.appendChild(closeIcon);
      if (content === "DateTime") {
        const tabRow = figma.createFrame();
        tabRow.name = "tab-row";
        tabRow.fills = [];
        tabRow.layoutMode = "HORIZONTAL";
        tabRow.primaryAxisSizingMode = "FIXED";
        tabRow.counterAxisSizingMode = "AUTO";
        tabRow.paddingLeft = 24;
        tabRow.paddingRight = 24;
        tabRow.itemSpacing = 0;
        tabRow.counterAxisAlignItems = "CENTER";
        comp.appendChild(tabRow);
        try {
          tabRow.layoutAlign = "STRETCH";
        } catch (e) {
        }
        const tabDefs = [{ state: "Unselected", label: "\uB0A0\uC9DC" }, { state: "Selected", label: "\uC2DC\uAC04" }];
        for (const td of tabDefs) {
          const cell = await pickLineTab(td.state);
          if (cell) {
            const inst = cell.createInstance();
            inst.name = td.label === "\uB0A0\uC9DC" ? "tab-date" : "tab-time";
            const txt = inst.findOne((n) => n.type === "TEXT");
            if (txt) {
              try {
                txt.characters = td.label;
              } catch (e) {
              }
            }
            tabRow.appendChild(inst);
            try {
              inst.layoutSizingHorizontal = "FILL";
            } catch (e) {
            }
          }
        }
      }
      const wheelWrap = figma.createFrame();
      wheelWrap.name = "wheel";
      wheelWrap.fills = [];
      wheelWrap.layoutMode = "HORIZONTAL";
      wheelWrap.primaryAxisSizingMode = "FIXED";
      wheelWrap.counterAxisSizingMode = "AUTO";
      wheelWrap.primaryAxisAlignItems = "CENTER";
      wheelWrap.counterAxisAlignItems = "CENTER";
      wheelWrap.paddingLeft = 24;
      wheelWrap.paddingRight = 24;
      wheelWrap.paddingTop = 40;
      wheelWrap.paddingBottom = 40;
      wheelWrap.itemSpacing = 36;
      wheelWrap.clipsContent = false;
      comp.appendChild(wheelWrap);
      try {
        wheelWrap.layoutAlign = "STRETCH";
      } catch (e) {
      }
      wheelWrap.appendChild(await makeWheelCol("ampm", ["\uC624\uC804", "\uC624\uD6C4"], 32, "CENTER"));
      wheelWrap.appendChild(await makeWheelCol("hour", ["7", "8", "9"], 32, "MAX"));
      wheelWrap.appendChild(await makeWheelCol("colon", [":", ":", ":"], 40, "CENTER"));
      wheelWrap.appendChild(await makeWheelCol("minute", ["59", "00", "01"], 32, "MIN"));
      const wheelH = wheelWrap.height;
      const fadeTop = makeWheelFade("top");
      wheelWrap.appendChild(fadeTop);
      try {
        fadeTop.layoutPositioning = "ABSOLUTE";
        fadeTop.x = 0;
        fadeTop.y = 0;
        fadeTop.constraints = { horizontal: "STRETCH", vertical: "MIN" };
      } catch (e) {
      }
      const fadeBottom = makeWheelFade("bottom");
      wheelWrap.appendChild(fadeBottom);
      try {
        fadeBottom.layoutPositioning = "ABSOLUTE";
        fadeBottom.x = 0;
        fadeBottom.y = Math.max(0, wheelH - FADE_H);
        fadeBottom.constraints = { horizontal: "STRETCH", vertical: "MAX" };
      } catch (e) {
      }
      const actionWrap = figma.createFrame();
      actionWrap.name = "action";
      actionWrap.fills = [];
      actionWrap.layoutMode = "HORIZONTAL";
      actionWrap.primaryAxisSizingMode = "FIXED";
      actionWrap.counterAxisSizingMode = "AUTO";
      actionWrap.primaryAxisAlignItems = "CENTER";
      actionWrap.counterAxisAlignItems = "CENTER";
      actionWrap.paddingLeft = 20;
      actionWrap.paddingRight = 20;
      comp.appendChild(actionWrap);
      try {
        actionWrap.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const btnComp = await getApplyBtn();
      if (btnComp) {
        const applyBtn = btnComp.createInstance();
        applyBtn.name = "apply";
        const txt = applyBtn.findOne((n) => n.type === "TEXT");
        if (txt) {
          try {
            txt.characters = "\uC801\uC6A9";
          } catch (e) {
          }
        }
        actionWrap.appendChild(applyBtn);
        try {
          applyBtn.layoutSizingHorizontal = "FILL";
        } catch (e) {
        }
      }
      setLightMode(comp, maps);
      return comp;
    };
    const timeOnly = await buildVariant("TimeOnly");
    const dateTime = await buildVariant("DateTime");
    const set = figma.combineAsVariants([timeOnly, dateTime], figma.currentPage);
    set.name = "Time Picker Mobile Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Time Picker Mobile Bottom Sheet"] = set;
    const opts = {
      title: "Time Picker Mobile Bottom Sheet",
      colHeaders: [""],
      rowLabels: ["\uC2DC\uAC04\uB9CC", "\uB0A0\uC9DC+\uC2DC\uAC04"],
      cellAt: (r) => r === 0 ? timeOnly : dateTime,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: SHEET_W + 40,
      cellH: 560,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  var LOCK_SET_KEY = "b3ccc4b275de6aac8e3940df2ae97fbb00168624";
  var LOCK_FALLBACK_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="5" y="10.5" width="14" height="9.5" rx="2" stroke="#757575" stroke-width="1.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" stroke="#757575" stroke-width="1.5"/></svg>`;
  var CHECK_24_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M5 12.5L10 17.5L19 6.5" stroke="#1D6CEB" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  var CHEVRON_RIGHT_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M9 6L15 12L9 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  var ACCOUNT_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" fill="#FFFFFF"/><path d="M5 20c0-3.5 3.13-6 7-6s7 2.5 7 6" fill="#FFFFFF"/></svg>`;
  async function makeLockIcon(colorVar, size) {
    var _a, _b;
    try {
      const set = await figma.importComponentSetByKeyAsync(LOCK_SET_KEY);
      const line = (_b = (_a = set.children.find((c) => c.type === "COMPONENT" && c.name.toLowerCase().includes("line"))) != null ? _a : set.defaultVariant) != null ? _b : set.children[0];
      if (line) {
        const inst = line.createInstance();
        inst.name = "lock";
        if (size && size !== inst.width) inst.resize(size, size);
        rebindIconColor(inst, colorVar);
        return inst;
      }
    } catch (e) {
      console.warn("lock \uC138\uD2B8 import \uC2E4\uD328 \u2192 \uBCA1\uD130 \uD3F4\uBC31:", e);
    }
    const node = figma.createNodeFromSvg(LOCK_FALLBACK_SVG);
    node.name = "lock";
    rebindIconColor(node, colorVar);
    return node;
  }
  async function getReuseComp(builtKey, setName, includes) {
    let c = BUILT_COMPS[builtKey];
    if (!c) {
      const s = await getBuiltSet(setName);
      if (s) c = s.children.find((x) => x.type === "COMPONENT" && includes.every((n) => x.name.includes(n)));
    }
    return c;
  }
  async function setInstanceLabel(inst, label) {
    const txt = inst.findOne((n) => n.type === "TEXT");
    if (!txt) return;
    try {
      await figma.loadFontAsync(txt.fontName);
    } catch (e) {
    }
    try {
      txt.characters = label;
    } catch (e) {
    }
  }
  async function buildBottomSheetOption(maps, originY) {
    const ROW_W = 360;
    const byKey = {};
    const rowLabel = async (color) => makeBoundText("\uD56D\uBAA9", 16, "Medium", scv(maps, color));
    const makeSelectRow = (name) => {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.counterAxisAlignItems = "CENTER";
      comp.paddingLeft = 20;
      comp.paddingRight = 20;
      comp.paddingTop = 8;
      comp.paddingBottom = 8;
      comp.itemSpacing = 8;
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      comp.resize(ROW_W, 48);
      return comp;
    };
    {
      const comp = makeSelectRow("Type=Text, State=Default");
      comp.primaryAxisAlignItems = "MIN";
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey["Text:Default"] = comp;
    }
    {
      const comp = makeSelectRow("Type=Text, State=Selected");
      comp.primaryAxisAlignItems = "SPACE_BETWEEN";
      comp.appendChild(await rowLabel("color/text/state/accent"));
      comp.appendChild(await makeIconInstance("check", scv(maps, "color/icon/blue"), 24, CHECK_24_SVG));
      setLightMode(comp, maps);
      byKey["Text:Selected"] = comp;
    }
    const cbOff = await getReuseComp("Checkbox:Default", "Checkbox", ["State=Default"]);
    const cbOn = await getReuseComp("Checkbox:Checked", "Checkbox", ["State=Checked"]);
    for (const st of [{ name: "Default", comp: cbOff }, { name: "Selected", comp: cbOn }]) {
      const comp = makeSelectRow(`Type=Checkbox, State=${st.name}`);
      comp.primaryAxisAlignItems = "MIN";
      if (st.comp) {
        const inst = st.comp.createInstance();
        inst.name = "checkbox";
        comp.appendChild(inst);
      }
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey[`Checkbox:${st.name}`] = comp;
    }
    const rdOff = await getReuseComp("Radio:Default:Off", "Radio", ["State=Default", "Label=Off"]);
    const rdOn = await getReuseComp("Radio:Selected:Off", "Radio", ["State=Selected", "Label=Off"]);
    for (const st of [{ name: "Default", comp: rdOff }, { name: "Selected", comp: rdOn }]) {
      const comp = makeSelectRow(`Type=Radio, State=${st.name}`);
      comp.primaryAxisAlignItems = "MIN";
      if (st.comp) {
        const inst = st.comp.createInstance();
        inst.name = "radio";
        comp.appendChild(inst);
      }
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey[`Radio:${st.name}`] = comp;
    }
    const makeAvatar = async () => {
      const av = figma.createFrame();
      av.name = "avatar";
      av.layoutMode = "HORIZONTAL";
      av.primaryAxisAlignItems = "CENTER";
      av.counterAxisAlignItems = "CENTER";
      av.primaryAxisSizingMode = "FIXED";
      av.counterAxisSizingMode = "FIXED";
      av.resize(40, 40);
      av.cornerRadius = 20;
      av.fills = [boundPaint(scv(maps, "color/icon/gray-light"))];
      av.appendChild(await makeIconInstance("account", scv(maps, "color/icon/white"), 24, ACCOUNT_SVG));
      return av;
    };
    const makeListLeft = async () => {
      const left = figma.createFrame();
      left.name = "list-left";
      left.fills = [];
      left.layoutMode = "HORIZONTAL";
      left.primaryAxisSizingMode = "AUTO";
      left.counterAxisSizingMode = "AUTO";
      left.counterAxisAlignItems = "CENTER";
      left.itemSpacing = 12;
      left.appendChild(await makeAvatar());
      const col = figma.createFrame();
      col.name = "list-text";
      col.fills = [];
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "AUTO";
      col.counterAxisSizingMode = "AUTO";
      col.itemSpacing = 2;
      const title = await makeBoundText("\uC81C\uBAA9", 16, "Medium", scv(maps, "color/text/body/primary"));
      title.name = "title";
      const sub = await makeBoundText("\uC11C\uBE0C \uD14D\uC2A4\uD2B8", 14, "Regular", scv(maps, "color/text/body/secondary"));
      sub.name = "sub";
      col.appendChild(title);
      col.appendChild(sub);
      left.appendChild(col);
      return left;
    };
    const makeListRow = async (name, rightIcon) => {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "SPACE_BETWEEN";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "AUTO";
      comp.paddingLeft = 20;
      comp.paddingRight = 20;
      comp.paddingTop = 12;
      comp.paddingBottom = 12;
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      comp.appendChild(await makeListLeft());
      comp.appendChild(rightIcon);
      try {
        comp.resize(ROW_W, comp.height);
      } catch (e) {
      }
      setLightMode(comp, maps);
      return comp;
    };
    byKey["List:Default"] = await makeListRow(
      "Type=List, State=Default",
      await makeIconInstance("chevron", scv(maps, "color/icon/gray-dark"), 24, CHEVRON_RIGHT_SVG)
    );
    byKey["List:Disabled"] = await makeListRow(
      "Type=List, State=Disabled",
      await makeLockIcon(scv(maps, "color/icon/gray"), 24)
    );
    const order = [
      "Text:Default",
      "Text:Selected",
      "Checkbox:Default",
      "Checkbox:Selected",
      "Radio:Default",
      "Radio:Selected",
      "List:Default",
      "List:Disabled"
    ];
    const comps = order.map((k) => byKey[k]);
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Bottom Sheet Option";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Bottom Sheet Option"] = set;
    BUILT_COMPS["BottomSheetOption:Text:Default"] = byKey["Text:Default"];
    BUILT_COMPS["BottomSheetOption:Text:Selected"] = byKey["Text:Selected"];
    const types = ["Text", "Checkbox", "Radio", "List"];
    const states = ["Default", "Selected", "Disabled"];
    const opts = {
      title: "Bottom Sheet Option",
      colHeaders: states,
      rowLabels: types,
      cellAt: (r, c) => {
        var _a;
        return (_a = byKey[`${types[r]}:${states[c]}`]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 80,
      rowLabelW: 80
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildBottomSheet(maps, originY) {
    const SHEET_W = 360;
    const buildContent = async () => {
      var _a;
      const content = figma.createFrame();
      content.name = "content";
      content.fills = [];
      content.layoutMode = "VERTICAL";
      content.primaryAxisSizingMode = "AUTO";
      content.counterAxisSizingMode = "FIXED";
      content.itemSpacing = 24;
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "CENTER";
      header.paddingLeft = 20;
      header.paddingRight = 20;
      const title = await makeBoundText("\uD5E4\uB354 \uD0C0\uC774\uD2C0", 20, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon.name = "close";
      header.appendChild(closeIcon);
      content.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const list = figma.createFrame();
      list.name = "list";
      list.fills = [];
      list.layoutMode = "VERTICAL";
      list.primaryAxisSizingMode = "AUTO";
      list.counterAxisSizingMode = "FIXED";
      list.itemSpacing = 0;
      const optDefault = BUILT_COMPS["BottomSheetOption:Text:Default"];
      const optSelected = BUILT_COMPS["BottomSheetOption:Text:Selected"];
      for (let i = 0; i < 4; i++) {
        const src = (_a = i === 1 ? optSelected : optDefault) != null ? _a : optDefault;
        if (!src) continue;
        const inst = src.createInstance();
        inst.name = "option";
        list.appendChild(inst);
        try {
          inst.layoutSizingHorizontal = "FILL";
        } catch (e) {
        }
      }
      content.appendChild(list);
      try {
        list.layoutAlign = "STRETCH";
      } catch (e) {
      }
      return content;
    };
    const makeFooterButton = async (variant, label) => {
      const vLabel = variant === "primary" ? "Primary" : "Secondary";
      const comp = await getReuseComp(
        `Button:${variant}:LG:Default`,
        "Button",
        [`Variant=${vLabel}`, "Size=LG", "State=Default"]
      );
      if (!comp) return null;
      const inst = comp.createInstance();
      inst.name = variant;
      await setInstanceLabel(inst, label);
      return inst;
    };
    const variants = [{ footer: "None" }, { footer: "Single" }, { footer: "Dual" }];
    const byFooter = {};
    for (const v of variants) {
      const comp = figma.createComponent();
      comp.name = `Footer=${v.footer}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SHEET_W, 100);
      comp.itemSpacing = 48;
      comp.paddingTop = 20;
      comp.paddingLeft = 0;
      comp.paddingRight = 0;
      comp.paddingBottom = v.footer === "None" ? 40 : 20;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      try {
        comp.topLeftRadius = 8;
        comp.topRightRadius = 8;
        comp.bottomLeftRadius = 0;
        comp.bottomRightRadius = 0;
      } catch (e) {
      }
      comp.clipsContent = true;
      const sheetEffects = shadowEffects("shadow/raised-up");
      try {
        comp.effects = sheetEffects;
      } catch (e) {
      }
      const content = await buildContent();
      comp.appendChild(content);
      try {
        content.layoutAlign = "STRETCH";
      } catch (e) {
      }
      if (v.footer !== "None") {
        const footer = figma.createFrame();
        footer.name = "footer";
        footer.fills = [];
        footer.layoutMode = "HORIZONTAL";
        footer.primaryAxisSizingMode = "FIXED";
        footer.counterAxisSizingMode = "AUTO";
        footer.primaryAxisAlignItems = "CENTER";
        footer.counterAxisAlignItems = "CENTER";
        footer.paddingLeft = 20;
        footer.paddingRight = 20;
        footer.itemSpacing = 8;
        comp.appendChild(footer);
        try {
          footer.layoutAlign = "STRETCH";
        } catch (e) {
        }
        if (v.footer === "Dual") {
          const cancel = await makeFooterButton("secondary", "\uCDE8\uC18C");
          if (cancel) {
            footer.appendChild(cancel);
            try {
              cancel.layoutSizingHorizontal = "FILL";
            } catch (e) {
            }
          }
        }
        const apply = await makeFooterButton("primary", "\uC801\uC6A9");
        if (apply) {
          footer.appendChild(apply);
          try {
            apply.layoutSizingHorizontal = "FILL";
          } catch (e) {
          }
        }
      }
      setLightMode(comp, maps);
      byFooter[v.footer] = comp;
    }
    const set = figma.combineAsVariants([byFooter["None"], byFooter["Single"], byFooter["Dual"]], figma.currentPage);
    set.name = "Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Bottom Sheet"] = set;
    const cols = ["None", "Single", "Dual"];
    const opts = {
      title: "Bottom Sheet",
      colHeaders: cols,
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = byFooter[cols[c]]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 420,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildModalShell(maps, originY) {
    const PANEL_W = 360;
    const buildContentGroup = async (titleText, bodyText) => {
      const group = figma.createFrame();
      group.name = "content";
      group.fills = [];
      group.layoutMode = "VERTICAL";
      group.primaryAxisSizingMode = "AUTO";
      group.counterAxisSizingMode = "FIXED";
      group.itemSpacing = 32;
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "MAX";
      header.paddingLeft = 24;
      header.paddingRight = 24;
      const title = await makeBoundText(titleText, 16, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon.name = "close";
      header.appendChild(closeIcon);
      group.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const body = figma.createFrame();
      body.name = "body";
      body.fills = [];
      body.layoutMode = "VERTICAL";
      body.primaryAxisSizingMode = "AUTO";
      body.counterAxisSizingMode = "FIXED";
      body.itemSpacing = 8;
      body.paddingLeft = 24;
      body.paddingRight = 24;
      const bodyNode = await makeBoundText(bodyText, 14, "Regular", scv(maps, "color/text/body/primary"));
      bodyNode.name = "message";
      body.appendChild(bodyNode);
      group.appendChild(body);
      try {
        body.layoutAlign = "STRETCH";
      } catch (e) {
      }
      return group;
    };
    const makeFooterButton = async (variant, label) => {
      const vLabel = variant === "primary" ? "Primary" : "Secondary";
      const comp = await getReuseComp(
        `Button:${variant}:XXSM:Default`,
        "Button",
        [`Variant=${vLabel}`, "Size=XXSM", "State=Default"]
      );
      if (!comp) {
        throw new Error(`[buildModalShell] \uCF54\uC5B4 Button \uC778\uC2A4\uD134\uC2A4 \uBBF8\uBC1C\uACAC: Button:${variant}:XXSM:Default (h28 \uC0AC\uC774\uC988 \uD0A4 \uBD88\uC77C\uCE58 \u2014 \uBE4C\uB4DC \uC911\uB2E8, \uC6B0\uD68C \uC548 \uD568)`);
      }
      const inst = comp.createInstance();
      inst.name = variant;
      await setInstanceLabel(inst, label);
      return inst;
    };
    const buildModalVariant = async (footer, titleText, bodyText) => {
      const comp = figma.createComponent();
      comp.name = `Footer=${footer}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(PANEL_W, 100);
      comp.itemSpacing = 32;
      comp.paddingTop = 20;
      comp.paddingBottom = 20;
      comp.paddingLeft = 0;
      comp.paddingRight = 0;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      try {
        comp.cornerRadius = 8;
      } catch (e) {
      }
      comp.strokes = [boundPaint(scv(maps, "color/modal/panel/border"))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.clipsContent = true;
      const modalEffects = boundShadowEffects(maps, "shadow/raised");
      try {
        comp.effects = modalEffects;
      } catch (e) {
      }
      const content = await buildContentGroup(titleText, bodyText);
      comp.appendChild(content);
      try {
        content.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const footerFrame = figma.createFrame();
      footerFrame.name = "footer";
      footerFrame.fills = [];
      footerFrame.layoutMode = "HORIZONTAL";
      footerFrame.primaryAxisSizingMode = "FIXED";
      footerFrame.counterAxisSizingMode = "AUTO";
      footerFrame.primaryAxisAlignItems = "MAX";
      footerFrame.counterAxisAlignItems = "CENTER";
      footerFrame.paddingLeft = 24;
      footerFrame.paddingRight = 24;
      footerFrame.itemSpacing = 8;
      comp.appendChild(footerFrame);
      try {
        footerFrame.layoutAlign = "STRETCH";
      } catch (e) {
      }
      if (footer === "Dual") {
        footerFrame.appendChild(await makeFooterButton("secondary", "\uCDE8\uC18C"));
        footerFrame.appendChild(await makeFooterButton("primary", "\uD655\uC778"));
      } else {
        footerFrame.appendChild(await makeFooterButton("primary", "\uD655\uC778"));
      }
      setLightMode(comp, maps);
      return comp;
    };
    const singleComp = await buildModalVariant("Single", "\uC81C\uBAA9 \uC601\uC5ED", "\uC694\uCCAD\uD558\uC2E0 \uC791\uC5C5\uC774 \uC815\uC0C1\uC801\uC73C\uB85C \uCC98\uB9AC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.\n\uBCC0\uACBD\uB41C \uB0B4\uC6A9\uC740 \uBAA9\uB85D\uC5D0\uC11C \uD655\uC778\uD558\uC2E4 \uC218 \uC788\uC5B4\uC694.");
    const dualComp = await buildModalVariant("Dual", "\uC81C\uBAA9 \uC601\uC5ED", "\uBCC0\uACBD\uD55C \uB0B4\uC6A9\uC774 \uC800\uC7A5\uB418\uC9C0 \uC54A\uACE0 \uC0AC\uB77C\uC9D1\uB2C8\uB2E4.\n\uC815\uB9D0 \uC774 \uC791\uC5C5\uC744 \uC9C4\uD589\uD558\uC2DC\uACA0\uC5B4\uC694?");
    const set = figma.combineAsVariants([singleComp, dualComp], figma.currentPage);
    set.name = "Modal";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Modal"] = set;
    const opts = {
      title: "Modal",
      colHeaders: ["Single", "Dual"],
      rowLabels: [""],
      cellAt: (_r, c) => c === 0 ? singleComp : dualComp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 260,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildCalendarCellLayout(maps, originY) {
    const { set, variants } = await getOrBuildCalendarCell(maps);
    const stdStates = ["Default", "Hover", "Today", "Selected", "Disabled"];
    const rngStates = ["Default", "Start", "End", "Disabled"];
    const cellW = 80, cellH = 60, rowLabelW = 80;
    const mkOpts = (title, states, type) => ({
      title,
      colHeaders: states,
      rowLabels: [""],
      // 표 제목이 Standard/Range 를 알리므로 행 라벨은 비움(좌측 gutter 만 유지)
      cellAt: (_r, c) => {
        var _a;
        return (_a = variants[`${type}:${states[c]}`]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW,
      cellH,
      rowLabelW
    });
    const stdOpts = mkOpts("Calendar Cell \u2014 Standard", stdStates, "Standard");
    const rngOpts = mkOpts("Calendar Cell \u2014 Range", rngStates, "Range");
    const setW = Math.max(specWidth(rowLabelW, stdStates.length, cellW), specWidth(rowLabelW, rngStates.length, cellW));
    const floatAt = (oy, cy) => ({
      text: async (s, x, y, w, al, col, fs, st) => {
        await makeLabel(s, fs, st, x, oy + y, w, al, col);
      },
      band: (x, y, w, h, col) => {
        const b = figma.createRectangle();
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [{ type: "SOLID", color: col }];
        b.x = x;
        b.y = oy + y;
      },
      cell: (comp, x, y) => {
        comp.x = x;
        comp.y = cy + y;
      }
    });
    set.x = 0;
    set.y = originY;
    try {
      set.fills = [{ type: "SOLID", color: specPalette(false).bg }];
    } catch (e) {
    }
    const h1 = await renderFlat(stdOpts, false, floatAt(originY, 0));
    const h2 = await renderFlat(rngOpts, false, floatAt(originY + h1, h1));
    set.resize(setW, h1 + h2);
    setLightMode(set, maps);
    let bottomY = originY + h1 + h2;
    try {
      const modeId = maps.semanticDarkModeId;
      const frame = figma.createFrame();
      frame.name = "Calendar Cell \u2014 Spec Dark";
      frame.fills = [{ type: "SOLID", color: specPalette(true).bg }];
      frame.cornerRadius = 8;
      frame.resize(setW, 1200);
      frame.x = setW + 80;
      frame.y = originY;
      const base = frameEmit(frame, maps, modeId);
      const dh1 = await renderFlat(stdOpts, true, base);
      const off = {
        text: (s, x, y, w, al, col, fs, st) => base.text(s, x, y + dh1, w, al, col, fs, st),
        band: (x, y, w, h, col) => base.band(x, y + dh1, w, h, col),
        cell: (comp, x, y) => base.cell(comp, x, y + dh1)
      };
      const dh2 = await renderFlat(rngOpts, true, off);
      frame.resize(setW, dh1 + dh2);
      setMode(frame, maps, modeId);
      bottomY = Math.max(bottomY, frame.y + dh1 + dh2);
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildCalendarTileLayout(maps, originY) {
    const { set, variants } = await getOrBuildCalendarTile(maps);
    set.x = 0;
    set.y = originY;
    const states = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Calendar Tile",
      colHeaders: states,
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = variants[states[c]]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 72
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var SHELL_WIFI_SVG = `<svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg"><mask id="sw1" fill="white"><path d="M2.34315 4.34315C3.84344 2.84286 5.87827 2 8 2C10.1217 2 12.1566 2.84285 13.6569 4.34314L8 10L2.34315 4.34315Z"/></mask><path d="M2.34315 4.34315C3.84344 2.84286 5.87827 2 8 2C10.1217 2 12.1566 2.84285 13.6569 4.34314L8 10L2.34315 4.34315Z" stroke="#353535" stroke-width="3.2" mask="url(#sw1)"/><mask id="sw2" fill="white"><path d="M4.46447 6.46447C5.40215 5.52678 6.67392 5 8 5C9.32608 5 10.5979 5.52678 11.5355 6.46447L8 10L4.46447 6.46447Z"/></mask><path d="M4.46447 6.46447C5.40215 5.52678 6.67392 5 8 5C9.32608 5 10.5979 5.52678 11.5355 6.46447L8 10L4.46447 6.46447Z" stroke="#353535" stroke-width="3.2" mask="url(#sw2)"/><circle cx="7.9998" cy="10.2" r="1.2" fill="#353535"/></svg>`;
  var SHELL_LOCK_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.0002 3C9.16131 3 6.85731 5.39657 6.85731 8.33829V11.2286H5.31445V21H18.6859V11.2286H17.143V8.33829C17.143 5.39657 14.839 3 12.0002 3ZM14.4173 17.8114L13.687 18.5417L11.9899 16.8446L10.2927 18.5417L9.56245 17.8114L11.2596 16.1143L9.56245 14.4171L10.2927 13.6869L11.9899 15.384L13.687 13.6869L14.4173 14.4171L12.7202 16.1143L14.4173 17.8114ZM7.88588 11.2286V8.33829C7.88588 5.96229 9.72702 4.02857 12.0002 4.02857C14.2733 4.02857 16.1145 5.96229 16.1145 8.33829V11.2286H7.88588Z" fill="#757575"/></svg>`;
  var SHELL_REFRESH_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.0002 19.9411C9.74488 19.9411 7.61666 18.9776 6.12374 17.3364H9.0143V16.2776H5.02257C4.7261 16.2776 4.49316 16.5106 4.49316 16.807V20.7882H5.55198V18.2576C7.23549 19.9941 9.54371 20.9999 12.0002 20.9999C16.966 20.9999 21.0001 16.9659 21.0001 12C21.0001 11.2271 20.9048 10.4647 20.7142 9.72357L19.6871 9.98828C19.8566 10.6342 19.9413 11.3118 19.9413 12C19.9413 16.3835 16.3836 19.9411 12.0002 19.9411Z" fill="#757575"/><path d="M18.4481 5.74282C16.7646 4.00636 14.4564 3.00049 11.9999 3.00049C7.03408 3.00049 3 7.03457 3 12.0004C3 12.7733 3.09529 13.5357 3.29647 14.2769L4.32352 14.0122C4.15411 13.3663 4.0694 12.6886 4.0694 12.0004C4.05881 7.61692 7.61643 4.0593 11.9999 4.0593C14.2552 4.0593 16.3834 5.02282 17.8763 6.66398H14.9858V7.7228H18.9669C19.2634 7.7228 19.4963 7.48986 19.4963 7.19339V3.21225H18.4375V5.74282H18.4481Z" fill="#757575"/></svg>`;
  function makeBoundIcon(svg, colorVar) {
    const node = figma.createNodeFromSvg(svg);
    node.name = "icon";
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "BOOLEAN_OPERATION"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      try {
        if (v.isMask) return;
        if (Array.isArray(v.strokes) && v.strokes.length) v.strokes = [boundPaint(colorVar)];
        if (Array.isArray(v.fills) && v.fills.length) v.fills = [boundPaint(colorVar)];
      } catch (e) {
      }
    });
    return node;
  }
  function shellRect(maps, x, y, w, h, r, colorKey, asStroke) {
    const rc = figma.createRectangle();
    rc.x = x;
    rc.y = y;
    rc.resize(w, h);
    rc.cornerRadius = r;
    if (asStroke) {
      rc.strokes = [boundPaint(scv(maps, colorKey))];
      rc.strokeWeight = 1;
      rc.fills = [];
    } else {
      rc.fills = [boundPaint(scv(maps, colorKey))];
      rc.strokes = [];
    }
    return rc;
  }
  async function populateStatusRow(target, maps) {
    target.layoutMode = "HORIZONTAL";
    target.primaryAxisSizingMode = "FIXED";
    target.counterAxisSizingMode = "FIXED";
    target.resize(360, 27);
    target.primaryAxisAlignItems = "SPACE_BETWEEN";
    target.counterAxisAlignItems = "CENTER";
    target.paddingLeft = 20;
    target.paddingRight = 16;
    target.paddingTop = 0;
    target.paddingBottom = 0;
    target.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    target.appendChild(await makeBoundText("12:30", 12, "Medium", scv(maps, "color/text/body/secondary")));
    const right = figma.createFrame();
    right.name = "status-right";
    right.layoutMode = "HORIZONTAL";
    right.primaryAxisSizingMode = "AUTO";
    right.counterAxisSizingMode = "AUTO";
    right.counterAxisAlignItems = "CENTER";
    right.itemSpacing = 6;
    right.fills = [];
    const signal = figma.createFrame();
    signal.name = "signal";
    signal.fills = [];
    signal.clipsContent = false;
    signal.resize(17, 12);
    signal.appendChild(shellRect(maps, 0, 8, 3, 4, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 4.5, 6, 3, 6, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 9, 4, 3, 8, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 13.5, 1, 3, 11, 0.5, "color/icon/gray-dark", false));
    right.appendChild(signal);
    const wifi = makeBoundIcon(SHELL_WIFI_SVG, scv(maps, "color/icon/gray-dark"));
    wifi.name = "wifi";
    right.appendChild(wifi);
    try {
      wifi.resize(16, 12);
    } catch (e) {
    }
    const battery = figma.createFrame();
    battery.name = "battery";
    battery.fills = [];
    battery.clipsContent = false;
    battery.resize(24, 12);
    battery.appendChild(shellRect(maps, 0, 0.5, 20, 11, 2.5, "color/icon/gray-dark", true));
    battery.appendChild(shellRect(maps, 20.4, 4, 1.6, 4, 1, "color/icon/gray-dark", false));
    battery.appendChild(shellRect(maps, 2, 2.5, 14.5, 7, 1, "color/icon/gray-dark", false));
    right.appendChild(battery);
    right.appendChild(await makeBoundText("78%", 12, "Medium", scv(maps, "color/text/body/secondary")));
    target.appendChild(right);
  }
  async function buildShellUrlBar(maps) {
    const bar = figma.createFrame();
    bar.name = "browser-url-bar";
    bar.layoutMode = "HORIZONTAL";
    bar.primaryAxisSizingMode = "FIXED";
    bar.counterAxisSizingMode = "FIXED";
    bar.resize(360, 50);
    bar.primaryAxisAlignItems = "CENTER";
    bar.counterAxisAlignItems = "CENTER";
    bar.itemSpacing = 6;
    bar.paddingLeft = 16;
    bar.paddingRight = 16;
    bar.paddingTop = 12;
    bar.paddingBottom = 12;
    bar.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    const lock = makeBoundIcon(SHELL_LOCK_SVG, scv(maps, "color/icon/gray"));
    lock.name = "ic_\uC7A0\uAE40";
    bar.appendChild(lock);
    try {
      lock.resize(24, 24);
    } catch (e) {
    }
    const pill = figma.createFrame();
    pill.name = "url";
    pill.layoutMode = "HORIZONTAL";
    pill.primaryAxisAlignItems = "CENTER";
    pill.counterAxisAlignItems = "CENTER";
    pill.primaryAxisSizingMode = "FIXED";
    pill.counterAxisSizingMode = "FIXED";
    pill.cornerRadius = 100;
    pill.fills = [boundPaint(scv(maps, "color/bg/level-2"))];
    pill.layoutGrow = 1;
    pill.layoutAlign = "STRETCH";
    pill.appendChild(await makeBoundText("m.s1.co.kr", 14, "Regular", scv(maps, "color/text/body/tertiary")));
    bar.appendChild(pill);
    const refresh = makeBoundIcon(SHELL_REFRESH_SVG, scv(maps, "color/icon/gray"));
    refresh.name = "ic_\uC0C8\uB85C\uACE0\uCE68";
    bar.appendChild(refresh);
    try {
      refresh.resize(24, 24);
    } catch (e) {
    }
    return bar;
  }
  var S1_LOGO_SVG = `<svg width="42" height="16" viewBox="0 0 42 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32.6826 14.3262H41.5254V16H30.6992V10.2461H32.6826V14.3262ZM10.1426 15.9902H8.32129V7.07812H7.39258C7.30419 11.1554 5.68825 13.0125 3.70117 13.0127C1.65723 13.0127 0 11.0554 0 6.73047C0 2.41216 1.65721 0.448242 3.70117 0.448242C5.52602 0.448409 7.03869 2.01912 7.34277 5.42676H8.32129V0.172852H10.1426V15.9902ZM12.9111 15.9902H11.084V0.173828H12.9111V15.9902ZM28.084 15.2305H15.084V13.5811H28.084V15.2305ZM41.2891 0.182617V13.0557H39.46V11.2832H36.459V9.64453H39.46V0.182617H41.2891ZM38.8672 8.87891H35.3379V12.1885H33.3799V8.87891H29.7305V7.3291H38.8672V8.87891ZM22.6143 2.46875C22.6143 4.89881 24.005 8.20501 27.7148 9.30078V11.0654C27.6961 11.063 23.8792 10.5615 21.583 6.69531C19.2775 10.5711 15.4512 11.0654 15.4512 11.0654V9.30078C19.1607 8.21325 20.5518 4.89883 20.5518 2.46875V0.551758H22.6143V2.46875ZM3.70215 2.41211C2.66837 2.41211 1.83011 3.41277 1.83008 6.7334C1.83008 10.0732 2.66835 11.0557 3.70215 11.0557C4.73624 11.0556 5.57422 10.0731 5.57422 6.7334C5.57418 3.41295 4.73622 2.41222 3.70215 2.41211ZM34.3525 0C36.6151 0 38.4492 1.17983 38.4492 3.41797C38.449 5.69092 36.615 6.83496 34.3525 6.83496C32.0903 6.83485 30.2561 5.69081 30.2559 3.41797C30.2559 1.17994 32.0901 0 34.3525 0ZM34.3486 1.57227C33.1672 1.57227 32.2091 2.36269 32.209 3.44043C32.209 4.51861 33.1671 5.30859 34.3486 5.30859C35.5303 5.3084 36.4883 4.51026 36.4883 3.44043C36.4882 2.35834 35.5302 1.57246 34.3486 1.57227Z" fill="#757575"/></svg>`;
  async function buildFooter(maps, originY) {
    const LINK_NAMES = ["\uC774\uC6A9\uC57D\uAD00", "\uAC1C\uC778\uC815\uBCF4 \uCC98\uB9AC\uBC29\uCE68", "\uC704\uCE58\uAE30\uBC18 \uC11C\uBE44\uC2A4 \uC774\uC6A9\uC57D\uAD00"];
    const pc = figma.createComponent();
    pc.name = "Platform=PC";
    pc.layoutMode = "HORIZONTAL";
    pc.primaryAxisSizingMode = "FIXED";
    pc.counterAxisSizingMode = "FIXED";
    pc.resize(1920, 116);
    pc.primaryAxisAlignItems = "SPACE_BETWEEN";
    pc.counterAxisAlignItems = "CENTER";
    pc.paddingLeft = 320;
    pc.paddingRight = 320;
    const sp28 = requireVar(maps.foundationNumber, "spacing/28", "Foundation Number");
    pc.setBoundVariable("paddingTop", sp28);
    pc.setBoundVariable("paddingBottom", sp28);
    pc.fills = [boundPaint(scv(maps, "color/navigation/bg"))];
    pc.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    pc.strokeAlign = "INSIDE";
    pc.strokeTopWeight = 1;
    pc.strokeBottomWeight = 0;
    pc.strokeLeftWeight = 0;
    pc.strokeRightWeight = 0;
    const leftBlock = figma.createFrame();
    leftBlock.name = "content-left";
    leftBlock.layoutMode = "VERTICAL";
    leftBlock.primaryAxisSizingMode = "AUTO";
    leftBlock.counterAxisSizingMode = "AUTO";
    leftBlock.fills = [];
    leftBlock.itemSpacing = 4;
    const linksRow = figma.createFrame();
    linksRow.name = "links";
    linksRow.layoutMode = "HORIZONTAL";
    linksRow.primaryAxisSizingMode = "AUTO";
    linksRow.counterAxisSizingMode = "AUTO";
    linksRow.fills = [];
    linksRow.itemSpacing = 12;
    for (let i = 0; i < LINK_NAMES.length; i++) {
      linksRow.appendChild(await makeBoundText(LINK_NAMES[i], 10, "Regular", scv(maps, "color/text/body/tertiary")));
      if (i < LINK_NAMES.length - 1) {
        const sep = figma.createRectangle();
        sep.name = "sep";
        sep.resize(1, 8);
        sep.fills = [boundPaint(scv(maps, "color/icon/gray-light"))];
        linksRow.appendChild(sep);
      }
    }
    leftBlock.appendChild(linksRow);
    leftBlock.appendChild(await makeBoundText("(\uC8FC)\uC5D0\uC2A4\uC6D0   \uC0AC\uC5C5\uC790\uB4F1\uB85D\uBC88\uD638 208-81-13302    \uB300\uD45C\uC774\uC0AC \uC815\uD574\uB9B0    04511 \uC11C\uC6B8\uD2B9\uBCC4\uC2DC \uC911\uAD6C \uC138\uC885\uB300\uB85C 7\uAE38 25 \uC5D0\uC2A4\uC6D0 \uBE4C\uB529", 10, "Regular", scv(maps, "color/text/body/tertiary")));
    leftBlock.appendChild(await makeBoundText("\xA9 S-1 Corp. All Rights Reserved.", 10, "Regular", scv(maps, "color/text/body/tertiary")));
    pc.appendChild(leftBlock);
    const logo = figma.createNodeFromSvg(S1_LOGO_SVG);
    logo.name = "C/IMG/Logo/S1_g";
    rebindIconColor(logo, scv(maps, "color/icon/gray"));
    pc.appendChild(logo);
    setLightMode(pc, maps);
    const mobile = figma.createComponent();
    mobile.name = "Platform=Mobile";
    mobile.layoutMode = "VERTICAL";
    mobile.primaryAxisSizingMode = "AUTO";
    mobile.counterAxisSizingMode = "AUTO";
    mobile.primaryAxisAlignItems = "MIN";
    mobile.counterAxisAlignItems = "MIN";
    mobile.fills = [];
    const sp4 = requireVar(maps.foundationNumber, "spacing/4", "Foundation Number");
    mobile.setBoundVariable("itemSpacing", sp4);
    mobile.paddingLeft = 16;
    mobile.paddingRight = 16;
    mobile.paddingTop = 8;
    mobile.paddingBottom = 8;
    const mLinks = figma.createFrame();
    mLinks.name = "links";
    mLinks.layoutMode = "HORIZONTAL";
    mLinks.primaryAxisSizingMode = "AUTO";
    mLinks.counterAxisSizingMode = "AUTO";
    mLinks.fills = [];
    mLinks.itemSpacing = 8;
    mLinks.primaryAxisAlignItems = "CENTER";
    mLinks.counterAxisAlignItems = "CENTER";
    for (let i = 0; i < LINK_NAMES.length; i++) {
      mLinks.appendChild(await makeBoundText(LINK_NAMES[i], 12, "Regular", scv(maps, "color/text/body/tertiary")));
      if (i < LINK_NAMES.length - 1) {
        const sep = figma.createRectangle();
        sep.name = "sep";
        sep.resize(1, 10);
        sep.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
        mLinks.appendChild(sep);
      }
    }
    mobile.appendChild(mLinks);
    const mCopyright = await makeBoundText("\xA9 S-1 Corp. All Rights Reserved.", 12, "Regular", scv(maps, "color/text/body/tertiary"));
    mobile.appendChild(mCopyright);
    try {
      mCopyright.layoutAlign = "STRETCH";
      mCopyright.textAlignHorizontal = "CENTER";
    } catch (e) {
    }
    setLightMode(mobile, maps);
    const set = figma.combineAsVariants([pc, mobile], figma.currentPage);
    set.name = "Footer";
    set.x = 0;
    set.y = originY;
    try {
      set.clipsContent = false;
    } catch (_) {
    }
    const opts = {
      title: "Footer",
      colHeaders: [""],
      rowLabels: ["PC", "Mobile"],
      cellAt: (r, _c) => r === 0 ? pc : mobile,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 1960,
      cellH: 120,
      rowLabelW: 64,
      leftAlignCells: true
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildStatusBar(maps, originY) {
    const app = figma.createComponent();
    app.name = "Platform=App";
    await populateStatusRow(app, maps);
    setLightMode(app, maps);
    const web = figma.createComponent();
    web.name = "Platform=Web";
    web.layoutMode = "VERTICAL";
    web.primaryAxisSizingMode = "AUTO";
    web.counterAxisSizingMode = "FIXED";
    web.resize(360, 77);
    web.itemSpacing = 0;
    web.fills = [];
    const row = figma.createFrame();
    row.name = "status-row";
    await populateStatusRow(row, maps);
    row.layoutAlign = "STRETCH";
    web.appendChild(row);
    const urlbar = await buildShellUrlBar(maps);
    urlbar.layoutAlign = "STRETCH";
    web.appendChild(urlbar);
    setLightMode(web, maps);
    const set = figma.combineAsVariants([app, web], figma.currentPage);
    set.name = "StatusBar";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "StatusBar",
      colHeaders: [""],
      rowLabels: ["App", "Web"],
      cellAt: (r, _c) => r === 0 ? app : web,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 80,
      rowLabelW: 56
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var NAV_SVG = (() => {
    const s = (d) => `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">${d}</svg>`;
    const P = (path) => `<path d="${path}" stroke="#757575" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`;
    return {
      chevronLeft: s(P("M15 6L9 12L15 18")),
      chevronRight: s(P("M9 6L15 12L9 18")),
      home: s(P("M3.5 11L12 4L20.5 11") + P("M6 9.5V20H18V9.5")),
      star: s(P("M12 3.5L14.58 8.74L20.36 9.58L16.18 13.65L17.17 19.41L12 16.69L6.83 19.41L7.82 13.65L3.64 9.58L9.42 8.74L12 3.5Z")),
      menu: s(P("M4 7H20") + P("M4 12H20") + P("M4 17H20")),
      recents: s(P("M8 6V18") + P("M12 6V18") + P("M16 6V18")),
      androidHome: s(`<rect x="6" y="6" width="12" height="12" rx="3" stroke="#757575" stroke-width="2"/>`)
    };
  })();
  function navIcon(svg, maps) {
    const i = makeBoundIcon(svg, scv(maps, "color/icon/gray"));
    i.name = "icon";
    try {
      i.resize(24, 24);
    } catch (e) {
    }
    return i;
  }
  async function navTabsIcon(maps) {
    const f = figma.createFrame();
    f.name = "tabs";
    f.fills = [];
    f.clipsContent = false;
    f.resize(24, 24);
    const r = figma.createRectangle();
    r.x = 4;
    r.y = 5;
    r.resize(16, 14);
    r.cornerRadius = 2;
    r.fills = [];
    r.strokes = [boundPaint(scv(maps, "color/icon/gray"))];
    r.strokeWeight = 2;
    f.appendChild(r);
    const t = await makeBoundText("29", 9, "Medium", scv(maps, "color/icon/gray"));
    try {
      t.textAutoResize = "NONE";
      t.resize(24, 14);
      t.textAlignHorizontal = "CENTER";
      t.textAlignVertical = "CENTER";
      t.x = 0;
      t.y = 5;
    } catch (e) {
    }
    f.appendChild(t);
    return f;
  }
  function populateAndroidNav(target, maps) {
    target.layoutMode = "HORIZONTAL";
    target.primaryAxisSizingMode = "FIXED";
    target.counterAxisSizingMode = "FIXED";
    target.resize(360, 45);
    target.primaryAxisAlignItems = "SPACE_BETWEEN";
    target.counterAxisAlignItems = "CENTER";
    target.paddingLeft = 48;
    target.paddingRight = 48;
    target.paddingTop = 0;
    target.paddingBottom = 0;
    target.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    target.appendChild(navIcon(NAV_SVG.recents, maps));
    target.appendChild(navIcon(NAV_SVG.androidHome, maps));
    target.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
  }
  async function buildBrowserToolbarRow(maps) {
    const row = figma.createFrame();
    row.name = "browser-toolbar";
    row.layoutMode = "HORIZONTAL";
    row.primaryAxisSizingMode = "FIXED";
    row.counterAxisSizingMode = "FIXED";
    row.resize(360, 50);
    row.primaryAxisAlignItems = "SPACE_BETWEEN";
    row.counterAxisAlignItems = "CENTER";
    row.paddingLeft = 16;
    row.paddingRight = 16;
    row.paddingTop = 0;
    row.paddingBottom = 0;
    row.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    row.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
    row.appendChild(navIcon(NAV_SVG.chevronRight, maps));
    row.appendChild(navIcon(NAV_SVG.home, maps));
    row.appendChild(navIcon(NAV_SVG.star, maps));
    row.appendChild(await navTabsIcon(maps));
    row.appendChild(navIcon(NAV_SVG.menu, maps));
    return row;
  }
  async function buildNavBar(maps, originY) {
    const app = figma.createComponent();
    app.name = "Platform=App";
    populateAndroidNav(app, maps);
    setLightMode(app, maps);
    const web = figma.createComponent();
    web.name = "Platform=Web";
    web.layoutMode = "VERTICAL";
    web.primaryAxisSizingMode = "AUTO";
    web.counterAxisSizingMode = "FIXED";
    web.resize(360, 95);
    web.itemSpacing = 0;
    web.fills = [];
    const toolbar = await buildBrowserToolbarRow(maps);
    toolbar.layoutAlign = "STRETCH";
    web.appendChild(toolbar);
    const nav = figma.createFrame();
    nav.name = "android-nav";
    populateAndroidNav(nav, maps);
    nav.layoutAlign = "STRETCH";
    web.appendChild(nav);
    setLightMode(web, maps);
    const set = figma.combineAsVariants([app, web], figma.currentPage);
    set.name = "NavBar";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "NavBar",
      colHeaders: [""],
      rowLabels: ["App", "Web"],
      cellAt: (r, _c) => r === 0 ? app : web,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 100,
      rowLabelW: 56
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLoginGNB(maps, originY) {
    const W = 1920, H = 56;
    const comp = figma.createComponent();
    comp.name = "LoginGNB";
    comp.layoutMode = "HORIZONTAL";
    comp.primaryAxisSizingMode = "FIXED";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(W, H);
    comp.primaryAxisAlignItems = "SPACE_BETWEEN";
    comp.counterAxisAlignItems = "CENTER";
    comp.paddingLeft = 320;
    comp.paddingRight = 320;
    comp.paddingTop = 12;
    comp.paddingBottom = 12;
    comp.fills = [boundPaint(scv(maps, "color/navigation/bg"))];
    comp.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    comp.strokeAlign = "INSIDE";
    comp.strokeTopWeight = 0;
    comp.strokeRightWeight = 0;
    comp.strokeLeftWeight = 0;
    comp.strokeBottomWeight = 1;
    const left = figma.createFrame();
    left.name = "service-group";
    left.layoutMode = "HORIZONTAL";
    left.primaryAxisSizingMode = "AUTO";
    left.counterAxisSizingMode = "AUTO";
    left.counterAxisAlignItems = "CENTER";
    left.itemSpacing = 11;
    left.fills = [];
    comp.appendChild(left);
    left.layoutSizingHorizontal = "HUG";
    left.layoutSizingVertical = "HUG";
    const svcText = await makeBoundText("[\uC11C\uBE44\uC2A4\uBA85]", 16, "Bold", scv(maps, "color/text/title/primary"));
    svcText.name = "service-name";
    left.appendChild(svcText);
    const right = figma.createFrame();
    right.name = "language-group";
    right.layoutMode = "HORIZONTAL";
    right.primaryAxisSizingMode = "AUTO";
    right.counterAxisSizingMode = "AUTO";
    right.counterAxisAlignItems = "CENTER";
    right.itemSpacing = 8;
    right.fills = [];
    comp.appendChild(right);
    right.layoutSizingHorizontal = "HUG";
    right.layoutSizingVertical = "HUG";
    const globeIcon = await makeIconInstance("globe", scv(maps, "color/icon/gray-dark"), 24, GNB_UTIL_SVGS.lang);
    globeIcon.name = "globe-icon";
    right.appendChild(globeIcon);
    const langText = await makeBoundText("\uD55C\uAD6D\uC5B4", 14, "Medium", scv(maps, "color/icon/gray-dark"));
    langText.name = "language-label";
    right.appendChild(langText);
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "LoginGNB";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "LoginGNB",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH: H + 24,
      rowLabelW: 0
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildWebTabBar(maps, originY) {
    const W = 1920, H = 101;
    const comp = figma.createComponent();
    comp.name = "WebTabBar";
    comp.layoutMode = "VERTICAL";
    comp.primaryAxisSizingMode = "FIXED";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(W, H);
    comp.itemSpacing = 0;
    comp.paddingTop = 0;
    comp.paddingBottom = 0;
    comp.paddingLeft = 0;
    comp.paddingRight = 0;
    comp.fills = [boundPaint(scv(maps, "color/scroll/bg"))];
    comp.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    comp.strokeAlign = "INSIDE";
    comp.strokeTopWeight = 0;
    comp.strokeRightWeight = 0;
    comp.strokeLeftWeight = 0;
    comp.strokeBottomWeight = 1;
    const tabRow = figma.createFrame();
    tabRow.name = "tab-row";
    tabRow.layoutMode = "HORIZONTAL";
    tabRow.primaryAxisSizingMode = "FIXED";
    tabRow.counterAxisSizingMode = "FIXED";
    tabRow.resize(W, 38);
    tabRow.primaryAxisAlignItems = "MIN";
    tabRow.counterAxisAlignItems = "MAX";
    tabRow.paddingLeft = 8;
    tabRow.paddingRight = 8;
    tabRow.itemSpacing = 2;
    tabRow.fills = [];
    comp.appendChild(tabRow);
    tabRow.layoutSizingHorizontal = "FILL";
    tabRow.layoutSizingVertical = "FIXED";
    const activeTab = figma.createFrame();
    activeTab.name = "tab-active";
    activeTab.layoutMode = "HORIZONTAL";
    activeTab.primaryAxisSizingMode = "FIXED";
    activeTab.counterAxisSizingMode = "FIXED";
    activeTab.resize(200, 32);
    activeTab.primaryAxisAlignItems = "MIN";
    activeTab.counterAxisAlignItems = "CENTER";
    activeTab.paddingLeft = 10;
    activeTab.paddingRight = 6;
    activeTab.itemSpacing = 6;
    activeTab.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    try {
      activeTab.topLeftRadius = 6;
      activeTab.topRightRadius = 6;
      activeTab.bottomLeftRadius = 0;
      activeTab.bottomRightRadius = 0;
    } catch (e) {
    }
    tabRow.appendChild(activeTab);
    const favicon = figma.createRectangle();
    favicon.name = "favicon";
    favicon.resize(16, 16);
    favicon.cornerRadius = 3;
    favicon.fills = [{ type: "SOLID", color: { r: 0.4, g: 0.6, b: 1 } }];
    activeTab.appendChild(favicon);
    const tabTitle = await makeBoundText("[\uC11C\uBE44\uC2A4\uBA85]", 13, "Regular", scv(maps, "color/text/body/secondary"));
    tabTitle.name = "tab-title";
    activeTab.appendChild(tabTitle);
    const tabClose = await makeIconInstance("remove", scv(maps, "color/icon/gray"), 16, REMOVE_ICON_SVG);
    tabClose.name = "tab-close";
    activeTab.appendChild(tabClose);
    const spacer = figma.createFrame();
    spacer.name = "spacer";
    spacer.fills = [];
    spacer.resize(1, 32);
    tabRow.appendChild(spacer);
    spacer.layoutSizingHorizontal = "FILL";
    spacer.layoutSizingVertical = "FIXED";
    const winCtrl = figma.createFrame();
    winCtrl.name = "window-controls";
    winCtrl.layoutMode = "HORIZONTAL";
    winCtrl.primaryAxisSizingMode = "AUTO";
    winCtrl.counterAxisSizingMode = "FIXED";
    winCtrl.resize(96, 38);
    winCtrl.itemSpacing = 20;
    winCtrl.counterAxisAlignItems = "CENTER";
    winCtrl.paddingLeft = 8;
    winCtrl.paddingRight = 8;
    winCtrl.fills = [];
    tabRow.appendChild(winCtrl);
    winCtrl.layoutSizingHorizontal = "HUG";
    winCtrl.layoutSizingVertical = "FILL";
    const winGlyphs = [
      { name: "minimize", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 6.5H10" stroke="#757575" stroke-width="1.2" stroke-linecap="round"/></svg>` },
      { name: "maximize", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2.6" y="2.6" width="6.8" height="6.8" rx="0.6" stroke="#757575" stroke-width="1.2"/></svg>` },
      { name: "close", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 3L9 9M9 3L3 9" stroke="#757575" stroke-width="1.2" stroke-linecap="round"/></svg>` }
    ];
    for (const g of winGlyphs) {
      const ic = makeBoundIcon(g.svg, scv(maps, "color/icon/gray"));
      ic.name = g.name;
      try {
        ic.resize(12, 12);
      } catch (e) {
      }
      winCtrl.appendChild(ic);
    }
    const addrRow = figma.createFrame();
    addrRow.name = "address-row";
    addrRow.layoutMode = "HORIZONTAL";
    addrRow.primaryAxisSizingMode = "FIXED";
    addrRow.counterAxisSizingMode = "FIXED";
    addrRow.resize(W, 63);
    addrRow.primaryAxisAlignItems = "MIN";
    addrRow.counterAxisAlignItems = "CENTER";
    addrRow.paddingLeft = 16;
    addrRow.paddingRight = 16;
    addrRow.itemSpacing = 8;
    addrRow.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    comp.appendChild(addrRow);
    addrRow.layoutSizingHorizontal = "FILL";
    addrRow.layoutSizingVertical = "FIXED";
    addrRow.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
    addrRow.appendChild(navIcon(NAV_SVG.chevronRight, maps));
    const refreshNode = makeBoundIcon(SHELL_REFRESH_SVG, scv(maps, "color/icon/gray"));
    refreshNode.name = "nav-refresh";
    try {
      refreshNode.resize(24, 24);
    } catch (e) {
    }
    addrRow.appendChild(refreshNode);
    const pill = figma.createFrame();
    pill.name = "address-pill";
    pill.layoutMode = "HORIZONTAL";
    pill.primaryAxisSizingMode = "FIXED";
    pill.counterAxisSizingMode = "FIXED";
    pill.resize(400, 27);
    pill.cornerRadius = 20;
    pill.paddingLeft = 16;
    pill.paddingRight = 16;
    pill.primaryAxisAlignItems = "MIN";
    pill.counterAxisAlignItems = "CENTER";
    pill.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    addrRow.appendChild(pill);
    pill.layoutSizingHorizontal = "FILL";
    pill.layoutSizingVertical = "FIXED";
    const urlText = await makeBoundText("https://", 13, "Regular", scv(maps, "color/text/body/secondary"));
    urlText.name = "url-text";
    pill.appendChild(urlText);
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "WebTabBar";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "WebTabBar",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH: H + 24,
      rowLabelW: 0
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildCI(maps, originY) {
    const S1_COLORS = [
      { color: "White", v: scv(maps, "color/icon/white") },
      { color: "Blue", v: requireVar(maps.foundationColor, "brand/ci", "Foundation Color") },
      { color: "Dark", v: scv(maps, "color/icon/gray") }
    ];
    const SAM_HASHES = [
      { color: "White", hash: "5ef070ce43a101a072964c656c0e666fe81e4f78" },
      { color: "Blue", hash: "8de26dc1976bd0a64ea5b7207b6bf6d9e0396053" },
      { color: "Dark", hash: "100a4d3fdd0a5a9304c8251792f2d96089ac458a" }
    ];
    const CI_COL = 158, CI_ROW = 60;
    const s1Comps = [];
    S1_COLORS.forEach(({ color, v }, i) => {
      const comp = figma.createComponent();
      comp.name = `Brand=\uC5D0\uC2A4\uC6D0, Color=${color}`;
      comp.resize(42, 16);
      comp.fills = [];
      comp.x = i * CI_COL;
      comp.y = 0;
      const logo = figma.createNodeFromSvg(S1_LOGO_SVG);
      logo.name = "logo";
      rebindIconColor(logo, v);
      comp.appendChild(logo);
      setLightMode(comp, maps);
      s1Comps.push(comp);
    });
    const samComps = [];
    SAM_HASHES.forEach(({ color, hash }, i) => {
      const comp = figma.createComponent();
      comp.name = `Brand=\uC0BC\uC131, Color=${color}`;
      comp.resize(134, 36);
      comp.fills = [];
      comp.x = i * CI_COL;
      comp.y = CI_ROW;
      const rect = figma.createRectangle();
      rect.name = `Samsung_Orig_Wordmark_${color.toUpperCase()}_RGB`;
      rect.resize(134, 36);
      rect.fills = [{ type: "IMAGE", scaleMode: "FILL", imageHash: hash }];
      comp.appendChild(rect);
      setLightMode(comp, maps);
      samComps.push(comp);
    });
    const set = figma.combineAsVariants([...s1Comps, ...samComps], figma.currentPage);
    set.name = "CI";
    set.x = 0;
    set.y = originY;
    try {
      set.fills = [boundPaint(requireVar(maps.foundationColor, "gray/50", "Foundation Color"))];
    } catch (e) {
    }
    setLightMode(set, maps);
    const sh = typeof set.height === "number" && set.height > 0 ? set.height : 84;
    return { set, bottomY: originY + sh };
  }
  async function buildMultiToggleElement(maps, originY) {
    const positions = ["first", "middle-left", "middle-right", "last"];
    const states = ["default", "hover", "selected", "disabled"];
    const sizes = [
      { id: "md", h: 44, padX: 12, font: 14, minW: 64 },
      // 최소 width = sizing/64 (사용자 결정 2026-06-26)
      { id: "sm", h: 34, padX: 8, font: 14, minW: 56 }
      // 최소 width = sizing/56
    ];
    const colorSlot = (st) => {
      switch (st) {
        case "default":
          return { bg: "color/button/bg/secondary--default", border: "color/button/border/secondary--default", text: "color/button/label/secondary--default" };
        case "hover":
          return { bg: "color/button/bg/secondary--hover", border: "color/button/border/secondary--hover", text: "color/button/label/secondary--hover" };
        case "selected":
          return { bg: "color/button/bg/primary--default", border: "color/button/border/primary--default", text: "color/button/label/primary--default" };
        case "disabled":
          return { bg: "color/button/bg/disabled", border: "color/button/border/disabled", text: "color/button/label/disabled" };
      }
    };
    const cornerConfig = (pos) => {
      switch (pos) {
        case "first":
          return { tl: 4, tr: 0, bl: 4, br: 0 };
        case "last":
          return { tl: 0, tr: 4, bl: 0, br: 4 };
        case "middle-left":
          return { tl: 0, tr: 0, bl: 0, br: 0 };
        case "middle-right":
          return { tl: 0, tr: 0, bl: 0, br: 0 };
      }
    };
    const strokeSides = (pos) => {
      switch (pos) {
        case "first":
          return { t: 1, r: 0, b: 1, l: 1 };
        case "middle-left":
          return { t: 1, r: 0, b: 1, l: 1 };
        case "middle-right":
          return { t: 1, r: 1, b: 1, l: 0 };
        case "last":
          return { t: 1, r: 1, b: 1, l: 0 };
      }
    };
    const comps = [];
    const cells = [];
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      const sz = sizes[szIdx];
      for (let posIdx = 0; posIdx < positions.length; posIdx++) {
        const pos = positions[posIdx];
        const cor = cornerConfig(pos);
        const sides = strokeSides(pos);
        for (let stIdx = 0; stIdx < states.length; stIdx++) {
          const st = states[stIdx];
          const slot = colorSlot(st);
          const comp = figma.createComponent();
          comp.name = `position=${pos}, state=${st}, size=${sz.id}`;
          comp.layoutMode = "HORIZONTAL";
          comp.primaryAxisAlignItems = "CENTER";
          comp.counterAxisAlignItems = "CENTER";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "FIXED";
          comp.paddingLeft = sz.padX;
          comp.paddingRight = sz.padX;
          comp.fills = [boundPaint(scv(maps, slot.bg))];
          comp.strokes = [boundPaint(scv(maps, slot.border))];
          comp.strokeAlign = "INSIDE";
          comp.strokeWeight = 1;
          try {
            comp.strokeTopWeight = sides.t;
            comp.strokeRightWeight = sides.r;
            comp.strokeBottomWeight = sides.b;
            comp.strokeLeftWeight = sides.l;
          } catch (e) {
          }
          comp.topLeftRadius = cor.tl;
          comp.topRightRadius = cor.tr;
          comp.bottomLeftRadius = cor.bl;
          comp.bottomRightRadius = cor.br;
          const txt = await makeBoundText("\uD56D\uBAA9", sz.font, "Medium", scv(maps, slot.text));
          txt.textAlignHorizontal = "CENTER";
          comp.appendChild(txt);
          try {
            txt.layoutGrow = 1;
          } catch (e) {
          }
          comp.resize(comp.width, sz.h);
          try {
            comp.minWidth = sz.minW;
          } catch (e) {
          }
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, posIdx, stIdx, szIdx });
          BUILT_COMPS[`MultiToggle:${pos}/${st}/${sz.id}`] = comp;
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Multi Toggle Element";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Multi Toggle Element"] = set;
    const ROW_DEFS = [];
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      for (let posIdx = 0; posIdx < positions.length; posIdx++) {
        ROW_DEFS.push({ pos: positions[posIdx], szId: sizes[szIdx].id, szIdx, posIdx });
      }
    }
    const STATE_LABELS = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Multi Toggle Element",
      colHeaders: STATE_LABELS,
      rowLabels: ROW_DEFS.map((r) => `${r.pos} / ${r.szId}`),
      cellAt: (r, c) => {
        var _a, _b;
        const rd = ROW_DEFS[r];
        return (_b = (_a = cells.find((x) => x.posIdx === rd.posIdx && x.szIdx === rd.szIdx && x.stIdx === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 52,
      rowLabelW: 160
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildMultiToggle(maps, originY) {
    const sizes = ["md", "sm"];
    const selections = ["Left", "Center", "Right"];
    const cellSpec = (j, selectedIdx) => {
      if (j < selectedIdx) {
        return { pos: j === 0 ? "first" : "middle-left", st: "default" };
      } else if (j === selectedIdx) {
        const pos = j === 0 ? "first" : j === 2 ? "last" : "middle-left";
        return { pos, st: "selected" };
      } else {
        return { pos: j === 2 ? "last" : "middle-right", st: "default" };
      }
    };
    const pickCell = async (pos, st, sz) => {
      const key = `MultiToggle:${pos}/${st}/${sz}`;
      let c = BUILT_COMPS[key];
      if (!c) {
        const s = await getBuiltSet("Multi Toggle Element");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name === `position=${pos}, state=${st}, size=${sz}`);
      }
      return c;
    };
    const comps = [];
    const specCells = [];
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      const sz = sizes[szIdx];
      for (let selIdx = 0; selIdx < selections.length; selIdx++) {
        const selLabel = selections[selIdx];
        const comp = figma.createComponent();
        comp.name = `Size=${sz}, Selected=${selLabel}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisAlignItems = "CENTER";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 0;
        comp.fills = [];
        for (let j = 0; j < 3; j++) {
          const { pos, st } = cellSpec(j, selIdx);
          const cellComp = await pickCell(pos, st, sz);
          if (cellComp) {
            const inst = cellComp.createInstance();
            comp.appendChild(inst);
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        specCells.push({ comp, selIdx, szIdx });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Multi Toggle";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Multi Toggle"] = set;
    const SIZE_LABELS = ["md", "sm"];
    const SEL_LABELS = ["Left", "Center", "Right"];
    const opts = {
      title: "Multi Toggle",
      colHeaders: SIZE_LABELS,
      rowLabels: SEL_LABELS,
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = specCells.find((x) => x.selIdx === r && x.szIdx === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 56,
      rowLabelW: 80
      // 셀 min-width(md 64×3) 로 넓어진 토글이 옆 컬럼과 겹치지 않게 220
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var COMPONENT_CATEGORIES_GRID = [
    [
      { name: "Platform", members: ["StatusBar", "NavBar", "CI", "LoginGNB", "WebTabBar", "Footer"] },
      { name: "Navigation", members: ["GNB", "GNB Utility Icon", "Language Icon", "Mobile Bottom Nav"] },
      { name: "Line Tab", members: ["Line Tab Set", "Line Tab"] },
      { name: "Pagination", members: ["Pagination", "Pagination Cell"] },
      { name: "Actions", members: ["Button"] },
      { name: "Selection", members: ["Checkbox", "Radio", "Toggle", "Multi Toggle", "Multi Toggle Element"] },
      // Dropdown 섹션 = Form Control 에서 분리(사용자 결정 2026-06-26). Selection 아래에 세로 스택 배치(stage 2 STACKED).
      //   Form Control 보다 GRID 앞에 둬서 Select Box(Form Control)의 Dropdown 의존(BUILD_DEPENDENCIES)이 빌드순서로 충족됨.
      { name: "Dropdown", members: ["Dropdown", "Dropdown List"] },
      { name: "Chip", members: ["Chip"] },
      // members = 표시(나열) 순서: 메인 컴포넌트 → 그 안을 구성하는 요소 컴포넌트 순. 빌드(생성) 순서는
      //   BUILD_DEPENDENCIES 로 의존성(요소 먼저)이 자동 적용된다 — 표시순서 ≠ 빌드순서 규칙(§ 아래 주석).
      { name: "Form Control", members: ["Input", "Search Input", "Text Area", "Select Box"] },
      { name: "Date Picker", members: ["Date Picker", "Calendar", "Calendar Cell", "Calendar Tile", "Date Picker Mobile Bottom Sheet"] },
      { name: "Time Picker", members: ["Time Picker", "Time Picker Dropdown", "Time Picker Cell", "Time Picker Mobile Bottom Sheet"] },
      { name: "Table", members: ["Table", "Table Cell"] },
      // Bottom Sheet: 메인 컨테이너(Bottom Sheet) → 요소(Bottom Sheet Option) 표시순서.
      //   빌드는 BUILD_DEPENDENCIES 로 요소(Option)·Checkbox·Radio·Button 이 먼저(카테고리를 Selection·Actions 뒤에 둠).
      { name: "Bottom Sheet", members: ["Bottom Sheet", "Bottom Sheet Option"] },
      // Modal(overlay): 공통 팝업 셸. 코어 Button(Actions, 앞 카테고리)을 인스턴스로 부착 → 카테고리 순서로 선빌드 보장.
      { name: "Modal", members: ["Modal"] }
    ],
    // Filter Chip은 별도로 (Chip 아래에 배치될 예정)
    [
      { name: "Filter Chip", members: ["Filter Chip"] }
    ]
  ];
  var COMPONENT_CATEGORIES = COMPONENT_CATEGORIES_GRID.reduce((a, r) => a.concat(r), []);
  var BUILD_DEPENDENCIES = {
    "Select Box": ["Dropdown"],
    // Open 상태가 Dropdown 패널 인스턴스 부착
    "Dropdown": ["Dropdown List"],
    // Dropdown 패널이 Dropdown List 옵션 인스턴스 4행 부착
    "Filter Chip": ["Dropdown"],
    // Selected 상태가 Dropdown 패널 인스턴스 부착(타 카테고리=순서 보장)
    "Time Picker": ["Time Picker Dropdown"],
    // Focus 상태가 Time Picker Dropdown 인스턴스 부착
    "GNB": ["GNB Utility Icon"],
    // GNB 바 유틸 영역이 GNB Utility Icon all-on 인스턴스 부착
    "GNB Utility Icon": ["Language Icon"],
    // language=on 변형이 Language Icon 인스턴스 부착
    "Pagination": ["Pagination Cell"],
    // 완성 바가 Pagination Cell(Arrow·Edge·Number) 인스턴스 조합
    "Multi Toggle": ["Multi Toggle Element"],
    // 조합형태가 Multi Toggle Element 셀 인스턴스 사용 → 요소 먼저 빌드
    "Date Picker": ["Calendar"],
    // Open 상태가 Calendar 패널 인스턴스 부착(BUILT_COMPS["Calendar:Date"])
    // 모바일 바텀시트: Calendar:Date 인스턴스(본문) + Button primary(하단 "적용") 부착 → 둘 다 선빌드 필요.
    "Date Picker Mobile Bottom Sheet": ["Calendar", "Button"],
    // 시간 휠 바텀시트: 하단 "적용" Button + (DateTime 변형) 날짜·시간 Line Tab 인스턴스 부착 → 둘 다 선빌드.
    //   Button(Actions)·Line Tab(Line Tab 카테고리) 은 Time Picker 보다 그리드 앞이라 카테고리 순서로도 보장되나 명시.
    "Time Picker Mobile Bottom Sheet": ["Button", "Line Tab"],
    "Line Tab Set": ["Line Tab"],
    // 탭 3개 묶음 세트가 Line Tab 셀 인스턴스 조합
    // Table 푸터가 완성 Pagination 바(BUILT_COMPS["Pagination:Bar/Middle"]) 인스턴스 부착.
    //   (타 카테고리 의존 = 카테고리 순서로 보장: Pagination 카테고리가 Table 보다 먼저라 선빌드됨.)
    "Table": ["Pagination"],
    // Bottom Sheet 컨테이너 = Bottom Sheet Option(Text) 리스트 + Button 인스턴스 부착 → 둘 다 선빌드.
    //   Option 은 같은 카테고리(요소 먼저), Button 은 Actions 카테고리(그리드 순서로 선빌드).
    "Bottom Sheet": ["Bottom Sheet Option", "Button"],
    "Modal": ["Button"],
    // 푸터가 코어 Button(XXSM) 인스턴스 부착 → Button 선빌드(Actions 카테고리 앞이라 순서로도 보장)
    // Bottom Sheet Option 의 Checkbox/Radio 행 = Checkbox·Radio 컴포넌트 인스턴스 부착(Selection 카테고리 선빌드).
    "Bottom Sheet Option": ["Checkbox", "Radio"]
  };
  function buildOrderFor(members) {
    const inCat = new Set(members);
    const visited = /* @__PURE__ */ new Set();
    const out = [];
    const visit = (m) => {
      if (visited.has(m)) return;
      visited.add(m);
      for (const dep of BUILD_DEPENDENCIES[m] || []) {
        if (inCat.has(dep)) visit(dep);
      }
      out.push(m);
    };
    for (const m of members) visit(m);
    return out;
  }
  async function buildAllComponents(maps, onProgress) {
    TEXT_STYLES2 = maps.textStyles || {};
    const page = figma.currentPage;
    let topNodes = [];
    try {
      if (Array.isArray(page.children)) topNodes = page.children;
    } catch (e) {
    }
    let existing = /* @__PURE__ */ new Set();
    try {
      const r = page.findAll((n) => n.type === "COMPONENT_SET");
      if (Array.isArray(r)) existing = new Set(r.map((n) => n.name));
    } catch (e) {
    }
    const footprint = (p) => {
      const base = [p, `${p} \u2014 Spec Light`, `${p} \u2014 Spec Dark`];
      if (p === "Time Picker Dropdown") base.push(
        "Time Picker Cell",
        "Time Picker Cell \u2014 Spec Light",
        "Time Picker Cell \u2014 Spec Dark"
      );
      if (p === "GNB") base.push(
        "GNB Menu",
        "GNB Menu \u2014 Spec Light",
        "GNB Menu \u2014 Spec Dark"
      );
      if (p === "StatusBar") base.push("Platform/StatusBar", "Shell/StatusBar");
      if (p === "NavBar") base.push("Platform/NavBar", "Shell/NavBar");
      if (p === "LoginGNB") base.push("Platform/LoginGNB");
      if (p === "WebTabBar") base.push("Platform/WebTabBar");
      if (p === "CI") base.push("C/IMG/Logo/Samsung_30");
      if (p === "Date Picker Mobile Bottom Sheet") base.push(
        "Date Picker Mobile",
        "Date Picker Mobile \u2014 Spec Light",
        "Date Picker Mobile \u2014 Spec Dark"
      );
      return base;
    };
    const regionBottom = (p) => {
      const names = new Set(footprint(p));
      const ms = topNodes.filter((n) => names.has(n.name));
      return ms.length ? Math.max(...ms.map((n) => n.y + n.height)) : null;
    };
    const removeByNames = (list) => {
      const names = new Set(list);
      for (const n of topNodes.filter((x) => names.has(x.name))) {
        try {
          n.remove();
        } catch (e) {
        }
      }
    };
    let created = 0;
    const added = [];
    const skipped = [];
    const runners = {
      "Button": (oy) => buildButtonSet(maps, onProgress, 92, 97, oy),
      "Checkbox": (oy) => buildCheckbox(maps, oy),
      "Radio": (oy) => buildRadio(maps, oy),
      "Toggle": (oy) => buildToggle(maps, oy),
      "Multi Toggle Element": (oy) => buildMultiToggleElement(maps, oy),
      "Multi Toggle": (oy) => buildMultiToggle(maps, oy),
      "Chip": (oy) => buildChip(maps, oy),
      "Filter Chip": (oy) => buildFilterChip(maps, oy),
      "Input": (oy) => buildInput(maps, oy, 0),
      "Search Input": (oy) => buildSearch(maps, oy),
      "Text Area": (oy) => buildTextarea(maps, oy),
      "Select Box": (oy) => buildSelect(maps, oy),
      "Dropdown List": (oy) => buildDropdownList(maps, oy),
      "Dropdown": (oy) => buildDropdown(maps, oy),
      "Calendar": (oy) => buildCalendar(maps, oy),
      "Date Picker": (oy) => buildDatePicker(maps, oy),
      "Date Picker Mobile Bottom Sheet": (oy) => buildDatePickerBottomSheet(maps, oy),
      "Bottom Sheet": (oy) => buildBottomSheet(maps, oy),
      "Bottom Sheet Option": (oy) => buildBottomSheetOption(maps, oy),
      "Modal": (oy) => buildModalShell(maps, oy),
      "Calendar Cell": (oy) => buildCalendarCellLayout(maps, oy),
      "Calendar Tile": (oy) => buildCalendarTileLayout(maps, oy),
      "Time Picker": (oy) => buildTimePicker(maps, oy),
      "Time Picker Dropdown": (oy) => buildTimePickerDropdown(maps, oy),
      "Time Picker Mobile Bottom Sheet": (oy) => buildTimePickerMobileBottomSheet(maps, oy),
      "Table Cell": (oy) => buildTableCell(maps, oy),
      "Table": (oy) => buildTable(maps, oy),
      "Line Tab": (oy) => buildLineTab(maps, oy),
      "Line Tab Set": (oy) => buildLineTabSet(maps, oy),
      "GNB Utility Icon": (oy) => buildGNBUtilIcon(maps, oy),
      "Language Icon": (oy) => buildLanguageIcon(maps, oy),
      "Mobile Bottom Nav": (oy) => buildMobileBottomNav(maps, oy),
      "GNB": (oy) => buildGNB(maps, oy),
      "Pagination": (oy) => buildPaginationBar(maps, oy),
      "Pagination Cell": (oy) => buildPaginationCell(maps, oy),
      "StatusBar": (oy) => buildStatusBar(maps, oy),
      "NavBar": (oy) => buildNavBar(maps, oy),
      "LoginGNB": (oy) => buildLoginGNB(maps, oy),
      "WebTabBar": (oy) => buildWebTabBar(maps, oy),
      "CI": (oy) => buildCI(maps, oy),
      "Footer": (oy) => buildFooter(maps, oy)
    };
    const TOTAL = COMPONENT_CATEGORIES.reduce((s, c) => s + c.members.length, 0);
    const SECTION_TITLE_SPACE = 140;
    const SECTION_GAP = 220;
    const SECTION_PAD = 64;
    let y = 0;
    let done = 0;
    for (const cat of COMPONENT_CATEGORIES) {
      const catTopY = y + SECTION_TITLE_SPACE;
      let catY = catTopY;
      for (const name of buildOrderFor(cat.members)) {
        const run = runners[name];
        if (!run) continue;
        done++;
        const isDepSet = name === "Calendar Cell" || name === "Calendar Tile";
        if (existing.has(name) && !isDepSet) {
          const rb = regionBottom(name);
          if (rb != null) catY = rb + 140;
          skipped.push(name);
          continue;
        }
        if (onProgress) onProgress(`${name} \uC0DD\uC131 \uC911\u2026`, 92 + Math.round(done / TOTAL * 8));
        removeByNames(footprint(name));
        const res = await run(catY);
        created += res.set.children.length;
        added.push(name);
        catY = res.bottomY + 140;
      }
      try {
        const pageKids = figma.currentPage.children;
        if (Array.isArray(pageKids)) {
          const kids = pageKids.filter((n) => n.type !== "SECTION");
          const cy = (n) => {
            const b = n.absoluteBoundingBox;
            return b && typeof b.y === "number" && typeof b.height === "number" ? b.y + b.height / 2 : null;
          };
          const seeds = [];
          for (const name of cat.members) {
            const names = new Set(footprint(name));
            const sb = absBBox(kids.filter((n) => names.has(n.name)));
            if (sb) seeds.push({ name, top: sb.minY, bot: sb.maxY });
          }
          if (seeds.length) {
            const byY = [...seeds].sort((a, b) => a.top - b.top);
            const bounds = byY.map((s, i) => ({
              name: s.name,
              lo: i === 0 ? -Infinity : (byY[i - 1].bot + s.top) / 2,
              hi: i === byY.length - 1 ? Infinity : (s.bot + byY[i + 1].top) / 2
            }));
            const nodesByName = {};
            for (const bnd of bounds) {
              nodesByName[bnd.name] = kids.filter((n) => {
                const c = cy(n);
                return c !== null && c > bnd.lo && c <= bnd.hi;
              });
            }
            let layoutY = catTopY;
            for (const name of cat.members) {
              const ns = nodesByName[name];
              if (!ns || !ns.length) continue;
              const bb = absBBox(ns);
              if (!bb) continue;
              const dy = layoutY - bb.minY;
              if (dy !== 0) for (const n of ns) {
                try {
                  n.y += dy;
                } catch (e) {
                }
              }
              layoutY += bb.maxY - bb.minY + 140;
            }
            catY = layoutY;
          }
        }
      } catch (e) {
      }
      await wrapCategoryInSection(cat.name, cat.members, footprint, SECTION_TITLE_SPACE, SECTION_PAD);
      y = catY + SECTION_GAP;
    }
    try {
      const findSec = (nm) => {
        const a = figma.currentPage.findAll((n) => n.type === "SECTION" && n.name === nm);
        return Array.isArray(a) && a.length ? a[0] : null;
      };
      const widthOf = (s) => {
        try {
          const b = s.absoluteBoundingBox;
          if (b && typeof b.width === "number") return b.width;
        } catch (e) {
        }
        return typeof s.width === "number" ? s.width : 0;
      };
      const heightOf = (s) => {
        try {
          const b = s.absoluteBoundingBox;
          if (b && typeof b.height === "number") return b.height;
        } catch (e) {
        }
        return typeof s.height === "number" ? s.height : 0;
      };
      const H_GAP = 120;
      const TOP_Y = 0;
      const ROW = [
        "Platform",
        "Navigation",
        "Line Tab",
        "Pagination",
        "Actions",
        "Selection",
        "Chip",
        "Form Control",
        "Date Picker",
        "Time Picker",
        "Table",
        "Modal"
      ];
      const STACKED = [
        { name: "Filter Chip", below: "Chip", placed: false },
        { name: "Dropdown", below: "Selection", placed: false },
        { name: "Bottom Sheet", below: "Selection", placed: false }
      ];
      let curX = 0;
      for (const nm of ROW) {
        const sec = findSec(nm);
        if (!sec) continue;
        relocateSection(sec, curX, TOP_Y);
        let colWidth = widthOf(sec);
        let stackY = TOP_Y + heightOf(sec) + H_GAP;
        for (const st of STACKED) {
          if (st.below !== nm) continue;
          const ssec = findSec(st.name);
          if (!ssec) continue;
          relocateSection(ssec, curX, stackY);
          colWidth = Math.max(colWidth, widthOf(ssec));
          stackY += heightOf(ssec) + H_GAP;
          st.placed = true;
        }
        curX += colWidth + H_GAP;
      }
      for (const st of STACKED) {
        if (st.placed) continue;
        const ssec = findSec(st.name);
        if (!ssec) continue;
        relocateSection(ssec, curX, TOP_Y);
        curX += widthOf(ssec) + H_GAP;
      }
    } catch (e) {
    }
    if (onProgress) onProgress(`\uC644\uB8CC \u2014 \uCD94\uAC00 ${added.length}\uAC1C \xB7 \uAE30\uC874 \uBCF4\uC874 ${skipped.length}\uAC1C`, 100);
    return { created, added, skipped };
  }
  function absBBox(nodes) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, ok = false;
    for (const n of nodes) {
      const b = n.absoluteBoundingBox;
      if (!b || typeof b.x !== "number" || typeof b.width !== "number") continue;
      ok = true;
      minX = Math.min(minX, b.x);
      minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.width);
      maxY = Math.max(maxY, b.y + b.height);
    }
    return ok ? { minX, minY, maxX, maxY } : null;
  }
  function relocateSection(section, targetX, targetY) {
    let kids = [];
    try {
      const c = section.children;
      if (Array.isArray(c)) kids = c;
    } catch (e) {
      return;
    }
    const sx = typeof section.x === "number" ? section.x : 0;
    const sy = typeof section.y === "number" ? section.y : 0;
    const dx = targetX - sx, dy = targetY - sy;
    const desired = [];
    for (const k of kids) {
      const b = k.absoluteBoundingBox;
      if (b && typeof b.x === "number" && typeof b.y === "number") desired.push({ k, x: b.x + dx, y: b.y + dy });
    }
    try {
      section.x = targetX;
      section.y = targetY;
    } catch (e) {
    }
    for (const d of desired) {
      const b = d.k.absoluteBoundingBox;
      if (b && typeof b.x === "number" && typeof d.k.x === "number") {
        d.k.x += d.x - b.x;
        d.k.y += d.y - b.y;
      }
    }
  }
  async function wrapCategoryInSection(title, members, footprintFn, titleSpace, pad) {
    if (typeof figma.createSection !== "function") return;
    let kids = [];
    try {
      const c = figma.currentPage.children;
      if (Array.isArray(c)) kids = c.filter((n) => n.type !== "SECTION");
    } catch (e) {
      return;
    }
    if (!kids.length) return;
    const names = /* @__PURE__ */ new Set();
    for (const m of members) for (const n of footprintFn(m)) names.add(n);
    const seedBox = absBBox(kids.filter((n) => names.has(n.name)));
    if (!seedBox) return;
    const bandTop = seedBox.minY - titleSpace;
    const bandBot = seedBox.maxY + pad;
    const nodes = kids.filter((n) => {
      const b = n.absoluteBoundingBox;
      if (!b || typeof b.y !== "number" || typeof b.height !== "number") return false;
      const cy = b.y + b.height / 2;
      return cy >= bandTop && cy <= bandBot;
    });
    if (!nodes.length) return;
    const box = absBBox(nodes);
    if (!box) return;
    let section = null;
    try {
      const secs = figma.currentPage.findAll((n) => n.type === "SECTION" && n.name === title);
      if (Array.isArray(secs) && secs.length) section = secs[0];
    } catch (e) {
    }
    if (!section) section = figma.createSection();
    section.name = title;
    try {
      section.x = box.minX - pad;
      section.y = box.minY - titleSpace;
    } catch (e) {
    }
    try {
      section.resizeWithoutConstraints(
        Math.max(0.01, box.maxX - box.minX + pad * 2),
        Math.max(0.01, box.maxY - box.minY + titleSpace + pad)
      );
    } catch (e) {
    }
    for (const n of nodes) {
      const before = n.absoluteBoundingBox;
      const bx = before && typeof before.x === "number" ? before.x : null;
      const by = before && typeof before.y === "number" ? before.y : null;
      try {
        section.appendChild(n);
      } catch (e) {
        continue;
      }
      const after = n.absoluteBoundingBox;
      if (bx != null && by != null && after && typeof after.x === "number" && typeof n.x === "number") {
        n.x += bx - after.x;
        n.y += by - after.y;
      }
    }
  }

  // plugins/figma-vars-installer/src/audit-engine.ts
  var V2_COLLECTION_NAMES = ["Foundation V2", "Semantic Color V2", "Semantic Number V2"];
  var CANONICAL_NAME_SET = (() => {
    const m = {};
    for (const cat of COMPONENT_CATEGORIES) {
      for (const name of cat.members) {
        m[(name || "").toLowerCase().replace(/[\s_\-\/]+/g, "")] = true;
      }
    }
    return m;
  })();
  var OFF_GUIDE_THRESHOLD = 12;
  function nearestFoundationDistance(hex, v2All) {
    let best = 999;
    for (const v of v2All) {
      if (v.collectionName !== "Foundation V2") continue;
      const modes = Object.keys(v.hexByMode);
      if (modes.length === 0) continue;
      const d = hexDistance(hex, v.hexByMode[modes[0]]);
      if (d < best) best = d;
    }
    return best;
  }
  function rgbToHex(rgb) {
    const to = (n) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, "0");
    return `#${to(rgb.r)}${to(rgb.g)}${to(rgb.b)}`.toUpperCase();
  }
  async function loadV2Vars() {
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const v2Cols = collections.filter((c) => V2_COLLECTION_NAMES.indexOf(c.name) >= 0);
    const v2CollectionIds = new Set(v2Cols.map((c) => c.id));
    const v2 = [];
    for (const col of v2Cols) {
      for (const variableId of col.variableIds) {
        const v = await figma.variables.getVariableByIdAsync(variableId);
        if (!v || v.resolvedType !== "COLOR") continue;
        const hexByMode = {};
        for (const m of col.modes) {
          try {
            const val = v.valuesByMode[m.modeId];
            let hex = "";
            if (val && typeof val === "object" && "type" in val && val.type === "VARIABLE_ALIAS") {
              let cur = val;
              for (let i = 0; i < 10; i++) {
                if (typeof cur === "object" && "type" in cur && cur.type === "VARIABLE_ALIAS") {
                  const next = await figma.variables.getVariableByIdAsync(cur.id);
                  if (!next) break;
                  cur = next.valuesByMode[m.modeId];
                  continue;
                }
                break;
              }
              if (cur && typeof cur === "object" && "r" in cur) {
                hex = rgbToHex(cur);
              }
            } else if (val && typeof val === "object" && "r" in val) {
              hex = rgbToHex(val);
            }
            if (hex) hexByMode[m.modeId] = hex;
          } catch (e) {
          }
        }
        v2.push({ id: v.id, name: v.name, collectionName: col.name, hexByMode });
      }
    }
    const byHex = {};
    for (const v of v2) {
      for (const modeId in v.hexByMode) {
        const h = v.hexByMode[modeId];
        if (!byHex[h]) byHex[h] = [];
        if (byHex[h].indexOf(v) === -1) byHex[h].push(v);
      }
    }
    return { v2, v2CollectionIds, byHex };
  }
  function isFrameLike(n) {
    return "children" in n;
  }
  function walk(node, acc = []) {
    if ("id" in node && node.id !== figma.currentPage.id) acc.push(node);
    if (isFrameLike(node)) {
      for (const c of node.children) walk(c, acc);
    }
    return acc;
  }
  function classifyNode(node) {
    if (node.type === "TEXT") return "text";
    if (node.type === "VECTOR" || node.type === "BOOLEAN_OPERATION") return "icon";
    const iconNamePattern = /(^|[_/\s-])ic([_-]|on\b)|icon/i;
    if (iconNamePattern.test(node.name || "")) return "icon";
    let cur = node.parent;
    let depth = 0;
    while (cur && cur.id !== figma.currentPage.id && depth < 5) {
      if (iconNamePattern.test(cur.name || "")) return "icon";
      cur = cur.parent;
      depth++;
    }
    return "shape";
  }
  function getComponentContext(node) {
    const isComponentLike = (n) => n.type === "COMPONENT" || n.type === "COMPONENT_SET" || n.type === "INSTANCE";
    const splitName = (name) => (name || "").split(/[/_\s,+]+/).map((s) => s.trim().toLowerCase()).filter(Boolean);
    if (isComponentLike(node)) {
      return splitName(node.name);
    }
    let cur = node.parent;
    while (cur && cur.id !== figma.currentPage.id) {
      if (isComponentLike(cur)) {
        return splitName(cur.name);
      }
      cur = cur.parent;
    }
    return [];
  }
  var KNOWN_ROLES = ["text", "label", "icon", "bg", "surface", "border", "line", "stroke", "fill"];
  function decideRoles(nodeKind, paintProp, externalVarName) {
    const roles = [];
    if (externalVarName) {
      const segs = externalVarName.toLowerCase().split("/").filter(Boolean);
      for (const seg of segs) {
        if (KNOWN_ROLES.indexOf(seg) >= 0 && roles.indexOf(seg) === -1) {
          roles.push(seg);
        }
      }
    }
    if (nodeKind === "text") {
      if (roles.indexOf("text") === -1) roles.push("text");
      if (roles.indexOf("label") === -1) roles.push("label");
    } else if (nodeKind === "icon") {
      if (roles.indexOf("icon") === -1) roles.push("icon");
    } else {
      if (paintProp === "fills") {
        if (roles.indexOf("bg") === -1) roles.push("bg");
        if (roles.indexOf("surface") === -1) roles.push("surface");
      } else {
        if (roles.indexOf("border") === -1) roles.push("border");
        if (roles.indexOf("line") === -1) roles.push("line");
      }
    }
    return roles;
  }
  function hexDistance(a, b) {
    if (!a || !b || a.length < 7 || b.length < 7) return 999;
    const ar = parseInt(a.slice(1, 3), 16);
    const ag = parseInt(a.slice(3, 5), 16);
    const ab = parseInt(a.slice(5, 7), 16);
    const br = parseInt(b.slice(1, 3), 16);
    const bg = parseInt(b.slice(3, 5), 16);
    const bb = parseInt(b.slice(5, 7), 16);
    return Math.sqrt((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2);
  }
  function categoryOf(varName) {
    const segs = varName.toLowerCase().split("/").filter(Boolean);
    if (segs.length < 2) return "etc";
    if (segs[0] !== "color") return segs[0];
    return segs[1];
  }
  function pickSuggestions(hex, byHex, v2All, paintProp, nodeKind, contextSegments, externalVarName) {
    const roles = decideRoles(nodeKind, paintProp, externalVarName);
    const exactList = byHex[hex] || [];
    const exactIds = new Set(exactList.map((v) => v.id));
    const result = [];
    const added = /* @__PURE__ */ new Set();
    for (const v of v2All) {
      if (v.collectionName !== "Semantic Color V2") continue;
      const lower = v.name.toLowerCase();
      let hasRoleMatch = false;
      for (const role of roles) {
        if (lower.indexOf(`/${role}/`) >= 0 || lower.indexOf(`/${role}--`) >= 0) {
          hasRoleMatch = true;
          break;
        }
      }
      if (!hasRoleMatch) continue;
      const cat = categoryOf(v.name);
      const isComponentMatch = contextSegments.indexOf(cat) >= 0;
      const isExact = exactIds.has(v.id);
      let matchType;
      let confidence;
      if (isComponentMatch) {
        matchType = "role+component";
        confidence = "high";
      } else {
        matchType = "role";
        confidence = "medium";
      }
      if (isExact) confidence = "high";
      result.push({
        variableId: v.id,
        variableName: v.name,
        collectionName: v.collectionName,
        confidence,
        matchType,
        category: cat
      });
      added.add(v.id);
    }
    for (const v of exactList) {
      if (added.has(v.id)) continue;
      result.push({
        variableId: v.id,
        variableName: v.name,
        collectionName: v.collectionName,
        confidence: "medium",
        matchType: "exact",
        category: v.collectionName === "Foundation V2" ? "foundation" : categoryOf(v.name)
      });
      added.add(v.id);
    }
    const nears = [];
    for (const v of v2All) {
      if (v.collectionName !== "Foundation V2") continue;
      if (added.has(v.id)) continue;
      const modes = Object.keys(v.hexByMode);
      if (modes.length === 0) continue;
      const vHex = v.hexByMode[modes[0]];
      const d = hexDistance(hex, vHex);
      nears.push({ v, dist: d });
    }
    nears.sort((a, b) => a.dist - b.dist);
    for (const n of nears.slice(0, 10)) {
      result.push({
        variableId: n.v.id,
        variableName: n.v.name,
        collectionName: n.v.collectionName,
        confidence: "low",
        matchType: "near",
        matchInfo: `\u0394${Math.round(n.dist)}`,
        category: "foundation"
      });
      added.add(n.v.id);
    }
    const orderMap = { "role+component": 0, "role": 1, "exact": 2, "near": 3 };
    result.sort((a, b) => {
      var _a, _b;
      const aCtx = contextSegments.indexOf(a.category) >= 0 ? 0 : 1;
      const bCtx = contextSegments.indexOf(b.category) >= 0 ? 0 : 1;
      if (aCtx !== bCtx) return aCtx - bCtx;
      const ao = (_a = orderMap[a.matchType]) != null ? _a : 9;
      const bo = (_b = orderMap[b.matchType]) != null ? _b : 9;
      if (ao !== bo) return ao - bo;
      if (a.category !== b.category) return a.category.localeCompare(b.category);
      return a.variableName.localeCompare(b.variableName);
    });
    return result;
  }
  async function audit(rootOverride) {
    const sel = rootOverride ? [rootOverride] : figma.currentPage.selection;
    if (sel.length === 0) {
      return { issues: [], stats: { scanned: 0, issuesCount: 0, highCount: 0 } };
    }
    const { v2, v2CollectionIds, byHex } = await loadV2Vars();
    const allNodes = [];
    for (const root of sel) {
      allNodes.push(root);
      walk(root, allNodes);
    }
    const issues = [];
    let issueCounter = 0;
    for (const n of allNodes) {
      const ctx = getComponentContext(n);
      const kind = classifyNode(n);
      for (const prop of ["fills", "strokes"]) {
        if (!(prop in n)) continue;
        const arr = n[prop];
        if (!Array.isArray(arr)) continue;
        for (let i = 0; i < arr.length; i++) {
          const p = arr[i];
          if (!p || p.type !== "SOLID") continue;
          const rgb = p.color;
          const hex = rgbToHex(rgb);
          const bound = p.boundVariables && p.boundVariables.color;
          let externalVarName;
          if (bound) {
            const vTemp = await figma.variables.getVariableByIdAsync(bound.id);
            if (vTemp && !v2CollectionIds.has(vTemp.variableCollectionId)) {
              externalVarName = vTemp.name;
            }
          }
          const suggestions = pickSuggestions(hex, byHex, v2, prop, kind, ctx, externalVarName);
          const hasComponentMatch = ctx.length > 0;
          const hasExact = suggestions.some((s) => s.matchType === "exact");
          const nearestDistance = nearestFoundationDistance(hex, v2);
          const offGuide = !hasExact && nearestDistance > OFF_GUIDE_THRESHOLD;
          if (bound) {
            const v = await figma.variables.getVariableByIdAsync(bound.id);
            if (!v) continue;
            if (v2CollectionIds.has(v.variableCollectionId)) continue;
            issues.push({
              id: "i" + ++issueCounter,
              nodeId: n.id,
              nodeName: n.name,
              nodeKind: kind,
              property: prop,
              paintIndex: i,
              reasonKind: "external-var",
              hex,
              sourceLabel: v.name,
              componentContext: ctx,
              hasComponentMatch,
              suggestions,
              offGuide,
              nearestDistance
            });
          } else {
            issues.push({
              id: "i" + ++issueCounter,
              nodeId: n.id,
              nodeName: n.name,
              nodeKind: kind,
              property: prop,
              paintIndex: i,
              reasonKind: "unbound-hex",
              hex,
              sourceLabel: hex,
              componentContext: ctx,
              hasComponentMatch,
              suggestions,
              offGuide,
              nearestDistance
            });
          }
        }
      }
    }
    const highCount = issues.filter((x) => x.suggestions.length === 1 && x.suggestions[0].confidence === "high").length;
    return { issues, stats: { scanned: allNodes.length, issuesCount: issues.length, highCount } };
  }
  async function applyOne(issue, suggestionIndex) {
    const sug = issue.suggestions[suggestionIndex];
    if (!sug) return false;
    const node = await figma.getNodeByIdAsync(issue.nodeId);
    if (!node) return false;
    const v2 = await figma.variables.getVariableByIdAsync(sug.variableId);
    if (!v2) return false;
    const arr = node[issue.property];
    if (!Array.isArray(arr)) return false;
    const copy = JSON.parse(JSON.stringify(arr));
    const paint = copy[issue.paintIndex];
    if (!paint || paint.type !== "SOLID") return false;
    copy[issue.paintIndex] = figma.variables.setBoundVariableForPaint(paint, "color", v2);
    node[issue.property] = copy;
    return true;
  }
  async function applyHighConfidence(issues) {
    let n = 0;
    for (const i of issues) {
      if (i.suggestions.length === 1 && i.suggestions[0].confidence === "high") {
        if (await applyOne(i, 0)) n++;
      }
    }
    return n;
  }
  async function applyMulti(picks) {
    let ok = 0;
    let fail = 0;
    const applied = [];
    for (const p of picks) {
      if (await applyOne(p.issue, p.suggestionIndex)) {
        ok++;
        applied.push({ issueId: p.issue.id, suggestionIndex: p.suggestionIndex });
      } else {
        fail++;
      }
    }
    return { ok, fail, applied };
  }
  async function setVariablesMode(mode) {
    const sel = figma.currentPage.selection;
    if (sel.length === 0) {
      return { count: 0, skipped: 0, message: "\uC120\uD0DD\uB41C \uB178\uB4DC \uC5C6\uC74C" };
    }
    if (mode === "clear") {
      let cleared = 0;
      let skipped2 = 0;
      const visit = (n) => {
        const modes = n.explicitVariableModes;
        if (modes) {
          const collectionIds = Object.keys(modes);
          for (const cid of collectionIds) {
            try {
              n.clearExplicitVariableModeForCollection(cid);
              cleared++;
            } catch (e) {
              skipped2++;
            }
          }
        }
        if ("children" in n) {
          for (const c of n.children) visit(c);
        }
      };
      for (const root of sel) visit(root);
      if (cleared === 0 && skipped2 === 0) {
        return { count: 0, skipped: 0, cleared: 0, message: "\uCD08\uAE30\uD654\uD560 \uBAA8\uB4DC override \uC5C6\uC74C" };
      }
      return { count: sel.length, skipped: skipped2, cleared };
    }
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const semantic = collections.find((c) => c.name === "Semantic Color V2");
    if (!semantic) {
      return { count: 0, skipped: 0, message: "Semantic Color V2 \uCEEC\uB809\uC158 \uC5C6\uC74C" };
    }
    const targetName = mode === "light" ? "Light" : "Dark";
    const found = semantic.modes.find((m) => m.name === targetName);
    if (!found) {
      return { count: 0, skipped: 0, message: `${targetName} \uBAA8\uB4DC\uB97C \uCC3E\uC9C0 \uBABB\uD568` };
    }
    let count = 0;
    let skipped = 0;
    for (const node of sel) {
      try {
        node.setExplicitVariableModeForCollection(semantic.id, found.modeId);
        count++;
      } catch (e) {
        skipped++;
      }
    }
    return { count, skipped };
  }
  function collectComponents(root, sourceFileName) {
    const acc = [];
    const visit = (n) => {
      if (n.type === "COMPONENT_SET") {
        acc.push({ id: n.id, key: n.key, name: n.name, type: "COMPONENT_SET", sourceFileName });
        return;
      }
      if (n.type === "COMPONENT") {
        if (n.parent && n.parent.type === "COMPONENT_SET") return;
        acc.push({ id: n.id, key: n.key, name: n.name, type: "COMPONENT", sourceFileName });
        return;
      }
      if ("children" in n) {
        for (const c of n.children) visit(c);
      }
    };
    visit(root);
    return acc;
  }
  function collectInstances(root) {
    const acc = [];
    const visit = (n) => {
      if (n.type === "INSTANCE") {
        acc.push(n);
      }
      if ("children" in n) {
        for (const c of n.children) visit(c);
      }
    };
    visit(root);
    return acc;
  }
  function hasInstanceAncestor(n) {
    let p = n.parent;
    while (p && p.type !== "PAGE" && p.type !== "DOCUMENT") {
      if (p.type === "INSTANCE") return true;
      p = p.parent;
    }
    return false;
  }
  function normalizeName(s) {
    return (s || "").toLowerCase().replace(/[\s_\-\/]+/g, "").trim();
  }
  function findReferenceMatch(name, pool) {
    const lower = name.toLowerCase();
    const exact = pool.find((p) => p.name.toLowerCase() === lower);
    if (exact) return { match: exact, matchType: "exact" };
    const norm = normalizeName(name);
    const normMatch = pool.find((p) => normalizeName(p.name) === norm);
    if (normMatch) return { match: normMatch, matchType: "normalized" };
    if (norm.length >= 3) {
      const part = pool.find((p) => {
        const pn = normalizeName(p.name);
        return pn.length >= 3 && (pn.indexOf(norm) >= 0 || norm.indexOf(pn) >= 0);
      });
      if (part) return { match: part, matchType: "partial" };
    }
    return { match: null, matchType: null };
  }
  function bigrams(s) {
    const out = [];
    for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  }
  function diceCoefficient(a, b) {
    if (a === b) return 1;
    const A = bigrams(a), B = bigrams(b);
    if (A.length === 0 || B.length === 0) return 0;
    const freq = {};
    for (const g of A) freq[g] = (freq[g] || 0) + 1;
    let hit = 0;
    for (const g of B) {
      if (freq[g] > 0) {
        freq[g]--;
        hit++;
      }
    }
    return 2 * hit / (A.length + B.length);
  }
  function tokenizeName(s) {
    return (s || "").toLowerCase().split(/[\s_\-\/,.]+/).filter((t) => t.length > 0);
  }
  function scoreNameSimilarity(legacy, canon) {
    const ln = normalizeName(legacy), cn = normalizeName(canon);
    if (!ln || !cn) return 0;
    if (ln === cn) return 1;
    let score = diceCoefficient(ln, cn);
    const lt = new Set(tokenizeName(legacy));
    const ct = tokenizeName(canon);
    if (ct.length) {
      let overlap = 0;
      for (const t of ct) if (lt.has(t)) overlap++;
      score = Math.max(score, overlap / ct.length);
    }
    if (ln.indexOf(cn) >= 0 || cn.indexOf(ln) >= 0) score = Math.max(score, 0.6);
    return score;
  }
  var MODULE_NESTED_THRESHOLD = 5;
  function rankSuggestions(legacyName, pool) {
    return pool.map((p) => ({ id: p.id, key: p.key, type: p.type, name: p.name, source: p.sourceFileName, score: Math.round(scoreNameSimilarity(legacyName, p.name) * 100) / 100 })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  }
  var VARIANT_VALUE_SYNONYMS = {
    small: "sm",
    sm: "sm",
    medium: "md",
    md: "md",
    large: "lg",
    lg: "lg"
  };
  function normAxisName(a) {
    return (a || "").toLowerCase().replace(/[\s_\-]+/g, "");
  }
  function normVariantValue(v) {
    const base = (v || "").toLowerCase().replace(/[\s_\-]+/g, "");
    return VARIANT_VALUE_SYNONYMS[base] || base;
  }
  function pickVariantTarget(set, legacyVP) {
    const variants = set.children.filter((c) => c.type === "COMPONENT");
    if (variants.length === 0) return { target: null, reason: "no-variant-match", axisLoss: 0 };
    const def = set.defaultVariant || variants[0];
    if (!legacyVP) return { target: def, reason: null, axisLoss: 0 };
    const defVP = def.variantProperties || {};
    const canonAxes = Object.keys(defVP);
    const canonByNorm = {};
    for (const a of canonAxes) canonByNorm[normAxisName(a)] = a;
    const shared = [];
    let axisLoss = 0;
    for (const la of Object.keys(legacyVP)) {
      const ca = canonByNorm[normAxisName(la)];
      if (ca) shared.push({ canon: ca, want: normVariantValue(legacyVP[la]) });
      else axisLoss++;
    }
    if (shared.length === 0) {
      if (variants.length === 1) return { target: def, reason: null, axisLoss };
      return { target: null, reason: "no-variant-match", axisLoss };
    }
    const matches = variants.filter((v) => {
      const vp = v.variantProperties || {};
      return shared.every((s) => normVariantValue(vp[s.canon]) === s.want);
    });
    if (matches.length === 0) return { target: null, reason: "no-variant-match", axisLoss };
    if (matches.length === 1) return { target: matches[0], reason: null, axisLoss };
    const otherAxes = canonAxes.filter((a) => !shared.some((s) => s.canon === a));
    const narrowed = matches.filter((v) => {
      const vp = v.variantProperties || {};
      return otherAxes.every((a) => vp[a] === defVP[a]);
    });
    if (narrowed.length === 1) return { target: narrowed[0], reason: null, axisLoss };
    return { target: null, reason: "no-variant-match", axisLoss };
  }
  async function scanSwapCandidates(pool, roots) {
    const sel = roots && roots.length ? roots : figma.currentPage.selection;
    const diag = {
      selectionCount: sel.length,
      instanceCount: 0,
      referencePoolSize: pool.length,
      matchedNameCount: 0,
      sameIdSkippedCount: 0,
      skippedNestedCount: 0,
      noMatchCount: 0,
      candidateCount: 0,
      instancesPreview: []
    };
    if (sel.length === 0) return { candidates: [], diagnostics: diag, manualCandidates: [], modules: [] };
    const candidates = [];
    const manualCandidates = [];
    const modules = [];
    const manualSeen = /* @__PURE__ */ new Set();
    const seen = /* @__PURE__ */ new Set();
    let counter = 0;
    for (const root of sel) {
      const insts = collectInstances(root);
      diag.instanceCount += insts.length;
      for (const inst of insts) {
        if (hasInstanceAncestor(inst)) {
          diag.skippedNestedCount++;
          continue;
        }
        const main = await inst.getMainComponentAsync();
        if (!main) {
          if (diag.instancesPreview.length < 8) diag.instancesPreview.push({ name: inst.name, mainName: "(mainComponent null)", mainTopId: "", matched: false, sameAsTarget: false });
          continue;
        }
        const compareName = main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.name : main.name;
        const currentTopId = main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.id : main.id;
        let found = findReferenceMatch(compareName, pool);
        if (!found.match && inst.name && inst.name !== compareName) {
          found = findReferenceMatch(inst.name, pool);
        }
        const target = found.match;
        const confidence = found.matchType === "partial" ? "ambiguous" : "high";
        const matched = !!target;
        const sameAsTarget = !!target && target.id === currentTopId;
        if (matched) diag.matchedNameCount++;
        if (sameAsTarget) diag.sameIdSkippedCount++;
        if (diag.instancesPreview.length < 8) {
          diag.instancesPreview.push({ name: inst.name, mainName: compareName, mainTopId: currentTopId, matched, sameAsTarget });
        }
        if (!matched) {
          diag.noMatchCount++;
          if (pool.length > 0 && !manualSeen.has(currentTopId)) {
            manualSeen.add(currentTopId);
            const nestedCount = collectInstances(inst).length - 1;
            if (nestedCount >= MODULE_NESTED_THRESHOLD) {
              modules.push({
                id: "g" + ++counter,
                instanceId: inst.id,
                instanceName: inst.name,
                currentMainName: compareName,
                currentMainPath: await describeComponentLocation(main),
                nestedCount
              });
            } else {
              manualCandidates.push({
                id: "m" + ++counter,
                instanceId: inst.id,
                instanceName: inst.name,
                currentMainName: compareName,
                currentMainPath: await describeComponentLocation(main),
                suggestions: rankSuggestions(inst.name && inst.name !== compareName ? `${compareName} ${inst.name}` : compareName, pool)
              });
            }
          }
          continue;
        }
        if (sameAsTarget) continue;
        const key = inst.id + ":" + target.id;
        if (seen.has(key)) continue;
        seen.add(key);
        const path = await describeComponentLocation(main);
        candidates.push({
          id: "s" + ++counter,
          instanceId: inst.id,
          instanceName: inst.name,
          currentMainId: currentTopId,
          currentMainName: compareName,
          currentMainPath: path,
          suggestedId: target.id,
          suggestedKey: target.key,
          suggestedType: target.type,
          suggestedName: target.name,
          suggestedSource: target.sourceFileName,
          confidence
        });
      }
    }
    diag.candidateCount = candidates.length;
    return { candidates, diagnostics: diag, manualCandidates, modules };
  }
  async function describeComponentLocation(comp) {
    let cur = comp;
    let pageName = "";
    while (cur) {
      if (cur.type === "PAGE") {
        pageName = cur.name;
        break;
      }
      cur = cur.parent;
    }
    return pageName || "(\uC678\uBD80)";
  }
  async function loadSuggestedNode(candidate) {
    try {
      const n = await figma.getNodeByIdAsync(candidate.suggestedId);
      if (n && (n.type === "COMPONENT" || n.type === "COMPONENT_SET")) return n;
    } catch (e) {
    }
    if (candidate.suggestedKey) {
      try {
        if (candidate.suggestedType === "COMPONENT_SET") {
          return await figma.importComponentSetByKeyAsync(candidate.suggestedKey);
        }
        return await figma.importComponentByKeyAsync(candidate.suggestedKey);
      } catch (e) {
        return null;
      }
    }
    return null;
  }
  async function resolveSwapTarget(candidate, mode, legacyVP) {
    const node = await loadSuggestedNode(candidate);
    if (!node) return { target: null, reason: "resolve-failed", variantReset: false, axisLoss: 0 };
    if (node.type === "COMPONENT") {
      return { target: node, reason: null, variantReset: false, axisLoss: 0 };
    }
    const set = node;
    const pick = pickVariantTarget(set, legacyVP);
    if (pick.target) {
      return { target: pick.target, reason: null, variantReset: false, axisLoss: pick.axisLoss };
    }
    if (mode === "lenient") {
      const fallback = set.defaultVariant || set.children.filter((c) => c.type === "COMPONENT")[0] || null;
      if (fallback) return { target: fallback, reason: null, variantReset: true, axisLoss: pick.axisLoss };
      return { target: null, reason: "resolve-failed", variantReset: false, axisLoss: pick.axisLoss };
    }
    return { target: null, reason: pick.reason || "no-variant-match", variantReset: false, axisLoss: pick.axisLoss };
  }
  function collectTextsWithPath(root) {
    const out = [];
    const walk2 = (node, path) => {
      if (node.type === "TEXT") out.push({ key: path.join("/"), node });
      if ("children" in node) {
        const kids = node.children;
        const nameSeen = {};
        for (const k of kids) {
          const base = k.name || k.type;
          const idx = nameSeen[base] = nameSeen[base] === void 0 ? 0 : nameSeen[base] + 1;
          walk2(k, path.concat(`${base}#${idx}`));
        }
      }
    };
    walk2(root, []);
    return out;
  }
  function captureTextOverrides(inst) {
    const map = /* @__PURE__ */ new Map();
    for (const t of collectTextsWithPath(inst)) {
      if (!map.has(t.key)) map.set(t.key, t.node.characters);
    }
    return map;
  }
  async function loadFontsForText(node) {
    const fn = node.fontName;
    if (fn === figma.mixed) {
      const len = node.characters.length;
      const seen = /* @__PURE__ */ new Set();
      for (let i = 0; i < len; i++) {
        const f = node.getRangeFontName(i, i + 1);
        if (f !== figma.mixed) seen.add(JSON.stringify(f));
      }
      for (const s of seen) await figma.loadFontAsync(JSON.parse(s));
    } else {
      await figma.loadFontAsync(fn);
    }
  }
  async function restoreTextOverrides(inst, captured) {
    if (captured.size === 0) return { restored: 0, unpreserved: [] };
    const used = /* @__PURE__ */ new Set();
    let restored = 0;
    for (const { key, node } of collectTextsWithPath(inst)) {
      if (!captured.has(key) || used.has(key)) continue;
      const chars = captured.get(key);
      used.add(key);
      if (node.characters === chars) {
        restored++;
        continue;
      }
      try {
        await loadFontsForText(node);
        node.characters = chars;
        restored++;
      } catch (e) {
        used.delete(key);
      }
    }
    const unpreserved = [];
    for (const [key, chars] of captured) {
      if (!used.has(key) && chars.trim() !== "") unpreserved.push(chars);
    }
    return { restored, unpreserved };
  }
  async function applySwap(candidate, mode = "lenient") {
    const inst = await figma.getNodeByIdAsync(candidate.instanceId);
    if (!inst || inst.type !== "INSTANCE") {
      return { ok: false, result: "failed", reason: "\uC778\uC2A4\uD134\uC2A4\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC74C" };
    }
    if (hasInstanceAncestor(inst)) {
      return { ok: false, result: "failed", reason: "\uB2E4\uB978 \uCEF4\uD3EC\uB10C\uD2B8 \uC548\uC5D0 \uD3EC\uD568\uB41C \uBD80\uD488\uC774\uB77C \uAC1C\uBCC4 \uAD50\uCCB4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    }
    const legacyVP = inst.variantProperties || null;
    const res = await resolveSwapTarget(candidate, mode, legacyVP);
    if (!res.target) {
      if (res.reason === "no-variant-match") {
        return { ok: false, result: "demoted", reason: "\uC815\uBCF8\uC5D0 \uAC19\uC740 \uC0C1\uD0DC(\uBCC0\uD615) \uC870\uD569\uC774 \uC5C6\uC5B4 \uC790\uB3D9 \uAD50\uCCB4\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.", axisLoss: res.axisLoss };
      }
      return { ok: false, result: "failed", reason: "\uAE30\uC900 \uCEF4\uD3EC\uB10C\uD2B8\uB97C import\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uAE30\uC900 \uD30C\uC77C\uC5D0\uC11C \uCEF4\uD3EC\uB10C\uD2B8\uAC00 publish\uB418\uC5C8\uB294\uC9C0 \uD655\uC778\uD574\uC8FC\uC138\uC694." };
    }
    const captured = captureTextOverrides(inst);
    try {
      inst.swapComponent(res.target);
    } catch (e) {
      return { ok: false, result: "failed", reason: String(e && e.message || e) };
    }
    let unpreserved = [];
    try {
      const pres = await restoreTextOverrides(inst, captured);
      unpreserved = pres.unpreserved;
    } catch (e) {
    }
    return { ok: true, result: "swapped", variantReset: res.variantReset, axisLoss: res.axisLoss, unpreserved };
  }
  function collectPageReference() {
    const fileName = figma.root.name;
    const seen = {};
    const out = [];
    const push = (list) => {
      for (const c of list) {
        const norm = (c.name || "").toLowerCase().replace(/[\s_\-\/]+/g, "");
        if (!CANONICAL_NAME_SET[norm]) continue;
        if (!seen[norm]) {
          seen[norm] = true;
          out.push(c);
        }
      }
    };
    try {
      push(collectComponents(figma.currentPage, fileName));
    } catch (e) {
    }
    for (const page of figma.root.children) {
      if (page.id === figma.currentPage.id) continue;
      try {
        push(collectComponents(page, fileName));
      } catch (e) {
      }
    }
    return out;
  }
  async function buildImprovedCopy() {
    const sel = figma.currentPage.selection;
    if (sel.length !== 1 || sel[0].type !== "FRAME") {
      return { ok: false, code: "need-single-frame", reason: "\uAC1C\uC120\uC548\uC744 \uB9CC\uB4E4 \uD654\uBA74 \uD504\uB808\uC784\uC744 \uD558\uB098\uB9CC \uC120\uD0DD\uD574\uC8FC\uC138\uC694." };
    }
    const src = sel[0];
    const pool = collectPageReference();
    if (pool.length === 0) {
      return { ok: false, code: "need-install", reason: "\uC774 \uD398\uC774\uC9C0\uC5D0 \uC815\uBCF8 \uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. [\uC124\uCE58] \uD0ED\uC744 \uBA3C\uC800 \uC2E4\uD589\uD574\uC8FC\uC138\uC694." };
    }
    const clone = src.clone();
    try {
      clone.name = src.name + " \u2014 \uAC1C\uC120\uC548";
      figma.currentPage.appendChild(clone);
      const box = src.absoluteBoundingBox;
      if (box) {
        clone.x = box.x + box.width + 200;
        clone.y = box.y;
      } else {
        clone.x = src.x + src.width + 200;
        clone.y = src.y;
      }
      const { candidates, diagnostics, manualCandidates, modules } = await scanSwapCandidates(pool, [clone]);
      let autoSwapped = 0, ambiguous = 0, failed = 0, axisLoss = 0, textUnpreserved = 0;
      const ambiguousList = [];
      const failedList = [];
      for (const c of candidates) {
        if (c.confidence !== "high") {
          ambiguous++;
          ambiguousList.push(__spreadProps(__spreadValues({}, c), { demoteReason: "\uC774\uB984\uC774 \uBD80\uBD84\uC801\uC73C\uB85C\uB9CC \uC77C\uCE58\uD574 \uD655\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4." }));
          continue;
        }
        const r = await applySwap(c, "strict");
        if (r.result === "swapped") {
          autoSwapped++;
          if (r.axisLoss && r.axisLoss > 0) axisLoss++;
          if (r.unpreserved && r.unpreserved.length) textUnpreserved += r.unpreserved.length;
        } else if (r.result === "demoted") {
          ambiguous++;
          ambiguousList.push(__spreadProps(__spreadValues({}, c), { confidence: "ambiguous", demoteReason: r.reason || "\uC815\uBCF8\uC5D0 \uAC19\uC740 \uC0C1\uD0DC(\uBCC0\uD615) \uC870\uD569\uC774 \uC5C6\uC2B5\uB2C8\uB2E4." }));
        } else {
          failed++;
          failedList.push(__spreadProps(__spreadValues({}, c), { demoteReason: r.reason || "\uAD50\uCCB4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." }));
        }
      }
      return {
        ok: true,
        summary: {
          cloned: true,
          cloneId: clone.id,
          cloneName: clone.name,
          sourceName: src.name,
          autoSwapped,
          ambiguous,
          failed,
          axisLoss,
          textUnpreserved,
          manualNeeded: manualCandidates.length,
          moduleNeeded: modules.length,
          skippedNested: diagnostics.skippedNestedCount,
          alreadyCanonical: diagnostics.sameIdSkippedCount,
          noMatch: diagnostics.noMatchCount,
          totalInstances: diagnostics.instanceCount,
          referencePoolSize: pool.length
        },
        ambiguousCandidates: ambiguousList,
        failedCandidates: failedList,
        manualCandidates,
        modules
      };
    } catch (e) {
      try {
        clone.remove();
      } catch (e2) {
      }
      throw e;
    }
  }
  var REFERENCE_STORAGE_KEY = "s1-component-audit:reference-pool";
  async function loadReference() {
    try {
      const saved = await figma.clientStorage.getAsync(REFERENCE_STORAGE_KEY);
      if (!saved || !saved.pool || saved.pool.length === 0) return null;
      const valid = [];
      for (const c of saved.pool) {
        if (c.key) {
          valid.push(c);
          continue;
        }
        const n = await figma.getNodeByIdAsync(c.id);
        if (n && (n.type === "COMPONENT" || n.type === "COMPONENT_SET")) {
          valid.push(c);
        }
      }
      if (valid.length === 0) return null;
      return { pool: valid, rootNames: saved.rootNames || [], sourceFileName: saved.sourceFileName };
    } catch (e) {
      return null;
    }
  }
  async function saveReference(pool, rootNames, sourceFileName) {
    try {
      await figma.clientStorage.setAsync(REFERENCE_STORAGE_KEY, { pool, rootNames, sourceFileName });
    } catch (e) {
    }
  }
  async function clearReference() {
    try {
      await figma.clientStorage.deleteAsync(REFERENCE_STORAGE_KEY);
    } catch (e) {
    }
  }

  // plugins/figma-vars-installer/src/code.ts
  figma.showUI(__html__, { width: 440, height: 800, title: "S-1 S/W UX Guide \uC124\uCE58/\uAC80\uC218\uAE30 0.2Ver" });
  figma.ui.onmessage = async (msg) => {
    var _a, _b;
    if (msg.type === "install") {
      await runInstall({
        foundation: msg.foundation === true,
        semantic: msg.semantic === true,
        textStyles: msg.textStyles === true,
        components: msg.components === true
      });
    } else if (msg.type === "reinstall-clean") {
      await removeInstalledComponents();
    } else if (msg.type === "scan-legacy") {
      await scanLegacyComponents();
    } else if (msg.type === "select-instances") {
      await selectInstancesByIds((_a = msg.nodeIds) != null ? _a : []);
    } else if (msg.type === "swap-components") {
      await swapLegacyComponents((_b = msg.mappings) != null ? _b : []);
    } else if (msg.type.indexOf("audit:") === 0) {
      await handleAuditMessage(msg.type.slice(6), msg.payload);
    } else if (msg.type === "cancel") {
      figma.closePlugin();
    }
  };
  async function handleAuditMessage(type, payload) {
    try {
      if (type === "scan") {
        const res = await audit();
        figma.ui.postMessage({ type: "audit:scan-result", payload: res });
      } else if (type === "select-node") {
        const n = await figma.getNodeByIdAsync(payload.nodeId);
        if (n && "type" in n) {
          figma.currentPage.selection = [n];
          figma.viewport.scrollAndZoomIntoView([n]);
        }
      } else if (type === "apply-one") {
        const ok = await applyOne(payload.issue, payload.suggestionIndex);
        figma.ui.postMessage({ type: "audit:apply-result", payload: { issueId: payload.issue.id, suggestionIndex: payload.suggestionIndex, ok } });
      } else if (type === "apply-high") {
        const count = await applyHighConfidence(payload.issues);
        figma.notify(`${count}\uAC74 \uC790\uB3D9 \uC801\uC6A9 \uC644\uB8CC`);
        figma.ui.postMessage({ type: "audit:apply-high-result", payload: { count } });
      } else if (type === "apply-multi") {
        const res = await applyMulti(payload.picks);
        figma.notify(`${res.ok}\uAC74 \uC801\uC6A9${res.fail ? ` \xB7 ${res.fail}\uAC74 \uC2E4\uD328` : ""}`);
        figma.ui.postMessage({ type: "audit:apply-multi-result", payload: res });
      } else if (type === "set-mode") {
        const res = await setVariablesMode(payload.mode);
        let notify;
        if (res.message) notify = res.message;
        else if (payload.mode === "clear") notify = `${res.cleared || 0}\uAC74 \uBAA8\uB4DC override \uC81C\uAC70 (\uC804\uCCB4 \uCEEC\uB809\uC158 \xB7 \uC790\uC190 \uD3EC\uD568)`;
        else notify = `${res.count}\uAC1C \uB178\uB4DC ${payload.mode} \uBAA8\uB4DC \uC801\uC6A9${res.skipped ? ` \xB7 ${res.skipped}\uAC1C skip` : ""}`;
        figma.notify(notify);
        figma.ui.postMessage({ type: "audit:set-mode-result", payload: __spreadProps(__spreadValues({}, res), { message: notify }) });
      } else if (type === "register-reference") {
        const sel = figma.currentPage.selection;
        if (sel.length === 0) {
          figma.ui.postMessage({ type: "audit:register-reference-result", payload: { ok: false, message: "\uAE30\uC900\uC73C\uB85C \uB4F1\uB85D\uD560 \uD398\uC774\uC9C0/\uD504\uB808\uC784\uC744 \uBA3C\uC800 \uC120\uD0DD\uD558\uC138\uC694" } });
        } else {
          const fileName = figma.root.name || "(unsaved)";
          const all = [];
          const rootNames = [];
          for (const root of sel) {
            rootNames.push(root.name);
            all.push(...collectComponents(root, fileName));
          }
          const dedup = /* @__PURE__ */ new Map();
          for (const c of all) {
            const k = c.name.toLowerCase();
            if (!dedup.has(k)) dedup.set(k, c);
          }
          const pool = Array.from(dedup.values());
          const withoutKey = pool.filter((p) => !p.key).length;
          await saveReference(pool, rootNames, fileName);
          figma.ui.postMessage({ type: "audit:register-reference-result", payload: { ok: true, pool, rootNames, sourceFileName: fileName, withoutKey } });
        }
      } else if (type === "clear-reference") {
        await clearReference();
        figma.ui.postMessage({ type: "audit:reference-cleared" });
      } else if (type === "scan-swap") {
        const res = await scanSwapCandidates(payload.pool || []);
        figma.ui.postMessage({ type: "audit:scan-swap-result", payload: res });
      } else if (type === "build-improved") {
        const res = await buildImprovedCopy();
        if (!res.ok) {
          figma.notify(res.reason);
          figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: false, code: res.code, message: res.reason } });
        } else {
          const node = await figma.getNodeByIdAsync(res.summary.cloneId);
          if (node) {
            figma.currentPage.selection = [node];
            figma.viewport.scrollAndZoomIntoView([node]);
          }
          const s = res.summary;
          let colorIssues = [];
          let colorStats = { scanned: 0, issuesCount: 0, highCount: 0 };
          if (node && "type" in node) {
            const ca = await audit(node);
            colorIssues = ca.issues;
            colorStats = ca.stats;
          }
          figma.notify(`\uAC80\uC218 \uC644\uB8CC \u2014 \uC790\uB3D9\uAD50\uCCB4 ${s.autoSwapped} \xB7 \uD655\uC778\uD544\uC694 ${s.ambiguous}${s.manualNeeded ? ` \xB7 \uC218\uB3D9\uB9E4\uD551 ${s.manualNeeded}` : ""}${s.moduleNeeded ? ` \xB7 \uBAA8\uB4C8 ${s.moduleNeeded}` : ""} \xB7 \uC0C9\uC0C1 ${colorIssues.length}`);
          figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: true, summary: s, candidates: res.ambiguousCandidates, failed: res.failedCandidates, manual: res.manualCandidates, modules: res.modules, colorIssues, colorStats } });
        }
      } else if (type === "apply-swap") {
        const res = await applySwap(payload.candidate, "lenient");
        const unpreservedCount = res.unpreserved ? res.unpreserved.length : 0;
        figma.ui.postMessage({ type: "audit:apply-swap-result", payload: { id: payload.candidate.id, ok: res.ok, result: res.result, reason: res.reason, variantReset: res.variantReset, axisLoss: res.axisLoss, unpreservedCount } });
      } else if (type === "apply-swap-multi") {
        const list = payload.candidates;
        const applied = [];
        const failures = [];
        let resetCount = 0;
        let unpreservedTotal = 0;
        for (const c of list) {
          const r = await applySwap(c, "lenient");
          if (r.ok) {
            applied.push(c.id);
            if (r.variantReset) resetCount++;
            if (r.unpreserved) unpreservedTotal += r.unpreserved.length;
          } else failures.push({ id: c.id, reason: r.reason || "unknown" });
        }
        figma.notify(`${applied.length}\uAC74 \uAD50\uCCB4 \uC644\uB8CC${resetCount ? ` \xB7 ${resetCount}\uAC74 \uC0C1\uD0DC \uB9AC\uC14B` : ""}${unpreservedTotal ? ` \xB7 \uD14D\uC2A4\uD2B8 ${unpreservedTotal}\uAC74 \uBCF4\uC874\uC548\uB428` : ""}${failures.length ? ` \xB7 ${failures.length}\uAC74 \uC2E4\uD328` : ""}`);
        figma.ui.postMessage({ type: "audit:apply-swap-multi-result", payload: { applied, fail: failures.length, failures, variantResetCount: resetCount, unpreservedTotal } });
      } else if (type === "resize") {
        const w = Math.max(420, Math.min(1400, Math.round(payload.w)));
        const h = Math.max(480, Math.min(1200, Math.round(payload.h)));
        figma.ui.resize(w, h);
      }
    } catch (e) {
      const message = String(e && e.message || e);
      if (type === "build-improved") {
        figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: false, message } });
      }
      figma.ui.postMessage({ type: "audit:error", payload: { message } });
    }
  }
  (async () => {
    const saved = await loadReference();
    if (saved) {
      figma.ui.postMessage({ type: "audit:reference-loaded", payload: { pool: saved.pool, rootNames: saved.rootNames, sourceFileName: saved.sourceFileName, restored: true } });
    }
  })();
  function hexToRgb(hex) {
    const n = parseInt(hex.replace("#", ""), 16);
    return {
      r: (n >> 16 & 255) / 255,
      g: (n >> 8 & 255) / 255,
      b: (n & 255) / 255,
      a: 1
    };
  }
  function rgbaStringToRgb(rgba) {
    const m = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return { r: 0, g: 0, b: 0, a: 1 };
    return {
      r: parseInt(m[1]) / 255,
      g: parseInt(m[2]) / 255,
      b: parseInt(m[3]) / 255,
      a: m[4] !== void 0 ? parseFloat(m[4]) : 1
    };
  }
  function post(type, payload) {
    figma.ui.postMessage(__spreadValues({ type }, payload));
  }
  async function getOrCreateCollection(name) {
    const all = await figma.variables.getLocalVariableCollectionsAsync();
    const existing = all.find((c) => c.name === name);
    if (existing) return existing;
    return figma.variables.createVariableCollection(name);
  }
  async function getOrCreateVariable(name, collection, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const existing = all.find(
      (v) => v.name === name && v.variableCollectionId === collection.id
    );
    if (existing) return existing;
    return figma.variables.createVariable(name, collection, resolvedType);
  }
  async function pruneCollection(collection, validNames, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const removed = [];
    for (const v of all) {
      if (v.variableCollectionId !== collection.id) continue;
      if (validNames.has(v.name)) continue;
      removed.push(v.name);
      try {
        v.remove();
      } catch (e) {
      }
    }
    return removed;
  }
  function ensureMode(collection, modeName) {
    const found = collection.modes.find((m) => m.name === modeName);
    if (found) return found.modeId;
    return collection.addMode(modeName);
  }
  function setupLightDarkModes(collection) {
    const first = collection.modes[0];
    if (first.name !== LIGHT_MODE && first.name !== DARK_MODE) {
      collection.renameMode(first.modeId, LIGHT_MODE);
    }
    const lightId = ensureMode(collection, LIGHT_MODE);
    const darkId = ensureMode(collection, DARK_MODE);
    const allowed = /* @__PURE__ */ new Set([lightId, darkId]);
    const extras = collection.modes.filter((m) => !allowed.has(m.modeId));
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return { lightId, darkId };
  }
  function colorScopes(path) {
    if (/^color\/[a-z-]+\/bg\//.test(path)) return ["FRAME_FILL", "SHAPE_FILL"];
    if (/^color\/[a-z-]+\/border\//.test(path)) return ["STROKE_COLOR"];
    if (/^color\/[a-z-]+\/label\//.test(path)) return ["TEXT_FILL"];
    if (/^color\/[a-z-]+\/icon\//.test(path)) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/bg/") || path.startsWith("color/surface/")) {
      return ["FRAME_FILL", "SHAPE_FILL"];
    }
    if (path.startsWith("color/text/")) return ["TEXT_FILL"];
    if (path.startsWith("color/border/")) return ["STROKE_COLOR"];
    if (path.startsWith("color/icon/")) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/action/")) return ["FRAME_FILL", "SHAPE_FILL", "TEXT_FILL"];
    if (path.startsWith("color/status/")) return ["FRAME_FILL", "TEXT_FILL", "STROKE_COLOR"];
    if (path === "color/overlay") return ["FRAME_FILL"];
    return ["ALL_SCOPES"];
  }
  function numberScopes(path) {
    if (path.startsWith("spacing/")) return ["GAP"];
    if (path.startsWith("sizing/")) return ["WIDTH_HEIGHT"];
    if (path.startsWith("radius/")) return ["CORNER_RADIUS"];
    if (path.startsWith("border-width/")) return ["STROKE_FLOAT"];
    if (path.startsWith("font-size/")) return ["FONT_SIZE"];
    if (path.startsWith("font-weight/")) return ["FONT_WEIGHT"];
    if (path.startsWith("line-height/")) return ["LINE_HEIGHT"];
    return ["ALL_SCOPES"];
  }
  function resolveColorRef(ref, foundationColorMap) {
    if (ref.startsWith("rgba")) return rgbaStringToRgb(ref);
    if (ref.startsWith("#")) return hexToRgb(ref);
    const target = foundationColorMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation color alias not found: ${ref}`);
      return { r: 1, g: 0, b: 1, a: 1 };
    }
    return figma.variables.createVariableAlias(target);
  }
  function resolveNumberRef(ref, foundationNumberMap) {
    if (typeof ref === "number") return ref;
    const target = foundationNumberMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation number alias not found: ${ref}`);
      return 0;
    }
    return figma.variables.createVariableAlias(target);
  }
  function setupSingleMode(collection, modeName) {
    const first = collection.modes[0];
    if (first.name !== modeName) {
      collection.renameMode(first.modeId, modeName);
    }
    const extras = collection.modes.filter((m) => m.modeId !== first.modeId);
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return first.modeId;
  }
  async function loadExistingVarMap(collectionName, resolvedType) {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const col = cols.find((c) => c.name === collectionName);
    const map = {};
    if (!col) return map;
    const vars = await figma.variables.getLocalVariablesAsync(resolvedType);
    for (const v of vars) {
      if (v.variableCollectionId === col.id) map[v.name] = v;
    }
    return map;
  }
  async function installFoundation() {
    post("progress", { step: "Foundation collection \uC900\uBE44 \uC911\u2026", pct: 3 });
    const fc = await getOrCreateCollection(FOUNDATION_COLLECTION);
    const fDefaultId = setupSingleMode(fc, "Default");
    const colorMap = {};
    const fcColorKeys = Object.keys(FOUNDATION_COLOR);
    for (let i = 0; i < fcColorKeys.length; i++) {
      const path = fcColorKeys[i];
      const v = await getOrCreateVariable(path, fc, "COLOR");
      v.setValueForMode(fDefaultId, hexToRgb(FOUNDATION_COLOR[path]));
      v.scopes = colorScopes(path);
      colorMap[path] = v;
      if (i % 20 === 0) {
        post("progress", { step: `Foundation Color: ${path}`, pct: 3 + Math.round(i / fcColorKeys.length * 22) });
      }
    }
    const removedColor = await pruneCollection(fc, new Set(fcColorKeys), "COLOR");
    post("progress", { step: "Foundation Number \uC900\uBE44 \uC911\u2026", pct: 28 });
    const numberMap = {};
    const fcNumberKeys = Object.keys(FOUNDATION_NUMBER);
    for (let i = 0; i < fcNumberKeys.length; i++) {
      const path = fcNumberKeys[i];
      const v = await getOrCreateVariable(path, fc, "FLOAT");
      v.setValueForMode(fDefaultId, FOUNDATION_NUMBER[path]);
      v.scopes = numberScopes(path);
      numberMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Foundation Number: ${path}`, pct: 28 + Math.round(i / fcNumberKeys.length * 15) });
      }
    }
    const removedNumber = await pruneCollection(fc, new Set(fcNumberKeys), "FLOAT");
    return {
      colorMap,
      numberMap,
      removed: [...removedColor, ...removedNumber],
      count: fcColorKeys.length + fcNumberKeys.length
    };
  }
  async function installSemantic(foundationColorMap, foundationNumberMap) {
    post("progress", { step: "Semantic Color collection \uC900\uBE44 \uC911\u2026", pct: 50 });
    const scc = await getOrCreateCollection(SEMANTIC_COLOR_COLLECTION);
    const { lightId: sLightId, darkId: sDarkId } = setupLightDarkModes(scc);
    const scColorKeys = Object.keys(SEMANTIC_COLOR);
    const semanticColorMap = {};
    for (let i = 0; i < scColorKeys.length; i++) {
      const path = scColorKeys[i];
      const entry = SEMANTIC_COLOR[path];
      const v = await getOrCreateVariable(path, scc, "COLOR");
      v.setValueForMode(sLightId, resolveColorRef(entry.light, foundationColorMap));
      v.setValueForMode(sDarkId, resolveColorRef(entry.dark, foundationColorMap));
      v.scopes = colorScopes(path);
      semanticColorMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Color: ${path}`, pct: 50 + Math.round(i / scColorKeys.length * 22) });
      }
    }
    const removedSemanticColor = await pruneCollection(scc, new Set(scColorKeys), "COLOR");
    post("progress", { step: "Semantic Number collection \uC900\uBE44 \uC911\u2026", pct: 73 });
    const scn = await getOrCreateCollection(SEMANTIC_NUMBER_COLLECTION);
    const scnDefaultId = setupSingleMode(scn, "Default");
    const scNumberKeys = Object.keys(SEMANTIC_NUMBER);
    for (let i = 0; i < scNumberKeys.length; i++) {
      const path = scNumberKeys[i];
      const v = await getOrCreateVariable(path, scn, "FLOAT");
      v.setValueForMode(scnDefaultId, resolveNumberRef(SEMANTIC_NUMBER[path], foundationNumberMap));
      v.scopes = numberScopes(path);
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Number: ${path}`, pct: 73 + Math.round(i / scNumberKeys.length * 13) });
      }
    }
    const removedSemanticNumber = await pruneCollection(scn, new Set(scNumberKeys), "FLOAT");
    return {
      semanticColorMap,
      scc,
      lightModeId: sLightId,
      darkModeId: sDarkId,
      removed: [...removedSemanticColor, ...removedSemanticNumber],
      count: scColorKeys.length + scNumberKeys.length
    };
  }
  var SHADOW_TOKENS_WITH_VARS = ["shadow/raised"];
  async function installShadow() {
    post("progress", { step: "Semantic Shadow collection \uC900\uBE44 \uC911\u2026", pct: 86 });
    const col = await getOrCreateCollection(SEMANTIC_SHADOW_COLLECTION);
    const { lightId, darkId } = setupLightDarkModes(col);
    const map = {};
    const validColor = /* @__PURE__ */ new Set();
    const validFloat = /* @__PURE__ */ new Set();
    for (const token of SHADOW_TOKENS_WITH_VARS) {
      const entry = SEMANTIC_SHADOW[token];
      if (!entry) throw new Error(`[installShadow] SEMANTIC_SHADOW \uC5D0 '${token}' \uC774 \uC5C6\uC2B5\uB2C8\uB2E4.`);
      const light = parseCssShadow(entry.light);
      const dark = parseCssShadow(entry.dark);
      if (light.length !== dark.length) {
        throw new Error(
          `[installShadow] '${token}' \uC758 \uB77C\uC774\uD2B8(${light.length}\uACB9)\uC640 \uB2E4\uD06C(${dark.length}\uACB9) \uACB9 \uC218\uAC00 \uB2E4\uB985\uB2C8\uB2E4. Figma \uB294 \uACB9 \uC218\uB97C \uBAA8\uB4DC\uB85C \uBC14\uAFC0 \uC218 \uC5C6\uC73C\uBBC0\uB85C \uC591\uCABD\uC744 \uAC19\uAC8C \uB9DE\uCDB0\uC57C \uD569\uB2C8\uB2E4.`
        );
      }
      for (let i = 0; i < light.length; i++) {
        const colorName = shadowVarName(token, i, "color");
        const cv = await getOrCreateVariable(colorName, col, "COLOR");
        cv.setValueForMode(lightId, light[i].color);
        cv.setValueForMode(darkId, dark[i].color);
        cv.scopes = ["EFFECT_COLOR"];
        map[colorName] = cv;
        validColor.add(colorName);
        const floatFields = [
          ["offset-y", "offsetY"],
          ["blur", "blur"],
          ["spread", "spread"]
        ];
        for (const [suffix, key] of floatFields) {
          const name = shadowVarName(token, i, suffix);
          const fv = await getOrCreateVariable(name, col, "FLOAT");
          fv.setValueForMode(lightId, light[i][key]);
          fv.setValueForMode(darkId, dark[i][key]);
          fv.scopes = ["EFFECT_FLOAT"];
          map[name] = fv;
          validFloat.add(name);
        }
      }
    }
    const removedColor = await pruneCollection(col, validColor, "COLOR");
    const removedFloat = await pruneCollection(col, validFloat, "FLOAT");
    return {
      shadowVarMap: map,
      removed: [...removedColor, ...removedFloat],
      count: Object.keys(map).length
    };
  }
  async function loadExistingSemantic() {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const scc = cols.find((c) => c.name === SEMANTIC_COLOR_COLLECTION);
    if (!scc) return null;
    const light = scc.modes.find((m) => m.name === LIGHT_MODE);
    const dark = scc.modes.find((m) => m.name === DARK_MODE);
    const lightModeId = light ? light.modeId : scc.modes[0].modeId;
    const darkModeId = dark ? dark.modeId : lightModeId;
    const semanticColorMap = await loadExistingVarMap(SEMANTIC_COLOR_COLLECTION, "COLOR");
    return { semanticColorMap, scc, lightModeId, darkModeId };
  }
  async function runInstall(sel) {
    try {
      if (!sel.foundation && !sel.semantic && !sel.textStyles && !sel.components) {
        throw new Error("\uC124\uCE58\uD560 \uD56D\uBAA9\uC744 \uD558\uB098 \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694.");
      }
      post("progress", { step: "\uC900\uBE44 \uC911\u2026", pct: 2 });
      const removedAll = [];
      let foundationCount = 0;
      let semanticCount = 0;
      let textStyleCount = 0;
      let componentCount = 0;
      let componentAdded = [];
      let componentSkipped = [];
      let foundationColorMap = {};
      let foundationNumberMap = {};
      if (sel.foundation) {
        const r = await installFoundation();
        foundationColorMap = r.colorMap;
        foundationNumberMap = r.numberMap;
        foundationCount = r.count;
        removedAll.push(...r.removed);
      } else if (sel.semantic || sel.components) {
        foundationColorMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "COLOR");
        foundationNumberMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "FLOAT");
      }
      let semanticColorMap = {};
      let scc = null;
      let lightModeId = "";
      let darkModeId = "";
      if (sel.semantic) {
        if (Object.keys(foundationColorMap).length === 0) {
          throw new Error("Semantic \uC124\uCE58\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        const r = await installSemantic(foundationColorMap, foundationNumberMap);
        semanticColorMap = r.semanticColorMap;
        scc = r.scc;
        lightModeId = r.lightModeId;
        darkModeId = r.darkModeId;
        semanticCount = r.count;
        removedAll.push(...r.removed);
      } else if (sel.components) {
        const loaded = await loadExistingSemantic();
        if (loaded) {
          semanticColorMap = loaded.semanticColorMap;
          scc = loaded.scc;
          lightModeId = loaded.lightModeId;
          darkModeId = loaded.darkModeId;
        }
      }
      let shadowVarMap = {};
      let shadowCollectionId = "";
      let shadowLightModeId = "";
      let shadowDarkModeId = "";
      if (sel.semantic || sel.components) {
        if (sel.semantic) {
          const r = await installShadow();
          shadowVarMap = r.shadowVarMap;
          semanticCount += r.count;
          removedAll.push(...r.removed);
        } else {
          const sColor = await loadExistingVarMap(SEMANTIC_SHADOW_COLLECTION, "COLOR");
          const sFloat = await loadExistingVarMap(SEMANTIC_SHADOW_COLLECTION, "FLOAT");
          shadowVarMap = __spreadValues(__spreadValues({}, sColor), sFloat);
        }
        const shadowCol = (await figma.variables.getLocalVariableCollectionsAsync()).find((c) => c.name === SEMANTIC_SHADOW_COLLECTION);
        if (shadowCol) {
          shadowCollectionId = shadowCol.id;
          const l = shadowCol.modes.find((m) => m.name === LIGHT_MODE);
          const d = shadowCol.modes.find((m) => m.name === DARK_MODE);
          shadowLightModeId = l ? l.modeId : shadowCol.modes[0].modeId;
          shadowDarkModeId = d ? d.modeId : shadowLightModeId;
        }
      }
      let textStyleMap = {};
      if (sel.textStyles || sel.components) {
        post("progress", { step: "Text Styles \uC124\uCE58 \uC911\u2026", pct: 88 });
        textStyleMap = await installTextStyles((step, pct) => post("progress", { step, pct }), 88, 94);
        textStyleCount = Object.keys(textStyleMap).length;
      }
      if (sel.components) {
        if (!scc || !lightModeId) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Semantic Color V2 \uAC00 \uD544\uC694\uD569\uB2C8\uB2E4. Semantic \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        if (Object.keys(foundationNumberMap).length === 0) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        post("progress", { step: "\uCEF4\uD3EC\uB10C\uD2B8 \uC0DD\uC131 \uC911\u2026", pct: 92 });
        const compResult = await buildAllComponents(
          {
            semanticColor: semanticColorMap,
            foundationColor: foundationColorMap,
            foundationNumber: foundationNumberMap,
            textStyles: textStyleMap,
            semanticColorCollectionId: scc.id,
            semanticLightModeId: lightModeId,
            semanticDarkModeId: darkModeId,
            shadowVars: shadowVarMap,
            semanticShadowCollectionId: shadowCollectionId || void 0,
            semanticShadowLightModeId: shadowLightModeId || void 0,
            semanticShadowDarkModeId: shadowDarkModeId || void 0
          },
          (step, pct) => post("progress", { step, pct })
        );
        componentCount = compResult.created;
        componentAdded = compResult.added;
        componentSkipped = compResult.skipped;
      }
      post("progress", { step: "\uC644\uB8CC", pct: 100 });
      post("done", {
        foundationCount,
        semanticCount,
        textStyleCount,
        componentCount,
        componentAdded,
        componentSkipped,
        removedCount: removedAll.length,
        removedNames: removedAll
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: msg });
    }
  }
  async function removeInstalledComponents() {
    try {
      const page = figma.currentPage;
      const total = COMPONENT_CATEGORIES.length;
      let removedSections = 0;
      for (let i = 0; i < total; i++) {
        const cat = COMPONENT_CATEGORIES[i];
        post("progress", { step: `${cat.name} \uC0AD\uC81C \uC911\u2026`, pct: Math.round((i + 1) / (total + 1) * 100) });
        await new Promise((r) => setTimeout(r, 0));
        let found = [];
        try {
          const r = page.findAll((n) => n.type === "SECTION" && n.name === cat.name);
          if (Array.isArray(r)) found = r;
        } catch (e) {
        }
        for (const n of found) {
          try {
            n.remove();
            removedSections++;
          } catch (e) {
          }
        }
      }
      post("progress", { step: "\uB0A8\uC740 \uB178\uB4DC \uC815\uB9AC \uC911\u2026", pct: 100 });
      await new Promise((r) => setTimeout(r, 0));
      const names = /* @__PURE__ */ new Set();
      for (const cat of COMPONENT_CATEGORIES) {
        for (const m of cat.members) {
          names.add(m);
          names.add(`${m} \u2014 Spec Light`);
          names.add(`${m} \u2014 Spec Dark`);
        }
      }
      let removedTopLevel = 0;
      let topNodes = [];
      try {
        if (Array.isArray(page.children)) topNodes = page.children.slice();
      } catch (e) {
      }
      for (const n of topNodes) {
        if (!names.has(n.name)) continue;
        try {
          n.remove();
          removedTopLevel++;
        } catch (e) {
        }
      }
      post("clean-done", { removedSections, removedTopLevel });
      if (removedSections + removedTopLevel > 0) {
        figma.notify(`\uAE30\uC874 \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uC0AD\uC81C\uD588\uC2B5\uB2C8\uB2E4(\uC139\uC158 ${removedSections}\uAC1C) \u2014 [\uC120\uD0DD \uD56D\uBAA9 \uC124\uCE58]\uB85C \uB2E4\uC2DC \uC124\uCE58\uD558\uC138\uC694.`);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: `\uC7AC\uC124\uCE58 \uC900\uBE44(\uC0AD\uC81C) \uC911 \uC624\uB958: ${msg}` });
    }
  }
  function nameSimilarity(a, b) {
    const tok = (s) => s.toLowerCase().replace(/[^a-z0-9가-힣]/g, " ").split(/\s+/).filter(Boolean);
    const tA = new Set(tok(a));
    const tB = new Set(tok(b));
    if (tA.size === 0 || tB.size === 0) return 0;
    let matches = 0;
    tA.forEach((t) => {
      if (tB.has(t)) matches++;
    });
    return matches / Math.max(tA.size, tB.size);
  }
  async function scanLegacyComponents() {
    var _a;
    try {
      post("progress", { step: "\uD604\uC7AC \uD398\uC774\uC9C0 \uC778\uC2A4\uD134\uC2A4 \uC2A4\uCE94 \uC911\u2026", pct: 10 });
      const page = figma.currentPage;
      const allInstances = page.findAll((n) => n.type === "INSTANCE");
      const remoteMap = /* @__PURE__ */ new Map();
      let scanned = 0;
      for (const inst of allInstances) {
        const main = await inst.getMainComponentAsync();
        scanned++;
        if (scanned % 20 === 0) {
          post("progress", {
            step: `${scanned}/${allInstances.length} \uC778\uC2A4\uD134\uC2A4 \uD655\uC778 \uC911\u2026`,
            pct: 10 + Math.floor(scanned / allInstances.length * 50)
          });
        }
        if (!main || !main.remote) continue;
        const isInSet = ((_a = main.parent) == null ? void 0 : _a.type) === "COMPONENT_SET";
        const key = isInSet ? main.parent.id : main.id;
        const setName = isInSet ? main.parent.name : main.name;
        const entry = remoteMap.get(key);
        if (entry) {
          entry.count++;
          entry.nodeIds.push(inst.id);
        } else {
          remoteMap.set(key, { setName, count: 1, nodeIds: [inst.id] });
        }
      }
      post("progress", { step: "\uB85C\uCEEC \uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC218\uC9D1 \uC911\u2026", pct: 65 });
      const localSets = figma.root.findAll((n) => n.type === "COMPONENT_SET").map((n) => ({ id: n.id, name: n.name }));
      const AUTO_THRESHOLD = 0.6;
      const remoteList = Array.from(remoteMap.entries()).map(([oldId, data]) => {
        var _a2, _b;
        const suggestions = localSets.map((s) => ({ id: s.id, name: s.name, score: nameSimilarity(data.setName, s.name) })).sort((a, b) => b.score - a.score).slice(0, 3);
        const autoMatchId = ((_b = (_a2 = suggestions[0]) == null ? void 0 : _a2.score) != null ? _b : 0) >= AUTO_THRESHOLD ? suggestions[0].id : null;
        return {
          oldId,
          oldName: data.setName,
          count: data.count,
          nodeIds: data.nodeIds,
          suggestions,
          autoMatchId
        };
      });
      post("scan-result", {
        remoteList,
        localSets,
        totalScanned: allInstances.length,
        remoteCount: remoteList.reduce((s, r) => s + r.count, 0)
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: msg });
    }
  }
  async function selectInstancesByIds(nodeIds) {
    const nodes = [];
    for (const id of nodeIds) {
      const node = await figma.getNodeByIdAsync(id);
      if (node) nodes.push(node);
    }
    if (nodes.length > 0) {
      figma.currentPage.selection = nodes;
      figma.viewport.scrollAndZoomIntoView(nodes);
    }
  }
  async function swapLegacyComponents(mappings) {
    var _a;
    try {
      if (mappings.length === 0) {
        post("swap-done", { swapped: 0, failed: 0, skipped: 0 });
        return;
      }
      const mappingMap = new Map(mappings.map((m) => [m.oldId, m.newSetId]));
      const page = figma.currentPage;
      const allInstances = page.findAll((n) => n.type === "INSTANCE");
      let swapped = 0, failed = 0, skipped = 0;
      for (let i = 0; i < allInstances.length; i++) {
        const inst = allInstances[i];
        const main = await inst.getMainComponentAsync();
        if (!main || !main.remote) continue;
        const newSetId = mappingMap.get(main.id);
        if (!newSetId) {
          skipped++;
          continue;
        }
        const newSet = await figma.getNodeByIdAsync(newSetId);
        if (!newSet || newSet.type !== "COMPONENT_SET") {
          failed++;
          continue;
        }
        const currentProps = (_a = inst.componentProperties) != null ? _a : {};
        let target = null;
        for (const child of newSet.children) {
          if (child.type !== "COMPONENT") continue;
          if (!target) target = child;
          const variantMatch = Object.entries(currentProps).every(([k, v]) => {
            return child.name.includes(`${k}=${v.value}`);
          });
          if (variantMatch) {
            target = child;
            break;
          }
        }
        if (!target) {
          failed++;
          continue;
        }
        try {
          inst.swapComponent(target);
          swapped++;
        } catch (e) {
          failed++;
        }
        if (i % 10 === 0) {
          post("progress", { step: `${swapped}\uAC1C \uAD50\uCCB4\uB428\u2026`, pct: 10 + Math.floor(i / allInstances.length * 80) });
        }
      }
      post("swap-done", { swapped, failed, skipped });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: msg });
    }
  }
})();
