"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));

  // plugins/figma-vars-installer/src/vars-data.ts
  var FOUNDATION_COLLECTION = "Foundation V2";
  var SEMANTIC_COLOR_COLLECTION = "Semantic Color V2";
  var SEMANTIC_NUMBER_COLLECTION = "Semantic Number V2";
  var SEMANTIC_SHADOW_COLLECTION = "Semantic Shadow V2";
  var LIGHT_MODE = "Light";
  var DARK_MODE = "Dark";
  var FOUNDATION_COLOR = {
    // ── Base ──────────────────────────────────────────
    "base/white": "#FFFFFF",
    "base/black": "#000000",
    // 모바일 Home 화면 전용 배경. 어느 스케일에도 속하지 않는 단독 색이라 base 에 둔다
    // (gray 계열이 아니다 — 색상각 230° 남보라빛, visual-gray 210° 청록과 계열이 다름).
    // 출처: V2.4 mobile_header 원본 surface/base-background/home. river 승인 2026-08-25.
    "base/home-bg": "#F5F6FB",
    // ── Brand ─────────────────────────────────────────
    "brand/blue": "#0072CE",
    "brand/red": "#FF312C",
    "brand/gray": "#DFDEDE",
    "brand/ci": "#004097",
    // ── Gray (Light scale) ────────────────────────────
    "gray/0": "#FAFAFA",
    "gray/50": "#F5F5F5",
    "gray/100": "#E9E9E9",
    "gray/200": "#D9D9D9",
    "gray/300": "#C4C4C4",
    "gray/400": "#9D9D9D",
    "gray/500": "#757575",
    "gray/600": "#555555",
    "gray/700": "#434343",
    "gray/800": "#353535",
    "gray/900": "#202020",
    // ── Gray Dark (Dark scale) ────────────────────────
    //
    // ⚠️ Dark 팔레트 스텝 방향 규칙 (필수) — **낮은 숫자 = 더 어두운 색, 높은 숫자 = 더 밝은 색**
    //   Dark 팔레트는 Light 팔레트와 스텝 의미가 **반대**다.
    //     · 낮은 스텝(0·50·100…)  Light=밝음(흰색 근처)  ↔  Dark=**어두움**(배경·심부)
    //     · 높은 스텝(700·800·900) Light=어두움(검정 근처) ↔  Dark=**밝음**(텍스트·하이라이트)
    //   이유: 다크 모드에서 배경은 어두워야 하고 텍스트는 밝아야 한다. Light 의 스텝 방향을
    //   그대로 따르면 어두운 배경 위에 어두운 텍스트가 올라오는 역전이 생긴다.
    //
    //   새 Dark 팔레트를 추가할 때 확인:
    //     □ step 0/50/100 이 가장 어두운 값인가?
    //     □ 전체 스텝의 70~80% 지점부터 밝아지는가?
    //     □ Semantic 이 배경은 낮은 스텝을, 텍스트는 높은 스텝을 참조하는가?
    //     □ 스텝 값은 원본 그대로인가(반올림·보정 금지)?
    //     □ 새 계열은 gray-dark / blue-dark 를 본떠 낮은 스텝(배경)→높은 스텝(텍스트) 방향으로 정의했는가?
    //
    //   (2026-08-01 이관: 종전 정본은 tokens/foundation.md §"Dark Foundation 스텝 방향 규칙"이었고
    //    그 문서가 아카이브되면서 규칙이 저장소에서 사라질 뻔했다. 값 옆이 규칙의 제자리라 여기로 옮긴다.
    //    사람이 읽는 요약본은 design-narrative.json → DESIGN.md §2 에도 있다.)
    "gray-dark/0": "#0D0E12",
    "gray-dark/50": "#131418",
    "gray-dark/100": "#1C1D23",
    "gray-dark/200": "#24252C",
    "gray-dark/300": "#2E2F38",
    "gray-dark/400": "#35363F",
    "gray-dark/500": "#3E4049",
    "gray-dark/600": "#55575F",
    "gray-dark/700": "#8A8C96",
    "gray-dark/800": "#B8BABF",
    "gray-dark/900": "#ECEDF0",
    // ── Blue ──────────────────────────────────────────
    "blue/50": "#E2F1FF",
    "blue/100": "#C8E4FF",
    "blue/150": "#A4D4FF",
    "blue/200": "#8BC6FF",
    "blue/250": "#5BB2FF",
    "blue/300": "#2B9EFF",
    "blue/350": "#268CF8",
    "blue/400": "#1D6CEB",
    "blue/450": "#2158C8",
    "blue/500": "#2747B9",
    "blue-dark/50": "#0C1D38",
    "blue-dark/100": "#112B55",
    "blue-dark/150": "#1A3D72",
    "blue-dark/200": "#214EA0",
    "blue-dark/250": "#2A65C8",
    "blue-dark/300": "#3070D8",
    "blue-dark/350": "#4285E8",
    "blue-dark/400": "#6FA5F8",
    "blue-dark/450": "#96BEF9",
    "blue-dark/500": "#C0D8FC",
    // ── Red ───────────────────────────────────────────
    "red/50": "#FFEBEF",
    "red/100": "#FFCCD6",
    "red/150": "#FBB2BA",
    "red/200": "#F8979E",
    "red/250": "#FC6E79",
    "red/300": "#FF4554",
    "red/350": "#F22544",
    "red/400": "#E50533",
    "red/450": "#D60228",
    "red/500": "#C8001E",
    "red-dark/50": "#2A0F14",
    "red-dark/100": "#3D1520",
    "red-dark/150": "#5C1E2E",
    "red-dark/200": "#8A2A3E",
    "red-dark/250": "#C03850",
    "red-dark/300": "#E04860",
    "red-dark/350": "#F06070",
    "red-dark/400": "#F48890",
    "red-dark/450": "#F8A8B0",
    "red-dark/500": "#FCD0D5",
    // ── Orange ────────────────────────────────────────
    "orange/50": "#FFEDE0",
    "orange/100": "#FDDBBF",
    "orange/150": "#FEC6A0",
    "orange/200": "#FFB482",
    "orange/250": "#FF954E",
    "orange/300": "#FF761A",
    "orange/350": "#EE680D",
    "orange/400": "#DA4C00",
    "orange/450": "#B63C00",
    "orange/500": "#8E2E00",
    "orange-dark/50": "#2E1505",
    "orange-dark/100": "#42200A",
    "orange-dark/150": "#6B3512",
    "orange-dark/200": "#A05020",
    "orange-dark/250": "#D06828",
    "orange-dark/300": "#E88038",
    "orange-dark/350": "#F09548",
    "orange-dark/400": "#F5AA68",
    "orange-dark/450": "#F8C090",
    "orange-dark/500": "#FCD8B8",
    // ── Yellow ────────────────────────────────────────
    "yellow/50": "#FFF4CE",
    "yellow/100": "#FEE89A",
    "yellow/150": "#FEDE6C",
    "yellow/200": "#FFD53D",
    "yellow/250": "#FFCC1E",
    "yellow/300": "#FFC200",
    "yellow/350": "#F5B900",
    "yellow/400": "#DBA400",
    "yellow/450": "#BA8900",
    "yellow/500": "#8F6A00",
    "yellow-dark/50": "#2A2005",
    "yellow-dark/100": "#3D2E08",
    "yellow-dark/150": "#605010",
    "yellow-dark/200": "#907818",
    "yellow-dark/250": "#C09828",
    "yellow-dark/300": "#D8B038",
    "yellow-dark/350": "#E8C048",
    "yellow-dark/400": "#F0D068",
    "yellow-dark/450": "#F5DE90",
    "yellow-dark/500": "#FAEAB8",
    // ── Green ─────────────────────────────────────────
    "green/50": "#E3F2EA",
    "green/100": "#CAECDA",
    "green/150": "#9CD8BD",
    "green/200": "#6FC4A2",
    "green/250": "#47BB8E",
    "green/300": "#1FB279",
    "green/350": "#10A86C",
    "green/400": "#009E5E",
    "green/450": "#008650",
    "green/500": "#006F42",
    "green-dark/50": "#0A2018",
    "green-dark/100": "#102E22",
    "green-dark/150": "#184530",
    "green-dark/200": "#206840",
    "green-dark/250": "#288A55",
    "green-dark/300": "#30A868",
    "green-dark/350": "#3FBE7E",
    "green-dark/400": "#68D098",
    "green-dark/450": "#98E0B8",
    "green-dark/500": "#C5F0D8",
    // ── Skyblue ───────────────────────────────────────
    "skyblue/50": "#C4EEF7",
    "skyblue/100": "#A5E5F3",
    "skyblue/150": "#7BD6EA",
    "skyblue/200": "#51C7E1",
    "skyblue/250": "#3BC0DD",
    "skyblue/300": "#25B9DA",
    "skyblue/350": "#1DAACB",
    "skyblue/400": "#159BBC",
    "skyblue/450": "#1284A0",
    "skyblue/500": "#0F6C84",
    "skyblue-dark/50": "#081E28",
    "skyblue-dark/100": "#102A38",
    "skyblue-dark/150": "#184050",
    "skyblue-dark/200": "#205A70",
    "skyblue-dark/250": "#287890",
    "skyblue-dark/300": "#3090A8",
    "skyblue-dark/350": "#40A8C0",
    "skyblue-dark/400": "#68C0D8",
    "skyblue-dark/450": "#98D8E8",
    "skyblue-dark/500": "#C0E8F0",
    // ── Purple ────────────────────────────────────────
    "purple/50": "#E8E9FC",
    "purple/100": "#CFD1F9",
    "purple/150": "#C0C0FC",
    "purple/200": "#B0B0FF",
    "purple/250": "#8B8BEE",
    "purple/300": "#6666DD",
    "purple/350": "#4E4EC3",
    "purple/400": "#3535A8",
    "purple/450": "#2D2D8F",
    "purple/500": "#252576",
    "purple-dark/50": "#14142A",
    "purple-dark/100": "#1E1E3D",
    "purple-dark/150": "#2A2A58",
    "purple-dark/200": "#383878",
    "purple-dark/250": "#4848A0",
    "purple-dark/300": "#5858B8",
    "purple-dark/350": "#7070D0",
    "purple-dark/400": "#9090E0",
    "purple-dark/450": "#B0B0EA",
    "purple-dark/500": "#D0D0F5",
    // ── Brown ─────────────────────────────────────────
    "brown/50": "#F6EEE9",
    "brown/100": "#E4D5C8",
    "brown/150": "#DBC6B3",
    "brown/200": "#D1B69F",
    "brown/250": "#A68C75",
    "brown/300": "#7C614A",
    "brown/350": "#685240",
    "brown/400": "#554435",
    "brown/450": "#483A2D",
    "brown/500": "#3B3025",
    "brown-dark/50": "#1E1610",
    "brown-dark/100": "#2A2018",
    "brown-dark/150": "#3D3025",
    "brown-dark/200": "#584535",
    "brown-dark/250": "#786050",
    "brown-dark/300": "#907868",
    "brown-dark/350": "#A89080",
    "brown-dark/400": "#C0A898",
    "brown-dark/450": "#D8C0B0",
    "brown-dark/500": "#E8D8C8",
    // ── Visual Gray (Light 전용 스케일) ───────────────
    "visual-gray/50": "#F3F5F7",
    "visual-gray/100": "#E8EBEF",
    "visual-gray/150": "#DADEE5",
    "visual-gray/200": "#CDD2DE",
    "visual-gray/250": "#ABB2BF",
    "visual-gray/300": "#808796",
    "visual-gray/350": "#646A74",
    "visual-gray/400": "#3E4347",
    "visual-gray/450": "#2B2F32",
    "visual-gray/500": "#1B1D1F",
    // ── Cool Gray Dark (Dark 전용 스케일) ─────────────
    "visual-gray-dark/50": "#12141A",
    "visual-gray-dark/100": "#1A1D25",
    "visual-gray-dark/150": "#252830",
    "visual-gray-dark/200": "#353840",
    "visual-gray-dark/250": "#484C58",
    "visual-gray-dark/300": "#606470",
    "visual-gray-dark/350": "#787C88",
    "visual-gray-dark/400": "#989CA8",
    "visual-gray-dark/450": "#B8BCC5",
    "visual-gray-dark/500": "#D8DBE0"
  };
  var FOUNDATION_NUMBER = {
    // ── Spacing ─────────────────────────────
    "spacing/2": 2,
    "spacing/4": 4,
    "spacing/6": 6,
    "spacing/8": 8,
    "spacing/10": 10,
    "spacing/12": 12,
    "spacing/14": 14,
    "spacing/16": 16,
    "spacing/20": 20,
    "spacing/24": 24,
    "spacing/28": 28,
    "spacing/32": 32,
    "spacing/36": 36,
    "spacing/40": 40,
    "spacing/44": 44,
    "spacing/48": 48,
    "spacing/56": 56,
    "spacing/64": 64,
    "spacing/80": 80,
    "spacing/96": 96,
    "spacing/128": 128,
    // ── Radius ──────────────────────────────
    "radius/0": 0,
    "radius/2": 2,
    "radius/4": 4,
    "radius/6": 6,
    "radius/8": 8,
    "radius/10": 10,
    "radius/12": 12,
    "radius/16": 16,
    "radius/20": 20,
    "radius/full": 9999,
    // ── Border Width ───────────────────────
    "border-width/1": 1,
    "border-width/2": 2,
    // ── Font Size ──────────────────────────
    "font-size/10": 10,
    "font-size/12": 12,
    "font-size/14": 14,
    "font-size/16": 16,
    "font-size/18": 18,
    "font-size/20": 20,
    "font-size/24": 24,
    "font-size/32": 32,
    // ── Font Weight ────────────────────────
    "font-weight/regular": 400,
    "font-weight/medium": 500,
    "font-weight/bold": 700,
    // ── Line Height (배수) ─────────────────
    "line-height/130": 1.3,
    "line-height/140": 1.4,
    // ── Sizing (Foundation primitive — 컴포넌트 높이·치수) ──
    "sizing/10": 10,
    "sizing/16": 16,
    "sizing/18": 18,
    "sizing/20": 20,
    "sizing/24": 24,
    "sizing/28": 28,
    "sizing/30": 30,
    "sizing/32": 32,
    "sizing/34": 34,
    "sizing/38": 38,
    "sizing/40": 40,
    "sizing/44": 44,
    "sizing/48": 48,
    "sizing/56": 56,
    "sizing/60": 60,
    "sizing/64": 64,
    "sizing/80": 80,
    "sizing/128": 128,
    // ── Opacity ──
    "opacity/0": 0,
    "opacity/25": 0.25,
    "opacity/50": 0.5,
    "opacity/75": 0.75,
    "opacity/100": 1,
    // ── Breakpoint (px) ──
    "breakpoint/xs": 320,
    "breakpoint/sm": 600,
    "breakpoint/md": 768,
    "breakpoint/lg": 1024,
    "breakpoint/xl": 1280,
    "breakpoint/2xl": 1440
  };
  var SEMANTIC_SHADOW = {
    // 딤 위에 떠있는 패널(Modal). 라이트·다크 **모두 2겹** — 겹 수는 테마가 아니라 표면 위계를 나타낸다.
    //   양쪽 겹 수를 맞춘 이유: Figma 는 그림자 겹 수를 변수 모드로 바꿀 수 없다. 겹 수가 같아야
    //   겹당 속성(색·offset·blur·spread)을 변수에 바인딩해 모드 전환을 표현할 수 있다.
    //   테마 차이는 겹 수가 아니라 alpha 와 기하다(라이트 .06/.10 · 다크 1.0).
    "shadow/raised": { light: "0 4px 6px -2px rgba(0,0,0,0.06), 0 12px 20px -4px rgba(0,0,0,0.10)", dark: "0 8px 8px -4px rgba(0,0,0,1), 0 20px 24px -4px rgba(0,0,0,1)" },
    // 하단에서 올라오는 표면(Bottom Sheet). y 부호가 반전된다.
    // TODO(shadow-dark): 미확정. Figma 다크 스펙 실측 후 교체 — 지금은 다크에서 그림자가 사라지는 회귀를 막으려 light 값 동일.
    "shadow/raised-up": { light: "0 -4px 16px rgba(0,0,0,0.15)", dark: "0 -4px 16px rgba(0,0,0,0.15)" },
    // 작은 팝오버 패널(Dropdown·Calendar·Time Picker Dropdown). 표면이 작아 blur 8.
    // TODO(shadow-dark): 미확정. Figma 다크 스펙 실측 후 교체 — 지금은 다크에서 그림자가 사라지는 회귀를 막으려 light 값 동일.
    "shadow/dropdown": { light: "0 4px 8px 0 rgba(0,0,0,0.15)", dark: "0 4px 8px 0 rgba(0,0,0,0.15)" }
  };
  var SEMANTIC_COLOR = {
    // ── bg (페이지·레이아웃 배경 — 깊이 스케일) ────
    // level-0(가장 위, 흰/카드) → level-3(가장 깊은 배경). 라이트는 기존 값 보존, 다크는 깊이 위계로 재정렬.
    // (옛 default/subtle/muted/selected, surface/* 는 깊이 스케일로 통합·드롭. bg/selected→테이블 자체 토큰, surface→드롭)
    "color/bg/level-0": { light: "base/white", dark: "gray-dark/0" },
    "color/bg/level-1": { light: "gray/0", dark: "gray-dark/50" },
    "color/bg/level-2": { light: "gray/50", dark: "gray-dark/100" },
    "color/bg/level-3": { light: "gray/100", dark: "gray-dark/200" },
    // home — 모바일 Home 화면 배경. 깊이 스케일(level-*)이 아니라 화면 전용 단일 값이다.
    // river 결정 2026-08-26: 다크에서도 Home 전용 푸른 배경 성격을 유지하도록 blue-dark/50 을 쓴다.
    // 그룹(color/home/*)을 새로 만들지 않고 bg 그룹의 이름 있는 멤버로 둔다.
    "color/bg/home": { light: "base/home-bg", dark: "blue-dark/50" },
    // ── surface (딤 위에 떠있는 패널 표면 — 모달·바텀시트·팝오버 공용) ────
    // bg/level 은 라이트/다크가 고정 쌍이라 "라이트=흰색 + 다크=올라온 회색" 조합을 표현 못 한다.
    // raised = 딤 위 떠있는 패널(모달·바텀시트·팝오버 공용): 라이트 흰색 / 다크 gray-dark/100.
    // 모달 스펙(chip·button 과 동일 raised 패턴)과 일치. 컴포넌트별 전용 토큰 대신 공용 표면.
    // (사용자 결정: 2026-07-03 신설 → 2026-07-06 다크값 gray-dark/400 → gray-dark/100 정정)
    "color/surface/raised": { light: "base/white", dark: "gray-dark/100" },
    // ── button ────────────────────────────────
    "color/button/bg/blue-line--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/blue-line--hover": { light: "blue/50", dark: "blue-dark/50" },
    "color/button/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/button/bg/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/bg/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/bg/secondary--default": { light: "base/white", dark: "gray-dark/100" },
    "color/button/bg/secondary--hover": { light: "gray/50", dark: "gray-dark/200" },
    // assist(보조 버튼) — 레거시 A pc_assist_button(540:4650) 이 **실제로 쓰는 전용 토큰만** 만든다.
    //   원본은 배경(기본·hover)과 테두리(기본)를 secondary 것으로 그대로 빌려 쓰고, 전용 이름은 3개뿐이다:
    //   border/assist--hover · label/assist--default · label/assist--hover.
    //   ⚠️ 2026-09-08 에 ⭐ 가 빈칸 없는 6개 한 벌로 만들었다가 river 결정으로 **원본 구조대로 3개로 줄였다**
    //     ("원본은 3개" 를 알린 뒤 river 가 B(원본 충실)를 선택). 값은 6개였을 때와 한 톨도 다르지 않다 —
    //     지운 3개가 secondary 와 값이 완전히 같았기 때문이다.
    "color/button/border/assist--hover": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/border/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/blue-line--hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/disabled": { light: "gray/200", dark: "gray-dark/300" },
    "color/button/border/primary--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/border/primary--hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/button/border/secondary--default": { light: "gray/200", dark: "gray-dark/500" },
    "color/button/border/secondary--hover": { light: "gray/200", dark: "gray-dark/500" },
    // 보조 버튼 글자 — 라이트는 원본 실측 #757575(gray/500). 다크는 원본에 없어 river 가 결정 화면에서
    //   "한 단계 옅게"(#8A8C96 = gray-dark/700)를 직접 골랐다 — secondary 글자(gray-dark/800)보다 한 단계 옅어
    //   라이트와 같은 위계가 된다.
    "color/button/label/assist--default": { light: "gray/500", dark: "gray-dark/700" },
    "color/button/label/assist--hover": { light: "gray/500", dark: "gray-dark/700" },
    "color/button/label/blue-line--default": { light: "blue/400", dark: "blue-dark/300" },
    "color/button/label/blue-line--hover": { light: "blue/500", dark: "blue-dark/300" },
    "color/button/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/button/label/primary--default": { light: "base/white", dark: "base/white" },
    "color/button/label/primary--hover": { light: "base/white", dark: "base/white" },
    "color/button/label/secondary--default": { light: "gray/800", dark: "gray-dark/800" },
    "color/button/label/secondary--hover": { light: "gray/800", dark: "gray-dark/800" },
    // ── chip ────────────────────────────────
    "color/chip/line/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/line/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/chip/line/bg/selected": { light: "base/white", dark: "gray-dark/100" },
    "color/chip/line/border/default": { light: "gray/300", dark: "gray-dark/500" },
    "color/chip/line/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/chip/line/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    // 화살표(쉐브론) 전용 — 종전에는 label 토큰을 그대로 빌려 썼다. 아이콘은 글자가 아니므로
    //   독립 토큰을 갖는다(river 지시 2026-09-10). 값은 지금 색 그대로 옮겨 화면은 변하지 않는다.
    "color/chip/line/icon/default": { light: "gray/500", dark: "gray-dark/700" },
    "color/chip/line/icon/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/line/label/default": { light: "gray/500", dark: "gray-dark/700" },
    "color/chip/line/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/line/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/chip/solid/bg/default": { light: "gray/50", dark: "gray-dark/300" },
    "color/chip/solid/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/bg/hover": { light: "gray/100", dark: "gray-dark/400" },
    "color/chip/solid/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/bg/selected-hover": { light: "blue/500", dark: "blue-dark/250" },
    "color/chip/solid/border/default": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/chip/solid/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/chip/solid/icon/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/chip/solid/icon/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/solid/icon/selected": { light: "base/white", dark: "base/white" },
    "color/chip/solid/label/default": { light: "gray/800", dark: "gray-dark/700" },
    "color/chip/solid/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/chip/solid/label/selected": { light: "base/white", dark: "base/white" },
    // ── control ────────────────────────────────
    "color/control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/control/bg/disabled": { light: "gray/100", dark: "gray-dark/300" },
    "color/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/control/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/control/border/disabled": { light: "gray/200", dark: "gray-dark/300" },
    "color/control/border/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/control/indicator/selected": { light: "base/white", dark: "base/white" },
    "color/control/indicator/selected-alt": { light: "blue/400", dark: "blue-dark/300" },
    "color/control/indicator/unselected": { light: "gray/300", dark: "gray-dark/400" },
    "color/control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    // ── table (구 data — 2026-06-15 그룹명 변경: data→table, state→cell) ──
    "color/table/border/default": { light: "gray/100", dark: "gray-dark/300" },
    // border/strong = 테이블 세트 외곽 프레임선(상단 2px·하단 1px), #353535(light gray/800·dark gray-dark/700). 셀선(default)과 구분되는 가장 진한 보더.
    //   2026-06-30: 구 border/emphasis 통합·삭제 → strong 으로 일원화(strong 슬롯은 헤더밑줄이 default 로 바뀌며 비어 있었음). 값은 외곽선 #353535 유지.
    "color/table/border/strong": { light: "gray/800", dark: "gray-dark/700" },
    "color/table/header/bg": { light: "gray/0", dark: "gray-dark/200" },
    "color/table/cell/default": { light: "base/white", dark: "gray-dark/100" },
    "color/table/cell/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/table/cell/selected": { light: "blue/50", dark: "blue-dark/100" },
    // ── dropdown ────────────────────────────────
    "color/dropdown/list/bg": { light: "base/white", dark: "gray-dark/100" },
    "color/dropdown/list/border": { light: "gray/200", dark: "gray-dark/500" },
    "color/dropdown/option/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/dropdown/option/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/dropdown/option/bg/selected": { light: "blue/50", dark: "blue-dark/100" },
    "color/dropdown/option/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/dropdown/option/label/hover": { light: "gray/900", dark: "gray-dark/900" },
    "color/dropdown/option/label/selected": { light: "blue/400", dark: "blue-dark/350" },
    // ── form-control ────────────────────────────────
    "color/form-control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/form-control/bg/disabled": { light: "gray/50", dark: "gray-dark/200" },
    "color/form-control/bg/hover": { light: "gray/0", dark: "gray-dark/200" },
    "color/form-control/bg/selected": { light: "base/white", dark: "gray-dark/200" },
    "color/form-control/border/correct": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/form-control/border/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/form-control/border/error": { light: "red/300", dark: "red-dark/350" },
    "color/form-control/border/selected": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/label/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/label/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/text/disabled": { light: "gray/300", dark: "gray-dark/600" },
    "color/form-control/text/placeholder": { light: "gray/500", dark: "gray-dark/600" },
    "color/form-control/text/selected": { light: "gray/900", dark: "gray-dark/800" },
    // ── icon ────────────────────────────────
    "color/icon/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/icon/gray": { light: "gray-dark/600", dark: "gray-dark/700" },
    "color/icon/gray-dark": { light: "gray/800", dark: "gray-dark/800" },
    "color/icon/gray-light": { light: "gray/300", dark: "gray-dark/400" },
    "color/icon/red": { light: "red/300", dark: "red-dark/350" },
    "color/icon/white": { light: "base/white", dark: "base/white" },
    // ── line ────────────────────────────────
    "color/line/blue": { light: "blue/400", dark: "blue-dark/300" },
    "color/line/gray/subtle": { light: "gray/100", dark: "gray-dark/300" },
    // ── navigation ────────────────────────────────
    "color/navigation/bg": { light: "base/white", dark: "gray-dark/100" },
    // 내비게이션 자리의 아이콘 색. navigation 묶음에는 아이콘 칸이 없어서 모바일 하단 내비가
    //   icon/* 에서 빌려 쓰고 있었다(미선택이 과하게 진했던 원인). river 결정 2026-09-14 —
    //   "모바일 바텀 내비도 네비게이션의 한 종류이고 아이콘이 없을 뿐이니까 아이콘 항목만 만들고".
    //   라벨은 새로 만들지 않고 기존 navigation/label/default 를 그대로 쓴다(같은 결정, 선택지 가).
    "color/navigation/icon/default": { light: "gray/300", dark: "gray-dark/600" },
    "color/navigation/indicator/default": { light: "gray/200", dark: "gray-dark/300" },
    "color/navigation/indicator/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/indicator/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/default": { light: "gray/600", dark: "gray-dark/600" },
    "color/navigation/label/default-alt": { light: "gray/700", dark: "gray-dark/700" },
    "color/navigation/label/hover": { light: "blue/400", dark: "blue-dark/300" },
    "color/navigation/label/selected": { light: "blue/400", dark: "blue-dark/300" },
    // 하위메뉴(펼침 패널)의 **카테고리 제목** 글자 — 기준 원본 = A `gnb list`(yE5UCFEbmXJBlYJWB24Lz2 / 540:6423
    //   변형 regular) 실측 #353535 = gray/800, 원본 변수 color/text/title/secondary. (river 지시 2026-09-08 "A로 가"
    //   — 그전 B gnb(5:10245) 기준은 폐기됐다.)
    //   상단바 메뉴 글자(label/default gray/600 · default-alt gray/700)보다 진한 값이라 기존 토큰으로 대체할 수 없다.
    //   그 아래 **항목** 글자는 새 토큰을 만들지 않고 label/default(gray/600, #555555)를 그대로 쓴다 — river 결정 2026-09-08.
    "color/navigation/submenu/label/default": { light: "gray/800", dark: "gray-dark/900" },
    // ── overlay ────────────────────────────────
    "color/overlay": { light: "rgba(0,0,0,0.5)", dark: "rgba(0,0,0,0.75)" },
    // wheel-fade: Time Picker Mobile Bottom Sheet 휠 위/아래 흐림 마스크의 '표면색 베이스'.
    //   alpha 그라데이션은 별도 마스크(구조적 alpha)로 구현하고, 이 토큰은 solid 표면색만 담당한다.
    //   → 다크모드에서 시트 표면색(gray-dark/100)으로 자연스럽게 fade(흰색 누출 방지). Figma 정본 VariableID:916:2.
    "color/overlay/wheel-fade": { light: "base/white", dark: "gray-dark/100" },
    // ── date-picker ────────────────────────────────
    // 신설: components.html 의 .s1-date-picker__* CSS 토큰 사용 기반
    // 레거시 semantic 컬렉션에 없던 그룹 — 우리 코드의 datepicker 디자인 정합
    // panel(패널 배경·테두리) / cell(날짜칸 배경·테두리) 분리 + icon(헤더 < >) 신설 — 사용자 결정 2026-06-26 (값 보존, 이름만 이동)
    "color/date-picker/panel/bg": { light: "base/white", dark: "gray-dark/100" },
    // 2026-07-29: 라이트를 gray/300 → gray/200 으로 변경. 패널 보더 4종(Modal·Dropdown·
    //   Time Picker Dropdown·Date Picker)을 같은 값으로 통일(사용자 결정). 다크는 불변.
    "color/date-picker/panel/border": { light: "gray/200", dark: "gray-dark/500" },
    "color/date-picker/cell/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/date-picker/cell/bg/today": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/cell/bg/selected": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/cell/bg/selected-hover": { light: "blue/500", dark: "blue-dark/250" },
    // (B)유형: 선택된 파란 칸의 hover는 회색 아닌 더 진한 파랑. chip-solid selected-hover 와 동일 단계.
    "color/date-picker/cell/bg/range": { light: "blue/50", dark: "blue-dark/100" },
    "color/date-picker/cell/border/today": { light: "blue/400", dark: "blue-dark/300" },
    // icon(헤더 이전/다음 < > — 현재 적용색 gray/900 보존, hover/disabled 신규)
    "color/date-picker/icon/default": { light: "gray/900", dark: "gray-dark/900" },
    "color/date-picker/icon/hover": { light: "gray/800", dark: "gray-dark/800" },
    "color/date-picker/icon/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/date-picker/text/primary": { light: "gray/900", dark: "gray-dark/900" },
    "color/date-picker/text/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/date-picker/text/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/date-picker/text/other-month": { light: "gray/300", dark: "gray-dark/400" },
    "color/date-picker/text/sunday": { light: "red/300", dark: "red-dark/350" },
    "color/date-picker/text/saturday": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/today": { light: "blue/400", dark: "blue-dark/300" },
    "color/date-picker/text/selected": { light: "base/white", dark: "base/white" },
    "color/date-picker/tile/bg/default": { light: "base/white", dark: "gray-dark/100" },
    // tile hover = Secondary 버튼 hover foundation 동일(gray/50·gray-dark/200) — Calendar Tile Hover variant, 사용자 결정 2026-06-25
    "color/date-picker/tile/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    "color/date-picker/tile/bg/selected": { light: "base/white", dark: "gray-dark/100" },
    "color/date-picker/tile/bg/disabled": { light: "gray/100", dark: "gray-dark/200" },
    "color/date-picker/tile/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/date-picker/tile/border/disabled": { light: "gray/100", dark: "gray-dark/300" },
    // ── modal ────────────────────────────────
    // 딤 위 팝업 셸(buildModalShell)의 패널 테두리. 2026-07-29 신설(사용자 결정).
    //   컴포넌트별 그룹으로 둔 이유: semantic.md 2026-06-23 정리가 "테두리는 color-line-* 및
    //   컴포넌트별 *-border-* 로 분산"이라 명시했고(보더 33건 중 28건이 컴포넌트별),
    //   color/surface/* 는 2026-06-30 에 의도적으로 드롭돼 raised 하나만 남은 그룹이라 확장 대상이 아니다.
    //   값이 같아도 별도 키를 두는 것이 이 저장소 관례(gray/200+gray-dark/500 조합을 이미 8키가 각자 보유).
    //   배경은 color/surface/raised 를 그대로 쓴다(이 그룹에 bg 를 만들지 않는다).
    "color/modal/panel/border": { light: "gray/200", dark: "gray-dark/500" },
    // ── pagination ────────────────────────────────
    "color/pagination/control/bg/default": { light: "base/white", dark: "gray-dark/100" },
    "color/pagination/control/bg/disabled": { light: "gray/50", dark: "gray-dark/300" },
    "color/pagination/control/bg/hover": { light: "gray/50", dark: "gray-dark/200" },
    // control(화살표/edge 버튼 박스) = Secondary 버튼과 동일 foundation (bg=base/white·hover=gray/50·border=gray/200) — 사용자 결정 2026-06-25
    "color/pagination/control/border/default": { light: "gray/200", dark: "gray-dark/500" },
    "color/pagination/control/border/disabled": { light: "gray/100", dark: "gray-dark/300" },
    "color/pagination/control/border/hover": { light: "gray/200", dark: "gray-dark/500" },
    // control/icon(화살표·edge 글리프) = Secondary 버튼 라벨과 동일 foundation (active=gray/800·disabled=gray/300) — 사용자 결정 2026-06-26
    "color/pagination/control/icon/default": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/hover": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/selected": { light: "gray/800", dark: "gray-dark/800" },
    "color/pagination/control/icon/disabled": { light: "gray/300", dark: "gray-dark/600" },
    // number(페이지 번호) = 기존 적용 색 보존: default·hover=text/state/helper(gray/400)·selected=text/body/secondary(gray/800) — 사용자 결정 2026-06-26
    "color/pagination/number/default": { light: "gray/400", dark: "gray-dark/600" },
    "color/pagination/number/hover": { light: "gray/400", dark: "gray-dark/600" },
    "color/pagination/number/selected": { light: "gray/800", dark: "gray-dark/800" },
    // ── status-card ────────────────────────────────
    "color/status-card/text/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/status-card/text/error": { light: "red/300", dark: "red-dark/350" },
    "color/status-card/text/primary--default": { light: "gray/900", dark: "gray-dark/900" },
    "color/status-card/text/primary--sub": { light: "gray/800", dark: "gray-dark/800" },
    "color/status-card/text/secondary--default": { light: "gray/600", dark: "gray-dark/700" },
    "color/status-card/text/secondary--sub": { light: "gray/500", dark: "gray-dark/700" },
    "color/status-card/text/tertiary--default": { light: "gray/400", dark: "gray-dark/600" },
    "color/status-card/text/tertiary--sub": { light: "gray/300", dark: "gray-dark/400" },
    // ── text ────────────────────────────────
    "color/text/body/primary": { light: "gray/800", dark: "gray-dark/900" },
    "color/text/body/secondary": { light: "gray/600", dark: "gray-dark/800" },
    "color/text/body/tertiary": { light: "gray/500", dark: "gray-dark/700" },
    "color/text/state/accent": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/accent-inverse": { light: "base/white", dark: "base/white" },
    "color/text/state/caption": { light: "gray/500", dark: "gray-dark/800" },
    "color/text/state/caution": { light: "red/300", dark: "red-dark/350" },
    "color/text/state/correct": { light: "blue/400", dark: "blue-dark/300" },
    "color/text/state/disabled": { light: "gray/300", dark: "gray-dark/400" },
    "color/text/state/helper": { light: "gray/400", dark: "gray-dark/600" },
    "color/text/title/primary": { light: "base/black", dark: "gray-dark/900" },
    "color/text/title/secondary": { light: "gray/800", dark: "gray-dark/800" },
    "color/form-control/icon/default": { light: "gray/800", dark: "gray-dark/700" },
    // 아이콘도 상태를 갖는다(river 승인 2026-09-10, 값은 '가' 진한 회색안).
    //   종전에는 default·disabled 둘뿐이라 마우스 올림·펼침에서도 아이콘 색이 한 가지였다.
    //   값은 글자의 text/selected(gray/900)와 같은 단계를 쓴다 — 같은 트리거 안에서 글자와 아이콘이 함께 진해진다.
    "color/form-control/icon/hover": { light: "gray/900", dark: "gray-dark/800" },
    "color/form-control/icon/selected": { light: "gray/900", dark: "gray-dark/800" },
    "color/form-control/icon/disabled": { light: "gray/300", dark: "gray-dark/500" },
    "color/scroll/bg": { light: "gray/200", dark: "gray-dark/600" },
    "color/form-control/text-cursor": { light: "blue/400", dark: "blue-dark/350" },
    "color/form-control/text/read-only": { light: "gray/500", dark: "gray-dark/700" }
  };
  var SEMANTIC_NUMBER = {
    // ── spacing/label-gap ─────────────────
    "spacing/label-gap-inline/sm": "spacing/8",
    "spacing/label-gap-inline/md": "spacing/12",
    "spacing/label-gap-inline/lg": "spacing/16",
    "spacing/label-gap-block/sm": "spacing/4",
    "spacing/label-gap-block/md": "spacing/8",
    // ── sizing (semantic) ─────────────────
    // 2026-06-12 폐지: 컴포넌트별 사이징(form-control-height·button-height·chip-height·
    //   table-row-height·dropdown-item-height·icon·button-min-width)을 전부 제거하고
    //   컴포넌트가 Foundation --sizing-N 을 직접 참조하도록 전환(사용자 결정).
    //   값 보존: 모든 옛 토큰이 Foundation sizing step과 1:1 매핑됨.
    // ── radius semantic ───────────────────
    "radius/control/xs": "radius/2",
    "radius/control/sm": "radius/4",
    "radius/button/md": "radius/4",
    "radius/card/md": "radius/10",
    "radius/modal/md": "radius/8"
  };

  // plugins/figma-vars-installer/src/shadow-parse.ts
  function shadowVarName(token, layerIndex, field) {
    const letters = "abcdefghijklmnopqrstuvwxyz";
    if (layerIndex < 0 || layerIndex >= letters.length) {
      throw new Error(`[shadow-parse] \uACB9 \uC778\uB371\uC2A4\uAC00 \uBC94\uC704\uB97C \uBC97\uC5B4\uB0AC\uC2B5\uB2C8\uB2E4: ${layerIndex}`);
    }
    return `${token}/layer-${letters[layerIndex]}/${field}`;
  }
  function splitShadowLayers(css) {
    const out = [];
    let depth = 0;
    let buf = "";
    for (let i = 0; i < css.length; i++) {
      const ch = css[i];
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
      if (ch === "," && depth === 0) {
        out.push(buf.trim());
        buf = "";
        continue;
      }
      buf += ch;
    }
    if (buf.trim()) out.push(buf.trim());
    if (depth !== 0) throw new Error(`[shadow-parse] \uAD04\uD638\uAC00 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    return out;
  }
  function parseRgba(token, ctx) {
    const m = token.match(/^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/i);
    if (!m) throw new Error(`[shadow-parse] \uC0C9\uC744 \uD574\uC11D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
    const a = m[4] === void 0 ? 1 : Number(m[4]);
    for (const [name, v, max] of [["r", r, 255], ["g", g, 255], ["b", b, 255], ["a", a, 1]]) {
      if (!isFinite(v) || v < 0 || v > max) {
        throw new Error(`[shadow-parse] \uC0C9 \uC131\uBD84 ${name}=${v} \uC774 \uBC94\uC704\uB97C \uBC97\uC5B4\uB0AC\uC2B5\uB2C8\uB2E4 (\uACB9: ${ctx})`);
      }
    }
    return { r: r / 255, g: g / 255, b: b / 255, a };
  }
  function parseLength(token, ctx) {
    const m = token.match(/^(-?[\d.]+)(px)?$/i);
    if (!m) throw new Error(`[shadow-parse] \uAE38\uC774\uAC12\uC744 \uD574\uC11D\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    const n = Number(m[1]);
    if (!isFinite(n)) throw new Error(`[shadow-parse] \uAE38\uC774\uAC12\uC774 \uC22B\uC790\uAC00 \uC544\uB2D9\uB2C8\uB2E4: ${JSON.stringify(token)} (\uACB9: ${ctx})`);
    return n;
  }
  function parseShadowLayer(layer) {
    const src = layer.trim();
    if (!src) throw new Error("[shadow-parse] \uBE48 \uACB9 \uBB38\uC790\uC5F4\uC785\uB2C8\uB2E4.");
    if (/\binset\b/i.test(src)) {
      throw new Error(`[shadow-parse] inset \uC740 DropShadow \uAC00 \uC544\uB2C8\uB77C InnerShadow \uC785\uB2C8\uB2E4(\uBBF8\uC9C0\uC6D0): ${JSON.stringify(src)}`);
    }
    const colorMatch = src.match(/rgba?\([^)]*\)/i);
    if (!colorMatch) {
      throw new Error(`[shadow-parse] \uC0C9(rgb/rgba)\uC774 \uC5C6\uC2B5\uB2C8\uB2E4: ${JSON.stringify(src)} \u2014 \uADF8\uB9BC\uC790 \uC0C9\uC740 rgba \uB85C \uC801\uB294\uB2E4(EX07).`);
    }
    const color = parseRgba(colorMatch[0], src);
    const rest = (src.slice(0, colorMatch.index) + " " + src.slice((colorMatch.index || 0) + colorMatch[0].length)).trim();
    const lengths = rest.split(/\s+/).filter(Boolean);
    if (lengths.length < 3 || lengths.length > 4) {
      throw new Error(
        `[shadow-parse] \uAE38\uC774\uAC12\uC774 ${lengths.length}\uAC1C\uC785\uB2C8\uB2E4(3 \uB610\uB294 4\uC5EC\uC57C \uD568: x y blur [spread]): ${JSON.stringify(src)}`
      );
    }
    const offsetX = parseLength(lengths[0], src);
    const offsetY = parseLength(lengths[1], src);
    const blur = parseLength(lengths[2], src);
    const spread = lengths.length === 4 ? parseLength(lengths[3], src) : 0;
    if (blur < 0) throw new Error(`[shadow-parse] blur \uB294 0 \uC774\uC0C1\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4(Figma \uC81C\uC57D): ${JSON.stringify(src)}`);
    return { offsetX, offsetY, blur, spread, color };
  }
  function parseCssShadow(css) {
    if (typeof css !== "string" || !css.trim()) {
      throw new Error(`[shadow-parse] \uBE48 \uAC12\uC785\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    }
    if (css.trim() === "none") {
      throw new Error("[shadow-parse] 'none' \uC740 Effect \uB85C \uBCC0\uD658\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uD638\uCD9C\uBD80\uC5D0\uC11C \uAC78\uB7EC\uC57C \uD569\uB2C8\uB2E4.");
    }
    const layers = splitShadowLayers(css).map(parseShadowLayer);
    if (layers.length === 0) throw new Error(`[shadow-parse] \uACB9\uC744 \uD558\uB098\uB3C4 \uCD94\uCD9C\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${JSON.stringify(css)}`);
    return layers;
  }
  function toDropShadowEffects(css) {
    return parseCssShadow(css).map((l) => ({
      type: "DROP_SHADOW",
      color: l.color,
      offset: { x: l.offsetX, y: l.offsetY },
      radius: l.blur,
      spread: l.spread,
      visible: true,
      blendMode: "NORMAL"
    }));
  }

  // plugins/figma-vars-installer/src/textstyles-data.ts
  var TEXT_STYLE_FONT_FAMILY = "Pretendard";
  var TEXT_STYLES = [
    // caption·helper 폐기(2026-06-12): body/12R와 값 동일 → body/12R 사용. (D4)
    // ── title ───────────────────────────────────────────
    { name: "title/32B", fontStyle: "Bold", fontSize: 32, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // title/32R: V2.4 패널엔 없던 신규 추가(2026-07-07). Time Picker Mobile Bottom Sheet 휠(32px accent 숫자)이
    //   Pretendard Regular 32 를 named 텍스트 스타일로 바인딩(setTextStyleIdAsync)할 수 있게 하기 위함.
    //   MCP(use_figma)는 폰트 직접 로드 불가 → named 스타일이 있어야 폰트 로드 없이 Pretendard 유지 가능.
    //   geometry 는 title/32B(32·130·0) 와 동일, weight 만 Regular. (title/20R 선례와 동일 계열.)
    { name: "title/32R", fontStyle: "Regular", fontSize: 32, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/24B", fontStyle: "Bold", fontSize: 24, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20B", fontStyle: "Bold", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/20R", fontStyle: "Regular", fontSize: 20, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // title/18B — 2026-08-20 모바일 Modal 제목 기준으로 정본 편입.
    //   출처: Mobile S/W UX GUIDE V2.32 Title/18B (18px · Bold · 130% · 0%).
    { name: "title/18B", fontStyle: "Bold", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/16B", fontStyle: "Bold", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "title/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "title/14B", fontStyle: "Bold", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // title/14M — 2026-08-03 신설(river 지시). 표 헤더처럼 **제목 역할인데 굵기가 Medium** 인 자리가
    //   title 계열에 없어서 body/14M 으로 갈 수밖에 없었다. 역할(제목)과 계열(body)이 어긋나던 것을 해소한다.
    //   Gate 34 승인 기록: registry/governance/canon-additions-baseline.json
    { name: "title/14M", fontStyle: "Medium", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: 0 },
    // ── body ────────────────────────────────────────────
    { name: "body/18M", fontStyle: "Medium", fontSize: 18, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16M", fontStyle: "Medium", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/16R", fontStyle: "Regular", fontSize: 16, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14M", fontStyle: "Medium", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/14R", fontStyle: "Regular", fontSize: 14, lineHeightPercent: 130, letterSpacingPercent: -2 },
    { name: "body/12M", fontStyle: "Medium", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/12R", fontStyle: "Regular", fontSize: 12, lineHeightPercent: 130, letterSpacingPercent: 0 },
    { name: "body/10M", fontStyle: "Medium", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 },
    { name: "body/10R", fontStyle: "Regular", fontSize: 10, lineHeightPercent: 140, letterSpacingPercent: 2 }
  ];

  // plugins/figma-vars-installer/src/install-textstyles.ts
  async function getOrCreateTextStyle(name) {
    const all = await figma.getLocalTextStylesAsync();
    const existing = all.find((s) => s.name === name);
    if (existing) return existing;
    return figma.createTextStyle();
  }
  async function loadRequiredFonts() {
    const styles = Array.from(new Set(TEXT_STYLES.map((s) => s.fontStyle)));
    for (const style of styles) {
      try {
        await figma.loadFontAsync({ family: TEXT_STYLE_FONT_FAMILY, style });
      } catch (e) {
        throw new Error(
          `\uD3F0\uD2B8 \uB85C\uB4DC \uC2E4\uD328: ${TEXT_STYLE_FONT_FAMILY} ${style}. \uC774 Figma \uD30C\uC77C/\uD658\uACBD\uC5D0 Pretendard ${style} \uAC00 \uC124\uCE58\uB418\uC5B4 \uC788\uB294\uC9C0 \uD655\uC778\uD558\uC138\uC694.`
        );
      }
    }
  }
  async function installTextStyles(onProgress, pctFrom = 70, pctTo = 85) {
    await loadRequiredFonts();
    const map = {};
    for (let i = 0; i < TEXT_STYLES.length; i++) {
      const def = TEXT_STYLES[i];
      const ts = await getOrCreateTextStyle(def.name);
      ts.name = def.name;
      ts.fontName = { family: TEXT_STYLE_FONT_FAMILY, style: def.fontStyle };
      ts.fontSize = def.fontSize;
      ts.lineHeight = { unit: "PERCENT", value: def.lineHeightPercent };
      ts.letterSpacing = { unit: "PERCENT", value: def.letterSpacingPercent };
      map[def.name] = ts;
      if (onProgress) {
        const pct = pctFrom + Math.round(i / TEXT_STYLES.length * (pctTo - pctFrom));
        onProgress(`Text Style: ${def.name}`, pct);
      }
    }
    return map;
  }

  // plugins/figma-vars-installer/src/build-components.ts
  var BUILT_SETS = {};
  var BUILT_COMPS = {};
  var TEXT_STYLES2 = {};
  var SPEC_MAPS = null;
  function primeSpecMaps(maps) {
    SPEC_MAPS = maps;
  }
  var SPEC_ROLE_TOKEN = {
    bg: "color/bg/level-0",
    band: "color/bg/level-2",
    title: "color/text/title/primary",
    platform: "color/text/body/primary",
    size: "color/text/body/secondary",
    label: "color/text/body/tertiary"
  };
  var SPEC_ROLES = {
    bg: "bg",
    band: "band",
    title: "title",
    platform: "platform",
    size: "size",
    label: "label"
  };
  var SPEC_FALLBACK = {
    bg: { light: { r: 1, g: 1, b: 1 }, dark: { r: 0.075, g: 0.078, b: 0.094 } },
    band: { light: { r: 0.93, g: 0.94, b: 0.96 }, dark: { r: 0.14, g: 0.15, b: 0.18 } },
    title: { light: { r: 0.07, g: 0.07, b: 0.09 }, dark: { r: 0.95, g: 0.95, b: 0.96 } },
    platform: { light: { r: 0.13, g: 0.13, b: 0.13 }, dark: { r: 0.9, g: 0.9, b: 0.92 } },
    size: { light: { r: 0.25, g: 0.27, b: 0.3 }, dark: { r: 0.78, g: 0.8, b: 0.84 } },
    label: { light: { r: 0.42, g: 0.45, b: 0.5 }, dark: { r: 0.6, g: 0.62, b: 0.67 } }
  };
  function specPaint(role, dark) {
    const v = SPEC_MAPS ? SPEC_MAPS.semanticColor[SPEC_ROLE_TOKEN[role]] : void 0;
    if (v) return boundPaint(v);
    return { type: "SOLID", color: SPEC_FALLBACK[role][dark ? "dark" : "light"] };
  }
  function specStyleKey(style) {
    return style === "Bold" ? "title/14B" : "body/12M";
  }
  var SURFACE_TOKEN = {
    section: "color/bg/level-0",
    page: "color/bg/level-2"
  };
  var SECTION_STROKE_TOKEN = "color/line/gray/subtle";
  function bindSurface(target, apply) {
    if (!SPEC_MAPS) return;
    const v = SPEC_MAPS.semanticColor[SURFACE_TOKEN[target]];
    if (!v) return;
    try {
      apply(boundPaint(v));
    } catch (e) {
    }
  }
  function pinLightMode(n) {
    if (SPEC_MAPS) {
      try {
        setLightMode(n, SPEC_MAPS);
      } catch (e) {
      }
    }
  }
  function textStyleKey(fontSize, style) {
    const letter = style === "Bold" ? "B" : style === "Medium" ? "M" : "R";
    let size = fontSize;
    if (size === 13) size = 14;
    if (size === 9) size = 10;
    if (size === 20 && letter === "M") size = 18;
    if (size === 32 && letter === "R") return "title/32R";
    return `${letter === "B" ? "title" : "body"}/${size}${letter}`;
  }
  async function getBuiltSet(name) {
    if (BUILT_SETS[name]) return BUILT_SETS[name];
    try {
      const f = figma.currentPage.findOne((n) => n.type === "COMPONENT_SET" && n.name === name);
      return f || null;
    } catch (e) {
      return null;
    }
  }
  async function reuseVariant(setName, cacheKey, matches) {
    if (BUILT_COMPS[cacheKey]) return BUILT_COMPS[cacheKey];
    const set = await getBuiltSet(setName);
    if (!set) return null;
    let found;
    try {
      found = set.children.find(
        (c) => c.type === "COMPONENT" && matches.every((m) => c.name.includes(m))
      );
    } catch (e) {
      return null;
    }
    if (found) BUILT_COMPS[cacheKey] = found;
    return found != null ? found : null;
  }
  function setMode(node, maps, modeId) {
    try {
      node.setExplicitVariableModeForCollection(maps.semanticColorCollectionId, modeId);
    } catch (e) {
      console.warn("[SW Installer] \uBAA8\uB4DC \uC5F0\uACB0 \uC2E4\uD328:", e);
    }
  }
  async function unpinInstalledMasters(maps) {
    const names = /* @__PURE__ */ new Set();
    for (const cat of COMPONENT_CATEGORIES) for (const m of cat.members) names.add(m);
    const colorCid = maps.semanticColorCollectionId;
    const shadowCid = maps.semanticShadowCollectionId;
    let count = 0;
    let pages = [];
    try {
      pages = figma.root.children;
    } catch (e) {
      return 0;
    }
    if (!Array.isArray(pages)) return 0;
    for (const page of pages) {
      try {
        await page.loadAsync();
      } catch (e) {
        continue;
      }
      let sets = [];
      try {
        sets = page.findAllWithCriteria({ types: ["COMPONENT_SET"] });
      } catch (e) {
        continue;
      }
      if (!Array.isArray(sets)) continue;
      const signed = /* @__PURE__ */ new Set();
      try {
        const marks = page.findAllWithCriteria({ types: ["FRAME"] });
        if (Array.isArray(marks)) {
          for (const m of marks) {
            const nm = String(m.name || "");
            for (const suffix of [" \u2014 Spec Light", " \u2014 Spec Dark"]) {
              if (nm.length > suffix.length && nm.slice(nm.length - suffix.length) === suffix) {
                signed.add(nm.slice(0, nm.length - suffix.length));
              }
            }
          }
        }
      } catch (e) {
      }
      if (signed.size === 0) continue;
      for (const set of sets) {
        if (!names.has(set.name) && !signed.has(set.name)) continue;
        let kids;
        try {
          kids = set.children;
        } catch (e) {
          continue;
        }
        if (!Array.isArray(kids)) continue;
        for (const child of kids) {
          if (String(child.type) !== "COMPONENT") continue;
          const pins = child.explicitVariableModes;
          if (!pins) continue;
          const clear = (cid) => {
            if (!cid || !pins[cid]) return false;
            try {
              child.clearExplicitVariableModeForCollection(cid);
              return true;
            } catch (e) {
              return false;
            }
          };
          const a = clear(colorCid);
          const b = clear(shadowCid);
          if (a || b) count++;
        }
      }
    }
    return count;
  }
  function clearMode(node, maps) {
    try {
      node.clearExplicitVariableModeForCollection(maps.semanticColorCollectionId);
    } catch (e) {
      console.warn("[SW Installer] \uBAA8\uB4DC \uD540 \uD574\uC81C \uC2E4\uD328:", e);
    }
  }
  function setShadowMode(node, maps, modeId) {
    const sCid = maps.semanticShadowCollectionId;
    if (!sCid || !modeId) return;
    let kind = "";
    try {
      kind = String(node.type);
    } catch (e) {
      kind = "";
    }
    if (kind === "COMPONENT") return;
    try {
      node.setExplicitVariableModeForCollection(sCid, modeId);
    } catch (e) {
    }
  }
  function shadowEffects(token) {
    const entry = SEMANTIC_SHADOW[token];
    if (!entry) throw new Error(`[build-components] SEMANTIC_SHADOW \uC5D0 '${token}' \uC774 \uC5C6\uC2B5\uB2C8\uB2E4.`);
    return toDropShadowEffects(entry.light);
  }
  function boundShadowEffects(maps, token) {
    const base = shadowEffects(token);
    const vars = maps.shadowVars;
    if (!vars) return base;
    return base.map((eff, i) => {
      let out = eff;
      const bind = (field, name) => {
        const v = vars[name];
        if (!v) return;
        try {
          out = figma.variables.setBoundVariableForEffect(out, field, v);
        } catch (e) {
        }
      };
      bind("color", shadowVarName(token, i, "color"));
      bind("offsetY", shadowVarName(token, i, "offset-y"));
      bind("radius", shadowVarName(token, i, "blur"));
      bind("spread", shadowVarName(token, i, "spread"));
      return out;
    });
  }
  function setLightMode(node, maps) {
    let kind = "";
    try {
      kind = String(node.type);
    } catch (e) {
      kind = "";
    }
    if (kind === "COMPONENT") return;
    setMode(node, maps, maps.semanticLightModeId);
  }
  var PLATFORMS = [
    { name: "PC", sizes: ["MD", "XSM", "XXSM"] },
    { name: "Mobile", sizes: ["LG"] }
  ];
  var VARIANTS = ["primary", "secondary", "blue-line"];
  var VARIANT_LABEL = {
    primary: "Primary",
    secondary: "Secondary",
    "blue-line": "Blue-Line"
  };
  var SIZE_CONFIG = {
    MD: { break: "PC", height: 44, padPath: "spacing/16", textStyle: "body/14M", minWidth: 80 },
    XSM: { break: "PC", height: 34, padPath: "spacing/8", textStyle: "body/14M", minWidth: 64 },
    XXSM: { break: "PC", height: 28, padPath: "spacing/8", textStyle: "body/12M", minWidth: 56 },
    LG: { break: "Mobile", height: 48, padPath: "spacing/16", textStyle: "body/16M", minWidth: 80 }
  };
  var SIZES = ["MD", "XSM", "XXSM", "LG"];
  var STATES = ["Default", "Hover", "Pressed", "Disabled"];
  var CELL_W = 132;
  var CELL_H = 60;
  var SPEC_LIGHT_X = 1040;
  var SPEC_DARK_X = 2080;
  var INPUT_SHEET_X = 4200;
  function variantSlots(variant, state) {
    if (state === "Disabled") {
      return {
        bg: "color/button/bg/disabled",
        border: "color/button/border/disabled",
        label: "color/button/label/disabled"
      };
    }
    const suffix = state === "Default" ? "default" : "hover";
    return {
      bg: `color/button/bg/${variant}--${suffix}`,
      border: `color/button/border/${variant}--${suffix}`,
      label: `color/button/label/${variant}--${suffix}`
    };
  }
  function boundPaint(variable) {
    const paint = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
    return figma.variables.setBoundVariableForPaint(paint, "color", variable);
  }
  function sweepRawPaints(root) {
    const left = [];
    const seen = /* @__PURE__ */ new Set();
    const nameOf = (n) => {
      try {
        return String(n.name);
      } catch (e) {
        return "?";
      }
    };
    const isBound = (p) => !!(p && p.boundVariables && p.boundVariables.color);
    const isInvisible = (p) => p.visible === false || p.opacity === 0;
    const visit = (node, path) => {
      if (node.type === "INSTANCE") return;
      let isMaskShape = false;
      try {
        isMaskShape = node.isMask === true;
      } catch (e) {
      }
      if (isMaskShape) {
        visitKids(node, path);
        return;
      }
      for (const prop of ["fills", "strokes"]) {
        let arr;
        try {
          arr = node[prop];
        } catch (e) {
          continue;
        }
        if (!Array.isArray(arr)) continue;
        const kept = arr.filter((p) => !(p && p.type === "SOLID" && !isBound(p) && isInvisible(p)));
        if (kept.length !== arr.length) {
          try {
            node[prop] = kept;
          } catch (e) {
          }
        }
        for (const p of kept) {
          if (!p || p.type !== "SOLID" || isBound(p)) continue;
          const label = `${path} (${prop === "fills" ? "\uCE60" : "\uC120"})`;
          if (seen.has(label)) continue;
          seen.add(label);
          left.push(label);
        }
      }
      visitKids(node, path);
    };
    function visitKids(node, path) {
      let kids;
      try {
        kids = node.children;
      } catch (e) {
        return;
      }
      if (!Array.isArray(kids)) return;
      for (const c of kids) visit(c, `${path} / ${nameOf(c)}`);
    }
    visit(root, nameOf(root));
    return left;
  }
  function requireVar(map, key, kind) {
    const v = map[key];
    if (!v) throw new Error(`${kind} \uBCC0\uC218 \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Variables \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return v;
  }
  function bindRadius(node, maps, token) {
    const v = requireVar(maps.foundationNumber, token, "Foundation Number");
    node.setBoundVariable("topLeftRadius", v);
    node.setBoundVariable("topRightRadius", v);
    node.setBoundVariable("bottomLeftRadius", v);
    node.setBoundVariable("bottomRightRadius", v);
  }
  function requireStyle(map, key) {
    const s = map[key];
    if (!s) throw new Error(`Text Style \uB204\uB77D: ${key} \u2014 \uBA3C\uC800 Text Styles \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    return s;
  }
  async function buildOne(variant, size, state, maps) {
    const cfg = SIZE_CONFIG[size];
    const slots = variantSlots(variant, state);
    const comp = figma.createComponent();
    comp.name = `Size=${size}, State=${state}, Variant=${VARIANT_LABEL[variant]}, Break=${cfg.break}`;
    comp.layoutMode = "HORIZONTAL";
    comp.primaryAxisAlignItems = "CENTER";
    comp.counterAxisAlignItems = "CENTER";
    comp.primaryAxisSizingMode = "AUTO";
    comp.counterAxisSizingMode = "FIXED";
    const padVar = requireVar(maps.foundationNumber, cfg.padPath, "Foundation Number");
    comp.paddingTop = 0;
    comp.paddingBottom = 0;
    comp.setBoundVariable("paddingLeft", padVar);
    comp.setBoundVariable("paddingRight", padVar);
    comp.minWidth = cfg.minWidth;
    await figma.loadFontAsync({ family: "Pretendard", style: "Medium" });
    const text2 = figma.createText();
    text2.fontName = { family: "Pretendard", style: "Medium" };
    text2.characters = "\uBC84\uD2BC";
    const ts = requireStyle(maps.textStyles, cfg.textStyle);
    await text2.setTextStyleIdAsync(ts.id);
    text2.fills = [boundPaint(requireVar(maps.semanticColor, slots.label, "Semantic Color"))];
    comp.appendChild(text2);
    comp.fills = [boundPaint(requireVar(maps.semanticColor, slots.bg, "Semantic Color"))];
    comp.strokes = [boundPaint(requireVar(maps.semanticColor, slots.border, "Semantic Color"))];
    comp.strokeAlign = "INSIDE";
    const bwVar = requireVar(maps.foundationNumber, "border-width/1", "Foundation Number");
    comp.setBoundVariable("strokeWeight", bwVar);
    bindRadius(comp, maps, "radius/4");
    const rootWidth = Math.max(comp.width, cfg.minWidth);
    comp.resize(rootWidth, cfg.height);
    setLightMode(comp, maps);
    return comp;
  }
  async function makeLabel(text2, fontSize, style, x, y, w, align, role, dark) {
    await figma.loadFontAsync({ family: "Pretendard", style });
    const t = figma.createText();
    t.fontName = { family: "Pretendard", style };
    t.fontSize = fontSize;
    t.characters = text2;
    const ts = TEXT_STYLES2[specStyleKey(style)];
    if (ts) {
      try {
        await t.setTextStyleIdAsync(ts.id);
      } catch (e) {
      }
    }
    t.textAutoResize = "HEIGHT";
    t.resize(w, t.height);
    t.textAlignHorizontal = align;
    t.x = x;
    t.y = y;
    t.fills = [specPaint(role, dark)];
    return t;
  }
  function specBg(contrast) {
    return contrast ? "band" : "bg";
  }
  function specWidth(rowLabelW, cols, cellW) {
    return 24 * 2 + rowLabelW + cols * cellW;
  }
  async function renderGrouped(opts, dark, emit) {
    const PAD2 = 24, TITLE_H = 34, PLATFORM_GAP = 20, BAND_H = 32, SIZE_GAP = 14, SIZE_TITLE_H = 22, HEADER_H = 24;
    const gridLeft = PAD2 + opts.rowLabelW;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const c = SPEC_ROLES;
    let y = PAD2;
    await emit.text(`${opts.title} \xB7 ${dark ? "Dark" : "Light"}`, PAD2, y, 320, "LEFT", c.title, 14, "Bold");
    y += TITLE_H;
    for (const plat of opts.platforms) {
      y += PLATFORM_GAP;
      emit.band(PAD2, y, W - PAD2 * 2, BAND_H, c.band);
      await emit.text(plat.name, PAD2 + 12, y + 8, 200, "LEFT", c.platform, 13, "Bold");
      y += BAND_H + 4;
      for (const size of plat.sizes) {
        y += SIZE_GAP;
        if (size) {
          await emit.text(size, PAD2, y, 200, "LEFT", c.size, 12, "Medium");
          y += SIZE_TITLE_H;
        }
        for (let col = 0; col < opts.colHeaders.length; col++) {
          if (opts.colHeaders[col]) await emit.text(opts.colHeaders[col], gridLeft + col * opts.cellW, y, opts.cellW, "CENTER", c.label, 12, "Medium");
        }
        y += HEADER_H;
        for (let ri = 0; ri < opts.rowLabels.length; ri++) {
          let rowH = 0;
          for (let ci = 0; ci < opts.colHeaders.length; ci++) {
            const cp = opts.cellAt(plat.name, size, ri, ci);
            if (cp && cp.height > rowH) rowH = cp.height;
          }
          rowH = (rowH || opts.cellH) + 16;
          const top = y + 4;
          if (opts.rowLabels[ri]) await emit.text(opts.rowLabels[ri], PAD2, top, opts.rowLabelW, "LEFT", c.label, 12, "Medium");
          for (let ci = 0; ci < opts.colHeaders.length; ci++) {
            const comp = opts.cellAt(plat.name, size, ri, ci);
            if (comp) emit.cell(comp, gridLeft + ci * opts.cellW + (opts.cellW - comp.width) / 2, top);
          }
          y += rowH;
        }
      }
    }
    return y + PAD2;
  }
  function frameEmit(frame, maps, modeId, shadowModeId) {
    return {
      text: async (s, x, y, w, al, role, fs, st) => {
        frame.appendChild(await makeLabel(s, fs, st, x, y, w, al, role, true));
      },
      band: (x, y, w, h, role) => {
        const b = figma.createRectangle();
        b.x = x;
        b.y = y;
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [specPaint(role, true)];
        frame.appendChild(b);
      },
      cell: (comp, x, y) => {
        const inst = comp.createInstance();
        frame.appendChild(inst);
        inst.x = x;
        inst.y = y;
        setMode(inst, maps, modeId);
        setShadowMode(inst, maps, shadowModeId);
        try {
          inst.findAll((n) => n.type === "INSTANCE").forEach((d) => setMode(d, maps, modeId));
        } catch (e) {
        }
      }
    };
  }
  var DECO_SUFFIX = "\u2014 Spec Deco";
  function floatingEmit(oy, ox = 0, tag) {
    const mark = (n) => {
      if (tag) {
        try {
          n.name = `${tag} ${DECO_SUFFIX}`;
        } catch (e) {
        }
      }
    };
    return {
      text: async (s, x, y, w, al, role, fs, st) => {
        const t = await makeLabel(s, fs, st, ox + x, oy + y, w, al, role, false);
        pinLightMode(t);
        mark(t);
      },
      band: (x, y, w, h, role) => {
        const b = figma.createRectangle();
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [specPaint(role, false)];
        b.x = ox + x;
        b.y = oy + y;
        pinLightMode(b);
        mark(b);
      },
      cell: (comp, x, y) => {
        comp.x = x;
        comp.y = y;
      }
    };
  }
  async function buildGroupedSpec(opts, maps) {
    var _a, _b, _c, _d, _e;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const modeId = maps.semanticDarkModeId;
    const frame = figma.createFrame();
    frame.name = `${opts.title} \u2014 Spec Dark`;
    frame.fills = [specPaint("bg", true)];
    frame.cornerRadius = 8;
    frame.resize(W, 2400);
    frame.x = (_c = (_a = opts.darkOffset) == null ? void 0 : _a.x) != null ? _c : ((_b = opts.offsetX) != null ? _b : 0) + W + 80;
    frame.y = (_e = (_d = opts.darkOffset) == null ? void 0 : _d.y) != null ? _e : opts.originY;
    const shadowModeId = opts.shadowMode ? maps.semanticShadowDarkModeId : void 0;
    const H = await renderGrouped(opts, true, frameEmit(frame, maps, modeId, shadowModeId));
    frame.resize(W, H);
    setMode(frame, maps, modeId);
    setShadowMode(frame, maps, shadowModeId);
    return Math.max(opts.originY, frame.y + H);
  }
  async function decorateSetGrouped(set, opts, maps) {
    var _a;
    const W = specWidth(opts.rowLabelW, opts.colHeaders.length, opts.cellW);
    const ox = (_a = opts.offsetX) != null ? _a : 0;
    set.x = ox;
    set.y = opts.originY;
    try {
      set.fills = [specPaint("bg", false)];
    } catch (e) {
    }
    const H = await renderGrouped(opts, false, floatingEmit(opts.originY, ox, set.name));
    set.resize(W, H);
    setLightMode(set, maps);
    if (opts.shadowMode) setShadowMode(set, maps, maps.semanticShadowLightModeId);
    return opts.originY + H;
  }
  async function buildButtonSet(maps, onProgress, pctFrom = 85, pctTo = 100, originY = 0) {
    const grid = [];
    let i = 0;
    const total = VARIANTS.length * SIZES.length * STATES.length;
    let rowIdx = 0;
    for (const variant of VARIANTS) {
      for (const size of SIZES) {
        for (let c = 0; c < STATES.length; c++) {
          const comp = await buildOne(variant, size, STATES[c], maps);
          grid.push({ comp, variant, size, state: STATES[c], row: rowIdx, col: c });
          i++;
          if (onProgress) {
            const pct = pctFrom + Math.round(i / total * (pctTo - pctFrom));
            onProgress(`Button: ${VARIANT_LABEL[variant]}/${size}/${STATES[c]}`, pct);
          }
        }
        rowIdx++;
      }
    }
    const set = figma.combineAsVariants(grid.map((g) => g.comp), figma.currentPage);
    set.name = "Button";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Button"] = set;
    grid.forEach((g) => {
      BUILT_COMPS[`Button:${g.variant}:${g.size}:${g.state}`] = g.comp;
    });
    const opts = {
      title: "Button",
      platforms: PLATFORMS,
      rowLabels: VARIANTS.map((v) => VARIANT_LABEL[v]),
      colHeaders: STATES,
      cellAt: (_p, size, ri, ci) => {
        var _a, _b;
        return (_b = (_a = grid.find((g) => g.variant === VARIANTS[ri] && g.size === size && g.state === STATES[ci])) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: CELL_W,
      cellH: CELL_H,
      rowLabelW: 88
    };
    const setH = await decorateSetGrouped(set, opts, maps);
    setLightMode(set, maps);
    let bottomY = set.y + setH;
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn("[SW Installer] Dark \uC2A4\uD399 \uD504\uB808\uC784 \uC2E4\uD328 (\uC138\uD2B8\uB294 \uC815\uC0C1):", e);
    }
    figma.viewport.scrollAndZoomIntoView([set]);
    return { set, bottomY };
  }
  var ASSIST_BUTTON_STATES = ["Default", "Hover", "Pressed", "Disabled"];
  async function buildAssistButtonSet(maps, originY) {
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const state of ASSIST_BUTTON_STATES) {
      const comp = figma.createComponent();
      comp.name = `State=${state}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.paddingTop = 0;
      comp.paddingBottom = 0;
      const padVar = requireVar(maps.foundationNumber, "spacing/12", "Foundation Number");
      comp.setBoundVariable("paddingLeft", padVar);
      comp.setBoundVariable("paddingRight", padVar);
      comp.resize(60, 32);
      try {
        comp.minWidth = 60;
      } catch (e) {
      }
      bindRadius(comp, maps, "radius/4");
      const hover = state !== "Default";
      const slot = state === "Disabled" ? { bg: "color/button/bg/disabled", border: "color/button/border/disabled", label: "color/button/label/disabled" } : {
        // 배경·기본 테두리는 원본처럼 Secondary 토큰을 빌려 쓴다(전용 토큰을 만들지 않는다).
        bg: `color/button/bg/secondary--${hover ? "hover" : "default"}`,
        border: hover ? "color/button/border/assist--hover" : "color/button/border/secondary--default",
        label: `color/button/label/assist--${hover ? "hover" : "default"}`
      };
      comp.fills = [boundPaint(scv(maps, slot.bg))];
      comp.strokes = [boundPaint(scv(maps, slot.border))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.appendChild(await makeBoundText("\uBCF4\uC870\uBC84\uD2BC", 14, "Medium", scv(maps, slot.label), "body/14M"));
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(state, comp);
      BUILT_COMPS[`AssistButton:${state}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Assist Button";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Assist Button"] = set;
    const opts = {
      title: "Assist Button",
      colHeaders: ASSIST_BUTTON_STATES,
      rowLabels: [""],
      // 크기 축이 없으므로 행은 하나다
      cellAt: (_r, c) => {
        var _a;
        return (_a = byKey.get(ASSIST_BUTTON_STATES[c])) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 132,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var TEXT_BUTTON_VARIANTS = [
    { name: "Primary", color: "color/text/state/accent" },
    { name: "Secondary", color: "color/text/body/tertiary" }
  ];
  var TEXT_BUTTON_STATES = ["Default", "Hover", "Pressed", "Disabled"];
  async function buildTextButtonSet(maps, originY) {
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const v of TEXT_BUTTON_VARIANTS) {
      for (const state of TEXT_BUTTON_STATES) {
        const comp = figma.createComponent();
        comp.name = `Variant=${v.name}, State=${state}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.primaryAxisAlignItems = "CENTER";
        comp.counterAxisAlignItems = "CENTER";
        comp.fills = [];
        const disabled = state === "Disabled";
        const label = await makeBoundText(
          "\uD14D\uC2A4\uD2B8\uBC84\uD2BC",
          14,
          "Medium",
          scv(maps, disabled ? "color/text/state/disabled" : v.color),
          "body/14M"
        );
        if (state === "Hover" || state === "Pressed") {
          try {
            label.textDecoration = "UNDERLINE";
          } catch (e) {
          }
        }
        comp.appendChild(label);
        setLightMode(comp, maps);
        comps.push(comp);
        byKey.set(`${v.name}:${state}`, comp);
        BUILT_COMPS[`TextButton:${v.name}:${state}`] = comp;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Text Button";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Text Button"] = set;
    const opts = {
      title: "Text Button",
      colHeaders: TEXT_BUTTON_STATES,
      rowLabels: TEXT_BUTTON_VARIANTS.map((v) => v.name),
      cellAt: (r, c) => {
        var _a;
        return (_a = byKey.get(`${TEXT_BUTTON_VARIANTS[r].name}:${TEXT_BUTTON_STATES[c]}`)) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 132,
      cellH: 48,
      rowLabelW: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  function scv(maps, key) {
    return requireVar(maps.semanticColor, key, "Semantic Color");
  }
  async function makeBoundText(chars, fontSize, style, colorVar, requiredStyleKey) {
    await figma.loadFontAsync({ family: "Pretendard", style });
    const t = figma.createText();
    t.fontName = { family: "Pretendard", style };
    t.fontSize = fontSize;
    t.characters = chars;
    const ts = TEXT_STYLES2[requiredStyleKey != null ? requiredStyleKey : textStyleKey(fontSize, style)];
    if (requiredStyleKey) {
      if (!ts) throw new Error(`Text Style \uB204\uB77D: ${requiredStyleKey} \u2014 Mobile Header\uB294 raw \uD0C0\uC774\uD3EC \uD3F4\uBC31\uC744 \uD5C8\uC6A9\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.`);
      await t.setTextStyleIdAsync(ts.id);
    } else if (ts) {
      try {
        await t.setTextStyleIdAsync(ts.id);
      } catch (e) {
      }
    }
    t.fills = [boundPaint(colorVar)];
    return t;
  }
  async function makeCheckIcon(strokeVar) {
    const svg = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2.9375 8L6.13252 11.375L13.0625 4.625" stroke="#FFFFFF" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
    const node = figma.createNodeFromSvg(svg);
    node.name = "check";
    if (node.width !== 16 || node.height !== 16) node.resize(16, 16);
    rebindIconColor(node, strokeVar);
    return node;
  }
  async function renderFlat(opts, dark, emit) {
    var _a, _b, _c;
    const PAD2 = 24, TITLE_H = 30, HEADER_H = 24;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const gridLeft = PAD2 + rowLabelW;
    const c = SPEC_ROLES;
    let y = PAD2;
    await emit.text(`${opts.title} \xB7 ${dark ? "Dark" : "Light"}`, PAD2, y, 320, "LEFT", c.title, 14, "Bold");
    y += TITLE_H;
    if (!opts.cellLabelAt) {
      for (let col = 0; col < opts.colHeaders.length; col++) {
        if (opts.colHeaders[col]) await emit.text(opts.colHeaders[col], gridLeft + col * opts.cellW, y, opts.cellW, "CENTER", c.label, 11, "Medium");
      }
      y += HEADER_H;
    }
    for (let r = 0; r < opts.rowLabels.length; r++) {
      let rowH = 0;
      for (let cc = 0; cc < opts.colHeaders.length; cc++) {
        const cp = opts.cellAt(r, cc);
        if (cp && cp.height > rowH) rowH = cp.height;
      }
      const cellLabelH = opts.cellLabelAt ? 22 : 0;
      rowH = (rowH || opts.cellH) + (cellLabelH ? cellLabelH + 8 : 16) + ((_b = opts.rowGap) != null ? _b : 0);
      const top = y + (cellLabelH || 4);
      if (opts.rowLabels[r]) await emit.text(opts.rowLabels[r], PAD2, top, rowLabelW, "LEFT", c.label, 11, "Medium");
      for (let cc = 0; cc < opts.colHeaders.length; cc++) {
        const comp = opts.cellAt(r, cc);
        if (comp) {
          const cellLabel = (_c = opts.cellLabelAt) == null ? void 0 : _c.call(opts, r, cc);
          if (cellLabel) await emit.text(cellLabel, gridLeft + cc * opts.cellW, y, opts.cellW, "CENTER", c.label, 11, "Medium");
          const cellX = opts.leftAlignCells ? gridLeft + cc * opts.cellW : gridLeft + cc * opts.cellW + (opts.cellW - comp.width) / 2;
          emit.cell(comp, cellX, top);
        }
      }
      y += rowH;
    }
    return y + PAD2;
  }
  async function buildSpec(opts, maps) {
    var _a, _b, _c, _d, _e, _f;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const W = specWidth(rowLabelW, opts.colHeaders.length, opts.cellW);
    const modeId = maps.semanticDarkModeId;
    const frame = figma.createFrame();
    frame.name = `${opts.title} \u2014 Spec Dark`;
    frame.fills = [specPaint(specBg(opts.contrastBg), true)];
    frame.cornerRadius = 8;
    frame.resize(W, 1600);
    frame.x = (_c = (_b = opts.darkOffset) == null ? void 0 : _b.x) != null ? _c : opts.stackDarkBelow ? 0 : W + 80;
    frame.y = (_e = (_d = opts.darkOffset) == null ? void 0 : _d.y) != null ? _e : opts.originY;
    const baseEmit = frameEmit(frame, maps, modeId);
    const emit = opts.darkCellNodes ? {
      text: baseEmit.text,
      band: baseEmit.band,
      cell: (comp, x, y) => {
        const ready = opts.darkCellNodes.get(comp.id);
        if (!ready) {
          console.warn(`[installer] \uB2E4\uD06C \uC0AC\uBCF8\uC744 \uBABB \uCC3E\uC544 \uC778\uC2A4\uD134\uC2A4\uB85C \uB300\uCCB4\uD569\uB2C8\uB2E4: ${comp.name}`);
          baseEmit.cell(comp, x, y);
          return;
        }
        frame.appendChild(ready);
        ready.x = x;
        ready.y = y;
        setMode(ready, maps, modeId);
        try {
          ready.findAll((n) => n.type === "INSTANCE").forEach((d) => setMode(d, maps, modeId));
        } catch (e) {
        }
      }
    } : baseEmit;
    const H = await renderFlat(opts, true, emit);
    frame.resize(W, H);
    if (opts.stackDarkBelow && ((_f = opts.darkOffset) == null ? void 0 : _f.y) === void 0) frame.y = opts.originY + H + 80;
    setMode(frame, maps, modeId);
    return Math.max(opts.originY, frame.y + H);
  }
  async function decorateSetFlat(set, opts, maps) {
    var _a;
    const rowLabelW = (_a = opts.rowLabelW) != null ? _a : 96;
    const W = specWidth(rowLabelW, opts.colHeaders.length, opts.cellW);
    set.x = 0;
    set.y = opts.originY;
    try {
      set.fills = [specPaint(specBg(opts.contrastBg), false)];
    } catch (e) {
    }
    const H = await renderFlat(opts, false, floatingEmit(opts.originY, 0, set.name));
    set.resize(W, H);
    setLightMode(set, maps);
    return opts.originY + H;
  }
  async function buildCheckbox(maps, originY) {
    const states = [
      { name: "Default", bg: "color/control/bg/default", border: "color/control/border/default" },
      { name: "Hover", bg: "color/control/bg/hover", border: "color/control/border/default" },
      { name: "Checked", bg: "color/control/bg/selected", border: "color/control/border/selected", check: "color/control/indicator/selected" },
      { name: "Disabled", bg: "color/control/bg/disabled", border: "color/control/border/disabled" },
      { name: "Dis+Checked", bg: "color/control/bg/disabled", border: "color/control/border/disabled", check: "color/control/indicator/disabled" }
    ];
    const comps = [];
    for (const s of states) {
      const comp = figma.createComponent();
      comp.name = `State=${s.name}`;
      comp.resize(18, 18);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, s.bg))];
      comp.strokes = [boundPaint(scv(maps, s.border))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      if (s.check) {
        const icon = await makeCheckIcon(scv(maps, s.check));
        comp.appendChild(icon);
        icon.x = 1;
        icon.y = 1;
      }
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Checkbox";
    set.x = 0;
    set.y = originY;
    states.forEach((s, i) => {
      BUILT_COMPS[`Checkbox:${s.name}`] = comps[i];
    });
    BUILT_SETS["Checkbox"] = set;
    const opts = {
      title: "Checkbox",
      colHeaders: states.map((s) => s.name),
      rowLabels: [""],
      cellAt: (_r, c) => comps[c],
      // 열 폭 76 — "Dis+Checked"(12M 기준 73.4px)가 한 줄에 들어가야 한다. 종전 64 에서는 줄바꿈됐다(2026-09-10 실측).
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 76,
      cellH: 44
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildRadio(maps, originY) {
    const states = [
      { name: "Default", bg: "color/control/bg/default", border: "color/control/border/default" },
      { name: "Hover", bg: "color/control/bg/hover", border: "color/control/border/default" },
      { name: "Selected", bg: "color/control/bg/default", border: "color/control/border/selected", dot: "color/control/indicator/selected-alt" },
      { name: "Disabled", bg: "color/control/bg/disabled", border: "color/control/border/disabled" },
      { name: "Dis+Selected", bg: "color/control/bg/disabled", border: "color/control/border/disabled", dot: "color/control/indicator/disabled" }
    ];
    const labels = ["Off", "On"];
    const comps = [];
    const cells = [];
    for (let row = 0; row < labels.length; row++) {
      for (let col = 0; col < states.length; col++) {
        const s = states[col];
        const lab = labels[row];
        const comp = figma.createComponent();
        comp.name = `State=${s.name}, Label=${lab}`;
        comp.layoutMode = "HORIZONTAL";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        comp.fills = [];
        const circle = figma.createFrame();
        circle.name = "circle";
        circle.resize(18, 18);
        circle.cornerRadius = 9;
        circle.fills = [boundPaint(scv(maps, s.bg))];
        circle.strokes = [boundPaint(scv(maps, s.border))];
        circle.strokeWeight = 1;
        circle.strokeAlign = "INSIDE";
        if (s.dot) {
          const dot = figma.createEllipse();
          dot.resize(10, 10);
          dot.fills = [boundPaint(scv(maps, s.dot))];
          circle.appendChild(dot);
          dot.x = 4;
          dot.y = 4;
        }
        comp.appendChild(circle);
        if (lab === "On") {
          const isDis = s.name.indexOf("Dis") === 0 || s.name === "Disabled";
          const labelVar = scv(maps, isDis ? "color/control/label/disabled" : "color/control/label/default");
          comp.appendChild(await makeBoundText("\uB77C\uB514\uC624", 14, "Medium", labelVar));
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Radio";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Radio",
      colHeaders: states.map((s) => s.name),
      rowLabels: labels.map((l) => `Label=${l}`),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 116,
      cellH: 34
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildToggle(maps, originY) {
    const press = ["Off", "On"];
    const sts = ["Default", "Disabled"];
    const comps = [];
    const cells = [];
    for (let row = 0; row < sts.length; row++) {
      for (let col = 0; col < press.length; col++) {
        const st = sts[row];
        const p = press[col];
        const on = p === "On";
        const dis = st === "Disabled";
        const trackKey = dis ? "color/control/bg/disabled" : on ? "color/control/bg/selected" : "color/control/indicator/unselected";
        const comp = figma.createComponent();
        comp.name = `Pressed=${p}, State=${st}`;
        comp.resize(40, 20);
        comp.cornerRadius = 10;
        comp.fills = [boundPaint(scv(maps, trackKey))];
        const knob = figma.createEllipse();
        knob.resize(16, 16);
        const knobKey = dis ? "color/control/indicator/disabled" : "color/control/indicator/selected";
        knob.fills = [boundPaint(scv(maps, knobKey))];
        comp.appendChild(knob);
        knob.y = 2;
        knob.x = on ? 22 : 2;
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Toggle";
    set.x = 0;
    set.y = originY;
    cells.forEach(({ comp, row, col }) => {
      BUILT_COMPS[`Toggle:${press[col]}:${sts[row]}`] = comp;
    });
    const opts = {
      title: "Toggle",
      colHeaders: press.map((p) => `Pressed=${p}`),
      rowLabels: sts.map((s) => `State=${s}`),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 72,
      cellH: 36
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildListRow(maps, originY) {
    const ROW_W = 360;
    const numv = (k) => requireVar(maps.foundationNumber, k, "Foundation Number");
    const types = ["Nav", "Value", "Read", "Pick", "Agree", "Switch", "Thumb"];
    const states = ["Default", "Pressed", "Disabled"];
    const bgKey = (st) => st === "Pressed" ? "color/bg/level-1" : "color/bg/level-0";
    const titleKey = (st) => st === "Disabled" ? "color/text/state/disabled" : "color/text/title/primary";
    const descKey = (st) => st === "Disabled" ? "color/text/state/disabled" : "color/text/body/tertiary";
    const valueKey = (st) => st === "Disabled" ? "color/text/state/disabled" : "color/text/body/primary";
    const iconKey = (st) => st === "Disabled" ? "color/icon/gray-light" : "color/icon/gray";
    const comps = [];
    const cells = [];
    for (const t of types) {
      for (const st of states) {
        const comp = figma.createComponent();
        comp.name = `Type=${t}, State=${st}`;
        comp.layoutMode = "HORIZONTAL";
        comp.counterAxisAlignItems = "CENTER";
        comp.resize(ROW_W, 1);
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "AUTO";
        comp.setBoundVariable("paddingLeft", numv("spacing/20"));
        comp.setBoundVariable("paddingRight", numv("spacing/20"));
        comp.setBoundVariable("paddingTop", numv("spacing/12"));
        comp.setBoundVariable("paddingBottom", numv("spacing/12"));
        comp.setBoundVariable("itemSpacing", numv("spacing/12"));
        comp.fills = [boundPaint(scv(maps, bgKey(st)))];
        if (t === "Pick" || t === "Agree") {
          const chkState = st === "Disabled" ? "Disabled" : "Default";
          const chk = await reuseVariant("Checkbox", `Checkbox:${chkState}`, [`State=${chkState}`]);
          const contents = [];
          if (chk) {
            const inst = chk.createInstance();
            inst.name = "control";
            contents.push(inst);
          } else {
            console.warn(`[List Row] Checkbox \uB97C \uCC3E\uC9C0 \uBABB\uD574 \uC784\uC2DC \uB3C4\uD615\uC73C\uB85C \uADF8\uB9BD\uB2C8\uB2E4 (State=${chkState}) \u2014 Checkbox \uB97C \uBA3C\uC800 \uC124\uCE58\uD558\uBA74 \uC778\uC2A4\uD134\uC2A4\uB85C \uBD99\uC2B5\uB2C8\uB2E4.`);
            const box = figma.createFrame();
            box.name = "control";
            box.resize(18, 18);
            box.cornerRadius = 2;
            box.fills = [boundPaint(scv(maps, st === "Disabled" ? "color/control/bg/disabled" : "color/control/bg/default"))];
            box.strokes = [boundPaint(scv(maps, st === "Disabled" ? "color/control/border/disabled" : "color/control/border/default"))];
            box.strokeWeight = 1;
            box.strokeAlign = "INSIDE";
            contents.push(box);
          }
          const radioSet = await getBuiltSet("Radio");
          await makeSlot(
            comp,
            "\uC67C\uCABD \uCE78",
            "\uACE0\uB974\uB294 \uD45C\uC2DC\uAC00 \uB4E4\uC5B4\uAC00\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 \uCCB4\uD06C\uC774\uBA70, \uB4E4\uC5B4 \uC788\uB294 \uAC83\uC744 \uBE7C\uACE0 \uB77C\uB514\uC624\xB7\uC544\uC774\uCF58 \uAC19\uC740 \uB2E4\uB978 \uBD80\uD488\uC744 \uADF8 \uC790\uB9AC\uC5D0 \uB123\uB294\uB2E4. \uBE44\uC6CC \uB450\uBA74 \uC67C\uCABD \uCE78\uC774 \uC5C6\uB294 \uC904\uC774 \uB41C\uB2E4.",
            contents,
            radioSet ? [{ type: "COMPONENT_SET", key: radioSet.key }] : [],
            {
              layoutMode: "HORIZONTAL",
              primaryAxisSizingMode: "AUTO",
              counterAxisSizingMode: "AUTO",
              primaryAxisAlignItems: "CENTER",
              counterAxisAlignItems: "CENTER",
              itemSpacing: 0
            }
          );
          for (const c of contents) {
            try {
              c.layoutSizingHorizontal = "FIXED";
              c.layoutSizingVertical = "FIXED";
            } catch (e) {
            }
          }
        } else if (t === "Thumb") {
          const box = figma.createFrame();
          box.name = "\uC790\uB9AC\uD45C\uC2DC";
          box.resize(40, 40);
          box.setBoundVariable("width", numv("sizing/40"));
          box.setBoundVariable("height", numv("sizing/40"));
          box.fills = [boundPaint(scv(maps, "color/bg/level-2"))];
          bindRadius(box, maps, "radius/4");
          await makeSlot(
            comp,
            "\uADF8\uB9BC",
            "\uC0AC\uC9C4\xB7\uC544\uC774\uCF58\xB7\uC544\uBC14\uD0C0\uAC00 \uB4E4\uC5B4\uAC00\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 40 \uAC01 \uC790\uB9AC\uD45C\uC2DC\uC774\uBA70, **\uC790\uB9AC\uD45C\uC2DC\uB97C \uBE7C\uACE0 \uB123\uC744 \uAC83\uC744 \uADF8 \uC790\uB9AC\uC5D0 \uB123\uB294\uB2E4**(\uB458\uC744 \uAC19\uC774 \uB450\uBA74 \uC67C\uCABD \uCE78\uC774 \uB458\uC774 \uB41C\uB2E4). \uBE44\uC6CC \uB450\uBA74 \uC790\uB9AC\uD45C\uC2DC\uB9CC \uB0A8\uB294\uB2E4. \uC904 \uB192\uC774(68)\uB294 \uAE00 \uC790\uB9AC\uAC00 \uC815\uD558\uBBC0\uB85C 40 \uBCF4\uB2E4 \uD070 \uAC83\uC744 \uB123\uC9C0 \uC54A\uB294\uB2E4.",
            [box],
            [],
            {
              layoutMode: "HORIZONTAL",
              primaryAxisSizingMode: "AUTO",
              counterAxisSizingMode: "AUTO",
              primaryAxisAlignItems: "CENTER",
              counterAxisAlignItems: "CENTER",
              itemSpacing: 0
            }
          );
          box.layoutSizingHorizontal = "FIXED";
          box.layoutSizingVertical = "FIXED";
        }
        const text2 = figma.createFrame();
        text2.name = "text";
        text2.layoutMode = "VERTICAL";
        text2.primaryAxisSizingMode = "AUTO";
        text2.counterAxisSizingMode = "AUTO";
        text2.primaryAxisAlignItems = "CENTER";
        text2.fills = [];
        text2.setBoundVariable("itemSpacing", numv("spacing/2"));
        text2.minHeight = 44;
        try {
          text2.setBoundVariable("minHeight", numv("sizing/44"));
        } catch (e) {
        }
        text2.appendChild(await makeBoundText("\uC81C\uBAA9", 16, "Medium", scv(maps, titleKey(st)), "title/16M"));
        const descNode = await makeBoundText("\uC124\uBA85", 14, "Regular", scv(maps, descKey(st)), "body/14R");
        descNode.name = "description";
        text2.appendChild(descNode);
        comp.appendChild(text2);
        text2.layoutGrow = 1;
        text2.layoutSizingHorizontal = "FILL";
        const needsTrail = t === "Nav" || t === "Value" || t === "Agree" || t === "Switch";
        if (needsTrail) {
          const trailContents = [];
          if (t === "Value") {
            trailContents.push(await makeBoundText("\uAC12", 14, "Regular", scv(maps, valueKey(st)), "body/14R"));
          }
          if (t === "Switch") {
            const tgState = st === "Disabled" ? "Disabled" : "Default";
            const tg = await reuseVariant("Toggle", `Toggle:On:${tgState}`, ["Pressed=On", `State=${tgState}`]);
            if (tg) {
              const inst = tg.createInstance();
              inst.name = "toggle";
              trailContents.push(inst);
            } else {
              console.warn(`[List Row] Toggle \uC744 \uCC3E\uC9C0 \uBABB\uD574 \uC784\uC2DC \uB3C4\uD615\uC73C\uB85C \uADF8\uB9BD\uB2C8\uB2E4 (State=${tgState}) \u2014 Toggle \uC744 \uBA3C\uC800 \uC124\uCE58\uD558\uBA74 \uC778\uC2A4\uD134\uC2A4\uB85C \uBD99\uC2B5\uB2C8\uB2E4.`);
              const track2 = figma.createFrame();
              track2.name = "toggle";
              track2.resize(40, 20);
              track2.cornerRadius = 10;
              track2.fills = [boundPaint(scv(maps, st === "Disabled" ? "color/control/bg/disabled" : "color/control/bg/selected"))];
              const knob = figma.createEllipse();
              knob.resize(16, 16);
              knob.fills = [boundPaint(scv(maps, st === "Disabled" ? "color/control/indicator/disabled" : "color/control/indicator/selected"))];
              track2.appendChild(knob);
              knob.x = 22;
              knob.y = 2;
              trailContents.push(track2);
            }
          } else {
            trailContents.push(await makeIconInstance("chevron", scv(maps, iconKey(st)), 24, CHEVRON_RIGHT_SVG, 0, { wrap: false }));
          }
          const trail = await makeSlot(
            comp,
            "\uC624\uB978\uCABD \uCE78",
            "\uC904 \uC624\uB978\uCABD\uC5D0 \uBD99\uB294 \uAC83\uC774 \uB4E4\uC5B4\uAC00\uB294 \uC790\uB9AC. \uC720\uD615\uC774 \uAE30\uBCF8\uC744 \uC900\uB2E4 \u2014 \uC774\uB3D9\xB7\uB3D9\uC758\uB294 \uD654\uC0B4\uD45C, \uAC12 \uC904\uC740 \uAC12+\uD654\uC0B4\uD45C, \uD1A0\uAE00 \uC904\uC740 \uD1A0\uAE00. \uB4E4\uC5B4 \uC788\uB294 \uAC83\uC744 \uBE7C\uACE0 \uC791\uC740 \uBC84\uD2BC\xB7\uBC30\uC9C0 \uAC19\uC740 \uB2E4\uB978 \uBD80\uD488\uC744 \uADF8 \uC790\uB9AC\uC5D0 \uB123\uC744 \uC218 \uC788\uACE0, \uBE44\uC6CC \uB450\uBA74 \uC624\uB978\uCABD\uC774 \uC5C6\uB294 \uC904\uC774 \uB41C\uB2E4.",
            trailContents,
            [],
            {
              layoutMode: "HORIZONTAL",
              primaryAxisSizingMode: "AUTO",
              counterAxisSizingMode: "AUTO",
              primaryAxisAlignItems: "CENTER",
              counterAxisAlignItems: "CENTER"
            }
          );
          trail.setBoundVariable("itemSpacing", numv("spacing/8"));
          for (const c of trailContents) {
            try {
              c.layoutSizingHorizontal = "FIXED";
              c.layoutSizingVertical = "FIXED";
            } catch (e) {
            }
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, type: t, state: st });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "List Row";
    set.x = 0;
    set.y = originY;
    const descPropId = set.addComponentProperty("\uC124\uBA85 \uBCF4\uC784", "BOOLEAN", true);
    for (const c of comps) {
      const textFrame = c.findChild((n) => n.name === "text");
      const desc = textFrame ? textFrame.findOne((n) => n.name === "description") : null;
      if (desc) desc.componentPropertyReferences = { visible: descPropId };
    }
    cells.forEach((c) => {
      BUILT_COMPS[`ListRow:${c.type}:${c.state}`] = c.comp;
    });
    const opts = {
      title: "List Row",
      colHeaders: states,
      rowLabels: types,
      cellAt: (ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.type === types[ri] && x.state === states[ci])) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 88,
      rowLabelW: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildChip(maps, originY) {
    var _a;
    const sizes = [
      { size: "SM", brk: "PC", h: 28, font: 12, pad: 16 },
      { size: "SM", brk: "Mobile", h: 30, font: 14, pad: 12 },
      { size: "MD", brk: "PC", h: 34, font: 14, pad: 16 }
    ];
    const states = ["Default", "Hover", "Selected", "Disabled"];
    const variants = ["Line", "Solid"];
    const slot = (st, v) => st === "Default" ? { bg: "default", bd: "default", lb: "default" } : st === "Hover" ? v === "line" ? { bg: "hover", bd: "default", lb: "default" } : { bg: "hover", bd: "hover", bdGroup: "bg", lb: "default" } : st === "Selected" ? { bg: "selected", bd: "selected", lb: "selected" } : { bg: "disabled", bd: "disabled", lb: "disabled" };
    const comps = [];
    const cells = [];
    let row = 0;
    for (const variant of variants) {
      const v = variant.toLowerCase();
      for (const sc of sizes) {
        for (let col = 0; col < states.length; col++) {
          const ss = slot(states[col], v);
          const comp = figma.createComponent();
          comp.name = `Size=${sc.size}, State=${states[col]}, Variant=${variant}, Break=${sc.brk}`;
          comp.layoutMode = "HORIZONTAL";
          comp.primaryAxisAlignItems = "CENTER";
          comp.counterAxisAlignItems = "CENTER";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "FIXED";
          comp.paddingLeft = sc.pad;
          comp.paddingRight = sc.pad;
          bindRadius(comp, maps, "radius/full");
          comp.fills = [boundPaint(scv(maps, `color/chip/${v}/bg/${ss.bg}`))];
          comp.strokes = [boundPaint(scv(maps, `color/chip/${v}/${(_a = ss.bdGroup) != null ? _a : "border"}/${ss.bd}`))];
          comp.strokeWeight = 1;
          comp.strokeAlign = "INSIDE";
          comp.appendChild(await makeBoundText("\uB77C\uBCA8", sc.font, "Medium", scv(maps, `color/chip/${v}/label/${ss.lb}`)));
          comp.resize(comp.width, sc.h);
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, row, col, variant, size: sc.size, brk: sc.brk, state: states[col] });
        }
        row++;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Chip";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Chip",
      platforms: [{ name: "PC", sizes: ["SM", "MD"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: variants,
      // Line / Solid
      colHeaders: states,
      cellAt: (platName, size, ri, ci) => {
        var _a2, _b;
        return (_b = (_a2 = cells.find((x) => x.variant === variants[ri] && x.size === size && x.brk === platName && x.state === states[ci])) == null ? void 0 : _a2.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 96,
      cellH: 48,
      rowLabelW: 96
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildInput(maps, originY, originX = INPUT_SHEET_X) {
    const fc = (k) => `color/form-control/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC785\uB825", tc: "text/placeholder" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Focus", bg: "bg/selected", border: "border/selected", txt: "\uD14D\uC2A4\uD2B8", tc: "text/selected" },
      { name: "Error", bg: "bg/default", border: "border/error", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Correct", bg: "bg/default", border: "border/correct", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Read-Only", bg: "bg/disabled", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/read-only" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uC785\uB825", tc: "text/disabled" }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, padL: 12, padR: 8, font: 12, head: "XXSM" },
      { size: "XSM", brk: "PC", h: 34, padL: 12, padR: 8, font: 14, head: "XSM" },
      { size: "MD", brk: "PC", h: 44, padL: 16, padR: 12, font: 14, head: "MD" },
      // Mobile 은 누르는 영역이 48×48 이라 padR 을 두면 아이콘이 안쪽으로 밀린다.
      // padR 0 으로 누르는 영역을 칸 끝에 붙인다. (river 지시 2026-09-04)
      { size: "MD", brk: "Mobile", h: 48, padL: 16, padR: 0, font: 14, head: "MD\xB7M" }
    ];
    const messages = ["Off", "On"];
    const comps = [];
    const cells = [];
    const wrapSuffixAction = (icon, actionName, hitSize, opts2) => {
      const action = figma.createFrame();
      action.name = actionName;
      action.layoutMode = "HORIZONTAL";
      action.primaryAxisAlignItems = (opts2 == null ? void 0 : opts2.pullInward) ? "MAX" : "CENTER";
      action.counterAxisAlignItems = "CENTER";
      action.primaryAxisSizingMode = "FIXED";
      action.counterAxisSizingMode = "FIXED";
      action.fills = [];
      action.resize(hitSize, hitSize);
      if ((opts2 == null ? void 0 : opts2.hover) !== false) {
        const hoverBg = figma.createRectangle();
        hoverBg.name = `${actionName}-hover-bg`;
        hoverBg.fills = [boundPaint(scv(maps, fc("bg/hover")))];
        bindRadius(hoverBg, maps, "radius/4");
        hoverBg.resize(hitSize, hitSize);
        hoverBg.visible = false;
        action.appendChild(hoverBg);
        hoverBg.layoutPositioning = "ABSOLUTE";
        hoverBg.x = 0;
        hoverBg.y = 0;
        hoverBg.constraints = { horizontal: "STRETCH", vertical: "STRETCH" };
      }
      action.appendChild(icon);
      return action;
    };
    for (const sc of sizes) {
      for (const st of states) {
        for (const msg of messages) {
          const dis = st.name === "Disabled";
          const field = figma.createFrame();
          field.name = "field";
          field.layoutMode = "HORIZONTAL";
          field.counterAxisAlignItems = "CENTER";
          field.primaryAxisSizingMode = "FIXED";
          field.counterAxisSizingMode = "FIXED";
          field.paddingLeft = sc.padL;
          field.paddingRight = sc.padR;
          field.paddingTop = 0;
          field.paddingBottom = 0;
          field.cornerRadius = 4;
          field.fills = [boundPaint(scv(maps, fc(st.bg)))];
          field.strokes = [boundPaint(scv(maps, fc(st.border)))];
          field.strokeWeight = 1;
          field.strokeAlign = "INSIDE";
          const textNode = await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc)));
          field.primaryAxisAlignItems = "MIN";
          let clearIcon = null;
          if (st.name === "Focus") {
            const lead = figma.createFrame();
            lead.name = "lead";
            lead.fills = [];
            lead.layoutMode = "HORIZONTAL";
            lead.counterAxisAlignItems = "CENTER";
            lead.primaryAxisSizingMode = "AUTO";
            lead.counterAxisSizingMode = "AUTO";
            lead.itemSpacing = 4;
            lead.appendChild(textNode);
            lead.appendChild(makeCaret(scv(maps, fc("text-cursor"))));
            field.appendChild(lead);
            lead.layoutGrow = 1;
            lead.layoutSizingHorizontal = "FILL";
            clearIcon = await makeClearIcon(scv(maps, fc("icon/default")), fcIconPx(sc.h, 0));
          } else {
            textNode.layoutGrow = 1;
            field.appendChild(textNode);
          }
          const eye = await makeIconInstance("eye", scv(maps, fc("icon/default")), sc.size === "XXSM" ? 20 : 24, EYE_OFF_SVG);
          eye.name = "eye-icon";
          const actionHitSize = sc.brk === "Mobile" ? 48 : 28;
          const isMobile = sc.brk === "Mobile";
          const passwordAction = wrapSuffixAction(eye, "password-action", actionHitSize, {
            hover: !isMobile,
            pullInward: isMobile && clearIcon !== null
          });
          passwordAction.visible = false;
          const trail = figma.createFrame();
          trail.name = "trail";
          trail.fills = [];
          trail.layoutMode = "HORIZONTAL";
          trail.counterAxisAlignItems = "CENTER";
          trail.primaryAxisSizingMode = "AUTO";
          trail.counterAxisSizingMode = "AUTO";
          trail.itemSpacing = isMobile ? 0 : 2;
          trail.appendChild(passwordAction);
          if (clearIcon) trail.appendChild(wrapSuffixAction(clearIcon, "clear-action", actionHitSize, { hover: !isMobile }));
          field.appendChild(trail);
          field.resize(200, sc.h);
          const comp = figma.createComponent();
          comp.name = `Size=${sc.size}, State=${st.name}, Message=${msg}, Break=${sc.brk}`;
          comp.layoutMode = "VERTICAL";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "AUTO";
          comp.itemSpacing = 6;
          comp.fills = [];
          comp.appendChild(field);
          if (msg === "On") {
            const msgColor = dis ? "color/text/state/disabled" : st.name === "Error" ? "color/text/state/caution" : st.name === "Correct" ? "color/text/state/correct" : "color/text/state/caption";
            comp.appendChild(await makeBoundText("\uC548\uB0B4 \uBA54\uC138\uC9C0", 12, "Regular", scv(maps, msgColor)));
          }
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name, message: msg });
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Input";
    const pwIconPropId = set.addComponentProperty("Password Icon", "BOOLEAN", false);
    const pwHoverPropId = set.addComponentProperty("Password Action Hover", "BOOLEAN", false);
    const clearHoverPropId = set.addComponentProperty("Clear Action Hover", "BOOLEAN", false);
    for (const c of comps) {
      const f = c.findChild((n) => n.name === "field");
      const passwordAction = f ? f.findOne((n) => n.name === "password-action") : null;
      const passwordHover = f ? f.findOne((n) => n.name === "password-action-hover-bg") : null;
      const clearHover = f ? f.findOne((n) => n.name === "clear-action-hover-bg") : null;
      if (passwordAction) passwordAction.componentPropertyReferences = { visible: pwIconPropId };
      if (passwordHover) passwordHover.componentPropertyReferences = { visible: pwHoverPropId };
      if (clearHover) clearHover.componentPropertyReferences = { visible: clearHoverPropId };
    }
    const OX = originX;
    set.x = OX;
    set.y = originY;
    const groups = [
      { name: "\uAE30\uBCF8", msg: "Off" },
      { name: "\uC548\uB0B4\uBA54\uC2DC\uC9C0", msg: "On" }
    ];
    const opts = {
      title: "Input",
      // 플랫폼(PC/Mobile) → 사이즈 → 메시지 그룹(rowLabels)으로 구분 (Button·SelectBox 패턴과 동일)
      platforms: [
        // cellAt 이 sizeName 으로 cells.size 를 직매칭(x.size === sizeName)하므로
        // cells 의 실제 키(XXSM/XSM/MD)와 동일해야 한다. Issue 8 리네임 잔재(XSMALL/SMALL/MEDIUM)였음 — PC·Mobile 스펙 시트 빈칸 유발.
        { name: "PC", sizes: ["XXSM", "XSM", "MD"] },
        { name: "Mobile", sizes: ["MD"] }
      ],
      rowLabels: groups.map((g) => g.name),
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, sizeName, ri, ci) => {
        var _a, _b;
        const g = groups[ri];
        if (!g) return null;
        return (_b = (_a = cells.find((x) => x.size === sizeName && x.brk === platName && x.state === states[ci].name && x.message === g.msg)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      // 세트(원본) → Light → Dark 를 OX 기준 가로로 나란히. specWidth(110,7,224)=1726, 컬럼 간 80 gap.
      offsetX: OX,
      lightX: OX + 1726 + 80,
      darkX: OX + (1726 + 80) * 2,
      originY,
      cellW: 224,
      cellH: 100,
      rowLabelW: 110
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  function makeStrokeIcon(svg, strokeVar) {
    const node = figma.createNodeFromSvg(svg);
    node.name = "icon";
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      v.strokes = [boundPaint(strokeVar)];
      v.fills = [];
    });
    return node;
  }
  function makeCaret(colorVar) {
    const caret = figma.createRectangle();
    caret.name = "caret";
    caret.resize(1, 16);
    caret.fills = [boundPaint(colorVar)];
    caret.strokes = [];
    return caret;
  }
  var ICON_KEYS = {
    remove: "24b2df622d341e0af21cd4b23b4a7d23b97a5ea7",
    // 삭제(원+X) 439:84
    close: "2a1abbd3597b536e34fd9523fb61eade3afe9934",
    // 닫기(plain-X, 원 없음) ic_닫기 89:4927 — 바텀시트/모달 닫기. remove(원+X)와 구분
    check: "5ab251e0d90adb555ee2fa316f84e86041f19916",
    // 확인(체크마크 ✓) 97:167 — 체크박스 내부용(ic_체크는 박스형이라 ic_확인 사용)
    search: "6b764af642b8883e892754281950da0e971224d7",
    // 찾기/조회(돋보기) 97:127
    clock: "ca1d043ac09be07f827e939be3d8c3c7af8a8dd9",
    // 시간,시계 97:271
    calendar: "ea0ffc118c38048f2cdfb5620be31c120426bb7a",
    // 날짜,달력 70:664
    menu: "5157e9edc76358e2e6bc1a5ebc1539ccf5f2e787",
    // 메뉴(햄버거) 97:227
    account: "a423e2e05cfff2f93062d6a83d6f3bdf79ca9647",
    // 계정/사용자 86:58
    chevron: "e1ac97aa82f4e52f257ac1c0ea77fd09d0e5f581",
    // 화살표,더보기(쉐브론 › 우향 기준) 419:69 — 방향은 rotation 으로(우0·상90·좌180·하270 — Figma 회전은 반시계)
    globe: "dee16df7e4ccddbd5dd7aa1d2fbf93f841f5dee2",
    // 인터넷(지구본) 35:3317 — GNB 언어(사용자 지정)
    eye: "d4e9eb5b7e193ee291aa2a7e04396c8de2d2dae7",
    // 비밀번호 미표시(눈+슬래시 ic_비밀번호미표시 Line) — Input Password Icon boolean 기본값. 표시 눈은 인스턴스 스왑으로 교체
    eye_show: "b130623bad9bf035e273501b404bf7a245af1460",
    // 비밀번호 표시(뜬 눈 ic_비밀번호표시 Line) — 웹 Password 옵션의 표시 중 아이콘(river C4, 2026-09-04). Figma 변형 자체는 위 eye(미표시) 하나만 쓰고, 표시 눈은 웹에서만 별도 스왑한다.
    home: "6bf422c937034ce15f6814e5c430d8f85953ed4e",
    // 홈(ic_홈 Solid) 97:292 — V2.2 아이콘 라이브러리. Mobile Bottom Nav
    // 하단 내비의 나머지 칸(2026-09-14 river 승인 "A로 진행해줘"). 홈이 Solid 라 같은 결로 Solid 를 쓴다.
    navSearch: "e86d0bce3a9de2bf1ed37b29ee56278bf4927cb9",
    // ic_찾기/조회 Solid 97:124 — 입력칸이 쓰는 search(Line)와 다른 변형이다
    navNotification: "0994ea9c97ad4c65a9d461a0f0b7381675946973",
    // ic_알림 Solid 97:260 — 헤더의 ic_알림(신규)(빨간 점)와 다른 아이콘
    navSettings: "175fb8933701ad7db5485a44dd07e26d34dfeef2",
    // ic_사용환경설정 Solid 97:312 — river 선택(톱니바퀴 · ic_기기설정(스패너) 아님)
    mobileHeaderBack: "7190e284d345ae19a679a16ed7bceafbd54073ca",
    // ic_이전 / Solid — Mobile Header
    mobileHeaderClose: "54469d54f16ed38de2d7b420b0e2195e4cf7c118",
    // ic_닫기 / Solid — Mobile Header
    mobileHeaderNotification: "13cf1b580ec982fda488f9318c6821930ddfb26e",
    // ic_알림(신규) / Line — Mobile Header
    mobileHeaderArrowDown: "6babc3f493e48be1e7191a7b8a68945833039fe8"
    // ic_화살표, 더보기, 다음장 / Solid(419:68) — Mobile Header, 아래 방향 -90°
  };
  var EYE_OFF_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" stroke="#353535" stroke-width="1.5"/><circle cx="12" cy="12" r="2.5" stroke="#353535" stroke-width="1.5"/><path d="M4 4l16 16" stroke="#353535" stroke-width="1.5"/></svg>`;
  var HOME_SVG = `<svg width="32" height="32" viewBox="0 0 32 32" fill="none"><path d="M16 5 28 15v11a1 1 0 0 1-1 1h-6v-8h-10v8H5a1 1 0 0 1-1-1V15L16 5Z" fill="#757575"/></svg>`;
  function rebindIconColor(node, colorVar) {
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "BOOLEAN_OPERATION"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      try {
        if (v.isMask) return;
        if (Array.isArray(v.strokes) && v.strokes.some((p) => p.visible !== false)) v.strokes = [boundPaint(colorVar)];
        if (Array.isArray(v.fills) && v.fills.some((p) => p.visible !== false)) v.fills = [boundPaint(colorVar)];
      } catch (e) {
      }
    });
  }
  async function makeIconInstance(role, colorVar, size, fallbackSvg, rotation = 0, opts = {}) {
    const useWrap = opts.wrap !== false;
    try {
      const comp = await figma.importComponentByKeyAsync(ICON_KEYS[role]);
      const inst = comp.createInstance();
      if (!opts.keepName) inst.name = role;
      if (size && size !== inst.width) inst.resize(size, size);
      rebindIconColor(inst, colorVar);
      if (rotation) {
        inst.rotation = rotation;
        if (!useWrap) return inst;
        const wrap = figma.createFrame();
        wrap.name = role;
        wrap.fills = [];
        wrap.clipsContent = false;
        wrap.layoutMode = "HORIZONTAL";
        wrap.primaryAxisAlignItems = "CENTER";
        wrap.counterAxisAlignItems = "CENTER";
        wrap.primaryAxisSizingMode = "FIXED";
        wrap.counterAxisSizingMode = "FIXED";
        wrap.resize(size || inst.width, size || inst.height);
        wrap.appendChild(inst);
        return wrap;
      }
      return inst;
    } catch (e) {
      console.warn(`icon ${role} import \uC2E4\uD328 \u2192 \uBCA1\uD130 \uD3F4\uBC31:`, e);
      const node = figma.createNodeFromSvg(fallbackSvg);
      node.name = role;
      rebindIconColor(node, colorVar);
      return node;
    }
  }
  async function makeRequiredIconInstance(role, colorVar, size, accentVar, rotation = 0) {
    const key = ICON_KEYS[role];
    if (!key) throw new Error(`Mobile Header \uC544\uC774\uCF58 \uD0A4 \uB204\uB77D: ${role}`);
    const remote = await figma.importComponentByKeyAsync(key);
    const inst = remote.createInstance();
    inst.name = role;
    if (size && (inst.width !== size || inst.height !== size)) inst.resize(size, size);
    rebindIconColor(inst, colorVar);
    if (rotation) inst.rotation = rotation;
    if (accentVar) {
      const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "BOOLEAN_OPERATION"];
      const visible = inst.findAll((n) => SHAPES.includes(n.type) && n.visible).filter((n) => !n.isMask);
      const namedAccent = visible.find((n) => /badge|dot|new|red|알림점/i.test(n.name));
      const accent = namedAccent != null ? namedAccent : visible.slice().sort((a, b) => a.width * a.height - b.width * b.height)[0];
      if (!accent) throw new Error("Mobile Header \uC54C\uB9BC \uC544\uC774\uCF58\uC758 accent \uB808\uC774\uC5B4\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      try {
        if (Array.isArray(accent.strokes) && accent.strokes.some((p) => p.visible !== false)) accent.strokes = [boundPaint(accentVar)];
        if (Array.isArray(accent.fills) && accent.fills.some((p) => p.visible !== false)) accent.fills = [boundPaint(accentVar)];
      } catch (e) {
        throw new Error("Mobile Header \uC54C\uB9BC \uC544\uC774\uCF58 accent Semantic \uBC14\uC778\uB529\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.");
      }
    }
    return inst;
  }
  function centerIconInBox(node, box, sz) {
    const bb = node.absoluteBoundingBox;
    const pb = box.absoluteBoundingBox;
    if (!bb || !pb) {
      node.x = (sz - node.width) / 2;
      node.y = (sz - node.height) / 2;
      return;
    }
    node.x += pb.x + (sz - bb.width) / 2 - bb.x;
    node.y += pb.y + (sz - bb.height) / 2 - bb.y;
  }
  var REMOVE_ICON_SVG = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M16 8C16 3.58588 12.4141 0 8 0C3.58588 0 0 3.58588 0 8C0 12.4141 3.58588 16 8 16C12.4141 16 16 12.4141 16 8ZM8 15.0588C4.10353 15.0588 0.941176 11.8965 0.941176 8C0.941176 4.10353 4.10353 0.941176 8 0.941176C11.8965 0.941176 15.0588 4.10353 15.0588 8C15.0588 11.8965 11.8965 15.0588 8 15.0588Z" fill="#353535"/><path d="M5.5 5.5L10.8333 10.8333" stroke="#353535" stroke-width="1.5" stroke-linejoin="round"/><path d="M10.8333 5.5L5.5 10.8333" stroke="#353535" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
  var CLOSE_ICON_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M6 6L18 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round"/><path d="M18 6L6 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round"/></svg>`;
  async function makeClearIcon(colorVar, size = 0) {
    return makeIconInstance("remove", colorVar, size, REMOVE_ICON_SVG);
  }
  var fcIconPx = (h, _base) => h <= 28 ? 20 : 24;
  var SEARCH_MIN_W = 200;
  async function buildSearch(maps, originY) {
    const fc = (k) => `color/form-control/${k}`;
    const MAG = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="#000" stroke-width="1.3"/><path d="M10.6 10.6L14 14" stroke="#000" stroke-width="1.3" stroke-linecap="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uAC80\uC0C9", tc: "text/placeholder", icon: "icon/default" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uAC80\uC0C9\uC5B4", tc: "text/default", icon: "icon/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uAC80\uC0C9", tc: "text/disabled", icon: "icon/disabled" }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12, padL: 12, padR: 8 },
      { size: "XSM", brk: "PC", h: 34, font: 14, padL: 12, padR: 8 },
      { size: "MD", brk: "PC", h: 44, font: 14, padL: 16, padR: 12 },
      { size: "MD", brk: "Mobile", h: 48, font: 14, padL: 16, padR: 0 }
    ];
    const wrapAction = (icon, actionName, hitSize, opts2) => {
      const action = figma.createFrame();
      action.name = actionName;
      action.layoutMode = "HORIZONTAL";
      action.primaryAxisAlignItems = (opts2 == null ? void 0 : opts2.pullInward) ? "MAX" : "CENTER";
      action.counterAxisAlignItems = "CENTER";
      action.primaryAxisSizingMode = "FIXED";
      action.counterAxisSizingMode = "FIXED";
      action.fills = [];
      action.resize(hitSize, hitSize);
      if ((opts2 == null ? void 0 : opts2.hover) !== false) {
        const hoverBg = figma.createRectangle();
        hoverBg.name = `${actionName}-hover-bg`;
        hoverBg.fills = [boundPaint(scv(maps, fc("bg/hover")))];
        bindRadius(hoverBg, maps, "radius/4");
        hoverBg.resize(hitSize, hitSize);
        hoverBg.visible = false;
        action.appendChild(hoverBg);
        hoverBg.layoutPositioning = "ABSOLUTE";
        hoverBg.x = 0;
        hoverBg.y = 0;
        hoverBg.constraints = { horizontal: "STRETCH", vertical: "STRETCH" };
      }
      action.appendChild(icon);
      return action;
    };
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.paddingLeft = sc.padL;
        comp.paddingRight = sc.padR;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.cornerRadius = 4;
        comp.fills = [boundPaint(scv(maps, fc(st.bg)))];
        comp.strokes = [boundPaint(scv(maps, fc(st.border)))];
        comp.strokeWeight = 1;
        comp.strokeAlign = "INSIDE";
        const textNode = await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc)));
        const actionHitSize = sc.brk === "Mobile" ? 48 : 28;
        if (st.name === "Filled") {
          comp.appendChild(textNode);
          const trail = figma.createFrame();
          trail.name = "trail";
          trail.fills = [];
          trail.layoutMode = "HORIZONTAL";
          trail.counterAxisAlignItems = "CENTER";
          trail.primaryAxisSizingMode = "AUTO";
          trail.counterAxisSizingMode = "AUTO";
          trail.itemSpacing = sc.brk === "Mobile" ? 0 : 4;
          const searchIsMobile = sc.brk === "Mobile";
          trail.appendChild(wrapAction(await makeClearIcon(scv(maps, fc("icon/default")), fcIconPx(sc.h, 0)), "clear-action", actionHitSize, { hover: !searchIsMobile, pullInward: searchIsMobile }));
          trail.appendChild(wrapAction(await makeIconInstance("search", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), MAG), "search-action", actionHitSize, { hover: !searchIsMobile }));
          comp.appendChild(trail);
        } else {
          comp.appendChild(textNode);
          comp.appendChild(wrapAction(await makeIconInstance("search", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), MAG), "search-action", actionHitSize, { hover: sc.brk !== "Mobile" }));
        }
        comp.resize(SEARCH_MIN_W, sc.h);
        try {
          comp.minWidth = SEARCH_MIN_W;
        } catch (e) {
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Search Input";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Search Input",
      platforms: [
        { name: "PC", sizes: ["XXSM", "XSM", "MD"] },
        { name: "Mobile", sizes: ["MD"] }
      ],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, sizeName, _ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === sizeName && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      // 칸 폭은 부품 폭(200)보다 넓어야 서로 안 붙는다 — SEARCH_MIN_W 를 따라간다.
      offsetX: 0,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: SEARCH_MIN_W + 24,
      cellH: 60,
      rowLabelW: 0
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTextarea(maps, originY) {
    const fc = (k) => `color/form-control/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC785\uB825", tc: "text/placeholder" },
      { name: "Focus", bg: "bg/selected", border: "border/selected", txt: "\uD14D\uC2A4\uD2B8", tc: "text/selected" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uC785\uB825", tc: "text/disabled" },
      { name: "Readonly", bg: "bg/disabled", border: "border/default", txt: "\uD14D\uC2A4\uD2B8", tc: "text/read-only" }
    ];
    const comps = [];
    const cells = [];
    for (let row = 0; row < states.length; row++) {
      const st = states[row];
      const comp = figma.createComponent();
      comp.name = `State=${st.name}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "MIN";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(240, 80);
      comp.paddingLeft = 12;
      comp.paddingRight = 12;
      comp.paddingTop = 10;
      comp.paddingBottom = 10;
      comp.cornerRadius = 4;
      comp.fills = [boundPaint(scv(maps, fc(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, fc(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const textNode = await makeBoundText(st.txt, 14, "Regular", scv(maps, fc(st.tc)));
      if (st.name === "Focus") {
        const lead = figma.createFrame();
        lead.name = "lead";
        lead.fills = [];
        lead.layoutMode = "HORIZONTAL";
        lead.counterAxisAlignItems = "CENTER";
        lead.primaryAxisSizingMode = "AUTO";
        lead.counterAxisSizingMode = "AUTO";
        lead.itemSpacing = 4;
        lead.appendChild(textNode);
        lead.appendChild(makeCaret(scv(maps, fc("text-cursor"))));
        comp.appendChild(lead);
      } else {
        comp.appendChild(textNode);
      }
      setLightMode(comp, maps);
      comps.push(comp);
      cells.push({ comp, row, col: 0 });
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Text Area";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Text Area",
      colHeaders: ["Field"],
      rowLabels: states.map((s) => s.name),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 264,
      cellH: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildSelect(maps, originY) {
    var _a, _b, _c, _d, _e;
    const fc = (k) => `color/form-control/${k}`;
    const chevDown = (c) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 6L8 10L12 6" stroke="${c}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const chevUp = (c) => `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 10L8 6L12 10" stroke="${c}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", tc: "text/placeholder", icon: "icon/default", up: false },
      { name: "Hover", bg: "bg/hover", border: "border/default", tc: "text/placeholder", icon: "icon/hover", up: false },
      { name: "Open", bg: "bg/selected", border: "border/selected", tc: "text/placeholder", icon: "icon/selected", up: true },
      { name: "Filled", bg: "bg/default", border: "border/default", tc: "text/selected", icon: "icon/default", up: false },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", tc: "text/disabled", icon: "icon/disabled", up: false }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12 },
      { size: "XSM", brk: "PC", h: 34, font: 14 },
      { size: "MD", brk: "PC", h: 44, font: 14 },
      { size: "MD", brk: "Mobile", h: 48, font: 14 }
    ];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const trigger = figma.createFrame();
        trigger.name = "trigger";
        trigger.layoutMode = "HORIZONTAL";
        trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
        trigger.counterAxisAlignItems = "CENTER";
        trigger.primaryAxisSizingMode = "FIXED";
        trigger.counterAxisSizingMode = "FIXED";
        trigger.paddingLeft = 16;
        trigger.paddingRight = sc.brk === "Mobile" ? 12 : 8;
        trigger.paddingTop = 0;
        trigger.paddingBottom = 0;
        trigger.cornerRadius = 4;
        trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
        trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
        trigger.strokeWeight = 1;
        trigger.strokeAlign = "INSIDE";
        trigger.appendChild(await makeBoundText("\uC120\uD0DD", sc.font, "Regular", scv(maps, fc(st.tc))));
        trigger.appendChild(await makeIconInstance("chevron", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), (st.up ? chevUp : chevDown)("#000"), st.up ? 90 : 270, { wrap: false }));
        trigger.resize(140, sc.h);
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        comp.fills = [];
        comp.appendChild(trigger);
        if (st.name === "Open") {
          const ddKey = `Dropdown:${sc.size}:Default`;
          let ddComp = (_b = (_a = BUILT_COMPS[ddKey]) != null ? _a : BUILT_COMPS["Dropdown:MD:Default"]) != null ? _b : BUILT_COMPS["Dropdown:Default"];
          if (!ddComp) {
            const ddSet = await getBuiltSet("Dropdown");
            if (ddSet) {
              ddComp = (_e = (_d = (_c = ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${sc.size}`) && c.name.includes("Type=Text"))) != null ? _c : ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${sc.size}`))) != null ? _d : ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Type=Text"))) != null ? _e : ddSet.children.find((c) => c.type === "COMPONENT");
            }
          }
          if (ddComp) {
            const ddInst = ddComp.createInstance();
            ddInst.name = "dropdown";
            comp.appendChild(ddInst);
            try {
              ddInst.resize(Math.max(DD_MIN_W, trigger.width), ddInst.height);
            } catch (e) {
            }
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Select Box";
    set.x = 0;
    set.y = originY;
    cells.forEach(({ comp, size, brk, state }) => {
      BUILT_COMPS[`SelectBox:${size}:${brk}:${state}`] = comp;
    });
    BUILT_SETS["Select Box"] = set;
    const opts = {
      title: "Select Box",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a2, _b2;
        return (_b2 = (_a2 = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 156,
      cellH: 220,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var DD_MIN_W = 100;
  async function buildDropdownList(maps, originY) {
    const dd = (k) => `color/dropdown/${k}`;
    const states = [
      { name: "Default", bg: "option/bg/default", label: "option/label/default", chk: "Default" },
      { name: "Hover", bg: "option/bg/hover", label: "option/label/hover", chk: "Hover" },
      // 2026-07-08 사용자 결정: 선택 배경=default와 동일 토큰(강조는 텍스트색만). option/bg/selected(하늘색)는
      // 더 이상 여기서 안 쓰지만 Time Picker Cell(별도 컴포넌트, buildTimePickerCell)은 계속 사용 — 그대로 둠.
      { name: "Selected", bg: "option/bg/default", label: "option/label/selected", chk: "Checked" }
    ];
    const types = [
      { name: "Text", checkbox: false, divider: false, text: "\uC635\uC158" },
      { name: "Checkbox", checkbox: true, divider: false, text: "\uC635\uC158" },
      // '전체 선택' → '전체' (river 지시 2026-09-09) — 정본이 기준, 웹 배포본도 이 값을 따른다.
      { name: "Checkbox+All", checkbox: true, divider: true, text: "\uC804\uCCB4" }
    ];
    const sizes = [
      { size: "XXSM", h: 28, font: 12 },
      { size: "XSM", h: 34, font: 14 },
      { size: "MD", h: 44, font: 14 }
    ];
    const CHK_GAP = 8;
    const CHK_PX = 18;
    const fillRow = async (host, sz, ty, st, rowH) => {
      host.layoutMode = "HORIZONTAL";
      host.counterAxisAlignItems = "CENTER";
      host.primaryAxisSizingMode = "FIXED";
      host.counterAxisSizingMode = "FIXED";
      host.paddingLeft = 12;
      host.paddingRight = 12;
      host.paddingTop = 0;
      host.paddingBottom = 0;
      host.itemSpacing = ty.checkbox ? CHK_GAP : 0;
      host.fills = [boundPaint(scv(maps, dd(st.bg)))];
      host.resize(DD_MIN_W, rowH);
      if (ty.checkbox) {
        const chkComp = await reuseVariant("Checkbox", `Checkbox:${st.chk}`, [`State=${st.chk}`]);
        if (chkComp) {
          const inst = chkComp.createInstance();
          inst.name = "checkbox";
          host.appendChild(inst);
        } else {
          console.warn(`[Dropdown List] Checkbox \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uCC3E\uC9C0 \uBABB\uD574 \uC784\uC2DC \uB3C4\uD615\uC73C\uB85C \uADF8\uB9BD\uB2C8\uB2E4 (State=${st.chk}) \u2014 Checkbox \uB97C \uBA3C\uC800 \uC124\uCE58\uD558\uBA74 \uC778\uC2A4\uD134\uC2A4\uB85C \uBD99\uC2B5\uB2C8\uB2E4.`);
          const box = figma.createFrame();
          box.name = "checkbox";
          box.resize(CHK_PX, CHK_PX);
          box.cornerRadius = 2;
          const on = st.chk === "Checked";
          const bgKey = on ? "color/control/bg/selected" : st.chk === "Hover" ? "color/control/bg/hover" : "color/control/bg/default";
          box.fills = [boundPaint(scv(maps, bgKey))];
          box.strokes = [boundPaint(scv(maps, on ? "color/control/border/selected" : "color/control/border/default"))];
          box.strokeWeight = 1;
          box.strokeAlign = "INSIDE";
          if (on) {
            const icon = await makeCheckIcon(scv(maps, "color/control/indicator/selected"));
            box.appendChild(icon);
            icon.x = 1;
            icon.y = 1;
          }
          host.appendChild(box);
        }
      }
      const labelKey = ty.checkbox && st.label === "option/label/selected" ? "option/label/default" : st.label;
      const label = await makeBoundText(ty.text, sz.font, "Regular", scv(maps, dd(labelKey)));
      label.layoutGrow = 1;
      label.textAutoResize = "HEIGHT";
      label.textTruncation = "ENDING";
      label.maxLines = 1;
      host.appendChild(label);
    };
    const comps = [];
    const cells = [];
    for (const sz of sizes) {
      for (let ri = 0; ri < types.length; ri++) {
        const ty = types[ri];
        for (let col = 0; col < states.length; col++) {
          const st = states[col];
          const comp = figma.createComponent();
          comp.name = `Size=${sz.size}, Type=${ty.name}, State=${st.name}`;
          if (ty.divider) {
            comp.layoutMode = "VERTICAL";
            comp.itemSpacing = 0;
            comp.primaryAxisSizingMode = "FIXED";
            comp.counterAxisSizingMode = "FIXED";
            comp.paddingLeft = 0;
            comp.paddingRight = 0;
            comp.paddingTop = 0;
            comp.paddingBottom = 0;
            comp.fills = [];
            comp.resize(DD_MIN_W, sz.h);
            const row = figma.createFrame();
            row.name = "option";
            await fillRow(row, sz, ty, st, sz.h - 1);
            comp.appendChild(row);
            try {
              row.layoutAlign = "STRETCH";
            } catch (e) {
            }
            const div = figma.createRectangle();
            div.name = "divider";
            div.resize(DD_MIN_W, 1);
            div.fills = [boundPaint(scv(maps, "color/dropdown/list/border"))];
            comp.appendChild(div);
            try {
              div.layoutAlign = "STRETCH";
            } catch (e) {
            }
          } else {
            await fillRow(comp, sz, ty, st, sz.h);
          }
          comps.push(comp);
          cells.push({ comp, size: sz.size, rowIdx: ri, colIdx: col });
          BUILT_COMPS[`DropdownList:${sz.size}:${ty.name}:${st.name}`] = comp;
          if (ty.name === "Text") {
            BUILT_COMPS[`DropdownList:${sz.size}:${st.name}`] = comp;
            if (sz.size === "MD") BUILT_COMPS[`DropdownList:${st.name}`] = comp;
          }
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Dropdown List";
    set.x = 0;
    set.y = originY;
    setLightMode(set, maps);
    BUILT_SETS["Dropdown List"] = set;
    const opts = {
      title: "Dropdown List",
      platforms: [{ name: "PC", sizes: sizes.map((s) => s.size) }],
      rowLabels: types.map((t) => t.name),
      colHeaders: states.map((s) => s.name),
      cellAt: (_p, size, ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === size && x.rowIdx === ri && x.colIdx === ci)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 160,
      cellH: 60,
      rowLabelW: 96
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDropdown(maps, originY) {
    var _a, _b, _c;
    const dd = (k) => `color/dropdown/${k}`;
    const sizes = [
      { size: "XXSM", h: 28 },
      { size: "XSM", h: 34 },
      { size: "MD", h: 44 }
    ];
    const panelTypes = [
      { name: "Text", rows: [["Text", "Default"], ["Text", "Hover"], ["Text", "Selected"], ["Text", "Default"]] },
      { name: "Checkbox", rows: [["Checkbox+All", "Default"], ["Checkbox", "Selected"], ["Checkbox", "Default"], ["Checkbox", "Hover"]] }
    ];
    const comps = [];
    const cells = [];
    const ddlSet = await getBuiltSet("Dropdown List");
    for (const sz of sizes) {
      for (let ti = 0; ti < panelTypes.length; ti++) {
        const pt = panelTypes[ti];
        const comp = figma.createComponent();
        comp.name = `Size=${sz.size}, Type=${pt.name}, State=Default`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "FIXED";
        comp.paddingTop = 4;
        comp.paddingBottom = 4;
        comp.itemSpacing = 0;
        comp.cornerRadius = 4;
        comp.clipsContent = false;
        comp.fills = [boundPaint(scv(maps, "color/dropdown/list/bg"))];
        comp.strokes = [boundPaint(scv(maps, "color/dropdown/list/border"))];
        comp.strokeWeight = 1;
        comp.strokeAlign = "OUTSIDE";
        const ddEffects = shadowEffects("shadow/dropdown");
        try {
          comp.effects = ddEffects;
        } catch (e) {
        }
        comp.resize(DD_MIN_W, 4 * sz.h + 8);
        const optionRows = [];
        for (const [rowType, stateName] of pt.rows) {
          let ddComp = await reuseVariant(
            "Dropdown List",
            `DropdownList:${sz.size}:${rowType}:${stateName}`,
            [`Size=${sz.size}`, `Type=${rowType}`, `State=${stateName}`]
          );
          if (!ddComp && rowType === "Text") {
            ddComp = (_c = (_b = (_a = BUILT_COMPS[`DropdownList:${sz.size}:${stateName}`]) != null ? _a : BUILT_COMPS[`DropdownList:${stateName}`]) != null ? _b : await reuseVariant("Dropdown List", `DropdownList:${sz.size}:${stateName}`, [`Size=${sz.size}`, `State=${stateName}`])) != null ? _c : void 0;
          }
          if (!ddComp && rowType !== "Text") {
            console.warn(`[Dropdown] \uC635\uC158 \uC904 ${rowType}/${stateName} (${sz.size}) \uC744 \uCC3E\uC9C0 \uBABB\uD574 \uAC74\uB108\uB701\uB2C8\uB2E4 \u2014 Dropdown List \uB97C \uD568\uAED8 \uC124\uCE58\uD558\uC138\uC694.`);
            continue;
          }
          if (ddComp) {
            const inst = ddComp.createInstance();
            inst.name = "ddl-row";
            optionRows.push(inst);
          } else {
            const sn = stateName.toLowerCase();
            const row = figma.createFrame();
            row.name = "ddl-row";
            row.layoutMode = "HORIZONTAL";
            row.counterAxisAlignItems = "CENTER";
            row.primaryAxisSizingMode = "FIXED";
            row.counterAxisSizingMode = "FIXED";
            row.resize(DD_MIN_W, sz.h);
            row.paddingLeft = 12;
            row.paddingRight = 12;
            row.paddingTop = 0;
            row.paddingBottom = 0;
            row.fills = [boundPaint(scv(maps, dd(`option/bg/${sn}`)))];
            row.appendChild(await makeBoundText("\uC635\uC158", sz.h <= 28 ? 12 : 14, "Regular", scv(maps, dd(`option/label/${sn}`))));
            optionRows.push(row);
          }
        }
        await makeSlot(
          comp,
          "Options",
          "\uC635\uC158 \uC904\uC774 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 4\uC904\uC774\uBA70, Dropdown List \uC778\uC2A4\uD134\uC2A4\uB97C \uB123\uACE0 \uBE7C\uC11C \uC635\uC158 \uC218\uB97C \uB298\uB9AC\uACE0 \uC904\uC778\uB2E4. \uC904 \uC218\uB97C \uBC14\uAFB8\uBA74 \uD328\uB110 \uB192\uC774\uB294 \uC790\uB3D9\uC73C\uB85C \uB530\uB77C\uAC04\uB2E4.",
          optionRows,
          ddlSet ? [{ type: "COMPONENT_SET", key: ddlSet.key }] : [],
          {
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "MIN",
            itemSpacing: 0,
            stretch: true,
            stretchContents: true
          }
        );
        comps.push(comp);
        cells.push({ comp, size: sz.size, typeIdx: ti });
        if (pt.name === "Text") BUILT_COMPS[`Dropdown:${sz.size}:Default`] = comp;
        else BUILT_COMPS[`Dropdown:${sz.size}:${pt.name}`] = comp;
      }
    }
    BUILT_COMPS["Dropdown:Default"] = BUILT_COMPS["Dropdown:MD:Default"];
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Dropdown";
    set.x = 0;
    set.y = originY;
    setLightMode(set, maps);
    BUILT_SETS["Dropdown"] = set;
    const opts = {
      title: "Dropdown",
      colHeaders: panelTypes.map((t) => t.name),
      rowLabels: sizes.map((s) => s.size),
      cellAt: (r, c) => {
        var _a2, _b2;
        return (_b2 = (_a2 = cells.find((x) => {
          var _a3;
          return x.size === ((_a3 = sizes[r]) == null ? void 0 : _a3.size) && x.typeIdx === c;
        })) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 220
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLineTab(maps, originY) {
    const nav = (k) => `color/navigation/${k}`;
    const states = [
      { name: "Unselected", label: "label/default", ind: "indicator/default" },
      { name: "Hover", label: "label/hover", ind: "indicator/hover" },
      { name: "Selected", label: "label/selected", ind: "indicator/selected" }
    ];
    const sizes = [
      { size: "SM", brk: "PC", h: 42, font: 16 },
      { size: "MD", brk: "PC", h: 44, font: 18 },
      { size: "XSM", brk: "PC", h: 40, font: 14 },
      { size: "SM", brk: "Mobile", h: 32, font: 16 }
    ];
    const MIN_W = 76;
    const PAD_X = 16;
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "AUTO";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.itemSpacing = 0;
        comp.paddingLeft = 0;
        comp.paddingRight = 0;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.fills = [];
        comp.clipsContent = false;
        comp.minWidth = MIN_W;
        const indH = st.name === "Unselected" ? 1 : 2;
        const t = await makeBoundText("\uBA54\uB274", sc.font, "Medium", scv(maps, nav(st.label)));
        try {
          t.textAutoResize = "WIDTH_AND_HEIGHT";
        } catch (e) {
        }
        const labelWrap = figma.createFrame();
        labelWrap.name = "label";
        labelWrap.fills = [];
        labelWrap.layoutMode = "HORIZONTAL";
        labelWrap.primaryAxisSizingMode = "AUTO";
        labelWrap.counterAxisSizingMode = "AUTO";
        labelWrap.primaryAxisAlignItems = "CENTER";
        labelWrap.counterAxisAlignItems = "CENTER";
        labelWrap.paddingLeft = PAD_X;
        labelWrap.paddingRight = PAD_X;
        labelWrap.appendChild(t);
        comp.appendChild(labelWrap);
        try {
          labelWrap.layoutGrow = 1;
          labelWrap.layoutAlign = "STRETCH";
        } catch (e) {
        }
        const ind = figma.createRectangle();
        ind.resize(MIN_W, indH);
        ind.fills = [boundPaint(scv(maps, nav(st.ind)))];
        comp.appendChild(ind);
        try {
          ind.layoutAlign = "STRETCH";
        } catch (e) {
        }
        try {
          comp.resize(MIN_W, sc.h);
        } catch (e) {
        }
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    cells.forEach((c) => {
      BUILT_COMPS[`LineTab:${c.brk}-${c.size}-${c.state}`] = c.comp;
    });
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Line Tab";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Line Tab",
      platforms: [{ name: "PC", sizes: ["SM", "MD", "XSM"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 110,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLineTabSet(maps, originY) {
    const TAB_LABELS = ["\uD0ED \uBA54\uB274 1", "\uD0ED \uBA54\uB274 2", "\uD0ED \uBA54\uB274 3"];
    const sizeDefs = [
      { name: "MD", brk: "PC", size: "MD" },
      { name: "SM", brk: "PC", size: "SM" },
      { name: "XSM", brk: "PC", size: "XSM" },
      { name: "SM", brk: "Mobile", size: "SM" }
    ];
    const pickCell = async (brk, size, state) => {
      let c = BUILT_COMPS[`LineTab:${brk}-${size}-${state}`];
      if (!c) {
        const s = await getBuiltSet("Line Tab");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name.includes(`Size=${size}`) && x.name.includes(`Break=${brk}`) && x.name.includes(`State=${state}`));
      }
      return c;
    };
    const lineTabSet = await getBuiltSet("Line Tab");
    const comps = [];
    const cellByKey = /* @__PURE__ */ new Map();
    for (const sd of sizeDefs) {
      const comp = figma.createComponent();
      comp.name = `Size=${sd.size}, Break=${sd.brk}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.counterAxisAlignItems = "MIN";
      comp.itemSpacing = 0;
      comp.fills = [];
      comp.clipsContent = false;
      const tabInsts = [];
      for (let i = 0; i < TAB_LABELS.length; i++) {
        const state = i === 0 ? "Selected" : "Unselected";
        const cell = await pickCell(sd.brk, sd.size, state);
        if (cell) {
          const inst = cell.createInstance();
          inst.name = `tab-${i + 1}`;
          const txt = inst.findOne((n) => n.type === "TEXT");
          if (txt) {
            try {
              txt.characters = TAB_LABELS[i];
            } catch (e) {
            }
          }
          tabInsts.push(inst);
        }
      }
      await makeSlot(
        comp,
        "Tabs",
        "\uD0ED\uC774 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 \uD0ED 3\uAC1C\uC774\uBA70, Line Tab \uC778\uC2A4\uD134\uC2A4\uB97C \uB123\uACE0 \uBE7C\uC11C \uD0ED \uC218\uB97C \uB298\uB9AC\uACE0 \uC904\uC778\uB2E4. \uC0C8\uB85C \uB123\uC740 \uD0ED\uC740 \uD3ED\uC744 \uAE30\uC874 \uD0ED\uACFC \uAC19\uAC8C \uB9DE\uCD98\uB2E4.",
        tabInsts,
        lineTabSet ? [{ type: "COMPONENT_SET", key: lineTabSet.key }] : [],
        { counterAxisAlignItems: "MIN", itemSpacing: 0 }
      );
      if (tabInsts.length) {
        const maxW = Math.max(...tabInsts.map((n) => {
          try {
            return n.width;
          } catch (e) {
            return 0;
          }
        }));
        for (const inst of tabInsts) {
          try {
            inst.layoutSizingHorizontal = "FIXED";
          } catch (e) {
          }
          try {
            inst.resize(maxW, inst.height);
          } catch (e) {
          }
        }
      }
      setLightMode(comp, maps);
      comps.push(comp);
      cellByKey.set(`${sd.brk}/${sd.size}`, comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Line Tab Set";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Line Tab Set"] = set;
    const opts = {
      title: "Line Tab Set",
      platforms: [{ name: "PC", sizes: ["MD", "SM", "XSM"] }, { name: "Mobile", sizes: ["SM"] }],
      rowLabels: [""],
      colHeaders: [""],
      cellAt: (platName, size, _ri, _ci) => {
        var _a;
        return (_a = cellByKey.get(`${platName}/${size}`)) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 360,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTableCell(maps, originY) {
    const variants = [
      { type: "Cell", state: "Default", bg: "color/table/cell/default", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Default" },
      { type: "Cell", state: "Hover", bg: "color/table/cell/hover", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Hover" },
      { type: "Cell", state: "Selected", bg: "color/table/cell/selected", border: "color/table/border/default", text: "color/text/body/primary", head: "Cell \xB7 Selected" },
      { type: "Header", state: "Default", bg: "color/table/header/bg", border: "color/table/border/default", text: "color/text/body/secondary", head: "Header" }
    ];
    const sizes = [
      { size: "XSM", h: 34, font: 12 },
      { size: "SM", h: 38, font: 14 },
      { size: "MD", h: 44, font: 14 }
    ];
    const aligns = [
      { key: "Left", label: "\uC67C\uCABD", center: false },
      { key: "Center", label: "\uAC00\uC6B4\uB370", center: true }
    ];
    const PAD2 = 16;
    const W = 130;
    const comps = [];
    const cells = [];
    for (let row = 0; row < sizes.length * aligns.length; row++) {
      const al = aligns[Math.floor(row / sizes.length)];
      const sc = sizes[row % sizes.length];
      for (let col = 0; col < variants.length; col++) {
        const v = variants[col];
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, Type=${v.type}, Variant=${v.state}, Align=${al.key}`;
        comp.resize(W, sc.h);
        comp.fills = [boundPaint(scv(maps, v.bg))];
        const t = await makeBoundText("1\uCE35 \uC815\uBB38", sc.font, v.type === "Header" ? "Medium" : "Regular", scv(maps, v.text));
        comp.appendChild(t);
        t.x = PAD2;
        t.y = (sc.h - 1 - t.height) / 2;
        if (al.center) {
          t.textAlignHorizontal = "CENTER";
          t.constraints = { horizontal: "STRETCH", vertical: "MIN" };
          try {
            t.textAutoResize = "HEIGHT";
            t.resize(W - PAD2 * 2, t.height);
          } catch (_) {
          }
          t.y = (sc.h - 1 - t.height) / 2;
        }
        const border = figma.createRectangle();
        border.resize(W, 1);
        border.fills = [boundPaint(scv(maps, v.border))];
        comp.appendChild(border);
        border.x = 0;
        border.y = sc.h - 1;
        border.constraints = { horizontal: "STRETCH", vertical: "MAX" };
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, row, col });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Table Cell";
    set.x = 0;
    set.y = originY;
    for (const { comp, row, col } of cells) {
      const align = aligns[Math.floor(row / sizes.length)].key;
      const size = sizes[row % sizes.length].size;
      const v = variants[col];
      BUILT_COMPS[`TableCell:${size}:${v.type}:${v.state}:${align}`] = comp;
    }
    BUILT_SETS["Table Cell"] = set;
    const opts = {
      title: "Table Cell",
      colHeaders: variants.map((v) => v.head),
      rowLabels: [].concat(...aligns.map((a) => sizes.map((sz) => `${a.label} \xB7 ${sz.size}`))),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.row === r && x.col === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 152,
      cellH: 60,
      rowLabelW: 80
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTable(maps, originY) {
    const COL = [48, 360, 200, 110, 110];
    const W = 828;
    const FOOTER_H = 44;
    async function makeTableRow(h, sizeKey, isHeader, state, ri) {
      const row = figma.createFrame();
      row.name = isHeader ? "header" : `row-${ri + 1}`;
      row.resize(W, h);
      row.fills = [];
      const colTexts = isHeader ? ["\uD56D\uBAA9\uBA85", "\uD56D\uBAA9\uBA85 (\uC815\uB82C)", "\uC218\uB7C9", "\uAD00\uB9AC"] : state === "Hover" ? ["Hover \uD589", "\uCE74\uD14C\uACE0\uB9AC A", "56", "\uAC80\uD1A0\uC911"] : state === "Selected" ? ["Selected \uD589", "\uCE74\uD14C\uACE0\uB9AC B", "33", "\uC644\uB8CC"] : [`\uD56D\uBAA9 ${ri + 1}`, "\uCE74\uD14C\uACE0\uB9AC C", `${(ri + 1) * 10}`, "\uD65C\uC131"];
      const cellType = isHeader ? "Header" : "Cell";
      const cellState = isHeader ? "Default" : state;
      const chkBg = isHeader ? "color/table/header/bg" : state === "Hover" ? "color/table/cell/hover" : state === "Selected" ? "color/table/cell/selected" : "color/table/cell/default";
      const chkFrame = figma.createFrame();
      chkFrame.name = "col-check";
      chkFrame.resize(COL[0], h);
      chkFrame.fills = [boundPaint(scv(maps, chkBg))];
      const chkState = isHeader ? "Default" : state === "Selected" ? "Checked" : state === "Hover" ? "Hover" : "Default";
      const chkComp = BUILT_COMPS[`Checkbox:${chkState}`];
      if (chkComp) {
        const ci = chkComp.createInstance();
        chkFrame.appendChild(ci);
        ci.x = (COL[0] - ci.width) / 2;
        ci.y = (h - ci.height) / 2;
      }
      const chkBdr = figma.createRectangle();
      chkBdr.resize(COL[0], 1);
      chkBdr.fills = [boundPaint(scv(maps, "color/table/border/default"))];
      chkFrame.appendChild(chkBdr);
      chkBdr.x = 0;
      chkBdr.y = h - 1;
      row.appendChild(chkFrame);
      chkFrame.x = 0;
      chkFrame.y = 0;
      const font = sizeKey === "XSM" ? 12 : 14;
      let xOff = COL[0];
      for (let k = 0; k < 4; k++) {
        const colW = COL[k + 1];
        const cellComp = BUILT_COMPS[`TableCell:${sizeKey}:${cellType}:${cellState}:Left`];
        if (cellComp) {
          const cellInst = cellComp.createInstance();
          cellInst.resize(colW, h);
          try {
            const tn = cellInst.findOne((n) => n.type === "TEXT");
            if (tn) {
              await figma.loadFontAsync(tn.fontName);
              tn.characters = colTexts[k];
            }
          } catch (_) {
          }
          row.appendChild(cellInst);
          cellInst.x = xOff;
          cellInst.y = 0;
        } else {
          const cf = figma.createFrame();
          cf.name = `col-${k + 1}`;
          cf.resize(colW, h);
          const bgKey = isHeader ? "color/table/header/bg" : state === "Hover" ? "color/table/cell/hover" : state === "Selected" ? "color/table/cell/selected" : "color/table/cell/default";
          cf.fills = [boundPaint(scv(maps, bgKey))];
          const textKey = isHeader ? "color/text/body/secondary" : "color/text/body/primary";
          const t = await makeBoundText(colTexts[k], font, isHeader ? "Medium" : "Regular", scv(maps, textKey));
          cf.appendChild(t);
          t.x = 16;
          t.y = Math.max(0, (h - t.height) / 2);
          const bdr = figma.createRectangle();
          bdr.resize(colW, 1);
          bdr.fills = [boundPaint(scv(maps, "color/table/border/default"))];
          cf.appendChild(bdr);
          bdr.x = 0;
          bdr.y = h - 1;
          row.appendChild(cf);
          cf.x = xOff;
          cf.y = 0;
        }
        xOff += colW;
      }
      return row;
    }
    async function makeTableFooter() {
      var _a;
      const footer = figma.createFrame();
      footer.name = "table-footer";
      footer.resize(W, FOOTER_H);
      footer.fills = [boundPaint(scv(maps, "color/table/cell/default"))];
      let barComp = BUILT_COMPS["Pagination:Bar/Middle"];
      if (!barComp) {
        const barSet = await getBuiltSet("Pagination");
        if (barSet) barComp = (_a = barSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Middle"))) != null ? _a : barSet.children.find((c) => c.type === "COMPONENT");
      }
      if (barComp) {
        const barInst = barComp.createInstance();
        barInst.name = "pagination";
        footer.appendChild(barInst);
        barInst.x = Math.round((W - barInst.width) / 2);
        barInst.y = Math.round((FOOTER_H - barInst.height) / 2);
      }
      const selComp = BUILT_COMPS["SelectBox:XXSM:PC:Default"];
      if (selComp) {
        const selInst = selComp.createInstance();
        selInst.name = "select-box";
        footer.appendChild(selInst);
        selInst.x = W - selInst.width - 8;
        selInst.y = (FOOTER_H - selInst.height) / 2;
      }
      return footer;
    }
    const sizes = [
      { size: "MD", sizeKey: "MD", h: 44 },
      { size: "SM", sizeKey: "SM", h: 38 },
      { size: "XSM", sizeKey: "XSM", h: 34 }
      // river 승인 2026-09-02 — 표 전용 34/12
    ];
    const ROW_STATES = ["Default", "Hover", "Selected", "Default", "Default", "Default", "Default", "Default"];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      const comp = figma.createComponent();
      comp.name = `Size=${sc.size}`;
      comp.resize(W, 10);
      comp.fills = [];
      let y = 0;
      const header = await makeTableRow(sc.h, sc.sizeKey, true, "Header", 0);
      comp.appendChild(header);
      header.x = 0;
      header.y = y;
      y += sc.h;
      for (let ri = 0; ri < 8; ri++) {
        const row = await makeTableRow(sc.h, sc.sizeKey, false, ROW_STATES[ri], ri);
        comp.appendChild(row);
        row.x = 0;
        row.y = y;
        y += sc.h;
      }
      const footer = await makeTableFooter();
      const footerY = y;
      comp.appendChild(footer);
      footer.x = 0;
      footer.y = footerY;
      y += FOOTER_H;
      comp.resize(W, y);
      const edgeTop = figma.createRectangle();
      edgeTop.name = "edge-top";
      edgeTop.resize(W, 2);
      edgeTop.fills = [boundPaint(scv(maps, "color/table/border/strong"))];
      comp.appendChild(edgeTop);
      edgeTop.x = 0;
      edgeTop.y = 0;
      const edgeBottom = figma.createRectangle();
      edgeBottom.name = "edge-bottom";
      edgeBottom.resize(W, 1);
      edgeBottom.fills = [boundPaint(scv(maps, "color/table/border/strong"))];
      comp.appendChild(edgeBottom);
      edgeBottom.x = 0;
      edgeBottom.y = footerY - 1;
      setLightMode(comp, maps);
      comps.push(comp);
      cells.push({ comp, size: sc.size });
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Table";
    set.x = 0;
    set.y = originY;
    const cellH = sizes[0].h * 9 + FOOTER_H + 40;
    const opts = {
      title: "Table",
      colHeaders: [""],
      rowLabels: sizes.map((s) => s.size),
      cellAt: (r, _c) => {
        var _a, _b;
        return (_b = (_a = cells[r]) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildFilterChip(maps, originY) {
    var _a, _b, _c, _d, _e, _f, _g;
    const arrowDown = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="#000" stroke-width="2" stroke-linecap="square"/></svg>`;
    const arrowUp = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M18 15L12 9L6 15" stroke="#000" stroke-width="2" stroke-linecap="square"/></svg>`;
    const variants = ["Line", "Solid"];
    const titles = [
      { key: "Off", name: "Label only" },
      { key: "On", name: "With title" }
    ];
    const states = ["Default", "Hover", "Selected", "Complete", "Disabled"];
    const sizes = [
      { size: "SM", brk: "PC", h: 28, font: 14, padL: 12, padR: 6 },
      { size: "MD", brk: "PC", h: 34, font: 14, padL: 16, padR: 8 },
      { size: "MD", brk: "Mobile", h: 30, font: 14, padL: 12, padR: 6 }
    ];
    function chipSlot(v, st) {
      if (v === "line") {
        switch (st) {
          case "Hover":
            return { bg: "hover", bd: "default", lb: "default", open: false };
          case "Selected":
            return { bg: "selected", bd: "selected", lb: "default", open: true };
          case "Disabled":
            return { bg: "disabled", bd: "disabled", lb: "disabled", open: false };
          default:
            return { bg: "default", bd: "default", lb: "default", open: false };
        }
      }
      switch (st) {
        case "Hover":
          return { bg: "hover", bd: "hover", bdGroup: "bg", lb: "default", open: false };
        case "Selected":
          return { bg: "selected", bd: "selected", lb: "selected", open: true };
        case "Disabled":
          return { bg: "disabled", bd: "disabled", lb: "disabled", open: false };
        default:
          return { bg: "default", bd: "default", lb: "default", open: false };
      }
    }
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const variant of variants) {
        const v = variant.toLowerCase();
        for (const t of titles) {
          for (const st of states) {
            const ss = chipSlot(v, st);
            const dis = st === "Disabled";
            const chip2 = figma.createFrame();
            chip2.name = "chip";
            chip2.layoutMode = "HORIZONTAL";
            chip2.counterAxisAlignItems = "CENTER";
            chip2.primaryAxisSizingMode = "AUTO";
            chip2.counterAxisSizingMode = "FIXED";
            chip2.itemSpacing = 4;
            chip2.paddingLeft = sc.padL;
            chip2.paddingRight = sc.padR;
            bindRadius(chip2, maps, "radius/full");
            chip2.fills = [boundPaint(scv(maps, `color/chip/${v}/bg/${ss.bg}`))];
            chip2.strokes = [boundPaint(scv(maps, `color/chip/${v}/${(_a = ss.bdGroup) != null ? _a : "border"}/${ss.bd}`))];
            chip2.strokeWeight = 1;
            chip2.strokeAlign = "INSIDE";
            if (t.key === "On") {
              chip2.appendChild(await makeBoundText("\uC815\uB82C", sc.font, "Medium", scv(maps, `color/chip/${v}/label/${ss.lb}`)));
            }
            const valLbSlot = t.key === "On" && v === "line" && !dis ? "selected" : ss.lb;
            const valText = st === "Complete" ? "\uACFC\uAC70\uC21C" : "\uCD5C\uC2E0\uC21C";
            chip2.appendChild(await makeBoundText(valText, sc.font, "Medium", scv(maps, `color/chip/${v}/label/${valLbSlot}`)));
            const arrowSlot = ss.lb;
            chip2.appendChild(await makeIconInstance("chevron", scv(maps, `color/chip/${v}/icon/${arrowSlot}`), 20, ss.open ? arrowUp : arrowDown, ss.open ? 90 : 270, { wrap: false }));
            chip2.resize(chip2.width, sc.h);
            const comp = figma.createComponent();
            comp.name = `Size=${sc.size}, Break=${sc.brk}, Variant=${variant}, Title=${t.key}, State=${st}`;
            comp.layoutMode = "VERTICAL";
            comp.primaryAxisSizingMode = "AUTO";
            comp.counterAxisSizingMode = "AUTO";
            comp.itemSpacing = 8;
            comp.fills = [];
            comp.appendChild(chip2);
            if (ss.open) {
              const chipToDd = { SM: "XXSM", MD: "XSM" };
              const ddSize = (_b = chipToDd[sc.size]) != null ? _b : "MD";
              const ddKey = `Dropdown:${ddSize}:Default`;
              let ddComp = (_d = (_c = BUILT_COMPS[ddKey]) != null ? _c : BUILT_COMPS["Dropdown:MD:Default"]) != null ? _d : BUILT_COMPS["Dropdown:Default"];
              if (!ddComp) {
                const ddSet = await getBuiltSet("Dropdown");
                if (ddSet) {
                  ddComp = (_g = (_f = (_e = ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${ddSize}`) && c.name.includes("Type=Text"))) != null ? _e : ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${ddSize}`))) != null ? _f : ddSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Type=Text"))) != null ? _g : ddSet.children.find((c) => c.type === "COMPONENT");
                }
              }
              if (ddComp) {
                const ddInst = ddComp.createInstance();
                ddInst.name = "dropdown";
                const selectedRow = ddInst.children[2];
                const defaultRowComp = BUILT_COMPS[`DropdownList:${ddSize}:Default`];
                if (selectedRow && selectedRow.type === "INSTANCE" && defaultRowComp) {
                  selectedRow.swapComponent(defaultRowComp);
                }
                comp.appendChild(ddInst);
                try {
                  ddInst.resize(Math.max(DD_MIN_W, chip2.width), ddInst.height);
                } catch (e) {
                }
              }
            }
            setLightMode(comp, maps);
            comps.push(comp);
            cells.push({ comp, variant, title: t.key, state: st, size: sc.size, brk: sc.brk });
          }
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Filter Chip";
    set.x = 0;
    set.y = originY;
    const groups = [
      { name: "Line \xB7 Label only", variant: "Line", title: "Off" },
      { name: "Line \xB7 With title", variant: "Line", title: "On" },
      { name: "Solid \xB7 Label only", variant: "Solid", title: "Off" },
      { name: "Solid \xB7 With title", variant: "Solid", title: "On" }
    ];
    const opts = {
      title: "Filter Chip",
      platforms: [
        { name: "PC", sizes: ["SM", "MD"] },
        { name: "Mobile", sizes: ["MD"] }
      ],
      rowLabels: groups.map((g) => g.name),
      colHeaders: states,
      cellAt: (platName, sizeLabel, ri, ci) => {
        var _a2, _b2;
        const g = groups[ri];
        if (!g) return null;
        const brk = platName === "Mobile" ? "Mobile" : "PC";
        return (_b2 = (_a2 = cells.find((x) => x.variant === g.variant && x.title === g.title && x.state === states[ci] && x.size === sizeLabel && x.brk === brk)) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 160,
      cellH: 160,
      rowLabelW: 120
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildTimePicker(maps, originY) {
    var _a;
    const fc = (k) => `color/form-control/${k}`;
    const CLOCK = `<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7.5" stroke="#000" stroke-width="1.2"/><path d="M9 5v4l2.5 2.5" stroke="#000" stroke-width="1.2" stroke-linecap="round"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/default" },
      { name: "Hover", bg: "bg/hover", border: "border/default", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/hover" },
      { name: "Focus", bg: "bg/default", border: "border/selected", txt: "\uC2DC\uAC04 \uC120\uD0DD", tc: "text/placeholder", icon: "icon/selected" },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "09:30", tc: "text/default", icon: "icon/default" },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "00:00", tc: "text/disabled", icon: "icon/disabled" }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12, padL: 10, padR: 6 },
      { size: "XSM", brk: "PC", h: 34, font: 14, padL: 12, padR: 8 },
      { size: "MD", brk: "PC", h: 44, font: 14, padL: 16, padR: 8 },
      // Mobile 은 아이콘 끝 여백 12 — Input·Search 와 같은 자리(river 결정 2026-09-21).
      { size: "MD", brk: "Mobile", h: 48, font: 14, padL: 16, padR: 12 }
    ];
    const types = [
      { key: "24h", label: "24\uC2DC\uAC04", filled: "09:30", disabled: "00:00" },
      { key: "12h", label: "12\uC2DC\uAC04", filled: "\uC624\uC804 09:30", disabled: "\uC624\uC804 12:00" }
    ];
    const comps = [];
    const cells = [];
    for (const ty of types) {
      for (const sc of sizes) {
        for (const st of states) {
          const stTxt = st.name === "Filled" ? ty.filled : st.name === "Disabled" ? ty.disabled : st.txt;
          const trigger = figma.createFrame();
          trigger.name = "trigger";
          trigger.layoutMode = "HORIZONTAL";
          trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
          trigger.counterAxisAlignItems = "CENTER";
          trigger.primaryAxisSizingMode = "FIXED";
          trigger.counterAxisSizingMode = "FIXED";
          trigger.paddingLeft = sc.padL;
          trigger.paddingRight = sc.padR;
          trigger.paddingTop = 0;
          trigger.paddingBottom = 0;
          trigger.itemSpacing = 8;
          trigger.cornerRadius = 4;
          trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
          trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
          trigger.strokeWeight = 1;
          trigger.strokeAlign = "INSIDE";
          trigger.appendChild(await makeBoundText(stTxt, sc.font, "Regular", scv(maps, fc(st.tc))));
          trigger.appendChild(await makeIconInstance("clock", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), CLOCK));
          trigger.resize(150, sc.h);
          const comp = figma.createComponent();
          comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}, Type=${ty.key}`;
          comp.layoutMode = "VERTICAL";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "AUTO";
          comp.itemSpacing = 4;
          comp.fills = [];
          comp.appendChild(trigger);
          if (st.name === "Focus") {
            const tpdComp = (_a = BUILT_COMPS[`TPD:${ty.key}/\uC2DC Selected`]) != null ? _a : BUILT_COMPS["TPD:focus-default"];
            if (tpdComp) {
              const tpdInst = tpdComp.createInstance();
              tpdInst.name = "tpd";
              comp.appendChild(tpdInst);
            }
          }
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name, type: ty.key });
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Time Picker",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: types.map((t) => t.label),
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, ri, ci) => {
        var _a2, _b;
        return (_b = (_a2 = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name && x.type === types[ri].key)) == null ? void 0 : _a2.comp) != null ? _b : null;
      },
      // 12h 패널(194)이 24h(121)보다 넓어 칸을 넓힌다 — 좁으면 Focus 열끼리 겹친다.
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 216,
      cellH: 250,
      rowLabelW: 60
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var TPC_W = 44;
  var TPC_H = 32;
  async function buildTimePickerCell(maps) {
    const opt = (k) => `color/dropdown/option/${k}`;
    const states = [
      { name: "Default", bg: "bg/default", lb: "label/default" },
      { name: "Hover", bg: "bg/hover", lb: "label/hover" },
      { name: "Selected", bg: "bg/selected", lb: "label/selected" }
    ];
    const comps = [];
    const variants = {};
    for (const st of states) {
      const comp = figma.createComponent();
      comp.name = `State=${st.name}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.paddingLeft = 12;
      comp.paddingRight = 12;
      comp.cornerRadius = 4;
      comp.resize(TPC_W, TPC_H);
      comp.fills = [boundPaint(scv(maps, opt(st.bg)))];
      comp.appendChild(await makeBoundText("00", 14, "Regular", scv(maps, opt(st.lb))));
      comps.push(comp);
      variants[st.name] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker Cell";
    return { set, variants };
  }
  var TPD_COLS_H = 192;
  var TPD_PAD_TOP = 12;
  var TPD_PANEL_W = (n) => n >= 3 ? 194 : 121;
  async function buildTimePickerDropdown(maps, originY) {
    var _a;
    const cell = await buildTimePickerCell(maps);
    async function makeCol(items, selIdx, hoverIdx) {
      const col = figma.createFrame();
      col.name = "col";
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "FIXED";
      col.counterAxisSizingMode = "FIXED";
      col.itemSpacing = 0;
      col.clipsContent = true;
      col.fills = [];
      col.resize(44, TPD_COLS_H);
      for (let i = 0; i < items.length; i++) {
        const state = i === selIdx ? "Selected" : i === hoverIdx ? "Hover" : "Default";
        const inst = cell.variants[state].createInstance();
        const txt = inst.findOne((n) => n.type === "TEXT");
        if (txt) {
          await figma.loadFontAsync(txt.fontName);
          txt.characters = items[i];
        }
        col.appendChild(inst);
        inst.layoutAlign = "STRETCH";
      }
      return col;
    }
    function makeColSep() {
      const sep = figma.createRectangle();
      sep.name = "sep";
      sep.resize(1, TPD_COLS_H);
      sep.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
      return sep;
    }
    async function fillPanel(node, cols, confirmActive) {
      const panelW = TPD_PANEL_W(cols.length);
      node.layoutMode = "VERTICAL";
      node.counterAxisAlignItems = "CENTER";
      node.itemSpacing = 0;
      node.paddingTop = TPD_PAD_TOP;
      node.paddingBottom = 0;
      node.cornerRadius = 4;
      node.clipsContent = true;
      node.fills = [boundPaint(scv(maps, "color/dropdown/list/bg"))];
      node.strokes = [boundPaint(scv(maps, "color/dropdown/list/border"))];
      node.strokeWeight = 1;
      node.strokeAlign = "INSIDE";
      node.effects = shadowEffects("shadow/dropdown");
      node.resize(panelW, 100);
      node.primaryAxisSizingMode = "AUTO";
      node.counterAxisSizingMode = "FIXED";
      const colsFrame = figma.createFrame();
      colsFrame.name = "cols";
      colsFrame.layoutMode = "HORIZONTAL";
      colsFrame.counterAxisAlignItems = "MIN";
      colsFrame.primaryAxisSizingMode = "FIXED";
      colsFrame.counterAxisSizingMode = "FIXED";
      colsFrame.itemSpacing = 8;
      colsFrame.paddingLeft = 8;
      colsFrame.paddingRight = 8;
      colsFrame.fills = [];
      colsFrame.resize(panelW, TPD_COLS_H);
      for (let i = 0; i < cols.length; i++) {
        if (i > 0) {
          const sep = makeColSep();
          colsFrame.appendChild(sep);
          sep.layoutAlign = "STRETCH";
        }
        const col = await makeCol(cols[i].items, cols[i].selIdx, cols[i].hoverIdx);
        colsFrame.appendChild(col);
        col.layoutGrow = 1;
        col.layoutAlign = "STRETCH";
      }
      node.appendChild(colsFrame);
      colsFrame.layoutAlign = "STRETCH";
      const fdivWrap = figma.createFrame();
      fdivWrap.name = "footer-sep";
      fdivWrap.layoutMode = "VERTICAL";
      fdivWrap.primaryAxisSizingMode = "AUTO";
      fdivWrap.counterAxisSizingMode = "FIXED";
      fdivWrap.paddingLeft = 8;
      fdivWrap.paddingRight = 8;
      fdivWrap.fills = [];
      fdivWrap.resize(panelW, 1);
      const fdiv = figma.createRectangle();
      fdiv.name = "line";
      fdiv.resize(panelW - 16, 1);
      fdiv.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
      fdivWrap.appendChild(fdiv);
      fdiv.layoutAlign = "STRETCH";
      node.appendChild(fdivWrap);
      fdivWrap.layoutAlign = "STRETCH";
      const footer = figma.createFrame();
      footer.name = "Option";
      footer.layoutMode = "HORIZONTAL";
      footer.primaryAxisAlignItems = "MAX";
      footer.counterAxisAlignItems = "CENTER";
      footer.primaryAxisSizingMode = "FIXED";
      footer.counterAxisSizingMode = "AUTO";
      footer.paddingLeft = 16;
      footer.paddingRight = 16;
      footer.paddingTop = 12;
      footer.paddingBottom = 12;
      footer.fills = [];
      footer.appendChild(await makeBoundText("\uD655\uC778", 14, "Medium", scv(maps, confirmActive ? "color/text/state/accent" : "color/text/state/disabled")));
      node.appendChild(footer);
      footer.layoutAlign = "STRETCH";
    }
    const hours = ["1", "2", "3", "4", "5", "6", "7"];
    const mins = ["00", "01", "02", "03", "04", "05", "06"];
    const ampm = ["\uC624\uC804", "\uC624\uD6C4"];
    const colsOf = (type, cfg) => {
      var _a2, _b, _c, _d, _e;
      const h = { items: hours, selIdx: (_a2 = cfg.hSel) != null ? _a2 : -1, hoverIdx: (_b = cfg.hHov) != null ? _b : -1 };
      const m = { items: mins, selIdx: (_c = cfg.mSel) != null ? _c : -1, hoverIdx: (_d = cfg.mHov) != null ? _d : -1 };
      if (type === "12h") return [{ items: ampm, selIdx: (_e = cfg.ampm) != null ? _e : -1, hoverIdx: -1 }, h, m];
      return [h, m];
    };
    const tpdStates = [
      { state: "\uC2DC Hover", cfg: { hHov: 1 }, confirm: false },
      { state: "\uC2DC Selected", cfg: { hSel: 2 }, confirm: false },
      { state: "\uBD84 Hover", cfg: { hSel: 2, mHov: 3 }, confirm: false },
      { state: "\uBD84 Selected", cfg: { hSel: 2, mSel: 3 }, confirm: true }
    ];
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const type of ["24h", "12h"]) {
      for (const ts of tpdStates) {
        const panel = figma.createComponent();
        panel.name = `Type=${type}, State=${ts.state}`;
        await fillPanel(panel, colsOf(type, __spreadProps(__spreadValues({}, ts.cfg), { ampm: type === "12h" ? 0 : void 0 })), ts.confirm);
        comps.push(panel);
        byKey.set(`${type}/${ts.state}`, panel);
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Time Picker Dropdown";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Time Picker Dropdown"] = set;
    for (const [k, c] of byKey) BUILT_COMPS[`TPD:${k}`] = c;
    BUILT_COMPS["TPD:focus-default"] = (_a = byKey.get("24h/\uC2DC Selected")) != null ? _a : comps[0];
    const opts = {
      title: "Time Picker Dropdown",
      colHeaders: tpdStates.map((ts) => ts.state),
      rowLabels: ["24h", "12h"],
      cellAt: (r, c) => {
        var _a2;
        return (_a2 = byKey.get(`${["24h", "12h"][r]}/${tpdStates[c].state}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 300,
      rowLabelW: 40
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    const cellTop = bottomY + 80;
    const cellComps = [cell.variants.Default, cell.variants.Hover, cell.variants.Selected];
    const cellOpts = {
      title: "Time Picker Cell",
      colHeaders: ["Default", "Hover", "Selected"],
      rowLabels: [""],
      cellAt: (_r, c) => cellComps[c],
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY: cellTop,
      cellW: 120,
      cellH: 56
    };
    bottomY = Math.max(bottomY, await decorateSetFlat(cell.set, cellOpts, maps));
    try {
      bottomY = Math.max(bottomY, await buildSpec(cellOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildPaginationCell(maps, originY) {
    var _a;
    const pg = (k) => `color/pagination/${k}`;
    const CHEV_PREV = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 3.5L5 7l4 3.5" stroke="#000" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const CHEV_EDGE = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M10 3.5L6.5 7l3.5 3.5M3.5 3.5v7" stroke="#000" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const SZ = 28;
    const arrowStates = [
      { state: "Default", bg: "control/bg/default", border: "control/border/default", icon: "color/pagination/control/icon/default" },
      { state: "Hover", bg: "control/bg/hover", border: "control/border/default", icon: "color/pagination/control/icon/hover" },
      { state: "Disabled", bg: "control/bg/disabled", border: "control/border/disabled", icon: "color/pagination/control/icon/disabled" }
    ];
    const numStates = [
      { state: "Default", bg: null, text: "color/pagination/number/default" },
      { state: "Hover", bg: "control/bg/hover", text: "color/pagination/number/hover" },
      { state: "Selected", bg: null, text: "color/pagination/number/selected" }
    ];
    const byKey = /* @__PURE__ */ new Map();
    const comps = [];
    const EDGE_SET_KEY = "606d0de897175059f133427bf62bb3635d18a860";
    let edgeLineComp;
    try {
      const edgeSet = await figma.importComponentSetByKeyAsync(EDGE_SET_KEY);
      edgeLineComp = (_a = edgeSet.children.find(
        (c) => c.type === "COMPONENT" && c.name.toLowerCase().includes("line")
      )) != null ? _a : edgeSet.defaultVariant;
    } catch (_) {
    }
    const ICON_PX = edgeLineComp ? Math.round(edgeLineComp.height) : 24;
    for (const st of arrowStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Arrow, State=${st.state}`;
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, pg(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, pg(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const icon = await makeIconInstance("chevron", scv(maps, st.icon), ICON_PX, CHEV_PREV, 180, { wrap: false, keepName: true });
      comp.appendChild(icon);
      centerIconInBox(icon, comp, SZ);
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Arrow/${st.state}`, comp);
    }
    for (const st of arrowStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Edge, State=${st.state}`;
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = [boundPaint(scv(maps, pg(st.bg)))];
      comp.strokes = [boundPaint(scv(maps, pg(st.border)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      let icon;
      let edgeRotated = false;
      if (edgeLineComp) {
        const inst = edgeLineComp.createInstance();
        if (ICON_PX && ICON_PX !== inst.width) inst.resize(ICON_PX, ICON_PX);
        rebindIconColor(inst, scv(maps, st.icon));
        try {
          inst.rotation = 180;
          edgeRotated = true;
        } catch (e) {
        }
        icon = inst;
      } else {
        icon = makeStrokeIcon(CHEV_EDGE, scv(maps, st.icon));
      }
      comp.appendChild(icon);
      if (edgeRotated) centerIconInBox(icon, comp, SZ);
      else {
        icon.x = (SZ - icon.width) / 2;
        icon.y = (SZ - icon.height) / 2;
      }
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Edge/${st.state}`, comp);
    }
    for (const st of numStates) {
      const comp = figma.createComponent();
      comp.name = `Element=Number, State=${st.state}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SZ, SZ);
      comp.cornerRadius = 2;
      comp.fills = st.bg ? [boundPaint(scv(maps, pg(st.bg)))] : [];
      const t = await makeBoundText("3", 14, "Medium", scv(maps, st.text));
      comp.appendChild(t);
      setLightMode(comp, maps);
      comps.push(comp);
      byKey.set(`Number/${st.state}`, comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Pagination Cell";
    set.x = 0;
    set.y = originY;
    for (const [k, v] of byKey) BUILT_COMPS[`Pagination:${k}`] = v;
    BUILT_SETS["Pagination Cell"] = set;
    const cols = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Pagination Cell",
      colHeaders: cols,
      rowLabels: ["Arrow", "Number", "Edge"],
      cellAt: (r, c) => {
        var _a2;
        return (_a2 = byKey.get(`${["Arrow", "Number", "Edge"][r]}/${cols[c]}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 72,
      cellH: 48,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildPaginationBar(maps, originY) {
    const SZ = 28, GAP_GROUP = 4, GAP_SECTION = 8;
    const pick = async (key, variantName) => {
      let c = BUILT_COMPS[`Pagination:${key}`];
      if (!c) {
        const s = await getBuiltSet("Pagination Cell");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name.includes(variantName));
      }
      return c;
    };
    const arrowDef = await pick("Arrow/Default", "Element=Arrow, State=Default");
    const arrowDis = await pick("Arrow/Disabled", "Element=Arrow, State=Disabled");
    const edgeDef = await pick("Edge/Default", "Element=Edge, State=Default");
    const edgeDis = await pick("Edge/Disabled", "Element=Edge, State=Disabled");
    const numDef = await pick("Number/Default", "Element=Number, State=Default");
    const numSel = await pick("Number/Selected", "Element=Number, State=Selected");
    const cases = [
      // 1) 원페이지(리스트 15개까지) — 이동버튼 전체 비활성, "1"만 selected.
      { state: "Single", pages: [1], selected: 1, first: false, prev: false, next: false, last: false },
      // 2) 맨앞 페이지 — 맨앞·이전 비활성, 1 selected, 다음·맨뒤 활성.
      { state: "First", pages: [1, 2, 3, 4, 5, 6], selected: 1, first: false, prev: false, next: true, last: true },
      // 3) 맨뒤 페이지 — 맨앞·이전 활성, 마지막(6) selected, 다음·맨뒤 비활성.
      { state: "Last", pages: [1, 2, 3, 4, 5, 6], selected: 6, first: true, prev: true, next: false, last: false },
      // 4) 중간 페이지 — 전부 활성, 가운데(4) selected.
      { state: "Middle", pages: [1, 2, 3, 4, 5, 6], selected: 4, first: true, prev: true, next: true, last: true }
    ];
    const comps = [];
    let maxW = 0;
    for (const cs of cases) {
      const comp = figma.createComponent();
      comp.name = `State=${cs.state}`;
      comp.fills = [];
      let x = 0;
      const add = (cell, name, rotate, num) => {
        if (cell) {
          const inst = cell.createInstance();
          inst.name = name;
          if (num != null) {
            const txt = inst.findOne((n) => n.type === "TEXT");
            if (txt) {
              try {
                txt.characters = String(num);
              } catch (e) {
              }
            }
          }
          comp.appendChild(inst);
          if (rotate) {
            try {
              inst.rotation = 180;
            } catch (e) {
            }
            try {
              inst.x = x + SZ;
              inst.y = SZ;
            } catch (e) {
              inst.x = x;
              inst.y = 0;
            }
          } else {
            inst.x = x;
            inst.y = 0;
          }
        }
        x += SZ;
      };
      add(cs.first ? edgeDef : edgeDis, "pg-first", false);
      x += GAP_GROUP;
      add(cs.prev ? arrowDef : arrowDis, "pg-prev", false);
      x += GAP_SECTION;
      for (const n of cs.pages) add(n === cs.selected ? numSel : numDef, `pg-num-${n}`, false, n);
      x += GAP_SECTION;
      add(cs.next ? arrowDef : arrowDis, "pg-next", true);
      x += GAP_GROUP;
      add(cs.last ? edgeDef : edgeDis, "pg-last", true);
      try {
        comp.resize(x, SZ);
      } catch (e) {
      }
      if (x > maxW) maxW = x;
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Pagination";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Pagination"] = set;
    BUILT_COMPS["Pagination:Bar/Middle"] = comps[3];
    const opts = {
      title: "Pagination",
      colHeaders: [""],
      rowLabels: cases.map((c) => c.state),
      cellAt: (r, _c) => {
        var _a;
        return (_a = comps[r]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: maxW + 40,
      cellH: SZ + 24,
      rowLabelW: 80
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var GNB_MENU_SIZE = {
    md: { h: 56, font: 18, padX: 40, inset: 24 },
    sm: { h: 48, font: 18, padX: 32, inset: 20 },
    xsm: { h: 36, font: 14, padX: 32, inset: 20 }
  };
  var GNB_UTIL_SVGS = {
    // 원본 글리프(components.html). currentColor fill → icon/gray-dark 바인딩. viewBox 비율 보존(max side ≈ 24).
    lang: `<svg width="24" height="24" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18C13.9659 18 18 13.9659 18 9C18 4.03412 13.9659 0 9 0C4.03412 0 0 4.03412 0 9C0 13.9659 4.03412 18 9 18ZM2.97529 3.84353C3.56824 4.09765 4.18235 4.32 4.81765 4.5C4.42588 5.80235 4.20353 7.13647 4.16118 8.47059H1.09059C1.20706 6.71294 1.89529 5.10353 2.97529 3.84353ZM5.99294 1.65176C5.67529 2.25529 5.4 2.86941 5.16706 3.49412C4.69059 3.35647 4.22471 3.20824 3.78 3.02824C4.43647 2.45647 5.17765 1.99059 5.99294 1.65176ZM8.47059 1.09059V4.01294C7.71882 3.98118 6.95647 3.89647 6.20471 3.73765C6.53294 2.88 6.93529 2.03294 7.43294 1.21765C7.77177 1.15412 8.12118 1.11176 8.47059 1.09059ZM10.5671 1.21765C11.0647 2.03294 11.4671 2.88 11.7953 3.73765C11.0435 3.88588 10.2918 3.98118 9.52941 4.01294V1.09059C9.87882 1.11176 10.2282 1.15412 10.5671 1.21765ZM14.22 3.02824C13.7753 3.20824 13.3094 3.36706 12.8329 3.49412C12.6 2.86941 12.3247 2.25529 12.0071 1.65176C12.8224 1.99059 13.5635 2.45647 14.22 3.02824ZM16.9094 8.47059H13.8388C13.7965 7.13647 13.5741 5.80235 13.1824 4.5C13.8282 4.32 14.4424 4.09765 15.0247 3.84353C16.1047 5.10353 16.7929 6.71294 16.9094 8.47059ZM15.0247 14.1565C14.4424 13.9024 13.8176 13.68 13.1824 13.5C13.5741 12.1976 13.7965 10.8635 13.8388 9.52941H16.9094C16.7929 11.2871 16.1047 12.8965 15.0247 14.1565ZM12.0071 16.3482C12.3247 15.7447 12.6 15.1306 12.8329 14.5059C13.3094 14.6435 13.7753 14.7918 14.22 14.9718C13.5635 15.5435 12.8224 16.0094 12.0071 16.3482ZM9.52941 16.9094V13.9871C10.2812 14.0188 11.0435 14.1035 11.7953 14.2624C11.4671 15.12 11.0647 15.9671 10.5671 16.7824C10.2282 16.8459 9.87882 16.8882 9.52941 16.9094ZM7.43294 16.7824C6.93529 15.9671 6.53294 15.12 6.20471 14.2624C6.95647 14.1141 7.70824 14.0188 8.47059 13.9871V16.9094C8.12118 16.8882 7.77177 16.8459 7.43294 16.7824ZM3.78 14.9718C4.22471 14.7918 4.69059 14.6329 5.16706 14.5059C5.4 15.1306 5.67529 15.7447 5.99294 16.3482C5.17765 16.0094 4.43647 15.5435 3.78 14.9718ZM5.84471 4.74353C6.71294 4.92353 7.59177 5.04 8.47059 5.07176V8.47059H5.22C5.26235 7.22118 5.47412 5.97177 5.85529 4.74353H5.84471ZM12.1553 4.74353C12.5259 5.97177 12.7376 7.22118 12.7906 8.47059H9.54V5.07176C10.4188 5.04 11.2871 4.93412 12.1659 4.74353H12.1553ZM12.1553 13.2565C11.2871 13.0765 10.4082 12.96 9.52941 12.9388V9.54H12.78C12.7376 10.7894 12.5259 12.0388 12.1447 13.2671L12.1553 13.2565ZM8.47059 9.52941V12.9282C7.59177 12.96 6.72353 13.0659 5.84471 13.2459C5.47412 12.0176 5.26235 10.7682 5.20941 9.51882H8.46L8.47059 9.52941ZM4.16118 9.52941C4.20353 10.8635 4.42588 12.1976 4.81765 13.5C4.17177 13.68 3.55765 13.9024 2.97529 14.1565C1.89529 12.8965 1.20706 11.2871 1.09059 9.52941H4.16118Z" fill="currentColor"/></svg>`,
    account: `<svg width="24" height="21.58" viewBox="0 0 24 21.5816" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.561 13.7324H7.43901C5.67118 13.7324 4.00236 14.3971 2.84266 15.5568C0.494991 17.9186 0.0141426 21.2704 0 21.3977L1.37183 21.5816C1.37183 21.5816 1.81025 18.5409 3.8185 16.5185C4.72363 15.6134 6.03889 15.1042 7.43901 15.1042H16.561C17.9611 15.1042 19.2764 15.6275 20.1815 16.5185C22.1897 18.5409 22.6282 21.5391 22.6282 21.5816L24 21.3977C23.9859 21.2563 23.505 17.9045 21.1573 15.5568C19.9976 14.3971 18.3288 13.7324 16.561 13.7324Z" fill="currentColor"/><path d="M5.9968 6.01061C5.9968 9.31998 8.69803 12.0212 12.0074 12.0212C15.3168 12.0212 18.018 9.31998 18.018 6.01061C18.018 2.70124 15.3168 0 12.0074 0C8.69803 0 5.9968 2.70124 5.9968 6.01061ZM16.6037 6.01061C16.6037 8.54213 14.5389 10.607 12.0074 10.607C9.47588 10.607 7.41106 8.54213 7.41106 6.01061C7.41106 3.47908 9.47588 1.41426 12.0074 1.41426C14.5389 1.41426 16.6037 3.47908 16.6037 6.01061Z" fill="currentColor"/></svg>`,
    menu: `<svg width="24" height="16.93" viewBox="0 0 24 16.9274" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0 1.41176H24V0.705882V0H0V1.41176Z" fill="currentColor"/><path d="M0 9.17647H24V8.47059V7.76471H0V9.17647Z" fill="currentColor"/><path d="M0 16.9274H24V16.2215V15.5156H0V16.9274Z" fill="currentColor"/></svg>`
  };
  async function makeSlot(comp, propName, description, contents, preferredValues = [], layout = {}) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    const before = new Set(Object.entries(comp.componentPropertyDefinitions || {}).filter(([, d]) => d.type === "SLOT").map(([n]) => n));
    const slot = comp.createSlot();
    slot.name = propName;
    slot.fills = [];
    slot.layoutMode = (_a = layout.layoutMode) != null ? _a : "HORIZONTAL";
    slot.primaryAxisSizingMode = (_b = layout.primaryAxisSizingMode) != null ? _b : "AUTO";
    slot.counterAxisSizingMode = (_c = layout.counterAxisSizingMode) != null ? _c : "AUTO";
    slot.primaryAxisAlignItems = (_d = layout.primaryAxisAlignItems) != null ? _d : "CENTER";
    slot.counterAxisAlignItems = (_e = layout.counterAxisAlignItems) != null ? _e : "CENTER";
    slot.itemSpacing = (_f = layout.itemSpacing) != null ? _f : 0;
    slot.clipsContent = false;
    slot.paddingLeft = (_g = layout.paddingLeft) != null ? _g : 0;
    slot.paddingRight = (_h = layout.paddingRight) != null ? _h : 0;
    slot.paddingTop = (_i = layout.paddingTop) != null ? _i : 0;
    slot.paddingBottom = (_j = layout.paddingBottom) != null ? _j : 0;
    for (const c of contents) slot.appendChild(c);
    ((_k = layout.parent) != null ? _k : comp).appendChild(slot);
    if (layout.stretch) {
      try {
        slot.layoutAlign = "STRETCH";
      } catch (e) {
      }
    }
    if (layout.stretchContents) {
      for (const c of contents) {
        try {
          c.layoutAlign = "STRETCH";
        } catch (e) {
        }
      }
    }
    const defs = Object.entries(comp.componentPropertyDefinitions || {});
    const added = (_l = defs.find(([n, d]) => d.type === "SLOT" && !before.has(n))) == null ? void 0 : _l[0];
    if (defs.length && !added) throw new Error(`[makeSlot] ${propName} \uC2AC\uB86F \uC18D\uC131\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.`);
    if (added) comp.editComponentProperty(added, { name: propName, description, preferredValues });
    return slot;
  }
  async function fillGnbMenu(node, maps, sizeKey, state) {
    const navc = (k) => `color/navigation/${k}`;
    const S = GNB_MENU_SIZE[sizeKey];
    const active = state !== "Default";
    node.fills = [];
    const t = await makeBoundText("\uBA54\uB274\uD0C0\uC774\uD2C0", S.font, "Medium", scv(maps, navc(active ? "label/selected" : "label/default-alt")));
    node.appendChild(t);
    const W = Math.max(116, Math.ceil(t.width) + S.padX * 2);
    node.resize(W, S.h);
    t.x = (W - t.width) / 2;
    t.y = (S.h - t.height) / 2;
    const ul = figma.createRectangle();
    ul.resize(W - S.inset * 2, 2);
    ul.x = S.inset;
    ul.y = S.h - 2;
    ul.fills = active ? [boundPaint(scv(maps, navc("indicator/selected")))] : [];
    node.appendChild(ul);
    return W;
  }
  async function buildGNBUtilIcon(maps, originY) {
    var _a;
    const iconBox = async (role, svg) => {
      const box = figma.createFrame();
      box.name = role;
      box.resize(32, 32);
      box.fills = [];
      box.layoutMode = "HORIZONTAL";
      box.primaryAxisSizingMode = "FIXED";
      box.counterAxisSizingMode = "FIXED";
      box.primaryAxisAlignItems = "CENTER";
      box.counterAxisAlignItems = "CENTER";
      box.appendChild(await makeIconInstance(role, scv(maps, "color/icon/gray-dark"), 24, svg));
      return box;
    };
    const defs = [
      { language: "on", menu: "on", user: "on", label: "\uC5B8\uC5B4\xB7\uACC4\uC815\xB7\uBA54\uB274" },
      { language: "on", menu: "off", user: "on", label: "\uC5B8\uC5B4\xB7\uACC4\uC815" },
      { language: "on", menu: "off", user: "off", label: "\uC5B8\uC5B4" },
      { language: "off", menu: "on", user: "on", label: "\uACC4\uC815\xB7\uBA54\uB274" },
      { language: "off", menu: "off", user: "on", label: "\uACC4\uC815" }
    ];
    const comps = [];
    for (const d of defs) {
      const comp = figma.createComponent();
      comp.name = `language=${d.language}, menu=${d.menu}, user=${d.user}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.itemSpacing = 8;
      comp.fills = [];
      if (d.language === "on") {
        const langComp = (_a = BUILT_COMPS["LanguageIcon:Korean"]) != null ? _a : BUILT_COMPS["LanguageIcon:English"];
        if (langComp) comp.appendChild(langComp.createInstance());
      }
      if (d.user === "on") comp.appendChild(await iconBox("account", GNB_UTIL_SVGS.account));
      if (d.menu === "on") comp.appendChild(await iconBox("menu", GNB_UTIL_SVGS.menu));
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "GNB Utility Icon";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["GNB Utility Icon"] = set;
    BUILT_COMPS["GNBUtil:full"] = comps[0];
    const opts = {
      title: "GNB Utility Icon",
      colHeaders: [""],
      rowLabels: defs.map((d) => d.label),
      cellAt: (r, _c) => {
        var _a2;
        return (_a2 = comps[r]) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 40,
      rowLabelW: 120
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildLanguageIcon(maps, originY) {
    const variants = [
      { lang: "English", text: "English" },
      { lang: "Korean", text: "\uD55C\uAD6D\uC5B4" }
    ];
    const comps = [];
    for (const v of variants) {
      const comp = figma.createComponent();
      comp.name = `Language=${v.lang}`;
      comp.layoutMode = "HORIZONTAL";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "AUTO";
      comp.itemSpacing = 4;
      comp.paddingRight = 8;
      comp.fills = [];
      const globe = figma.createFrame();
      globe.name = "globe";
      globe.resize(32, 32);
      globe.fills = [];
      const gi = await makeIconInstance("globe", scv(maps, "color/icon/gray-dark"), 24, GNB_UTIL_SVGS.lang);
      globe.appendChild(gi);
      gi.x = (32 - gi.width) / 2;
      gi.y = (32 - gi.height) / 2;
      comp.appendChild(globe);
      const t = await makeBoundText(v.text, 14, "Medium", scv(maps, "color/text/body/primary"));
      comp.appendChild(t);
      setLightMode(comp, maps);
      comps.push(comp);
      BUILT_COMPS[`LanguageIcon:${v.lang}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Language Icon";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Language Icon"] = set;
    const opts = {
      title: "Language Icon",
      colHeaders: variants.map((v) => v.lang),
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = comps[c]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 56,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var BOTTOM_NAV_ICONS = [
    { icon: "home", role: "home", label: "\uD648" },
    { icon: "search", role: "navSearch", label: "\uAC80\uC0C9" },
    { icon: "notification", role: "navNotification", label: "\uC54C\uB9BC" },
    { icon: "settings", role: "navSettings", label: "\uC124\uC815" }
  ];
  async function buildMobileBottomNav(maps, originY) {
    const states = [
      { state: "unselected", icon: "color/navigation/icon/default", label: "color/navigation/label/default" },
      { state: "selected", icon: "color/icon/blue", label: "color/navigation/label/selected" }
    ];
    const variants = [];
    for (const iconDef of BOTTOM_NAV_ICONS) {
      for (const st of states) {
        variants.push(__spreadProps(__spreadValues({}, st), { iconName: iconDef.icon, iconRole: iconDef.role, text: iconDef.label }));
      }
    }
    const comps = [];
    for (const v of variants) {
      const comp = figma.createComponent();
      comp.name = `icon=${v.iconName}, state=${v.state}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.itemSpacing = 4;
      comp.fills = [];
      comp.resize(60, 60);
      const icon = v.iconRole === "home" ? await makeIconInstance("home", scv(maps, v.icon), 32, HOME_SVG) : await makeRequiredIconInstance(v.iconRole, scv(maps, v.icon), 32);
      comp.appendChild(icon);
      const label = await makeBoundText(v.text, 12, "Medium", scv(maps, v.label));
      comp.appendChild(label);
      setLightMode(comp, maps);
      comps.push(comp);
      BUILT_COMPS[`MobileBottomNav:${v.iconName}:${v.state}`] = comp;
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Mobile Bottom Nav";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Mobile Bottom Nav"] = set;
    const opts = {
      title: "Mobile Bottom Nav",
      colHeaders: ["Unselected", "Selected"],
      rowLabels: BOTTOM_NAV_ICONS.map((one) => one.icon),
      cellAt: (r, c) => {
        var _a;
        return (_a = comps[r * 2 + c]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 60,
      rowLabelW: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var MOBILE_HEADER_TYPES = [
    "Home / Title",
    "Home / Title + 1 Icon",
    "Home / Title + Subtitle + 1 Icon",
    "Standard / Title",
    "Standard / Title + Close",
    "Standard / No Title",
    "Standard / No Title + Close"
  ];
  var MOBILE_HEADER_PLATFORMS = ["App", "Web"];
  function makeMobileHeaderSlot(name) {
    const slot = figma.createFrame();
    slot.name = name;
    slot.layoutMode = "HORIZONTAL";
    slot.primaryAxisAlignItems = "CENTER";
    slot.counterAxisAlignItems = "CENTER";
    slot.primaryAxisSizingMode = "FIXED";
    slot.counterAxisSizingMode = "FIXED";
    slot.fills = [];
    slot.clipsContent = false;
    slot.resize(32, 32);
    return slot;
  }
  async function makeMobileHeaderIconSlot(name, role, colorVar, accentVar, iconSize = 24) {
    const slot = makeMobileHeaderSlot(name);
    slot.appendChild(await makeRequiredIconInstance(role, colorVar, iconSize, accentVar));
    return slot;
  }
  function makeMobileHeaderGrowFrame(name, align) {
    const frame = figma.createFrame();
    frame.name = name;
    frame.layoutMode = "HORIZONTAL";
    frame.primaryAxisAlignItems = align;
    frame.counterAxisAlignItems = "CENTER";
    frame.primaryAxisSizingMode = "FIXED";
    frame.counterAxisSizingMode = "FIXED";
    frame.layoutGrow = 1;
    frame.fills = [];
    frame.clipsContent = false;
    frame.resize(1, 32);
    return frame;
  }
  async function mobileHeaderStatusBarInstance(platform) {
    var _a;
    const status = (_a = BUILT_COMPS[`StatusBar:${platform}`]) != null ? _a : await reuseVariant("StatusBar", `StatusBar:${platform}`, [`Platform=${platform}`]);
    if (!status) throw new Error(`Mobile Header\uB294 StatusBar / Platform=${platform} \uC815\uBCF8\uC774 \uBA3C\uC800 \uD544\uC694\uD569\uB2C8\uB2E4.`);
    const inst = status.createInstance();
    inst.name = "StatusBar";
    return inst;
  }
  async function buildMobileHeaderVariant(type, platform, maps) {
    const isHome = type.startsWith("Home /");
    const statusBarHeight = platform === "Web" ? 77 : 27;
    const rootHeight = platform === "Web" ? 149 : 99;
    const comp = figma.createComponent();
    comp.name = `Type=${type}, Platform=${platform}`;
    comp.layoutMode = "VERTICAL";
    comp.primaryAxisSizingMode = "FIXED";
    comp.counterAxisSizingMode = "FIXED";
    comp.itemSpacing = 16;
    comp.fills = [boundPaint(scv(maps, isHome ? "color/bg/home" : "color/bg/level-0"))];
    comp.resize(360, rootHeight);
    const statusInst = await mobileHeaderStatusBarInstance(platform);
    comp.appendChild(statusInst);
    statusInst.resize(360, statusBarHeight);
    statusInst.layoutAlign = "STRETCH";
    statusInst.layoutSizingHorizontal = "FILL";
    statusInst.layoutSizingVertical = "FIXED";
    clearMode(statusInst, maps);
    statusInst.fills = [];
    const appBar = figma.createFrame();
    appBar.name = "AppBar";
    appBar.layoutMode = "HORIZONTAL";
    appBar.primaryAxisAlignItems = "CENTER";
    appBar.counterAxisAlignItems = "CENTER";
    appBar.primaryAxisSizingMode = "FIXED";
    appBar.counterAxisSizingMode = "FIXED";
    appBar.layoutAlign = "STRETCH";
    appBar.paddingTop = 12;
    appBar.paddingBottom = 12;
    appBar.paddingLeft = isHome ? 20 : 16;
    appBar.paddingRight = 16;
    appBar.fills = [boundPaint(scv(maps, isHome ? "color/bg/home" : "color/bg/level-0"))];
    appBar.resize(360, 56);
    comp.appendChild(appBar);
    const iconLight = scv(maps, "color/icon/gray-light");
    const iconDark = scv(maps, "color/icon/gray-dark");
    const titleColor = scv(maps, "color/text/title/primary");
    if (!isHome) {
      appBar.itemSpacing = 8;
      appBar.appendChild(await makeMobileHeaderIconSlot("Back", "mobileHeaderBack", iconDark));
      const center = makeMobileHeaderGrowFrame("Title", "CENTER");
      if (!type.startsWith("Standard / No Title")) {
        center.appendChild(await makeBoundText("\uC2A4\uD0E0\uB2E4\uB4DC\uD615 \uD0C0\uC774\uD2C0", 18, "Medium", titleColor, "title/18M"));
      }
      appBar.appendChild(center);
      appBar.appendChild(type.endsWith("+ Close") ? await makeMobileHeaderIconSlot("Close", "mobileHeaderClose", iconDark) : makeMobileHeaderSlot("Right spacer"));
    } else if (type === "Home / Title + Subtitle + 1 Icon") {
      const copy = figma.createFrame();
      copy.name = "Title + Subtitle";
      copy.layoutMode = "VERTICAL";
      copy.primaryAxisAlignItems = "CENTER";
      copy.counterAxisAlignItems = "MIN";
      copy.primaryAxisSizingMode = "AUTO";
      copy.counterAxisSizingMode = "AUTO";
      copy.layoutGrow = 1;
      copy.itemSpacing = 2;
      copy.fills = [];
      appBar.paddingTop = 6;
      appBar.paddingBottom = 6;
      const titleRow = figma.createFrame();
      titleRow.name = "Title";
      titleRow.layoutMode = "HORIZONTAL";
      titleRow.primaryAxisAlignItems = "MIN";
      titleRow.counterAxisAlignItems = "CENTER";
      titleRow.primaryAxisSizingMode = "AUTO";
      titleRow.counterAxisSizingMode = "AUTO";
      titleRow.itemSpacing = 4;
      titleRow.fills = [];
      titleRow.appendChild(await makeBoundText("\uD648 \uD0C0\uC774\uD2C0", 18, "Bold", titleColor, "title/18B"));
      titleRow.appendChild(await makeRequiredIconInstance("mobileHeaderArrowDown", iconDark, 24, void 0, -90));
      copy.appendChild(titleRow);
      copy.appendChild(await makeBoundText("\uD648 \uC11C\uBE0C\uD0C0\uC774\uD2C0", 14, "Regular", scv(maps, "color/text/body/tertiary"), "body/14R"));
      appBar.appendChild(copy);
      appBar.appendChild(await makeMobileHeaderIconSlot("Notification", "mobileHeaderNotification", iconDark, scv(maps, "color/icon/red")));
    } else {
      const title = makeMobileHeaderGrowFrame("Title", "MIN");
      title.appendChild(await makeBoundText("\uD648 \uD0C0\uC774\uD2C0", 18, "Bold", titleColor, "title/18B"));
      appBar.appendChild(title);
      if (type === "Home / Title + 1 Icon") {
        appBar.itemSpacing = 8;
        appBar.appendChild(await makeMobileHeaderIconSlot("Notification", "mobileHeaderNotification", iconDark, scv(maps, "color/icon/red")));
      }
    }
    setLightMode(comp, maps);
    return comp;
  }
  async function buildMobileHeader(maps, originY) {
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const platform of MOBILE_HEADER_PLATFORMS) {
      for (const type of MOBILE_HEADER_TYPES) {
        const comp = await buildMobileHeaderVariant(type, platform, maps);
        comps.push(comp);
        byKey.set(`${platform}:${type}`, comp);
        BUILT_COMPS[`MobileHeader:${platform}:${type}`] = comp;
        if (platform === "App") BUILT_COMPS[`MobileHeader:${type}`] = comp;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Mobile Header";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Mobile Header"] = set;
    const HOME_TYPES = MOBILE_HEADER_TYPES.filter((t) => t.startsWith("Home /"));
    const STD_TYPES = MOBILE_HEADER_TYPES.filter((t) => !t.startsWith("Home /"));
    const typeAt = (r, c) => (r % 2 === 0 ? HOME_TYPES : STD_TYPES)[c];
    const opts = {
      title: "Mobile Header",
      // Platform별로 Home 계열, Standard 계열을 나눠 완전 조합을 한눈에 검수한다.
      // 폭이 긴 스펙이므로 Dark 는 Light 오른쪽이 아니라 바로 아래에 둔다.
      // 열 수는 계열 길이에서 유도한다 — 고정하면 계열이 늘 때 마지막 유형이 조용히 사라진다.
      //   (🤖 component-verifier 2026-09-08 지적: 인덱스 산식은 없앴지만 열 수 고정은 같은 실패 모양으로 남아 있었다.)
      colHeaders: new Array(Math.max(HOME_TYPES.length, STD_TYPES.length)).fill(""),
      rowLabels: ["App / Home", "App / Standard", "Web / Home", "Web / Standard"],
      cellAt: (r, c) => {
        var _a;
        const platform = r < 2 ? "App" : "Web";
        const type = typeAt(r, c);
        return type ? (_a = byKey.get(`${platform}:${type}`)) != null ? _a : null : null;
      },
      cellLabelAt: (r, c) => {
        const platform = r < 2 ? "App" : "Web";
        const type = typeAt(r, c);
        const comp = type ? byKey.get(`${platform}:${type}`) : null;
        return comp ? comp.name.replace(/^Type=/, "").replace(/, Platform=(App|Web)$/, "") : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 384,
      cellH: 149,
      rowLabelW: 232,
      leftAlignCells: true,
      stackDarkBelow: true,
      // 상태끼리 다닥다닥 붙어 어디까지가 한 유형인지 안 보였다(river 지시 2026-09-09).
      rowGap: 56,
      // 헤더가 흰 바탕이라 흰 스펙 배경에서 사라진다 → 배경을 한 단계 진하게.
      contrastBg: true
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildGNB(maps, originY) {
    var _a, _b;
    const navc = (k) => `color/navigation/${k}`;
    const sizeKeys = ["md", "sm", "xsm"];
    const menuStates = ["Default", "Hover", "Selected"];
    const menuComps = [];
    const menuCellByKey = /* @__PURE__ */ new Map();
    for (const sk of sizeKeys) {
      for (const ms of menuStates) {
        const comp = figma.createComponent();
        comp.name = `Size=${sk}, State=${ms}`;
        await fillGnbMenu(comp, maps, sk, ms);
        setLightMode(comp, maps);
        menuComps.push(comp);
        menuCellByKey.set(`${sk}/${ms}`, comp);
      }
    }
    const menuSet = figma.combineAsVariants(menuComps, figma.currentPage);
    menuSet.name = "GNB Menu";
    const menuOpts = {
      title: "GNB Menu",
      platforms: [{ name: "PC", sizes: sizeKeys }],
      rowLabels: [""],
      colHeaders: menuStates,
      cellAt: (_p, size, _ri, ci) => {
        var _a2;
        return (_a2 = menuCellByKey.get(`${size}/${menuStates[ci]}`)) != null ? _a2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 200,
      cellH: 72,
      rowLabelW: 16
    };
    let bottomY = originY;
    const BAR_W = 1920;
    const barH = { md: 56, sm: 48, xsm: 36 };
    const aligns = [
      { name: "Center-Between", key: "center-between" },
      { name: "Start", key: "start" }
    ];
    const barComps = [];
    const barCellByKey = /* @__PURE__ */ new Map();
    for (const al of aligns) {
      for (const sk of sizeKeys) {
        const h = barH[sk];
        const padL = sk === "xsm" ? 20 : 24;
        const padR = sk === "xsm" ? 24 : 20;
        const comp = figma.createComponent();
        comp.name = `Align=${al.name}, Size=${sk}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.primaryAxisAlignItems = "SPACE_BETWEEN";
        comp.counterAxisAlignItems = "CENTER";
        comp.paddingLeft = padL;
        comp.paddingRight = padR;
        comp.paddingTop = 0;
        comp.paddingBottom = 0;
        comp.itemSpacing = 0;
        comp.fills = [boundPaint(scv(maps, navc("bg")))];
        comp.clipsContent = true;
        comp.resize(BAR_W, h);
        const logo = await makeBoundText("SAMPLE LOGO", 20, "Bold", scv(maps, "color/text/title/primary"));
        const menuItems = [];
        for (let mi = 0; mi < 3; mi++) {
          const state = mi === 0 ? "Selected" : "Default";
          const menuComp = menuCellByKey.get(`${sk}/${state}`);
          if (menuComp) {
            menuItems.push(menuComp.createInstance());
          } else {
            const f = figma.createFrame();
            f.name = "menu";
            await fillGnbMenu(f, maps, sk, state);
            menuItems.push(f);
          }
        }
        const menus = await makeSlot(
          comp,
          "Menus",
          "\uBA54\uB274\uAC00 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 \uBA54\uB274 3\uAC1C\uC774\uBA70, GNB Menu \uC778\uC2A4\uD134\uC2A4\uB97C \uB123\uACE0 \uBE7C\uC11C \uBA54\uB274 \uC218\uB97C \uB298\uB9AC\uACE0 \uC904\uC778\uB2E4.",
          menuItems,
          menuSet ? [{ type: "COMPONENT_SET", key: menuSet.key }] : []
        );
        let utilComp = BUILT_COMPS["GNBUtil:full"];
        if (!utilComp) {
          const us = await getBuiltSet("GNB Utility Icon");
          if (us) utilComp = (_a = (us.children || []).find((c) => c.type === "COMPONENT" && c.name.includes("language=on, menu=on, user=on"))) != null ? _a : (us.children || []).find((c) => c.type === "COMPONENT");
        }
        const util = utilComp ? utilComp.createInstance() : null;
        if (al.key === "center-between") {
          comp.appendChild(logo);
          comp.appendChild(menus);
          if (util) comp.appendChild(util);
        } else {
          const leading = figma.createFrame();
          leading.name = "leading";
          leading.fills = [];
          leading.layoutMode = "HORIZONTAL";
          leading.itemSpacing = 64;
          leading.counterAxisAlignItems = "CENTER";
          leading.primaryAxisSizingMode = "AUTO";
          leading.counterAxisSizingMode = "AUTO";
          comp.appendChild(leading);
          leading.appendChild(logo);
          leading.appendChild(menus);
          if (util) comp.appendChild(util);
        }
        const border = figma.createRectangle();
        border.name = "border";
        border.resize(BAR_W, 1);
        border.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
        try {
          comp.insertChild(0, border);
        } catch (e) {
          comp.appendChild(border);
        }
        try {
          border.layoutPositioning = "ABSOLUTE";
        } catch (e) {
        }
        border.x = 0;
        border.y = h - 1;
        setLightMode(comp, maps);
        barComps.push(comp);
        barCellByKey.set(`${al.name}/${sk}`, comp);
      }
    }
    const barSet = figma.combineAsVariants(barComps, figma.currentPage);
    barSet.name = "GNB";
    const barTop = originY;
    const barOrder = [];
    for (const a of aligns) for (const sk of sizeKeys) barOrder.push({ comp: (_b = barCellByKey.get(`${a.name}/${sk}`)) != null ? _b : null, label: `${a.name} \xB7 ${sk}` });
    const barOpts = {
      title: "GNB",
      colHeaders: [""],
      rowLabels: barOrder.map((b) => b.label),
      cellAt: (r, _c) => barOrder[r].comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY: barTop,
      cellW: BAR_W + 40,
      cellH: 96,
      rowLabelW: 160
    };
    const barLightBottomY = await decorateSetFlat(barSet, barOpts, maps);
    bottomY = Math.max(bottomY, barLightBottomY);
    barOpts.darkOffset = { x: 0, y: barLightBottomY + 80 };
    try {
      bottomY = Math.max(bottomY, await buildSpec(barOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    menuOpts.originY = bottomY + 80;
    bottomY = Math.max(bottomY, await decorateSetGrouped(menuSet, menuOpts, maps));
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(menuOpts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set: barSet, bottomY };
  }
  var GNB_SUBMENU_DEPTHS = ["1depth", "2depth"];
  var GNB_SUBMENU_TYPES = ["regular", "compact-1", "compact-2"];
  var GNB_SUBMENU_STATES = ["Default", "Hover", "Selected"];
  var gnbSubMenuItemHasState = (depth, state) => depth !== "1depth" || state === "Default";
  async function buildGNBSubMenuItem(maps, originY) {
    const navc = (k) => `color/navigation/${k}`;
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const depth of GNB_SUBMENU_DEPTHS) {
      const first = depth === "1depth";
      for (const state of GNB_SUBMENU_STATES) {
        if (!gnbSubMenuItemHasState(depth, state)) continue;
        const comp = figma.createComponent();
        comp.name = `Depth=${depth}, State=${state}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.counterAxisAlignItems = "CENTER";
        comp.fills = [];
        const colorKey = state === "Default" ? first ? "submenu/label/default" : "label/default" : "label/selected";
        comp.appendChild(first ? await makeBoundText("\uCE74\uD14C\uACE0\uB9AC \uC81C\uBAA9", 16, "Bold", scv(maps, navc(colorKey)), "title/16B") : await makeBoundText("\uD558\uC704 \uBA54\uB274", 16, "Medium", scv(maps, navc(colorKey)), "title/16M"));
        setLightMode(comp, maps);
        comps.push(comp);
        byKey.set(`${depth}:${state}`, comp);
        BUILT_COMPS[`GNBSubMenuItem:${depth}:${state}`] = comp;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "GNB Sub Menu Item";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["GNB Sub Menu Item"] = set;
    const opts = {
      title: "GNB Sub Menu Item",
      colHeaders: GNB_SUBMENU_STATES,
      rowLabels: GNB_SUBMENU_DEPTHS.map((d) => d),
      // 1depth 의 Hover·Selected 칸은 비운다(변형이 없다) — 스펙시트는 null 을 빈 칸으로 그린다.
      cellAt: (r, c) => {
        var _a;
        return (_a = byKey.get(`${GNB_SUBMENU_DEPTHS[r]}:${GNB_SUBMENU_STATES[c]}`)) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 160,
      cellH: 44,
      rowLabelW: 96
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildGNBSubMenu(maps, originY) {
    const PANEL_W = 1920;
    const itemComp = async (depth, state) => {
      var _a;
      const c = (_a = BUILT_COMPS[`GNBSubMenuItem:${depth}:${state}`]) != null ? _a : await reuseVariant("GNB Sub Menu Item", `GNBSubMenuItem:${depth}:${state}`, [`Depth=${depth}`, `State=${state}`]);
      if (c) return c.createInstance();
      throw new Error("GNB Sub Menu \uB294 GNB Sub Menu Item \uC815\uBCF8\uC774 \uBA3C\uC800 \uD544\uC694\uD569\uB2C8\uB2E4.");
    };
    const num = (t) => requireVar(maps.foundationNumber, t, "Foundation Number");
    const TYPE_SPEC = {
      // regular(540:6423) — 제목 + 항목. 4열이고 열마다 항목 수가 다르다: 5 / 3 / 4 / 5.
      //   Selected 표본은 4번째 열의 4번째 항목("단말기정보")이다 — 원본 스크린샷 실측
      //   (figma-shots/regular_540-6423.png). 종전 [4,4,4,4]·첫 열 첫 항목은 근사치였다
      //   (🤖 component-verifier 2026-09-09 A-1·A-2 적발). 높이로 교차검증됨:
      //   32 + (제목 21 + 항목 5×21 + 간격 5×24 = 246) + 64 = 342 = 원본 높이.
      "regular": {
        padTop: "spacing/32",
        padBottom: "spacing/64",
        groups: 4,
        perGroup: [5, 3, 4, 5],
        groupAxis: "VERTICAL",
        groupGap: "spacing/80",
        innerGap: "spacing/24",
        withTitle: true,
        selected: [3, 3]
      },
      // compact-1(540:6399) — 제목 없이 항목 6개를 한 줄로 가로 나열. 원본은 마지막 항목이 파란 강조다.
      "compact-1": {
        padTop: "spacing/24",
        padBottom: "spacing/24",
        groups: 6,
        perGroup: [1, 1, 1, 1, 1, 1],
        groupAxis: "VERTICAL",
        groupGap: "spacing/80",
        innerGap: null,
        withTitle: false,
        selected: [5, 0]
      },
      // compact-2(540:6407) — 제목 없이 5묶음, 묶음당 항목 2개(마지막 묶음만 1개). 원본은 그 1개가 파란 강조다.
      "compact-2": {
        padTop: "spacing/24",
        padBottom: "spacing/24",
        groups: 5,
        perGroup: [2, 2, 2, 2, 1],
        groupAxis: "VERTICAL",
        groupGap: "spacing/80",
        innerGap: "spacing/20",
        withTitle: false,
        selected: [4, 0]
      }
    };
    const comps = [];
    for (const type of GNB_SUBMENU_TYPES) {
      const spec = TYPE_SPEC[type];
      const comp = figma.createComponent();
      comp.name = `Type=${type}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "AUTO";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "MIN";
      comp.itemSpacing = 0;
      comp.fills = [boundPaint(scv(maps, "color/navigation/bg"))];
      comp.setBoundVariable("paddingTop", num(spec.padTop));
      comp.setBoundVariable("paddingBottom", num(spec.padBottom));
      comp.setBoundVariable("paddingLeft", num("spacing/24"));
      comp.setBoundVariable("paddingRight", num("spacing/24"));
      comp.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.strokeTopWeight = 0;
      comp.strokeLeftWeight = 0;
      comp.strokeRightWeight = 0;
      comp.strokeBottomWeight = 1;
      comp.resize(PANEL_W, 100);
      try {
        comp.effects = boundShadowEffects(maps, "shadow/dropdown");
      } catch (e) {
      }
      const columns = [];
      for (let gi = 0; gi < spec.groups; gi++) {
        const col = figma.createFrame();
        col.name = "column";
        col.layoutMode = spec.groupAxis;
        col.primaryAxisSizingMode = "AUTO";
        col.counterAxisSizingMode = "AUTO";
        col.counterAxisAlignItems = "MIN";
        col.itemSpacing = spec.innerGap ? Number(spec.innerGap.split("/")[1]) : 0;
        if (spec.innerGap) col.setBoundVariable("itemSpacing", num(spec.innerGap));
        col.fills = [];
        if (spec.withTitle) col.appendChild(await itemComp("1depth", "Default"));
        for (let ii = 0; ii < spec.perGroup[gi]; ii++) {
          const isSel = gi === spec.selected[0] && ii === spec.selected[1];
          col.appendChild(await itemComp("2depth", isSel ? "Selected" : "Default"));
        }
        columns.push(col);
      }
      const wrap = await makeSlot(
        comp,
        "Columns",
        "\uD558\uC704\uBA54\uB274 \uD56D\uBAA9\uC774 \uB193\uC774\uB294 \uC790\uB9AC. GNB Sub Menu Item \uC778\uC2A4\uD134\uC2A4\uB97C \uB123\uACE0 \uBE7C\uC11C \uBA54\uB274 \uC218\uC640 \uAE4A\uC774\uB97C \uC870\uC808\uD55C\uB2E4. regular \uB294 \uC81C\uBAA9+\uD56D\uBAA9 4\uC5F4, compact-1 \uC740 \uD56D\uBAA9 \uD55C \uC904, compact-2 \uB294 \uBB36\uC74C\uB9C8\uB2E4 \uD56D\uBAA9 2\uAC1C\uAE4C\uC9C0\uB2E4.",
        columns,
        BUILT_SETS["GNB Sub Menu Item"] ? [{ type: "COMPONENT_SET", key: BUILT_SETS["GNB Sub Menu Item"].key }] : [],
        {
          layoutMode: "HORIZONTAL",
          primaryAxisSizingMode: "AUTO",
          counterAxisSizingMode: "AUTO",
          primaryAxisAlignItems: "MIN",
          counterAxisAlignItems: "MIN",
          itemSpacing: 80
        }
      );
      try {
        wrap.setBoundVariable("itemSpacing", num(spec.groupGap));
      } catch (e) {
      }
      setLightMode(comp, maps);
      comps.push(comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "GNB Sub Menu";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["GNB Sub Menu"] = set;
    const opts = {
      title: "GNB Sub Menu",
      colHeaders: [""],
      rowLabels: GNB_SUBMENU_TYPES.map((t) => t),
      cellAt: (r, _c) => {
        var _a;
        return (_a = comps[r]) != null ? _a : null;
      },
      // 폭 1920 — GNB 바와 같은 이유로 다크 스펙을 우측이 아니라 아래에 쌓는다.
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: PANEL_W + 40,
      cellH: 380,
      rowLabelW: 160,
      leftAlignCells: true
    };
    const lightBottom = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottom + 80 };
    let bottomY = lightBottom;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var DP = (k) => `color/date-picker/${k}`;
  var CAL_GEO = {
    // MD — 종전 값 그대로. 패널 352 는 원본(Date 356 · Tile 364)을 단일 높이로 정규화한 기존 정본 값이며
    //   이번 작업에서 손대지 않는다(원본과의 차이는 별도 보고 — 이 작업의 범위가 아니다).
    MD: {
      cell: 44,
      inner: 30,
      cellFont: 16,
      bandY: 7,
      bandH: 30,
      tileW: 88,
      tileH: 56,
      tileFont: 16,
      tileGapX: 12,
      tileGapY: 12,
      panelW: 356,
      padX: 24,
      padTop: 20,
      panelHDate: 352,
      padBottomDate: 20,
      hdrHDate: 32,
      gapDate: 16,
      panelHTile: 352,
      padBottomTile: 20,
      hdrHTile: 32,
      gapTile: 20,
      hdrFont: 24
    },
    // SM — 원본 실측. 폭 267 = 좌우 18 + 7×33. Date 높이 266 = 16+24+12+33+(5×33)+16.
    //   타일 뷰 높이 276 = 16+32+12+(4×40+3×12)+20. 타일 그리드(218)는 MD 와 같은 중앙 정렬이라
    //   좌우 안쪽 여백이 24.5 가 되는데, 원본(폭 266·여백 24)과 0.5px 차이다.
    SM: {
      cell: 33,
      inner: 22.5,
      cellFont: 12,
      bandY: 5.25,
      bandH: 22.5,
      tileW: 68,
      tileH: 40,
      tileFont: 12,
      tileGapX: 7,
      tileGapY: 12,
      panelW: 267,
      padX: 18,
      padTop: 16,
      panelHDate: 266,
      padBottomDate: 16,
      hdrHDate: 24,
      gapDate: 12,
      panelHTile: 276,
      padBottomTile: 20,
      hdrHTile: 32,
      gapTile: 12,
      hdrFont: 18
    }
  };
  var CAL_SIZES = ["MD", "SM"];
  async function calCellCompsForSize(maps, size) {
    const STD = {
      Default: ["cell/bg/today", "cell/bg/today", "text/secondary"],
      Hover: ["cell/bg/hover", "cell/bg/hover", "text/secondary"],
      Today: ["cell/bg/today", "cell/border/today", "text/today"],
      Selected: ["cell/bg/selected", "cell/border/today", "text/selected"],
      "Selected Hover": ["cell/bg/selected-hover", "cell/bg/selected-hover", "text/selected"],
      Disabled: ["cell/bg/today", "cell/bg/today", "text/disabled"]
    };
    const RNG = {
      Default: ["cell/bg/range", "cell/bg/range", "text/secondary"],
      Start: ["cell/bg/today", "cell/border/today", "text/today"],
      End: ["cell/bg/selected", "cell/border/today", "text/selected"],
      Disabled: ["cell/bg/range", "cell/bg/range", "text/disabled"]
    };
    function bandGeo(state, cw) {
      if (state === "Start") return [cw / 2, cw / 2];
      if (state === "End") return [0, cw / 2];
      return [0, cw];
    }
    async function makeInner(g2, fillKey, strokeKey, textKey) {
      const inner = figma.createFrame();
      inner.name = "inner";
      bindRadius(inner, maps, "radius/full");
      inner.layoutMode = "HORIZONTAL";
      inner.primaryAxisAlignItems = "CENTER";
      inner.counterAxisAlignItems = "CENTER";
      inner.primaryAxisSizingMode = "FIXED";
      inner.counterAxisSizingMode = "FIXED";
      inner.resize(g2.inner, g2.inner);
      inner.fills = [boundPaint(scv(maps, DP(fillKey)))];
      inner.strokes = [boundPaint(scv(maps, DP(strokeKey)))];
      inner.strokeWeight = 1;
      inner.strokeAlign = "INSIDE";
      const t = await makeBoundText("1", g2.cellFont, "Medium", scv(maps, DP(textKey)));
      t.name = "num";
      inner.appendChild(t);
      return inner;
    }
    const comps = [];
    const variants = {};
    function makeOuter(g2, name) {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(g2.cell, g2.cell);
      comp.fills = [];
      comp.clipsContent = true;
      return comp;
    }
    const g = CAL_GEO[size];
    for (const state of ["Default", "Hover", "Today", "Selected", "Selected Hover", "Disabled"]) {
      const [f, st, txt] = STD[state];
      const comp = makeOuter(g, `Size=${size}, Type=Standard, State=${state}`);
      comp.appendChild(await makeInner(g, f, st, txt));
      comps.push(comp);
      variants[`${size}:Standard:${state}`] = comp;
    }
    for (const state of ["Default", "Start", "End", "Disabled"]) {
      const [f, st, txt] = RNG[state];
      const [bx, bw] = bandGeo(state, g.cell);
      const comp = makeOuter(g, `Size=${size}, Type=Range, State=${state}`);
      const band = figma.createRectangle();
      band.name = "band";
      band.resize(bw, g.bandH);
      band.fills = [boundPaint(scv(maps, DP("cell/bg/range")))];
      band.strokes = [];
      comp.appendChild(band);
      try {
        band.layoutPositioning = "ABSOLUTE";
      } catch (e) {
      }
      try {
        band.x = bx;
        band.y = g.bandY;
      } catch (e) {
      }
      comp.appendChild(await makeInner(g, f, st, txt));
      comps.push(comp);
      variants[`${size}:Range:${state}`] = comp;
    }
    return variants;
  }
  async function buildCalendarCell(maps) {
    const variants = {};
    for (const size of CAL_SIZES) Object.assign(variants, await calCellCompsForSize(maps, size));
    const set = figma.combineAsVariants(Object.values(variants), figma.currentPage);
    set.name = "Calendar Cell";
    return { set, variants };
  }
  async function calTileCompsForSize(maps, size) {
    const TILE = {
      Default: ["tile/bg/default", "tile/border/default", "text/primary", "2022"],
      // Hover bg = Secondary 버튼 hover foundation 동일(gray/50·gray-dark/200) → tile/bg/hover 신규(사용자 결정 2026-06-25).
      Hover: ["tile/bg/hover", "tile/border/default", "text/primary", "2023"],
      Selected: ["tile/bg/selected", "cell/border/today", "text/today", "2025"],
      Disabled: ["tile/bg/disabled", "tile/border/disabled", "text/disabled", "2021"]
    };
    const variants = {};
    const g = CAL_GEO[size];
    for (const state of ["Default", "Hover", "Selected", "Disabled"]) {
      const [bg, bd, txt, label] = TILE[state];
      const comp = figma.createComponent();
      comp.name = `Size=${size}, State=${state}`;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(g.tileW, g.tileH);
      comp.cornerRadius = 4;
      comp.clipsContent = true;
      comp.fills = [boundPaint(scv(maps, DP(bg)))];
      comp.strokes = [boundPaint(scv(maps, DP(bd)))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      const t = await makeBoundText(label, g.tileFont, "Medium", scv(maps, DP(txt)));
      t.name = "label";
      comp.appendChild(t);
      variants[`${size}:${state}`] = comp;
    }
    return variants;
  }
  async function buildCalendarTile(maps) {
    const variants = {};
    for (const size of CAL_SIZES) Object.assign(variants, await calTileCompsForSize(maps, size));
    const set = figma.combineAsVariants(Object.values(variants), figma.currentPage);
    set.name = "Calendar Tile";
    return { set, variants };
  }
  var _calCell = null;
  var _calTile = null;
  function variantProp(comp, prop) {
    const m = comp.name.match(new RegExp(`(?:^|, )${prop}=([^,]+)`));
    return m ? m[1].trim() : null;
  }
  function reconstructCalCellVariants(set) {
    const variants = {};
    for (const ch of set.children) {
      if (ch.type !== "COMPONENT") continue;
      const t = variantProp(ch, "Type"), st = variantProp(ch, "State");
      if (!t || !st) continue;
      let sz = variantProp(ch, "Size");
      if (!sz) {
        sz = "MD";
        ch.name = `Size=MD, ${ch.name}`;
      }
      variants[`${sz}:${t}:${st}`] = ch;
    }
    return variants;
  }
  function reconstructCalTileVariants(set) {
    const variants = {};
    for (const ch of set.children) {
      if (ch.type !== "COMPONENT") continue;
      const st = variantProp(ch, "State");
      if (!st) continue;
      let sz = variantProp(ch, "Size");
      if (!sz) {
        sz = "MD";
        ch.name = `Size=MD, ${ch.name}`;
      }
      variants[`${sz}:${st}`] = ch;
    }
    return variants;
  }
  async function fillMissingCalSizes(set, variants, make) {
    for (const size of CAL_SIZES) {
      if (Object.keys(variants).some((k) => k.startsWith(`${size}:`))) continue;
      const added = await make(size);
      for (const comp of Object.values(added)) set.appendChild(comp);
      Object.assign(variants, added);
    }
    return variants;
  }
  async function getOrBuildCalendarCell(maps) {
    if (_calCell && !_calCell.set.removed) return _calCell;
    const existing = await getBuiltSet("Calendar Cell");
    if (existing && !existing.removed && existing.children.some((c) => c.type === "COMPONENT")) {
      const variants = await fillMissingCalSizes(existing, reconstructCalCellVariants(existing), (sz) => calCellCompsForSize(maps, sz));
      _calCell = { set: existing, variants };
    } else {
      _calCell = await buildCalendarCell(maps);
    }
    BUILT_SETS["Calendar Cell"] = _calCell.set;
    for (const [k, c] of Object.entries(_calCell.variants)) BUILT_COMPS[`CalendarCell:${k}`] = c;
    return _calCell;
  }
  async function getOrBuildCalendarTile(maps) {
    if (_calTile && !_calTile.set.removed) return _calTile;
    const existing = await getBuiltSet("Calendar Tile");
    if (existing && !existing.removed && existing.children.some((c) => c.type === "COMPONENT")) {
      const variants = await fillMissingCalSizes(existing, reconstructCalTileVariants(existing), (sz) => calTileCompsForSize(maps, sz));
      _calTile = { set: existing, variants };
    } else {
      _calTile = await buildCalendarTile(maps);
    }
    BUILT_SETS["Calendar Tile"] = _calTile.set;
    for (const [k, c] of Object.entries(_calTile.variants)) BUILT_COMPS[`CalendarTile:${k}`] = c;
    return _calTile;
  }
  async function calCellInstance(cell, key, day, numColor) {
    var _a, _b;
    const master = (_a = cell.variants[key]) != null ? _a : cell.variants["MD:Standard:Default"];
    const inst = master.createInstance();
    const t = (_b = inst.findOne((n) => n.name === "num" && n.type === "TEXT")) != null ? _b : inst.findOne((n) => n.type === "TEXT");
    if (t) {
      await figma.loadFontAsync(t.fontName);
      t.characters = String(day);
      if (numColor) {
        try {
          t.fills = [boundPaint(numColor)];
        } catch (e) {
        }
      }
    }
    return inst;
  }
  async function calTileInstance(tile, key, label) {
    var _a, _b;
    const master = (_a = tile.variants[key]) != null ? _a : tile.variants["MD:Default"];
    const inst = master.createInstance();
    const t = (_b = inst.findOne((n) => n.name === "label" && n.type === "TEXT")) != null ? _b : inst.findOne((n) => n.type === "TEXT");
    if (t) {
      await figma.loadFontAsync(t.fontName);
      t.characters = label;
    }
    return inst;
  }
  function dayKindToCellKey(kind) {
    if (kind === "today") return "Standard:Today";
    if (kind === "selected") return "Standard:Selected";
    if (kind === "disabled" || kind === "other") return "Standard:Disabled";
    return "Standard:Default";
  }
  async function buildCalendarNavArrow(maps, originY) {
    const dpn = (k) => `color/date-picker/${k}`;
    const CHEV_PREV = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 12L6 8l4-4" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const BOX = 24;
    const states = [
      { state: "Default", bg: null, icon: dpn("icon/default") },
      { state: "Hover", bg: dpn("cell/bg/hover"), icon: dpn("icon/hover") },
      { state: "Disabled", bg: null, icon: dpn("icon/disabled") }
    ];
    const comps = [];
    const byState = /* @__PURE__ */ new Map();
    for (const st of states) {
      const comp = figma.createComponent();
      comp.name = `State=${st.state}`;
      comp.resize(BOX, BOX);
      comp.cornerRadius = 4;
      comp.fills = st.bg ? [boundPaint(scv(maps, st.bg))] : [];
      const icon = await makeIconInstance("chevron", scv(maps, st.icon), 0, CHEV_PREV, 180, { wrap: false, keepName: true });
      comp.appendChild(icon);
      centerIconInBox(icon, comp, BOX);
      setLightMode(comp, maps);
      comps.push(comp);
      byState.set(st.state, comp);
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Calendar Nav Arrow";
    set.x = 0;
    set.y = originY;
    for (const [k, v] of byState) BUILT_COMPS[`CalendarNavArrow:${k}`] = v;
    BUILT_SETS["Calendar Nav Arrow"] = set;
    const cols = states.map((s) => s.state);
    const opts = {
      title: "Calendar Nav Arrow",
      colHeaders: cols,
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = byState.get(cols[c])) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 72,
      cellH: 48,
      rowLabelW: 64,
      contrastBg: true
      // 상자 자체가 투명(Default·Disabled)이라 흰 배경에서는 면이 안 보인다
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildCalendar(maps, originY) {
    const dp = (k) => `color/date-picker/${k}`;
    const calCell = await getOrBuildCalendarCell(maps);
    const calTile = await getOrBuildCalendarTile(maps);
    const CHEV_L = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 12L6 8l4-4" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const CHEV_R = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M6 4l4 4-4 4" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    function initComp(g, compName, panelH, padBottom, vGap) {
      const comp = figma.createComponent();
      comp.name = compName;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.primaryAxisAlignItems = "CENTER";
      comp.counterAxisAlignItems = "CENTER";
      comp.resize(g.panelW, panelH);
      comp.paddingLeft = g.padX;
      comp.paddingRight = g.padX;
      comp.paddingTop = g.padTop;
      comp.paddingBottom = padBottom;
      comp.itemSpacing = 0;
      comp.cornerRadius = 4;
      comp.fills = [boundPaint(scv(maps, dp("panel/bg")))];
      comp.strokes = [boundPaint(scv(maps, dp("panel/border")))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.clipsContent = true;
      const calEffects = shadowEffects("shadow/dropdown");
      try {
        comp.effects = calEffects;
      } catch (_) {
      }
      const inner = figma.createFrame();
      inner.name = "content";
      inner.fills = [];
      inner.layoutMode = "VERTICAL";
      inner.primaryAxisSizingMode = "AUTO";
      inner.counterAxisSizingMode = "AUTO";
      inner.counterAxisAlignItems = "CENTER";
      inner.itemSpacing = vGap;
      comp.appendChild(inner);
      inner.layoutAlign = "STRETCH";
      return [comp, inner];
    }
    async function calNavArrow(next, fallbackSvg) {
      var _a;
      const master = (_a = BUILT_COMPS["CalendarNavArrow:Default"]) != null ? _a : await reuseVariant("Calendar Nav Arrow", "CalendarNavArrow:Default", ["State=Default"]);
      if (!master) {
        console.warn("[Calendar] Calendar Nav Arrow \uC138\uD2B8\uB97C \uCC3E\uC9C0 \uBABB\uD574 \uC544\uC774\uCF58\uC744 \uC9C1\uC811 \uADF8\uB9BD\uB2C8\uB2E4 \u2014 \uC138\uD2B8\uB97C \uBA3C\uC800 \uC124\uCE58\uD558\uBA74 \uC778\uC2A4\uD134\uC2A4\uB85C \uBD99\uC2B5\uB2C8\uB2E4.");
        return makeIconInstance("chevron", scv(maps, dp("icon/default")), 0, fallbackSvg, next ? 0 : 180, { wrap: !next });
      }
      const inst = master.createInstance();
      inst.name = next ? "next" : "prev";
      if (!next) return inst;
      const wrap = figma.createFrame();
      wrap.name = "next";
      wrap.fills = [];
      wrap.clipsContent = false;
      wrap.layoutMode = "HORIZONTAL";
      wrap.primaryAxisAlignItems = "CENTER";
      wrap.counterAxisAlignItems = "CENTER";
      wrap.primaryAxisSizingMode = "FIXED";
      wrap.counterAxisSizingMode = "FIXED";
      wrap.resize(inst.width, inst.height);
      try {
        inst.rotation = 180;
      } catch (e) {
      }
      wrap.appendChild(inst);
      return wrap;
    }
    async function makeCalHdr(g, hdrH, label) {
      const hdr = figma.createFrame();
      hdr.name = "header";
      hdr.fills = [];
      hdr.layoutMode = "HORIZONTAL";
      hdr.primaryAxisSizingMode = "FIXED";
      hdr.counterAxisSizingMode = "FIXED";
      hdr.primaryAxisAlignItems = "SPACE_BETWEEN";
      hdr.counterAxisAlignItems = "CENTER";
      hdr.resize(g.panelW - g.padX * 2, hdrH);
      hdr.appendChild(await calNavArrow(false, CHEV_L));
      hdr.appendChild(await makeBoundText(label, g.hdrFont, "Bold", scv(maps, dp("text/primary"))));
      hdr.appendChild(await calNavArrow(true, CHEV_R));
      return hdr;
    }
    async function makeYMTile(size, label, disabled) {
      return calTileInstance(calTile, `${size}:${disabled ? "Disabled" : "Default"}`, label);
    }
    async function makeYMRow(g, size, labels, dis) {
      var _a;
      const row = figma.createFrame();
      row.name = "tile-row";
      row.fills = [];
      row.layoutMode = "HORIZONTAL";
      row.primaryAxisSizingMode = "AUTO";
      row.counterAxisSizingMode = "AUTO";
      row.counterAxisAlignItems = "CENTER";
      row.itemSpacing = g.tileGapX;
      for (let i = 0; i < labels.length; i++) row.appendChild(await makeYMTile(size, labels[i], (_a = dis[i]) != null ? _a : false));
      return row;
    }
    const comps = [];
    const cells = [];
    for (const size of CAL_SIZES) {
      const g = CAL_GEO[size];
      const CW = (g.panelW - g.padX * 2) / 7;
      const [dateComp, dateInner] = initComp(g, `Size=${size}, State=Date`, g.panelHDate, g.padBottomDate, g.gapDate);
      dateInner.appendChild(await makeCalHdr(g, g.hdrHDate, "2025.01"));
      const calBody = figma.createFrame();
      calBody.name = "cal-body";
      calBody.fills = [];
      calBody.layoutMode = "VERTICAL";
      calBody.primaryAxisSizingMode = "AUTO";
      calBody.counterAxisSizingMode = "AUTO";
      calBody.counterAxisAlignItems = "MIN";
      calBody.itemSpacing = 0;
      dateInner.appendChild(calBody);
      const wkRow = figma.createFrame();
      wkRow.name = "weekdays";
      wkRow.fills = [];
      wkRow.layoutMode = "HORIZONTAL";
      wkRow.itemSpacing = 0;
      wkRow.primaryAxisSizingMode = "AUTO";
      wkRow.counterAxisSizingMode = "AUTO";
      calBody.appendChild(wkRow);
      const wkColor = (ch) => ch === "\uD1A0" ? dp("text/saturday") : ch === "\uC77C" ? dp("text/sunday") : dp("text/primary");
      for (const ch of ["\uC6D4", "\uD654", "\uC218", "\uBAA9", "\uAE08", "\uD1A0", "\uC77C"]) {
        const cell = figma.createFrame();
        cell.name = "wk";
        cell.fills = [];
        cell.layoutMode = "HORIZONTAL";
        cell.primaryAxisAlignItems = "CENTER";
        cell.counterAxisAlignItems = "CENTER";
        cell.primaryAxisSizingMode = "FIXED";
        cell.counterAxisSizingMode = "FIXED";
        cell.resize(CW, g.cell);
        cell.appendChild(await makeBoundText(ch, g.cellFont, "Medium", scv(maps, wkColor(ch))));
        wkRow.appendChild(cell);
      }
      const calGrid = [{ day: 30, kind: "other" }, { day: 31, kind: "other" }];
      for (let d = 1; d <= 31; d++) {
        calGrid.push({ day: d, kind: d === 10 ? "today" : d === 17 ? "selected" : d === 25 ? "disabled" : "normal" });
      }
      let nm = 1;
      while (calGrid.length < 35) calGrid.push({ day: nm++, kind: "other" });
      for (let r = 0; r < 5; r++) {
        const weekRow = figma.createFrame();
        weekRow.name = "week";
        weekRow.fills = [];
        weekRow.layoutMode = "HORIZONTAL";
        weekRow.itemSpacing = 0;
        weekRow.primaryAxisSizingMode = "AUTO";
        weekRow.counterAxisSizingMode = "AUTO";
        calBody.appendChild(weekRow);
        for (let c = 0; c < 7; c++) {
          const gcell = calGrid[r * 7 + c];
          const weekendColor = gcell.kind !== "normal" ? void 0 : c === 5 ? scv(maps, dp("text/saturday")) : c === 6 ? scv(maps, dp("text/sunday")) : void 0;
          const inst = await calCellInstance(calCell, `${size}:${dayKindToCellKey(gcell.kind)}`, gcell.day, weekendColor);
          weekRow.appendChild(inst);
        }
      }
      setLightMode(dateComp, maps);
      const [yearComp, yearInner] = initComp(g, `Size=${size}, State=Year`, g.panelHTile, g.padBottomTile, g.gapTile);
      yearInner.appendChild(await makeCalHdr(g, g.hdrHTile, "2025"));
      const yearGrid = figma.createFrame();
      yearGrid.name = "year-grid";
      yearGrid.fills = [];
      yearGrid.layoutMode = "VERTICAL";
      yearGrid.primaryAxisSizingMode = "AUTO";
      yearGrid.counterAxisSizingMode = "AUTO";
      yearGrid.counterAxisAlignItems = "CENTER";
      yearGrid.itemSpacing = g.tileGapY;
      for (const [ls, ds] of [
        [["2021", "2022", "2023"], [true, false, false]],
        [["2024", "2025", "2026"], [false, false, false]],
        [["2027", "2028", "2029"], [false, false, false]],
        [["2030", "2031", "2032"], [true, true, true]]
      ]) yearGrid.appendChild(await makeYMRow(g, size, ls, ds));
      yearInner.appendChild(yearGrid);
      setLightMode(yearComp, maps);
      const [monthComp, monthInner] = initComp(g, `Size=${size}, State=Month`, g.panelHTile, g.padBottomTile, g.gapTile);
      monthInner.appendChild(await makeCalHdr(g, g.hdrHTile, "2025"));
      const monthGrid = figma.createFrame();
      monthGrid.name = "month-grid";
      monthGrid.fills = [];
      monthGrid.layoutMode = "VERTICAL";
      monthGrid.primaryAxisSizingMode = "AUTO";
      monthGrid.counterAxisSizingMode = "AUTO";
      monthGrid.counterAxisAlignItems = "CENTER";
      monthGrid.itemSpacing = g.tileGapY;
      for (const ls of [["1\uC6D4", "2\uC6D4", "3\uC6D4"], ["4\uC6D4", "5\uC6D4", "6\uC6D4"], ["7\uC6D4", "8\uC6D4", "9\uC6D4"], ["10\uC6D4", "11\uC6D4", "12\uC6D4"]]) {
        monthGrid.appendChild(await makeYMRow(g, size, ls, [false, false, false]));
      }
      monthInner.appendChild(monthGrid);
      setLightMode(monthComp, maps);
      for (const [state, comp] of [["Date", dateComp], ["Year", yearComp], ["Month", monthComp]]) {
        comps.push(comp);
        cells.push({ comp, size, state });
        BUILT_COMPS[`Calendar:${size}:${state}`] = comp;
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Calendar";
    set.x = 0;
    set.y = originY;
    BUILT_COMPS["Calendar:Date"] = BUILT_COMPS["Calendar:MD:Date"];
    BUILT_COMPS["Calendar:Year"] = BUILT_COMPS["Calendar:MD:Year"];
    BUILT_COMPS["Calendar:Month"] = BUILT_COMPS["Calendar:MD:Month"];
    BUILT_SETS["Calendar"] = set;
    const opts = {
      title: "Calendar",
      colHeaders: ["Date", "Year", "Month"],
      rowLabels: CAL_SIZES.map((sz) => sz),
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = cells.find((x) => x.size === CAL_SIZES[r] && x.state === ["Date", "Year", "Month"][c])) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 380
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDatePicker(maps, originY) {
    var _a, _b;
    const fc = (k) => `color/form-control/${k}`;
    const CAL_ICON = `<svg width="16" height="16" viewBox="0 0 16.2581 16.8" fill="none"><path d="M0 1.08387V16.2581C0 16.5615 0.238452 16.8 0.541936 16.8H15.7161C16.0196 16.8 16.2581 16.5615 16.2581 16.2581V1.08387C16.2581 0.780387 16.0196 0.541935 15.7161 0.541935H13.0065V0H11.9226V0.541935H4.33548V0H3.25161V0.541935H0.541936C0.238452 0.541935 0 0.780387 0 1.08387ZM4.33548 2.16774V1.62581H11.9226V2.16774H13.0065V1.62581H15.1742V3.79355H1.08387V1.62581H3.25161V2.16774H4.33548ZM15.1742 15.7161H1.08387V4.87742H15.1742V15.7161Z" fill="#000"/><path d="M5.14859 9.21302H3.52279V10.8388H5.14859V9.21302Z" fill="#000"/><path d="M8.94208 9.21302H7.31628V10.8388H8.94208V9.21302Z" fill="#000"/><path d="M12.7356 9.21302H11.1098V10.8388H12.7356V9.21302Z" fill="#000"/></svg>`;
    const states = [
      { name: "Default", bg: "bg/default", border: "border/default", txt: "\uB0A0\uC9DC \uC120\uD0DD", tc: "text/placeholder", icon: "icon/default", open: false },
      { name: "Filled", bg: "bg/default", border: "border/default", txt: "26.06.17", tc: "text/default", icon: "icon/default", open: false },
      { name: "Open", bg: "bg/selected", border: "border/selected", txt: "26.06.17", tc: "text/selected", icon: "icon/selected", open: true },
      { name: "Disabled", bg: "bg/disabled", border: "border/disabled", txt: "\uB0A0\uC9DC \uC120\uD0DD", tc: "text/disabled", icon: "icon/disabled", open: false }
    ];
    const sizes = [
      { size: "XXSM", brk: "PC", h: 28, font: 12 },
      { size: "XSM", brk: "PC", h: 34, font: 14 },
      { size: "MD", brk: "PC", h: 44, font: 14 },
      { size: "MD", brk: "Mobile", h: 48, font: 14 }
    ];
    const comps = [];
    const cells = [];
    for (const sc of sizes) {
      for (const st of states) {
        const trigger = figma.createFrame();
        trigger.name = "trigger";
        trigger.layoutMode = "HORIZONTAL";
        trigger.primaryAxisAlignItems = "SPACE_BETWEEN";
        trigger.counterAxisAlignItems = "CENTER";
        trigger.primaryAxisSizingMode = "FIXED";
        trigger.counterAxisSizingMode = "FIXED";
        trigger.paddingLeft = 16;
        trigger.paddingRight = sc.brk === "Mobile" ? 12 : 8;
        trigger.paddingTop = 0;
        trigger.paddingBottom = 0;
        trigger.cornerRadius = 4;
        trigger.fills = [boundPaint(scv(maps, fc(st.bg)))];
        trigger.strokes = [boundPaint(scv(maps, fc(st.border)))];
        trigger.strokeWeight = 1;
        trigger.strokeAlign = "INSIDE";
        trigger.appendChild(await makeBoundText(st.txt, sc.font, "Regular", scv(maps, fc(st.tc))));
        trigger.appendChild(await makeIconInstance("calendar", scv(maps, fc(st.icon)), fcIconPx(sc.h, 0), CAL_ICON));
        trigger.resize(180, sc.h);
        const comp = figma.createComponent();
        comp.name = `Size=${sc.size}, State=${st.name}, Break=${sc.brk}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 8;
        comp.fills = [];
        comp.appendChild(trigger);
        if (st.open && sc.brk === "PC") {
          const calSize = sc.size === "MD" ? "MD" : "SM";
          let calComp = BUILT_COMPS[`Calendar:${calSize}:Date`];
          if (!calComp) {
            const calSet = await getBuiltSet("Calendar");
            if (calSet) {
              calComp = (_b = (_a = calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes(`Size=${calSize}`) && c.name.includes("State=Date"))) != null ? _a : calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Date"))) != null ? _b : calSet.children.find((c) => c.type === "COMPONENT");
            }
          }
          if (calComp) {
            const calInst = calComp.createInstance();
            calInst.name = "calendar";
            comp.appendChild(calInst);
          }
        }
        setLightMode(comp, maps);
        comps.push(comp);
        cells.push({ comp, size: sc.size, brk: sc.brk, state: st.name });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Date Picker";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "Date Picker",
      platforms: [{ name: "PC", sizes: ["XXSM", "XSM", "MD"] }, { name: "Mobile", sizes: ["MD"] }],
      rowLabels: [""],
      colHeaders: states.map((s) => s.name),
      cellAt: (platName, size, _ri, ci) => {
        var _a2, _b2;
        return (_b2 = (_a2 = cells.find((x) => x.size === size && x.brk === platName && x.state === states[ci].name)) == null ? void 0 : _a2.comp) != null ? _b2 : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 440,
      rowLabelW: 16
      // cellW≥캘린더356 → Open 패널이 Disabled 열 침범 방지
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildDatePickerBottomSheet(maps, originY) {
    var _a, _b, _c, _d;
    const SHEET_W = 360;
    const comp = figma.createComponent();
    comp.name = "Platform=Mobile";
    comp.layoutMode = "VERTICAL";
    comp.primaryAxisSizingMode = "AUTO";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(SHEET_W, 100);
    comp.itemSpacing = 32;
    comp.paddingTop = 20;
    comp.paddingBottom = 20;
    comp.paddingLeft = 0;
    comp.paddingRight = 0;
    comp.counterAxisAlignItems = "CENTER";
    comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
    try {
      comp.topLeftRadius = 8;
      comp.topRightRadius = 8;
      comp.bottomLeftRadius = 0;
      comp.bottomRightRadius = 0;
    } catch (e) {
    }
    comp.clipsContent = false;
    const header = figma.createFrame();
    header.name = "header";
    header.fills = [];
    header.layoutMode = "HORIZONTAL";
    header.primaryAxisSizingMode = "FIXED";
    header.counterAxisSizingMode = "AUTO";
    header.primaryAxisAlignItems = "SPACE_BETWEEN";
    header.counterAxisAlignItems = "CENTER";
    header.paddingLeft = 20;
    header.paddingRight = 20;
    comp.appendChild(header);
    try {
      header.layoutAlign = "STRETCH";
    } catch (e) {
    }
    const title = await makeBoundText("\uB0A0\uC9DC \uC120\uD0DD", 20, "Bold", scv(maps, "color/text/title/primary"));
    title.name = "title";
    header.appendChild(title);
    const closeIcon2 = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
    closeIcon2.name = "close";
    header.appendChild(closeIcon2);
    const calWrap = figma.createFrame();
    calWrap.name = "calendar-wrap";
    calWrap.fills = [];
    calWrap.layoutMode = "VERTICAL";
    calWrap.primaryAxisSizingMode = "AUTO";
    calWrap.counterAxisSizingMode = "FIXED";
    calWrap.primaryAxisAlignItems = "CENTER";
    calWrap.counterAxisAlignItems = "CENTER";
    calWrap.paddingLeft = 24;
    calWrap.paddingRight = 24;
    comp.appendChild(calWrap);
    try {
      calWrap.layoutAlign = "STRETCH";
    } catch (e) {
    }
    let calComp = (_a = BUILT_COMPS["Calendar:MD:Date"]) != null ? _a : BUILT_COMPS["Calendar:Date"];
    if (!calComp) {
      const calSet = await getBuiltSet("Calendar");
      if (calSet) {
        calComp = (_c = (_b = calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Size=MD") && c.name.includes("State=Date"))) != null ? _b : calSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("State=Date"))) != null ? _c : calSet.children.find((c) => c.type === "COMPONENT");
      }
    }
    if (calComp) {
      const calInst = calComp.createInstance();
      calInst.name = "calendar";
      try {
        calInst.strokes = [];
        calInst.effects = [];
      } catch (e) {
      }
      calWrap.appendChild(calInst);
    }
    const actionWrap = figma.createFrame();
    actionWrap.name = "action";
    actionWrap.fills = [];
    actionWrap.layoutMode = "HORIZONTAL";
    actionWrap.primaryAxisSizingMode = "FIXED";
    actionWrap.counterAxisSizingMode = "AUTO";
    actionWrap.primaryAxisAlignItems = "CENTER";
    actionWrap.counterAxisAlignItems = "CENTER";
    actionWrap.paddingLeft = 20;
    actionWrap.paddingRight = 20;
    comp.appendChild(actionWrap);
    try {
      actionWrap.layoutAlign = "STRETCH";
    } catch (e) {
    }
    let btnComp = BUILT_COMPS["Button:primary:LG:Default"];
    if (!btnComp) {
      const btnSet = await getBuiltSet("Button");
      if (btnSet) {
        btnComp = (_d = btnSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Variant=Primary") && c.name.includes("Size=LG") && c.name.includes("State=Default"))) != null ? _d : btnSet.children.find((c) => c.type === "COMPONENT" && c.name.includes("Variant=Primary"));
      }
    }
    if (btnComp) {
      const applyBtn = btnComp.createInstance();
      applyBtn.name = "apply";
      const txt = applyBtn.findOne((n) => n.type === "TEXT");
      if (txt) {
        try {
          txt.characters = "\uC801\uC6A9";
        } catch (e) {
        }
      }
      actionWrap.appendChild(applyBtn);
      try {
        applyBtn.layoutSizingHorizontal = "FILL";
      } catch (e) {
      }
    }
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "Date Picker Mobile Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Date Picker Mobile Bottom Sheet"] = set;
    const opts = {
      title: "Date Picker Mobile Bottom Sheet",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: SHEET_W + 40,
      cellH: 500,
      rowLabelW: 16
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildTimePickerMobileBottomSheet(maps, originY) {
    const SHEET_W = 360;
    const FADE_H = 110;
    const ACCENT = "color/text/state/accent";
    const WHEEL_COL_W = { ampm: 56, hour: 40, colon: 8, minute: 40 };
    const makeWheelCol = async (name, labels, gap, align) => {
      const col = figma.createFrame();
      col.name = name;
      col.fills = [];
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "AUTO";
      col.counterAxisSizingMode = "FIXED";
      col.primaryAxisAlignItems = "CENTER";
      col.counterAxisAlignItems = align;
      col.itemSpacing = gap;
      for (const lb of labels) {
        const t = await makeBoundText(lb, 32, "Regular", scv(maps, ACCENT));
        col.appendChild(t);
      }
      const w = WHEEL_COL_W[name];
      if (w) {
        try {
          col.resize(w, col.height);
        } catch (e) {
          throw new Error(`[time-picker sheet] \uD720 \uC5F4 "${name}" \uD3ED(${w}) \uC9C0\uC815 \uC2E4\uD328: ${String(e)}`);
        }
      }
      return col;
    };
    const makeWheelFade = (position) => {
      const fade = figma.createFrame();
      fade.name = position === "top" ? "fade-top" : "fade-bottom";
      fade.fills = [];
      fade.clipsContent = true;
      fade.resize(SHEET_W, FADE_H);
      const mask = figma.createRectangle();
      mask.name = "fade-mask";
      mask.resize(SHEET_W, FADE_H);
      const stops = position === "top" ? [
        { position: 0, color: { r: 1, g: 1, b: 1, a: 0.9 } },
        { position: 0.25, color: { r: 1, g: 1, b: 1, a: 0.9 } },
        { position: 0.65, color: { r: 1, g: 1, b: 1, a: 0.7 } },
        { position: 1, color: { r: 1, g: 1, b: 1, a: 0 } }
      ] : [
        { position: 0, color: { r: 1, g: 1, b: 1, a: 0 } },
        { position: 0.35, color: { r: 1, g: 1, b: 1, a: 0.7 } },
        { position: 0.75, color: { r: 1, g: 1, b: 1, a: 0.9 } },
        { position: 1, color: { r: 1, g: 1, b: 1, a: 0.9 } }
      ];
      mask.fills = [{ type: "GRADIENT_LINEAR", gradientTransform: [[0, 1, 0], [-1, 0, 1]], gradientStops: stops }];
      mask.isMask = true;
      fade.appendChild(mask);
      const fill = figma.createRectangle();
      fill.name = "fade-fill";
      fill.resize(SHEET_W, FADE_H);
      fill.fills = [boundPaint(scv(maps, "color/overlay/wheel-fade"))];
      fade.appendChild(fill);
      return fade;
    };
    const pickLineTab = async (state) => {
      let c = BUILT_COMPS[`LineTab:Mobile-SM-${state}`];
      if (!c) {
        const s = await getBuiltSet("Line Tab");
        if (s) c = s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Size=SM") && x.name.includes("Mobile") && x.name.includes(`State=${state}`));
      }
      return c;
    };
    const getApplyBtn = async () => {
      var _a;
      let c = BUILT_COMPS["Button:primary:LG:Default"];
      if (!c) {
        const s = await getBuiltSet("Button");
        if (s) c = (_a = s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Variant=Primary") && x.name.includes("Size=LG") && x.name.includes("State=Default"))) != null ? _a : s.children.find((x) => x.type === "COMPONENT" && x.name.includes("Variant=Primary"));
      }
      return c;
    };
    const buildVariant = async (content) => {
      const comp = figma.createComponent();
      comp.name = `Content=${content}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SHEET_W, 100);
      comp.itemSpacing = 32;
      comp.paddingTop = 20;
      comp.paddingBottom = 20;
      comp.paddingLeft = 0;
      comp.paddingRight = 0;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      try {
        comp.topLeftRadius = 8;
        comp.topRightRadius = 8;
        comp.bottomLeftRadius = 0;
        comp.bottomRightRadius = 0;
      } catch (e) {
      }
      comp.clipsContent = false;
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "CENTER";
      header.paddingLeft = 20;
      header.paddingRight = 20;
      comp.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const titleText = content === "TimeOnly" ? "\uC2DC\uAC04 \uC120\uD0DD" : "\uC2DC\uC791 \uC77C\uC2DC";
      const title = await makeBoundText(titleText, 20, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon2 = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon2.name = "close";
      header.appendChild(closeIcon2);
      if (content === "DateTime") {
        const tabRow = figma.createFrame();
        tabRow.name = "tab-row";
        tabRow.fills = [];
        tabRow.layoutMode = "HORIZONTAL";
        tabRow.primaryAxisSizingMode = "FIXED";
        tabRow.counterAxisSizingMode = "AUTO";
        tabRow.paddingLeft = 24;
        tabRow.paddingRight = 24;
        tabRow.itemSpacing = 0;
        tabRow.counterAxisAlignItems = "CENTER";
        comp.appendChild(tabRow);
        try {
          tabRow.layoutAlign = "STRETCH";
        } catch (e) {
        }
        const tabDefs = [{ state: "Unselected", label: "\uB0A0\uC9DC" }, { state: "Selected", label: "\uC2DC\uAC04" }];
        for (const td of tabDefs) {
          const cell = await pickLineTab(td.state);
          if (cell) {
            const inst = cell.createInstance();
            inst.name = td.label === "\uB0A0\uC9DC" ? "tab-date" : "tab-time";
            const txt = inst.findOne((n) => n.type === "TEXT");
            if (txt) {
              try {
                txt.characters = td.label;
              } catch (e) {
              }
            }
            tabRow.appendChild(inst);
            try {
              inst.layoutSizingHorizontal = "FILL";
            } catch (e) {
            }
          }
        }
      }
      const wheelWrap = figma.createFrame();
      wheelWrap.name = "wheel";
      wheelWrap.fills = [];
      wheelWrap.layoutMode = "HORIZONTAL";
      wheelWrap.primaryAxisSizingMode = "FIXED";
      wheelWrap.counterAxisSizingMode = "AUTO";
      wheelWrap.primaryAxisAlignItems = "CENTER";
      wheelWrap.counterAxisAlignItems = "MIN";
      wheelWrap.paddingLeft = 24;
      wheelWrap.paddingRight = 24;
      wheelWrap.paddingTop = 40;
      wheelWrap.paddingBottom = 40;
      wheelWrap.itemSpacing = 36;
      wheelWrap.clipsContent = false;
      comp.appendChild(wheelWrap);
      try {
        wheelWrap.layoutAlign = "STRETCH";
      } catch (e) {
      }
      wheelWrap.appendChild(await makeWheelCol("ampm", ["\uC624\uC804", "\uC624\uD6C4"], 32, "CENTER"));
      const timeGroup = figma.createFrame();
      timeGroup.name = "time-group";
      timeGroup.fills = [];
      timeGroup.layoutMode = "HORIZONTAL";
      timeGroup.primaryAxisSizingMode = "AUTO";
      timeGroup.counterAxisSizingMode = "AUTO";
      timeGroup.primaryAxisAlignItems = "CENTER";
      timeGroup.counterAxisAlignItems = "MIN";
      timeGroup.itemSpacing = 32;
      timeGroup.clipsContent = false;
      wheelWrap.appendChild(timeGroup);
      timeGroup.appendChild(await makeWheelCol("hour", ["7", "8", "9"], 32, "MAX"));
      timeGroup.appendChild(await makeWheelCol("colon", [":", ":", ":"], 32, "CENTER"));
      timeGroup.appendChild(await makeWheelCol("minute", ["59", "00", "01"], 32, "MIN"));
      const wheelH = wheelWrap.height;
      const fadeTop = makeWheelFade("top");
      wheelWrap.appendChild(fadeTop);
      try {
        fadeTop.layoutPositioning = "ABSOLUTE";
        fadeTop.x = 0;
        fadeTop.y = 0;
        fadeTop.constraints = { horizontal: "STRETCH", vertical: "MIN" };
      } catch (e) {
      }
      const fadeBottom = makeWheelFade("bottom");
      wheelWrap.appendChild(fadeBottom);
      try {
        fadeBottom.layoutPositioning = "ABSOLUTE";
        fadeBottom.x = 0;
        fadeBottom.y = Math.max(0, wheelH - FADE_H);
        fadeBottom.constraints = { horizontal: "STRETCH", vertical: "MAX" };
      } catch (e) {
      }
      const actionWrap = figma.createFrame();
      actionWrap.name = "action";
      actionWrap.fills = [];
      actionWrap.layoutMode = "HORIZONTAL";
      actionWrap.primaryAxisSizingMode = "FIXED";
      actionWrap.counterAxisSizingMode = "AUTO";
      actionWrap.primaryAxisAlignItems = "CENTER";
      actionWrap.counterAxisAlignItems = "CENTER";
      actionWrap.paddingLeft = 20;
      actionWrap.paddingRight = 20;
      comp.appendChild(actionWrap);
      try {
        actionWrap.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const btnComp = await getApplyBtn();
      if (btnComp) {
        const applyBtn = btnComp.createInstance();
        applyBtn.name = "apply";
        const txt = applyBtn.findOne((n) => n.type === "TEXT");
        if (txt) {
          try {
            txt.characters = "\uC801\uC6A9";
          } catch (e) {
          }
        }
        actionWrap.appendChild(applyBtn);
        try {
          applyBtn.layoutSizingHorizontal = "FILL";
        } catch (e) {
        }
      }
      setLightMode(comp, maps);
      return comp;
    };
    const timeOnly = await buildVariant("TimeOnly");
    const dateTime = await buildVariant("DateTime");
    const set = figma.combineAsVariants([timeOnly, dateTime], figma.currentPage);
    set.name = "Time Picker Mobile Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Time Picker Mobile Bottom Sheet"] = set;
    const opts = {
      title: "Time Picker Mobile Bottom Sheet",
      colHeaders: [""],
      rowLabels: ["\uC2DC\uAC04\uB9CC", "\uB0A0\uC9DC+\uC2DC\uAC04"],
      cellAt: (r) => r === 0 ? timeOnly : dateTime,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: SHEET_W + 40,
      cellH: 560,
      rowLabelW: 64
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  var LOCK_SET_KEY = "b3ccc4b275de6aac8e3940df2ae97fbb00168624";
  var LOCK_FALLBACK_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="5" y="10.5" width="14" height="9.5" rx="2" stroke="#757575" stroke-width="1.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" stroke="#757575" stroke-width="1.5"/></svg>`;
  var CHECK_24_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M5 12.5L10 17.5L19 6.5" stroke="#1D6CEB" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  var CHEVRON_RIGHT_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M9 6L15 12L9 18" stroke="#353535" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  var ACCOUNT_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" fill="#FFFFFF"/><path d="M5 20c0-3.5 3.13-6 7-6s7 2.5 7 6" fill="#FFFFFF"/></svg>`;
  async function makeLockIcon(colorVar, size) {
    var _a, _b;
    try {
      const set = await figma.importComponentSetByKeyAsync(LOCK_SET_KEY);
      const line = (_b = (_a = set.children.find((c) => c.type === "COMPONENT" && c.name.toLowerCase().includes("line"))) != null ? _a : set.defaultVariant) != null ? _b : set.children[0];
      if (line) {
        const inst = line.createInstance();
        inst.name = "lock";
        if (size && size !== inst.width) inst.resize(size, size);
        rebindIconColor(inst, colorVar);
        return inst;
      }
    } catch (e) {
      console.warn("lock \uC138\uD2B8 import \uC2E4\uD328 \u2192 \uBCA1\uD130 \uD3F4\uBC31:", e);
    }
    const node = figma.createNodeFromSvg(LOCK_FALLBACK_SVG);
    node.name = "lock";
    rebindIconColor(node, colorVar);
    return node;
  }
  async function getReuseComp(builtKey, setName, includes) {
    let c = BUILT_COMPS[builtKey];
    if (!c) {
      const s = await getBuiltSet(setName);
      if (s) c = s.children.find((x) => x.type === "COMPONENT" && includes.every((n) => x.name.includes(n)));
    }
    return c;
  }
  async function setInstanceLabel(inst, label) {
    const txt = inst.findOne((n) => n.type === "TEXT");
    if (!txt) return;
    try {
      await figma.loadFontAsync(txt.fontName);
    } catch (e) {
    }
    try {
      txt.characters = label;
    } catch (e) {
    }
  }
  async function buildBottomSheetOption(maps, originY) {
    const ROW_W = 360;
    const byKey = {};
    const rowLabel = async (color) => makeBoundText("\uD56D\uBAA9", 16, "Medium", scv(maps, color));
    const makeSelectRow = (name) => {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "FIXED";
      comp.counterAxisAlignItems = "CENTER";
      comp.paddingLeft = 20;
      comp.paddingRight = 20;
      comp.paddingTop = 8;
      comp.paddingBottom = 8;
      comp.itemSpacing = 8;
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      comp.resize(ROW_W, 48);
      return comp;
    };
    {
      const comp = makeSelectRow("Type=Text, State=Default");
      comp.primaryAxisAlignItems = "MIN";
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey["Text:Default"] = comp;
    }
    {
      const comp = makeSelectRow("Type=Text, State=Disabled");
      comp.primaryAxisAlignItems = "MIN";
      comp.appendChild(await rowLabel("color/text/state/disabled"));
      setLightMode(comp, maps);
      byKey["Text:Disabled"] = comp;
    }
    {
      const comp = makeSelectRow("Type=Text, State=Selected");
      comp.primaryAxisAlignItems = "SPACE_BETWEEN";
      comp.appendChild(await rowLabel("color/text/state/accent"));
      comp.appendChild(await makeIconInstance("check", scv(maps, "color/icon/blue"), 24, CHECK_24_SVG));
      setLightMode(comp, maps);
      byKey["Text:Selected"] = comp;
    }
    const cbOff = await getReuseComp("Checkbox:Default", "Checkbox", ["State=Default"]);
    const cbOn = await getReuseComp("Checkbox:Checked", "Checkbox", ["State=Checked"]);
    for (const st of [{ name: "Default", comp: cbOff }, { name: "Selected", comp: cbOn }]) {
      const comp = makeSelectRow(`Type=Checkbox, State=${st.name}`);
      comp.primaryAxisAlignItems = "MIN";
      if (st.comp) {
        const inst = st.comp.createInstance();
        inst.name = "checkbox";
        comp.appendChild(inst);
      }
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey[`Checkbox:${st.name}`] = comp;
    }
    const rdOff = await getReuseComp("Radio:Default:Off", "Radio", ["State=Default", "Label=Off"]);
    const rdOn = await getReuseComp("Radio:Selected:Off", "Radio", ["State=Selected", "Label=Off"]);
    for (const st of [{ name: "Default", comp: rdOff }, { name: "Selected", comp: rdOn }]) {
      const comp = makeSelectRow(`Type=Radio, State=${st.name}`);
      comp.primaryAxisAlignItems = "MIN";
      if (st.comp) {
        const inst = st.comp.createInstance();
        inst.name = "radio";
        comp.appendChild(inst);
      }
      comp.appendChild(await rowLabel("color/text/body/primary"));
      setLightMode(comp, maps);
      byKey[`Radio:${st.name}`] = comp;
    }
    const makeAvatar = async () => {
      const av = figma.createFrame();
      av.name = "avatar";
      av.layoutMode = "HORIZONTAL";
      av.primaryAxisAlignItems = "CENTER";
      av.counterAxisAlignItems = "CENTER";
      av.primaryAxisSizingMode = "FIXED";
      av.counterAxisSizingMode = "FIXED";
      av.resize(40, 40);
      av.cornerRadius = 20;
      av.fills = [boundPaint(scv(maps, "color/icon/gray-light"))];
      av.appendChild(await makeIconInstance("account", scv(maps, "color/icon/white"), 24, ACCOUNT_SVG));
      return av;
    };
    const makeListLeft = async () => {
      const left = figma.createFrame();
      left.name = "list-left";
      left.fills = [];
      left.layoutMode = "HORIZONTAL";
      left.primaryAxisSizingMode = "AUTO";
      left.counterAxisSizingMode = "AUTO";
      left.counterAxisAlignItems = "CENTER";
      left.itemSpacing = 12;
      left.appendChild(await makeAvatar());
      const col = figma.createFrame();
      col.name = "list-text";
      col.fills = [];
      col.layoutMode = "VERTICAL";
      col.primaryAxisSizingMode = "AUTO";
      col.counterAxisSizingMode = "AUTO";
      col.itemSpacing = 2;
      const title = await makeBoundText("\uC81C\uBAA9", 16, "Medium", scv(maps, "color/text/body/primary"));
      title.name = "title";
      const sub = await makeBoundText("\uC11C\uBE0C \uD14D\uC2A4\uD2B8", 14, "Regular", scv(maps, "color/text/body/secondary"));
      sub.name = "sub";
      col.appendChild(title);
      col.appendChild(sub);
      left.appendChild(col);
      return left;
    };
    const makeListRow = async (name, rightIcon) => {
      const comp = figma.createComponent();
      comp.name = name;
      comp.layoutMode = "HORIZONTAL";
      comp.primaryAxisAlignItems = "SPACE_BETWEEN";
      comp.counterAxisAlignItems = "CENTER";
      comp.primaryAxisSizingMode = "FIXED";
      comp.counterAxisSizingMode = "AUTO";
      comp.paddingLeft = 20;
      comp.paddingRight = 20;
      comp.paddingTop = 12;
      comp.paddingBottom = 12;
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      comp.appendChild(await makeListLeft());
      comp.appendChild(rightIcon);
      try {
        comp.resize(ROW_W, comp.height);
      } catch (e) {
      }
      setLightMode(comp, maps);
      return comp;
    };
    byKey["List:Default"] = await makeListRow(
      "Type=List, State=Default",
      await makeIconInstance("chevron", scv(maps, "color/icon/gray-dark"), 24, CHEVRON_RIGHT_SVG)
    );
    byKey["List:Disabled"] = await makeListRow(
      "Type=List, State=Disabled",
      await makeLockIcon(scv(maps, "color/icon/gray"), 24)
    );
    const order = [
      "Text:Default",
      "Text:Selected",
      "Text:Disabled",
      "Checkbox:Default",
      "Checkbox:Selected",
      "Radio:Default",
      "Radio:Selected",
      "List:Default",
      "List:Disabled"
    ];
    const comps = order.map((k) => byKey[k]);
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Bottom Sheet Option";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Bottom Sheet Option"] = set;
    BUILT_COMPS["BottomSheetOption:Text:Default"] = byKey["Text:Default"];
    BUILT_COMPS["BottomSheetOption:Text:Selected"] = byKey["Text:Selected"];
    BUILT_COMPS["BottomSheetOption:Text:Disabled"] = byKey["Text:Disabled"];
    const types = ["Text", "Checkbox", "Radio", "List"];
    const states = ["Default", "Selected", "Disabled"];
    const opts = {
      title: "Bottom Sheet Option",
      colHeaders: states,
      rowLabels: types,
      cellAt: (r, c) => {
        var _a;
        return (_a = byKey[`${types[r]}:${states[c]}`]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 380,
      cellH: 80,
      rowLabelW: 80
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildBottomSheet(maps, originY) {
    const SHEET_W = 360;
    const buildContent = async (owner, useSlot, darkModeId) => {
      var _a, _b;
      const content = figma.createFrame();
      content.name = "content";
      content.fills = [];
      content.layoutMode = "VERTICAL";
      content.primaryAxisSizingMode = "AUTO";
      content.counterAxisSizingMode = "FIXED";
      content.itemSpacing = 24;
      owner.appendChild(content);
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "CENTER";
      header.paddingLeft = 20;
      header.paddingRight = 20;
      const title = await makeBoundText("\uD5E4\uB354 \uD0C0\uC774\uD2C0", 20, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon2 = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon2.name = "close";
      header.appendChild(closeIcon2);
      if (darkModeId) setMode(closeIcon2, maps, darkModeId);
      content.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const existingSlotProperties = new Set(useSlot ? Object.entries(owner.componentPropertyDefinitions).filter(([, definition]) => definition.type === "SLOT").map(([propertyName]) => propertyName) : []);
      const slot = useSlot ? owner.createSlot() : figma.createFrame();
      slot.name = "Content";
      slot.fills = [];
      slot.layoutMode = "VERTICAL";
      slot.primaryAxisSizingMode = "AUTO";
      slot.counterAxisSizingMode = "FIXED";
      slot.itemSpacing = 0;
      slot.resize(SHEET_W, 48 * 4);
      const optDefault = BUILT_COMPS["BottomSheetOption:Text:Default"];
      const optSelected = BUILT_COMPS["BottomSheetOption:Text:Selected"];
      for (let i = 0; i < 4; i++) {
        const src = (_a = i === 1 ? optSelected : optDefault) != null ? _a : optDefault;
        if (!src) continue;
        const inst = src.createInstance();
        inst.name = "option";
        slot.appendChild(inst);
        if (darkModeId) setMode(inst, maps, darkModeId);
        try {
          inst.layoutSizingHorizontal = "FILL";
        } catch (e) {
        }
      }
      content.appendChild(slot);
      try {
        slot.layoutAlign = "STRETCH";
      } catch (e) {
      }
      if (!useSlot) return content;
      const slotDefinitions = Object.entries(owner.componentPropertyDefinitions || {});
      const slotProperty = (_b = slotDefinitions.find(([propertyName, definition]) => definition.type === "SLOT" && !existingSlotProperties.has(propertyName))) == null ? void 0 : _b[0];
      if (slotDefinitions.length && !slotProperty) {
        throw new Error("[buildBottomSheet] Content Slot component property\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      }
      if (slotProperty) {
        const optionSet = BUILT_SETS["Bottom Sheet Option"];
        owner.editComponentProperty(slotProperty, {
          name: "Content",
          description: "\uBC14\uD140\uC2DC\uD2B8 \uBCF8\uBB38 \uC2AC\uB86F. \uAE30\uBCF8\uAC12\uC740 Bottom Sheet Option 4\uD589\uC774\uBA70 \uD5E4\uB354\uC640 \uD478\uD130\uB294 \uC2AC\uB86F \uBC16\uC758 \uC815\uBCF8 \uAD6C\uC870\uB85C \uC720\uC9C0\uD569\uB2C8\uB2E4.",
          preferredValues: optionSet ? [{ type: "COMPONENT_SET", key: optionSet.key }] : []
        });
      }
      return content;
    };
    const makeFooterButton = async (variant, label, darkModeId) => {
      const vLabel = variant === "primary" ? "Primary" : "Secondary";
      const comp = await getReuseComp(
        `Button:${variant}:LG:Default`,
        "Button",
        [`Variant=${vLabel}`, "Size=LG", "State=Default"]
      );
      if (!comp) return null;
      const inst = comp.createInstance();
      inst.name = variant;
      await setInstanceLabel(inst, label);
      if (darkModeId) setMode(inst, maps, darkModeId);
      return inst;
    };
    const variants = [{ footer: "None" }, { footer: "Single" }, { footer: "Dual" }];
    const byFooter = {};
    const darkCopies = /* @__PURE__ */ new Map();
    const makeSheet = async (footer, asComponent) => {
      const comp = asComponent ? figma.createComponent() : figma.createFrame();
      comp.name = asComponent ? `Footer=${footer}` : `Bottom Sheet ${footer} \u2014 Dark`;
      const v = { footer };
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(SHEET_W, 100);
      comp.itemSpacing = 48;
      comp.paddingTop = 20;
      comp.paddingLeft = 0;
      comp.paddingRight = 0;
      comp.paddingBottom = v.footer === "None" ? 40 : 20;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      try {
        comp.topLeftRadius = 8;
        comp.topRightRadius = 8;
        comp.bottomLeftRadius = 0;
        comp.bottomRightRadius = 0;
      } catch (e) {
      }
      comp.clipsContent = true;
      const sheetEffects = shadowEffects("shadow/raised-up");
      try {
        comp.effects = sheetEffects;
      } catch (e) {
      }
      const darkModeId = asComponent ? void 0 : maps.semanticDarkModeId;
      const content = await buildContent(comp, asComponent, darkModeId);
      try {
        content.layoutAlign = "STRETCH";
      } catch (e) {
      }
      if (v.footer !== "None") {
        const footer2 = figma.createFrame();
        footer2.name = "footer";
        footer2.fills = [];
        footer2.layoutMode = "HORIZONTAL";
        footer2.primaryAxisSizingMode = "FIXED";
        footer2.counterAxisSizingMode = "AUTO";
        footer2.primaryAxisAlignItems = "CENTER";
        footer2.counterAxisAlignItems = "CENTER";
        footer2.paddingLeft = 20;
        footer2.paddingRight = 20;
        footer2.itemSpacing = 8;
        comp.appendChild(footer2);
        try {
          footer2.layoutAlign = "STRETCH";
        } catch (e) {
        }
        if (v.footer === "Dual") {
          const cancel = await makeFooterButton("secondary", "\uCDE8\uC18C", darkModeId);
          if (cancel) {
            footer2.appendChild(cancel);
            try {
              cancel.layoutSizingHorizontal = "FILL";
            } catch (e) {
            }
          }
        }
        const apply = await makeFooterButton("primary", "\uC801\uC6A9", darkModeId);
        if (apply) {
          footer2.appendChild(apply);
          try {
            apply.layoutSizingHorizontal = "FILL";
          } catch (e) {
          }
        }
      }
      if (asComponent) setLightMode(comp, maps);
      else setMode(comp, maps, maps.semanticDarkModeId);
      return comp;
    };
    for (const v of variants) {
      byFooter[v.footer] = await makeSheet(v.footer, true);
    }
    for (const v of variants) {
      try {
        darkCopies.set(byFooter[v.footer].id, await makeSheet(v.footer, false));
      } catch (e) {
        console.warn(`[installer] Bottom Sheet \uB2E4\uD06C \uC0AC\uBCF8 \uC0DD\uC131 \uC2E4\uD328(Footer=${v.footer}) \u2014 \uC774 \uCE78\uC740 \uBCF8\uBB38\uC774 \uBE44\uC5B4 \uBCF4\uC785\uB2C8\uB2E4:`, e);
      }
    }
    if (darkCopies.size !== variants.length) {
      console.warn(`[installer] Bottom Sheet \uB2E4\uD06C \uC0AC\uBCF8 ${darkCopies.size}/${variants.length}\uAC1C\uB9CC \uC900\uBE44\uB410\uC2B5\uB2C8\uB2E4.`);
    }
    const set = figma.combineAsVariants([byFooter["None"], byFooter["Single"], byFooter["Dual"]], figma.currentPage);
    set.name = "Bottom Sheet";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Bottom Sheet"] = set;
    const cols = ["None", "Single", "Dual"];
    const opts = {
      title: "Bottom Sheet",
      colHeaders: cols,
      rowLabels: [""],
      cellAt: (_r, c) => {
        var _a;
        return (_a = byFooter[cols[c]]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 420,
      rowLabelW: 16,
      darkCellNodes: darkCopies
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildModalShell(maps, originY) {
    const MODAL_PC_WIDTH = 360;
    const MODAL_MOBILE_WIDTH = 300;
    const CONTENT_SLOT_DESC = "\uBAA8\uB2EC \uBCF8\uBB38\uC774 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 \uC548\uB0B4 \uBB38\uAD6C \uD55C \uB369\uC5B4\uB9AC\uC774\uBA70, \uBB38\uAD6C \uB300\uC2E0 \uC774\uBBF8\uC9C0\xB7\uD14D\uC2A4\uD2B8\uC5D0\uB9AC\uC5B4\xB7\uC785\uB825 \uD3FC \uB4F1 \uBB34\uC5C7\uC774\uB4E0 \uB123\uC744 \uC218 \uC788\uB2E4. \uC81C\uBAA9\uACFC \uB2EB\uAE30(X)\uB294 \uC2AC\uB86F \uBC16 \uACE0\uC815 \uC601\uC5ED\uC774\uB2E4.";
    const buildContentGroup = async (owner, brk, titleText, bodyText) => {
      const group = figma.createFrame();
      group.name = "content";
      group.fills = [];
      group.layoutMode = "VERTICAL";
      group.primaryAxisSizingMode = "AUTO";
      group.counterAxisSizingMode = "FIXED";
      group.itemSpacing = brk === "PC" ? 32 : 24;
      owner.appendChild(group);
      try {
        group.layoutAlign = "STRETCH";
      } catch (e) {
      }
      if (brk === "Mobile") {
        const title2 = await makeBoundText(titleText, 18, "Bold", scv(maps, "color/text/title/primary"));
        title2.name = "title";
        title2.textAutoResize = "HEIGHT";
        group.appendChild(title2);
        try {
          title2.layoutAlign = "STRETCH";
        } catch (e) {
        }
        const bodyNode2 = await makeBoundText(bodyText, 16, "Regular", scv(maps, "color/text/body/primary"));
        bodyNode2.name = "message";
        bodyNode2.textAutoResize = "HEIGHT";
        const mSlot = await makeSlot(
          owner,
          "Content",
          CONTENT_SLOT_DESC,
          [bodyNode2],
          [],
          {
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "MIN",
            itemSpacing: 8,
            stretchContents: true,
            parent: group
          }
        );
        try {
          mSlot.layoutAlign = "STRETCH";
        } catch (e) {
        }
        return group;
      }
      const header = figma.createFrame();
      header.name = "header";
      header.fills = [];
      header.layoutMode = "HORIZONTAL";
      header.primaryAxisSizingMode = "FIXED";
      header.counterAxisSizingMode = "AUTO";
      header.primaryAxisAlignItems = "SPACE_BETWEEN";
      header.counterAxisAlignItems = "MAX";
      header.paddingLeft = 24;
      header.paddingRight = 24;
      const title = await makeBoundText(titleText, 16, "Bold", scv(maps, "color/text/title/primary"));
      title.name = "title";
      header.appendChild(title);
      const closeIcon2 = await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG);
      closeIcon2.name = "close";
      header.appendChild(closeIcon2);
      group.appendChild(header);
      try {
        header.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const bodyNode = await makeBoundText(bodyText, 14, "Regular", scv(maps, "color/text/body/primary"));
      bodyNode.name = "message";
      const body = await makeSlot(
        owner,
        "Content",
        CONTENT_SLOT_DESC,
        [bodyNode],
        [],
        {
          layoutMode: "VERTICAL",
          primaryAxisSizingMode: "AUTO",
          counterAxisSizingMode: "FIXED",
          primaryAxisAlignItems: "MIN",
          counterAxisAlignItems: "MIN",
          itemSpacing: 8,
          // spacing/8
          paddingLeft: 24,
          paddingRight: 24,
          parent: group
        }
      );
      try {
        body.layoutAlign = "STRETCH";
      } catch (e) {
      }
      return group;
    };
    const makeFooterButton = async (brk, variant, label) => {
      const vLabel = variant === "primary" ? "Primary" : "Secondary";
      const size = brk === "PC" ? "XXSM" : "LG";
      const comp = await getReuseComp(
        `Button:${variant}:${size}:Default`,
        "Button",
        [`Variant=${vLabel}`, `Size=${size}`, "State=Default"]
      );
      if (!comp) {
        throw new Error(`[buildModalShell] \uCF54\uC5B4 Button \uC778\uC2A4\uD134\uC2A4 \uBBF8\uBC1C\uACAC: Button:${variant}:${size}:Default (${brk} \uC0AC\uC774\uC988 \uD0A4 \uBD88\uC77C\uCE58 \u2014 \uBE4C\uB4DC \uC911\uB2E8, \uC6B0\uD68C \uC548 \uD568)`);
      }
      const inst = comp.createInstance();
      inst.name = variant;
      await setInstanceLabel(inst, label);
      return inst;
    };
    const buildModalVariant = async (brk, footer, titleText, bodyText) => {
      const mobile = brk === "Mobile";
      const comp = figma.createComponent();
      comp.name = `Break=${brk}, Footer=${footer}`;
      comp.layoutMode = "VERTICAL";
      comp.primaryAxisSizingMode = "AUTO";
      comp.counterAxisSizingMode = "FIXED";
      comp.resize(mobile ? MODAL_MOBILE_WIDTH : MODAL_PC_WIDTH, 100);
      comp.itemSpacing = mobile ? 30 : 32;
      comp.paddingTop = 20;
      comp.paddingBottom = 20;
      comp.paddingLeft = mobile ? 20 : 0;
      comp.paddingRight = mobile ? 20 : 0;
      comp.counterAxisAlignItems = "CENTER";
      comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
      bindRadius(comp, maps, "radius/8");
      comp.strokes = [boundPaint(scv(maps, "color/modal/panel/border"))];
      comp.strokeWeight = 1;
      comp.strokeAlign = "INSIDE";
      comp.clipsContent = true;
      const modalEffects = boundShadowEffects(maps, "shadow/raised");
      try {
        comp.effects = modalEffects;
      } catch (e) {
      }
      await buildContentGroup(comp, brk, titleText, bodyText);
      const footerFrame = figma.createFrame();
      footerFrame.name = "footer";
      footerFrame.fills = [];
      footerFrame.layoutMode = "HORIZONTAL";
      footerFrame.primaryAxisSizingMode = "FIXED";
      footerFrame.counterAxisSizingMode = mobile ? "FIXED" : "AUTO";
      footerFrame.primaryAxisAlignItems = mobile ? "MIN" : "MAX";
      footerFrame.counterAxisAlignItems = "CENTER";
      footerFrame.paddingLeft = mobile ? 0 : 24;
      footerFrame.paddingRight = mobile ? 0 : 24;
      footerFrame.itemSpacing = footer === "Dual" ? 8 : 0;
      if (mobile) footerFrame.resize(260, 48);
      comp.appendChild(footerFrame);
      try {
        footerFrame.layoutAlign = "STRETCH";
      } catch (e) {
      }
      const appendFooterButton = async (variant, label) => {
        const button2 = await makeFooterButton(brk, variant, label);
        footerFrame.appendChild(button2);
        if (mobile) {
          try {
            button2.layoutSizingHorizontal = "FILL";
          } catch (e) {
          }
        }
      };
      if (footer === "Dual") {
        await appendFooterButton("secondary", mobile ? "\uC544\uB2C8\uC624" : "\uCDE8\uC18C");
        await appendFooterButton("primary", mobile ? "\uB124" : "\uD655\uC778");
      } else {
        await appendFooterButton("primary", mobile ? "\uC5C5\uB370\uC774\uD2B8" : "\uD655\uC778");
      }
      setLightMode(comp, maps);
      setShadowMode(comp, maps, maps.semanticShadowLightModeId);
      return comp;
    };
    const COPY = {
      "PC:Single": { title: "\uC81C\uBAA9 \uC601\uC5ED", body: "\uC694\uCCAD\uD558\uC2E0 \uC791\uC5C5\uC774 \uC815\uC0C1\uC801\uC73C\uB85C \uCC98\uB9AC\uB418\uC5C8\uC2B5\uB2C8\uB2E4.\n\uBCC0\uACBD\uB41C \uB0B4\uC6A9\uC740 \uBAA9\uB85D\uC5D0\uC11C \uD655\uC778\uD558\uC2E4 \uC218 \uC788\uC5B4\uC694." },
      "PC:Dual": { title: "\uC81C\uBAA9 \uC601\uC5ED", body: "\uBCC0\uACBD\uD55C \uB0B4\uC6A9\uC774 \uC800\uC7A5\uB418\uC9C0 \uC54A\uACE0 \uC0AC\uB77C\uC9D1\uB2C8\uB2E4.\n\uC815\uB9D0 \uC774 \uC791\uC5C5\uC744 \uC9C4\uD589\uD558\uC2DC\uACA0\uC5B4\uC694?" },
      "Mobile:Single": { title: "\uC5C5\uB370\uC774\uD2B8 \uC548\uB0B4", body: "\uBCF4\uB2E4 \uC548\uC815\uC801\uC778 \uC11C\uBE44\uC2A4 \uC774\uC6A9\uC744 \uC704\uD574 \uCD5C\uC2E0\n\uBC84\uC804\uC73C\uB85C \uC5C5\uB370\uC774\uD2B8\uD574 \uC8FC\uC138\uC694." },
      "Mobile:Dual": { title: "\uC790\uB3D9 \uB85C\uADF8\uC778 \uC124\uC815", body: "\uB85C\uADF8\uC778\uB418\uC5C8\uC5B4\uC694.\n\uB2E4\uC74C\uBD80\uD130 \uC790\uB3D9\uC73C\uB85C \uB85C\uADF8\uC778\uD560\uAE4C\uC694?" }
    };
    const FOOTERS = ["Single", "Dual"];
    const modalComps = [];
    const modalByKey = /* @__PURE__ */ new Map();
    for (const brk of ["PC", "Mobile"]) {
      for (const footer of FOOTERS) {
        const copy = COPY[`${brk}:${footer}`];
        const comp = await buildModalVariant(brk, footer, copy.title, copy.body);
        modalComps.push(comp);
        modalByKey.set(`${brk}:${footer}`, comp);
      }
    }
    const set = figma.combineAsVariants(modalComps, figma.currentPage);
    set.name = "Modal";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Modal"] = set;
    const opts = {
      title: "Modal",
      platforms: [{ name: "PC", sizes: [""] }, { name: "Mobile", sizes: [""] }],
      colHeaders: ["Single", "Dual"],
      rowLabels: [""],
      cellAt: (platform, _size, _r, c) => {
        var _a;
        return (_a = modalByKey.get(`${platform}:${FOOTERS[c]}`)) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 260,
      rowLabelW: 16,
      shadowMode: true
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  var MODAL_CONTENT_SIZES = ["MD", "LG", "XL"];
  var MODAL_CONTENT_GEO = {
    MD: { w: 520, h: 336 },
    LG: { w: 1e3, h: 587 },
    XL: { w: 1200, h: 587 }
  };
  var MODAL_CONTENT_SLOT_DESC = '\uBAA8\uB2EC \uBCF8\uBB38\uC774 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 "\uCEE8\uD150\uCE20 \uC601\uC5ED" \uC790\uB9AC\uD45C\uC2DC \uB124\uBAA8\uCE78\uC774\uBA70, \uADF8\uAC83\uC744 \uBE7C\uACE0 \uC785\uB825 \uD3FC\xB7\uD45C\xB7\uC774\uBBF8\uC9C0 \uB4F1 \uBB34\uC5C7\uC774\uB4E0 \uB123\uC744 \uC218 \uC788\uB2E4. \uC81C\uBAA9\xB7\uB2EB\uAE30(X)\uC640 \uD478\uD130 \uBC84\uD2BC\uC740 \uC2AC\uB86F \uBC16 \uACE0\uC815 \uC601\uC5ED\uC774\uB2E4.';
  async function buildModalContent(maps, originY) {
    const FOOTERS = ["Single", "Dual"];
    const num = (t) => requireVar(maps.foundationNumber, t, "Foundation Number");
    const footerButton = async (variant, label) => {
      const vLabel = variant === "primary" ? "Primary" : "Secondary";
      const comp = await getReuseComp(
        `Button:${variant}:XXSM:Default`,
        "Button",
        [`Variant=${vLabel}`, "Size=XXSM", "State=Default"]
      );
      if (!comp) throw new Error(`[buildModalContent] \uCF54\uC5B4 Button \uC778\uC2A4\uD134\uC2A4 \uBBF8\uBC1C\uACAC: Button:${variant}:XXSM:Default \u2014 \uBE4C\uB4DC \uC911\uB2E8, \uC6B0\uD68C \uC548 \uD568`);
      const inst = comp.createInstance();
      inst.name = variant;
      await setInstanceLabel(inst, label);
      return inst;
    };
    const comps = [];
    const byKey = /* @__PURE__ */ new Map();
    for (const size of MODAL_CONTENT_SIZES) {
      for (const footer of FOOTERS) {
        const geo = MODAL_CONTENT_GEO[size];
        const comp = figma.createComponent();
        comp.name = `Size=${size}, Footer=${footer}`;
        comp.layoutMode = "VERTICAL";
        comp.primaryAxisSizingMode = "FIXED";
        comp.counterAxisSizingMode = "FIXED";
        comp.counterAxisAlignItems = "CENTER";
        comp.setBoundVariable("paddingTop", num("spacing/20"));
        comp.setBoundVariable("paddingBottom", num("spacing/20"));
        comp.itemSpacing = 32;
        comp.setBoundVariable("itemSpacing", num("spacing/32"));
        comp.resize(geo.w, geo.h);
        comp.fills = [boundPaint(scv(maps, "color/surface/raised"))];
        bindRadius(comp, maps, "radius/8");
        comp.strokes = [boundPaint(scv(maps, "color/modal/panel/border"))];
        comp.strokeWeight = 1;
        comp.strokeAlign = "INSIDE";
        comp.clipsContent = true;
        try {
          comp.effects = boundShadowEffects(maps, "shadow/raised");
        } catch (e) {
        }
        const header = figma.createFrame();
        header.name = "header";
        header.fills = [];
        header.layoutMode = "HORIZONTAL";
        header.primaryAxisSizingMode = "FIXED";
        header.counterAxisSizingMode = "AUTO";
        header.primaryAxisAlignItems = "SPACE_BETWEEN";
        header.counterAxisAlignItems = "CENTER";
        header.setBoundVariable("paddingLeft", num("spacing/24"));
        header.setBoundVariable("paddingRight", num("spacing/24"));
        comp.appendChild(header);
        try {
          header.layoutAlign = "STRETCH";
        } catch (e) {
        }
        header.appendChild(await makeBoundText("\uC81C\uBAA9 \uC601\uC5ED", 16, "Bold", scv(maps, "color/text/title/primary"), "title/16B"));
        header.appendChild(await makeIconInstance("close", scv(maps, "color/icon/gray-dark"), 24, CLOSE_ICON_SVG));
        const body = figma.createFrame();
        body.name = "content";
        body.layoutMode = "VERTICAL";
        body.primaryAxisSizingMode = "FIXED";
        body.counterAxisSizingMode = "FIXED";
        body.primaryAxisAlignItems = "CENTER";
        body.counterAxisAlignItems = "CENTER";
        body.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
        bindRadius(body, maps, "radius/4");
        comp.appendChild(body);
        try {
          body.layoutAlign = "STRETCH";
          body.layoutGrow = 1;
        } catch (e) {
        }
        body.appendChild(await makeBoundText("\uCEE8\uD150\uCE20 \uC601\uC5ED", 14, "Medium", scv(maps, "color/text/body/tertiary"), "body/14M"));
        const bodyWrap = figma.createFrame();
        bodyWrap.name = "content-area";
        bodyWrap.fills = [];
        bodyWrap.layoutMode = "VERTICAL";
        bodyWrap.primaryAxisSizingMode = "FIXED";
        bodyWrap.counterAxisSizingMode = "FIXED";
        bodyWrap.setBoundVariable("paddingLeft", num("spacing/24"));
        bodyWrap.setBoundVariable("paddingRight", num("spacing/24"));
        comp.insertChild(1, bodyWrap);
        try {
          bodyWrap.layoutAlign = "STRETCH";
          bodyWrap.layoutGrow = 1;
        } catch (e) {
        }
        const contentSlot = await makeSlot(
          comp,
          "Content",
          MODAL_CONTENT_SLOT_DESC,
          [body],
          [],
          {
            parent: bodyWrap,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            itemSpacing: 0,
            stretch: true,
            stretchContents: true
          }
        );
        try {
          contentSlot.layoutGrow = 1;
        } catch (e) {
        }
        try {
          body.layoutAlign = "STRETCH";
          body.layoutGrow = 1;
        } catch (e) {
        }
        const footerFrame = figma.createFrame();
        footerFrame.name = "footer";
        footerFrame.fills = [];
        footerFrame.layoutMode = "HORIZONTAL";
        footerFrame.primaryAxisSizingMode = "FIXED";
        footerFrame.counterAxisSizingMode = "AUTO";
        footerFrame.primaryAxisAlignItems = "MAX";
        footerFrame.counterAxisAlignItems = "CENTER";
        footerFrame.setBoundVariable("paddingLeft", num("spacing/24"));
        footerFrame.setBoundVariable("paddingRight", num("spacing/24"));
        footerFrame.itemSpacing = 8;
        footerFrame.setBoundVariable("itemSpacing", num("spacing/8"));
        comp.appendChild(footerFrame);
        try {
          footerFrame.layoutAlign = "STRETCH";
        } catch (e) {
        }
        if (footer === "Dual") {
          footerFrame.appendChild(await footerButton("secondary", "\uCDE8\uC18C"));
          footerFrame.appendChild(await footerButton("primary", "\uD655\uC778"));
        } else {
          footerFrame.appendChild(await footerButton("primary", "\uD655\uC778"));
        }
        setLightMode(comp, maps);
        setShadowMode(comp, maps, maps.semanticShadowLightModeId);
        comps.push(comp);
        byKey.set(`${size}:${footer}`, comp);
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Modal Content";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Modal Content"] = set;
    const opts = {
      title: "Modal Content",
      platforms: [{ name: "PC", sizes: MODAL_CONTENT_SIZES }],
      colHeaders: ["Single", "Dual"],
      rowLabels: [""],
      cellAt: (_p, size, _r, c) => {
        var _a;
        return (_a = byKey.get(`${size}:${FOOTERS[c]}`)) != null ? _a : null;
      },
      // XL 1200 을 담아야 해서 셀이 크다 — GNB 와 같은 이유로 다크 스펙을 아래에 쌓는다.
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 1240,
      cellH: 640,
      rowLabelW: 16,
      shadowMode: true
    };
    let bottomY = await decorateSetGrouped(set, opts, maps);
    opts.darkOffset = { x: 0, y: bottomY + 80 };
    try {
      bottomY = Math.max(bottomY, await buildGroupedSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    set.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    return { set, bottomY };
  }
  async function buildCalendarCellLayout(maps, originY) {
    const { set, variants } = await getOrBuildCalendarCell(maps);
    const stdStates = ["Default", "Hover", "Today", "Selected", "Selected Hover", "Disabled"];
    const rngStates = ["Default", "Start", "End", "Disabled"];
    const cellW = 92, cellH = 60, rowLabelW = 80;
    const mkOpts = (title, states, type) => ({
      title,
      colHeaders: states,
      rowLabels: CAL_SIZES.map((sz) => sz),
      // 행 = 크기(MD·SM), 열 = 상태. 표 제목이 Standard/Range 를 알린다.
      cellAt: (r, c) => {
        var _a;
        return (_a = variants[`${CAL_SIZES[r]}:${type}:${states[c]}`]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW,
      cellH,
      rowLabelW
    });
    const stdOpts = mkOpts("Calendar Cell \u2014 Standard", stdStates, "Standard");
    const rngOpts = mkOpts("Calendar Cell \u2014 Range", rngStates, "Range");
    const setW = Math.max(specWidth(rowLabelW, stdStates.length, cellW), specWidth(rowLabelW, rngStates.length, cellW));
    const floatAt = (oy, cy) => ({
      text: async (s, x, y, w, al, role, fs, st) => {
        const t = await makeLabel(s, fs, st, x, oy + y, w, al, role, false);
        pinLightMode(t);
        try {
          t.name = `${set.name} ${DECO_SUFFIX}`;
        } catch (e) {
        }
      },
      band: (x, y, w, h, role) => {
        const b = figma.createRectangle();
        b.resize(w, h);
        b.cornerRadius = 4;
        b.fills = [specPaint(role, false)];
        b.x = x;
        b.y = oy + y;
        pinLightMode(b);
        try {
          b.name = `${set.name} ${DECO_SUFFIX}`;
        } catch (e) {
        }
      },
      cell: (comp, x, y) => {
        comp.x = x;
        comp.y = cy + y;
      }
    });
    set.x = 0;
    set.y = originY;
    try {
      set.fills = [specPaint("bg", false)];
    } catch (e) {
    }
    const h1 = await renderFlat(stdOpts, false, floatAt(originY, 0));
    const h2 = await renderFlat(rngOpts, false, floatAt(originY + h1, h1));
    set.resize(setW, h1 + h2);
    setLightMode(set, maps);
    let bottomY = originY + h1 + h2;
    try {
      const modeId = maps.semanticDarkModeId;
      const frame = figma.createFrame();
      frame.name = "Calendar Cell \u2014 Spec Dark";
      frame.fills = [specPaint("bg", true)];
      frame.cornerRadius = 8;
      frame.resize(setW, 1200);
      frame.x = setW + 80;
      frame.y = originY;
      const base = frameEmit(frame, maps, modeId);
      const dh1 = await renderFlat(stdOpts, true, base);
      const off = {
        text: (s, x, y, w, al, role, fs, st) => base.text(s, x, y + dh1, w, al, role, fs, st),
        band: (x, y, w, h, role) => base.band(x, y + dh1, w, h, role),
        cell: (comp, x, y) => base.cell(comp, x, y + dh1)
      };
      const dh2 = await renderFlat(rngOpts, true, off);
      frame.resize(setW, dh1 + dh2);
      setMode(frame, maps, modeId);
      bottomY = Math.max(bottomY, frame.y + dh1 + dh2);
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildCalendarTileLayout(maps, originY) {
    const { set, variants } = await getOrBuildCalendarTile(maps);
    set.x = 0;
    set.y = originY;
    const states = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Calendar Tile",
      colHeaders: states,
      rowLabels: CAL_SIZES.map((sz) => sz),
      // 행 = 크기(MD 88×56 · SM 68×40)
      cellAt: (r, c) => {
        var _a;
        return (_a = variants[`${CAL_SIZES[r]}:${states[c]}`]) != null ? _a : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 72
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var SHELL_WIFI_SVG = `<svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg"><mask id="sw1" fill="white"><path d="M2.34315 4.34315C3.84344 2.84286 5.87827 2 8 2C10.1217 2 12.1566 2.84285 13.6569 4.34314L8 10L2.34315 4.34315Z"/></mask><path d="M2.34315 4.34315C3.84344 2.84286 5.87827 2 8 2C10.1217 2 12.1566 2.84285 13.6569 4.34314L8 10L2.34315 4.34315Z" stroke="#353535" stroke-width="3.2" mask="url(#sw1)"/><mask id="sw2" fill="white"><path d="M4.46447 6.46447C5.40215 5.52678 6.67392 5 8 5C9.32608 5 10.5979 5.52678 11.5355 6.46447L8 10L4.46447 6.46447Z"/></mask><path d="M4.46447 6.46447C5.40215 5.52678 6.67392 5 8 5C9.32608 5 10.5979 5.52678 11.5355 6.46447L8 10L4.46447 6.46447Z" stroke="#353535" stroke-width="3.2" mask="url(#sw2)"/><circle cx="7.9998" cy="10.2" r="1.2" fill="#353535"/></svg>`;
  var SHELL_LOCK_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.0002 3C9.16131 3 6.85731 5.39657 6.85731 8.33829V11.2286H5.31445V21H18.6859V11.2286H17.143V8.33829C17.143 5.39657 14.839 3 12.0002 3ZM14.4173 17.8114L13.687 18.5417L11.9899 16.8446L10.2927 18.5417L9.56245 17.8114L11.2596 16.1143L9.56245 14.4171L10.2927 13.6869L11.9899 15.384L13.687 13.6869L14.4173 14.4171L12.7202 16.1143L14.4173 17.8114ZM7.88588 11.2286V8.33829C7.88588 5.96229 9.72702 4.02857 12.0002 4.02857C14.2733 4.02857 16.1145 5.96229 16.1145 8.33829V11.2286H7.88588Z" fill="#757575"/></svg>`;
  var SHELL_REFRESH_SVG = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.0002 19.9411C9.74488 19.9411 7.61666 18.9776 6.12374 17.3364H9.0143V16.2776H5.02257C4.7261 16.2776 4.49316 16.5106 4.49316 16.807V20.7882H5.55198V18.2576C7.23549 19.9941 9.54371 20.9999 12.0002 20.9999C16.966 20.9999 21.0001 16.9659 21.0001 12C21.0001 11.2271 20.9048 10.4647 20.7142 9.72357L19.6871 9.98828C19.8566 10.6342 19.9413 11.3118 19.9413 12C19.9413 16.3835 16.3836 19.9411 12.0002 19.9411Z" fill="#757575"/><path d="M18.4481 5.74282C16.7646 4.00636 14.4564 3.00049 11.9999 3.00049C7.03408 3.00049 3 7.03457 3 12.0004C3 12.7733 3.09529 13.5357 3.29647 14.2769L4.32352 14.0122C4.15411 13.3663 4.0694 12.6886 4.0694 12.0004C4.05881 7.61692 7.61643 4.0593 11.9999 4.0593C14.2552 4.0593 16.3834 5.02282 17.8763 6.66398H14.9858V7.7228H18.9669C19.2634 7.7228 19.4963 7.48986 19.4963 7.19339V3.21225H18.4375V5.74282H18.4481Z" fill="#757575"/></svg>`;
  function makeBoundIcon(svg, colorVar) {
    const node = figma.createNodeFromSvg(svg);
    node.name = "icon";
    const SHAPES = ["VECTOR", "ELLIPSE", "RECTANGLE", "LINE", "POLYGON", "STAR", "BOOLEAN_OPERATION"];
    node.findAll((n) => SHAPES.includes(n.type)).forEach((v) => {
      try {
        if (v.isMask) return;
        if (Array.isArray(v.strokes) && v.strokes.length) v.strokes = [boundPaint(colorVar)];
        if (Array.isArray(v.fills) && v.fills.length) v.fills = [boundPaint(colorVar)];
      } catch (e) {
      }
    });
    return node;
  }
  function shellRect(maps, x, y, w, h, r, colorKey, asStroke) {
    const rc = figma.createRectangle();
    rc.x = x;
    rc.y = y;
    rc.resize(w, h);
    rc.cornerRadius = r;
    if (asStroke) {
      rc.strokes = [boundPaint(scv(maps, colorKey))];
      rc.strokeWeight = 1;
      rc.fills = [];
    } else {
      rc.fills = [boundPaint(scv(maps, colorKey))];
      rc.strokes = [];
    }
    return rc;
  }
  async function populateStatusRow(target, maps) {
    target.layoutMode = "HORIZONTAL";
    target.primaryAxisSizingMode = "FIXED";
    target.counterAxisSizingMode = "FIXED";
    target.resize(360, 27);
    target.primaryAxisAlignItems = "SPACE_BETWEEN";
    target.counterAxisAlignItems = "CENTER";
    target.paddingLeft = 20;
    target.paddingRight = 16;
    target.paddingTop = 0;
    target.paddingBottom = 0;
    target.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    target.appendChild(await makeBoundText("12:30", 12, "Medium", scv(maps, "color/text/body/secondary")));
    const right = figma.createFrame();
    right.name = "status-right";
    right.layoutMode = "HORIZONTAL";
    right.primaryAxisSizingMode = "AUTO";
    right.counterAxisSizingMode = "AUTO";
    right.counterAxisAlignItems = "CENTER";
    right.itemSpacing = 6;
    right.fills = [];
    const signal = figma.createFrame();
    signal.name = "signal";
    signal.fills = [];
    signal.clipsContent = false;
    signal.resize(17, 12);
    signal.appendChild(shellRect(maps, 0, 8, 3, 4, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 4.5, 6, 3, 6, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 9, 4, 3, 8, 0.5, "color/icon/gray-dark", false));
    signal.appendChild(shellRect(maps, 13.5, 1, 3, 11, 0.5, "color/icon/gray-dark", false));
    right.appendChild(signal);
    const wifi = makeBoundIcon(SHELL_WIFI_SVG, scv(maps, "color/icon/gray-dark"));
    wifi.name = "wifi";
    right.appendChild(wifi);
    try {
      wifi.resize(16, 12);
    } catch (e) {
    }
    const battery = figma.createFrame();
    battery.name = "battery";
    battery.fills = [];
    battery.clipsContent = false;
    battery.resize(24, 12);
    battery.appendChild(shellRect(maps, 0, 0.5, 20, 11, 2.5, "color/icon/gray-dark", true));
    battery.appendChild(shellRect(maps, 20.4, 4, 1.6, 4, 1, "color/icon/gray-dark", false));
    battery.appendChild(shellRect(maps, 2, 2.5, 14.5, 7, 1, "color/icon/gray-dark", false));
    right.appendChild(battery);
    right.appendChild(await makeBoundText("78%", 12, "Medium", scv(maps, "color/text/body/secondary")));
    target.appendChild(right);
  }
  async function buildShellUrlBar(maps) {
    const bar = figma.createFrame();
    bar.name = "browser-url-bar";
    bar.layoutMode = "HORIZONTAL";
    bar.primaryAxisSizingMode = "FIXED";
    bar.counterAxisSizingMode = "FIXED";
    bar.resize(360, 50);
    bar.primaryAxisAlignItems = "CENTER";
    bar.counterAxisAlignItems = "CENTER";
    bar.itemSpacing = 6;
    bar.paddingLeft = 16;
    bar.paddingRight = 16;
    bar.paddingTop = 12;
    bar.paddingBottom = 12;
    bar.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    const lock = makeBoundIcon(SHELL_LOCK_SVG, scv(maps, "color/icon/gray"));
    lock.name = "ic_\uC7A0\uAE40";
    bar.appendChild(lock);
    try {
      lock.resize(24, 24);
    } catch (e) {
    }
    const pill = figma.createFrame();
    pill.name = "url";
    pill.layoutMode = "HORIZONTAL";
    pill.primaryAxisAlignItems = "CENTER";
    pill.counterAxisAlignItems = "CENTER";
    pill.primaryAxisSizingMode = "FIXED";
    pill.counterAxisSizingMode = "FIXED";
    pill.cornerRadius = 100;
    pill.fills = [boundPaint(scv(maps, "color/bg/level-2"))];
    pill.layoutGrow = 1;
    pill.layoutAlign = "STRETCH";
    pill.appendChild(await makeBoundText("m.s1.co.kr", 14, "Regular", scv(maps, "color/text/body/tertiary")));
    bar.appendChild(pill);
    const refresh = makeBoundIcon(SHELL_REFRESH_SVG, scv(maps, "color/icon/gray"));
    refresh.name = "ic_\uC0C8\uB85C\uACE0\uCE68";
    bar.appendChild(refresh);
    try {
      refresh.resize(24, 24);
    } catch (e) {
    }
    return bar;
  }
  var S1_LOGO_SVG = `<svg width="42" height="16" viewBox="0 0 42 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32.6826 14.3262H41.5254V16H30.6992V10.2461H32.6826V14.3262ZM10.1426 15.9902H8.32129V7.07812H7.39258C7.30419 11.1554 5.68825 13.0125 3.70117 13.0127C1.65723 13.0127 0 11.0554 0 6.73047C0 2.41216 1.65721 0.448242 3.70117 0.448242C5.52602 0.448409 7.03869 2.01912 7.34277 5.42676H8.32129V0.172852H10.1426V15.9902ZM12.9111 15.9902H11.084V0.173828H12.9111V15.9902ZM28.084 15.2305H15.084V13.5811H28.084V15.2305ZM41.2891 0.182617V13.0557H39.46V11.2832H36.459V9.64453H39.46V0.182617H41.2891ZM38.8672 8.87891H35.3379V12.1885H33.3799V8.87891H29.7305V7.3291H38.8672V8.87891ZM22.6143 2.46875C22.6143 4.89881 24.005 8.20501 27.7148 9.30078V11.0654C27.6961 11.063 23.8792 10.5615 21.583 6.69531C19.2775 10.5711 15.4512 11.0654 15.4512 11.0654V9.30078C19.1607 8.21325 20.5518 4.89883 20.5518 2.46875V0.551758H22.6143V2.46875ZM3.70215 2.41211C2.66837 2.41211 1.83011 3.41277 1.83008 6.7334C1.83008 10.0732 2.66835 11.0557 3.70215 11.0557C4.73624 11.0556 5.57422 10.0731 5.57422 6.7334C5.57418 3.41295 4.73622 2.41222 3.70215 2.41211ZM34.3525 0C36.6151 0 38.4492 1.17983 38.4492 3.41797C38.449 5.69092 36.615 6.83496 34.3525 6.83496C32.0903 6.83485 30.2561 5.69081 30.2559 3.41797C30.2559 1.17994 32.0901 0 34.3525 0ZM34.3486 1.57227C33.1672 1.57227 32.2091 2.36269 32.209 3.44043C32.209 4.51861 33.1671 5.30859 34.3486 5.30859C35.5303 5.3084 36.4883 4.51026 36.4883 3.44043C36.4882 2.35834 35.5302 1.57246 34.3486 1.57227Z" fill="#757575"/></svg>`;
  async function buildFooter(maps, originY) {
    const LINK_NAMES = ["\uC774\uC6A9\uC57D\uAD00", "\uAC1C\uC778\uC815\uBCF4 \uCC98\uB9AC\uBC29\uCE68", "\uC704\uCE58\uAE30\uBC18 \uC11C\uBE44\uC2A4 \uC774\uC6A9\uC57D\uAD00"];
    const pc = figma.createComponent();
    pc.name = "Platform=PC";
    pc.layoutMode = "HORIZONTAL";
    pc.primaryAxisSizingMode = "FIXED";
    pc.counterAxisSizingMode = "FIXED";
    pc.resize(1920, 116);
    pc.primaryAxisAlignItems = "SPACE_BETWEEN";
    pc.counterAxisAlignItems = "CENTER";
    pc.paddingLeft = 320;
    pc.paddingRight = 320;
    const sp28 = requireVar(maps.foundationNumber, "spacing/28", "Foundation Number");
    pc.setBoundVariable("paddingTop", sp28);
    pc.setBoundVariable("paddingBottom", sp28);
    pc.fills = [boundPaint(scv(maps, "color/navigation/bg"))];
    pc.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    pc.strokeAlign = "INSIDE";
    pc.strokeTopWeight = 1;
    pc.strokeBottomWeight = 0;
    pc.strokeLeftWeight = 0;
    pc.strokeRightWeight = 0;
    const leftBlock = figma.createFrame();
    leftBlock.name = "content-left";
    leftBlock.layoutMode = "VERTICAL";
    leftBlock.primaryAxisSizingMode = "AUTO";
    leftBlock.counterAxisSizingMode = "AUTO";
    leftBlock.fills = [];
    leftBlock.itemSpacing = 4;
    const linksRow = figma.createFrame();
    linksRow.name = "links";
    linksRow.layoutMode = "HORIZONTAL";
    linksRow.primaryAxisSizingMode = "AUTO";
    linksRow.counterAxisSizingMode = "AUTO";
    linksRow.fills = [];
    linksRow.itemSpacing = 12;
    for (let i = 0; i < LINK_NAMES.length; i++) {
      linksRow.appendChild(await makeBoundText(LINK_NAMES[i], 10, "Regular", scv(maps, "color/text/body/tertiary")));
      if (i < LINK_NAMES.length - 1) {
        const sep = figma.createRectangle();
        sep.name = "sep";
        sep.resize(1, 8);
        sep.fills = [boundPaint(scv(maps, "color/icon/gray-light"))];
        linksRow.appendChild(sep);
      }
    }
    leftBlock.appendChild(linksRow);
    leftBlock.appendChild(await makeBoundText("(\uC8FC)\uC5D0\uC2A4\uC6D0   \uC0AC\uC5C5\uC790\uB4F1\uB85D\uBC88\uD638 208-81-13302    \uB300\uD45C\uC774\uC0AC \uC815\uD574\uB9B0    04511 \uC11C\uC6B8\uD2B9\uBCC4\uC2DC \uC911\uAD6C \uC138\uC885\uB300\uB85C 7\uAE38 25 \uC5D0\uC2A4\uC6D0 \uBE4C\uB529", 10, "Regular", scv(maps, "color/text/body/tertiary")));
    leftBlock.appendChild(await makeBoundText("\xA9 S-1 Corp. All Rights Reserved.", 10, "Regular", scv(maps, "color/text/body/tertiary")));
    pc.appendChild(leftBlock);
    const logo = figma.createNodeFromSvg(S1_LOGO_SVG);
    logo.name = "C/IMG/Logo/S1_g";
    rebindIconColor(logo, scv(maps, "color/icon/gray"));
    pc.appendChild(logo);
    setLightMode(pc, maps);
    const mobile = figma.createComponent();
    mobile.name = "Platform=Mobile";
    mobile.layoutMode = "VERTICAL";
    mobile.primaryAxisSizingMode = "AUTO";
    mobile.counterAxisSizingMode = "AUTO";
    mobile.primaryAxisAlignItems = "MIN";
    mobile.counterAxisAlignItems = "MIN";
    mobile.fills = [];
    const sp4 = requireVar(maps.foundationNumber, "spacing/4", "Foundation Number");
    mobile.setBoundVariable("itemSpacing", sp4);
    mobile.paddingLeft = 16;
    mobile.paddingRight = 16;
    mobile.paddingTop = 8;
    mobile.paddingBottom = 8;
    const mLinks = figma.createFrame();
    mLinks.name = "links";
    mLinks.layoutMode = "HORIZONTAL";
    mLinks.primaryAxisSizingMode = "AUTO";
    mLinks.counterAxisSizingMode = "AUTO";
    mLinks.fills = [];
    mLinks.itemSpacing = 8;
    mLinks.primaryAxisAlignItems = "CENTER";
    mLinks.counterAxisAlignItems = "CENTER";
    for (let i = 0; i < LINK_NAMES.length; i++) {
      mLinks.appendChild(await makeBoundText(LINK_NAMES[i], 12, "Regular", scv(maps, "color/text/body/tertiary")));
      if (i < LINK_NAMES.length - 1) {
        const sep = figma.createRectangle();
        sep.name = "sep";
        sep.resize(1, 10);
        sep.fills = [boundPaint(scv(maps, "color/line/gray/subtle"))];
        mLinks.appendChild(sep);
      }
    }
    mobile.appendChild(mLinks);
    const mCopyright = await makeBoundText("\xA9 S-1 Corp. All Rights Reserved.", 12, "Regular", scv(maps, "color/text/body/tertiary"));
    mobile.appendChild(mCopyright);
    try {
      mCopyright.layoutAlign = "STRETCH";
      mCopyright.textAlignHorizontal = "CENTER";
    } catch (e) {
    }
    setLightMode(mobile, maps);
    const set = figma.combineAsVariants([pc, mobile], figma.currentPage);
    set.name = "Footer";
    set.x = 0;
    set.y = originY;
    try {
      set.clipsContent = false;
    } catch (_) {
    }
    const opts = {
      title: "Footer",
      colHeaders: [""],
      rowLabels: ["PC", "Mobile"],
      cellAt: (r, _c) => r === 0 ? pc : mobile,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 1960,
      cellH: 120,
      rowLabelW: 64,
      leftAlignCells: true
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildStatusBar(maps, originY) {
    const app = figma.createComponent();
    app.name = "Platform=App";
    await populateStatusRow(app, maps);
    setLightMode(app, maps);
    const web = figma.createComponent();
    web.name = "Platform=Web";
    web.layoutMode = "VERTICAL";
    web.primaryAxisSizingMode = "AUTO";
    web.counterAxisSizingMode = "FIXED";
    web.resize(360, 77);
    web.itemSpacing = 0;
    web.fills = [];
    const row = figma.createFrame();
    row.name = "status-row";
    await populateStatusRow(row, maps);
    row.layoutAlign = "STRETCH";
    web.appendChild(row);
    const urlbar = await buildShellUrlBar(maps);
    urlbar.layoutAlign = "STRETCH";
    web.appendChild(urlbar);
    setLightMode(web, maps);
    const set = figma.combineAsVariants([app, web], figma.currentPage);
    set.name = "StatusBar";
    set.x = 0;
    set.y = originY;
    BUILT_COMPS["StatusBar:App"] = app;
    BUILT_COMPS["StatusBar:Web"] = web;
    BUILT_SETS["StatusBar"] = set;
    const opts = {
      title: "StatusBar",
      colHeaders: [""],
      rowLabels: ["App", "Web"],
      cellAt: (r, _c) => r === 0 ? app : web,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 80,
      rowLabelW: 56
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var NAV_SVG = (() => {
    const s = (d) => `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">${d}</svg>`;
    const P = (path) => `<path d="${path}" stroke="#757575" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`;
    return {
      chevronLeft: s(P("M15 6L9 12L15 18")),
      chevronRight: s(P("M9 6L15 12L9 18")),
      home: s(P("M3.5 11L12 4L20.5 11") + P("M6 9.5V20H18V9.5")),
      star: s(P("M12 3.5L14.58 8.74L20.36 9.58L16.18 13.65L17.17 19.41L12 16.69L6.83 19.41L7.82 13.65L3.64 9.58L9.42 8.74L12 3.5Z")),
      menu: s(P("M4 7H20") + P("M4 12H20") + P("M4 17H20")),
      recents: s(P("M8 6V18") + P("M12 6V18") + P("M16 6V18")),
      androidHome: s(`<rect x="6" y="6" width="12" height="12" rx="3" stroke="#757575" stroke-width="2"/>`)
    };
  })();
  function navIcon(svg, maps) {
    const i = makeBoundIcon(svg, scv(maps, "color/icon/gray"));
    i.name = "icon";
    try {
      i.resize(24, 24);
    } catch (e) {
    }
    return i;
  }
  async function navTabsIcon(maps) {
    const f = figma.createFrame();
    f.name = "tabs";
    f.fills = [];
    f.clipsContent = false;
    f.resize(24, 24);
    const r = figma.createRectangle();
    r.x = 4;
    r.y = 5;
    r.resize(16, 14);
    r.cornerRadius = 2;
    r.fills = [];
    r.strokes = [boundPaint(scv(maps, "color/icon/gray"))];
    r.strokeWeight = 2;
    f.appendChild(r);
    const t = await makeBoundText("29", 9, "Medium", scv(maps, "color/icon/gray"));
    try {
      t.textAutoResize = "NONE";
      t.resize(24, 14);
      t.textAlignHorizontal = "CENTER";
      t.textAlignVertical = "CENTER";
      t.x = 0;
      t.y = 5;
    } catch (e) {
    }
    f.appendChild(t);
    return f;
  }
  function populateAndroidNav(target, maps) {
    target.layoutMode = "HORIZONTAL";
    target.primaryAxisSizingMode = "FIXED";
    target.counterAxisSizingMode = "FIXED";
    target.resize(360, 45);
    target.primaryAxisAlignItems = "SPACE_BETWEEN";
    target.counterAxisAlignItems = "CENTER";
    target.paddingLeft = 48;
    target.paddingRight = 48;
    target.paddingTop = 0;
    target.paddingBottom = 0;
    target.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    target.appendChild(navIcon(NAV_SVG.recents, maps));
    target.appendChild(navIcon(NAV_SVG.androidHome, maps));
    target.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
  }
  async function buildBrowserToolbarRow(maps) {
    const row = figma.createFrame();
    row.name = "browser-toolbar";
    row.layoutMode = "HORIZONTAL";
    row.primaryAxisSizingMode = "FIXED";
    row.counterAxisSizingMode = "FIXED";
    row.resize(360, 50);
    row.primaryAxisAlignItems = "SPACE_BETWEEN";
    row.counterAxisAlignItems = "CENTER";
    row.paddingLeft = 16;
    row.paddingRight = 16;
    row.paddingTop = 0;
    row.paddingBottom = 0;
    row.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    row.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
    row.appendChild(navIcon(NAV_SVG.chevronRight, maps));
    row.appendChild(navIcon(NAV_SVG.home, maps));
    row.appendChild(navIcon(NAV_SVG.star, maps));
    row.appendChild(await navTabsIcon(maps));
    row.appendChild(navIcon(NAV_SVG.menu, maps));
    return row;
  }
  async function buildNavBar(maps, originY) {
    const app = figma.createComponent();
    app.name = "Platform=App";
    populateAndroidNav(app, maps);
    const web = figma.createComponent();
    web.name = "Platform=Web";
    web.layoutMode = "VERTICAL";
    web.primaryAxisSizingMode = "AUTO";
    web.counterAxisSizingMode = "FIXED";
    web.resize(360, 95);
    web.itemSpacing = 0;
    web.fills = [];
    const toolbar = await buildBrowserToolbarRow(maps);
    toolbar.layoutAlign = "STRETCH";
    web.appendChild(toolbar);
    const nav = figma.createFrame();
    nav.name = "android-nav";
    populateAndroidNav(nav, maps);
    nav.layoutAlign = "STRETCH";
    web.appendChild(nav);
    const appKeyboard = figma.createComponent();
    appKeyboard.name = "Platform=App + Keyboard";
    appKeyboard.layoutMode = "VERTICAL";
    appKeyboard.primaryAxisSizingMode = "FIXED";
    appKeyboard.counterAxisSizingMode = "FIXED";
    appKeyboard.resize(360, 341);
    appKeyboard.itemSpacing = 0;
    appKeyboard.fills = [];
    const appKeyboardSurface = await buildKeyboardFrame(maps);
    appKeyboardSurface.layoutAlign = "STRETCH";
    appKeyboard.appendChild(appKeyboardSurface);
    const appKeyboardNav = figma.createFrame();
    appKeyboardNav.name = "android-nav";
    populateAndroidNav(appKeyboardNav, maps);
    appKeyboardNav.layoutAlign = "STRETCH";
    appKeyboard.appendChild(appKeyboardNav);
    const webKeyboard = figma.createComponent();
    webKeyboard.name = "Platform=Web + Keyboard";
    webKeyboard.layoutMode = "VERTICAL";
    webKeyboard.primaryAxisSizingMode = "FIXED";
    webKeyboard.counterAxisSizingMode = "FIXED";
    webKeyboard.resize(360, 391);
    webKeyboard.itemSpacing = 0;
    webKeyboard.fills = [];
    const webKeyboardSurface = await buildKeyboardFrame(maps);
    webKeyboardSurface.layoutAlign = "STRETCH";
    webKeyboard.appendChild(webKeyboardSurface);
    const webKeyboardToolbar = await buildBrowserToolbarRow(maps);
    webKeyboardToolbar.layoutAlign = "STRETCH";
    webKeyboard.appendChild(webKeyboardToolbar);
    const webKeyboardNav = figma.createFrame();
    webKeyboardNav.name = "android-nav";
    populateAndroidNav(webKeyboardNav, maps);
    webKeyboardNav.layoutAlign = "STRETCH";
    webKeyboard.appendChild(webKeyboardNav);
    const set = figma.combineAsVariants([app, web, appKeyboard, webKeyboard], figma.currentPage);
    set.name = "NavBar";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "NavBar",
      colHeaders: ["App", "Web"],
      rowLabels: ["Default", "Keyboard"],
      cellAt: (r, c) => r === 0 ? c === 0 ? app : web : c === 0 ? appKeyboard : webKeyboard,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 400,
      cellH: 400,
      rowLabelW: 56,
      leftAlignCells: true
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var KEYBOARD_TOOL_SVG = (() => {
    const s = (body) => `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
    const p = (d) => `<path d="${d}" stroke="#757575" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>`;
    return {
      emoji: s(`<circle cx="12" cy="12" r="8" stroke="#757575" stroke-width="1.7"/><circle cx="9" cy="10" r="1" fill="#757575"/><circle cx="15" cy="10" r="1" fill="#757575"/>${p("M8.5 14C9.4 15.3 10.6 16 12 16C13.4 16 14.6 15.3 15.5 14")}`),
      mic: s(p("M9 6C9 4.34 10.34 3 12 3C13.66 3 15 4.34 15 6V11C15 12.66 13.66 14 12 14C10.34 14 9 12.66 9 11V6Z") + p("M6.5 10.5V11C6.5 14.04 8.96 16.5 12 16.5C15.04 16.5 17.5 14.04 17.5 11V10.5") + p("M12 16.5V20") + p("M9 20H15")),
      settings: s(`<circle cx="12" cy="12" r="3" stroke="#757575" stroke-width="1.7"/>${p("M12 3V5M12 19V21M3 12H5M19 12H21M5.64 5.64L7.05 7.05M16.95 16.95L18.36 18.36M18.36 5.64L16.95 7.05M7.05 16.95L5.64 18.36")}`),
      search: s(`<circle cx="10.5" cy="10.5" r="6.5" stroke="#757575" stroke-width="1.7"/>${p("M15.5 15.5L20 20")}`),
      translate: s(p("M4 5H13M8.5 3V5M6 8C7 10.5 9 12.5 12 14M11.5 8C10 12 7.5 15 4 17") + p("M14 19L17.5 10L21 19M15.2 16H19.8")),
      more: s(`<circle cx="6" cy="12" r="1.3" fill="#757575"/><circle cx="12" cy="12" r="1.3" fill="#757575"/><circle cx="18" cy="12" r="1.3" fill="#757575"/>`),
      shift: s(p("M5 12L12 5L19 12H15.5V19H8.5V12H5Z")),
      backspace: s(p("M9 7H20V17H9L4 12L9 7Z") + p("M12 10L16 14M16 10L12 14")),
      enter: s(p("M19 6V14H8") + p("M11 10L7 14L11 18"))
    };
  })();
  function keyboardToolIcon(svg, maps, name) {
    const icon = makeBoundIcon(svg, scv(maps, "color/icon/gray"));
    icon.name = name;
    try {
      icon.resize(24, 24);
    } catch (e) {
    }
    return icon;
  }
  async function buildKeyboardFrame(maps) {
    const keyboard = figma.createFrame();
    keyboard.name = "keyboard";
    keyboard.resize(360, 296);
    keyboard.layoutMode = "NONE";
    keyboard.fills = [boundPaint(scv(maps, "color/bg/level-1"))];
    const toolbar = figma.createFrame();
    toolbar.name = "toolbar";
    toolbar.resize(360, 42);
    toolbar.x = 0;
    toolbar.y = 0;
    toolbar.layoutMode = "HORIZONTAL";
    toolbar.primaryAxisSizingMode = "FIXED";
    toolbar.counterAxisSizingMode = "FIXED";
    toolbar.primaryAxisAlignItems = "SPACE_BETWEEN";
    toolbar.counterAxisAlignItems = "CENTER";
    toolbar.paddingLeft = 18;
    toolbar.paddingRight = 10;
    toolbar.fills = [];
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.emoji, maps, "emoji"));
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.mic, maps, "microphone"));
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.settings, maps, "settings"));
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.search, maps, "search"));
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.translate, maps, "translate"));
    toolbar.appendChild(keyboardToolIcon(KEYBOARD_TOOL_SVG.more, maps, "more"));
    keyboard.appendChild(toolbar);
    const makeKey = async (label, width, kind = "letter", iconSvg) => {
      const key = figma.createFrame();
      key.name = label || "space";
      key.layoutMode = "HORIZONTAL";
      key.primaryAxisSizingMode = "FIXED";
      key.counterAxisSizingMode = "FIXED";
      key.resize(width, 38);
      key.primaryAxisAlignItems = "CENTER";
      key.counterAxisAlignItems = "CENTER";
      bindRadius(key, maps, "radius/4");
      key.fills = [boundPaint(scv(maps, kind === "letter" ? "color/bg/level-0" : "color/bg/level-2"))];
      if (kind === "letter") {
        key.strokes = [boundPaint(scv(maps, "color/bg/level-2"))];
        key.strokeWeight = 1;
        key.strokeAlign = "INSIDE";
      } else key.strokes = [];
      if (iconSvg) key.appendChild(keyboardToolIcon(iconSvg, maps, label));
      else if (label) key.appendChild(await makeBoundText(label, label.length > 2 ? 14 : 18, "Medium", scv(maps, "color/text/body/primary")));
      return key;
    };
    const makeRow = (name, y, gap) => {
      const row = figma.createFrame();
      row.name = name;
      row.resize(346, 38);
      row.x = 7;
      row.y = y;
      row.layoutMode = "HORIZONTAL";
      row.primaryAxisSizingMode = "FIXED";
      row.counterAxisSizingMode = "FIXED";
      row.primaryAxisAlignItems = "CENTER";
      row.counterAxisAlignItems = "CENTER";
      row.itemSpacing = gap;
      row.fills = [];
      keyboard.appendChild(row);
      return row;
    };
    const appendLabels = async (row, labels, width) => {
      for (const label of labels) row.appendChild(await makeKey(label, width));
    };
    const numbers = makeRow("number-row", 47, 6);
    await appendLabels(numbers, ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"], 29);
    const qwerty = makeRow("qwerty-row", 95, 6);
    await appendLabels(qwerty, ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"], 29);
    const home = makeRow("home-row", 143, 6);
    await appendLabels(home, ["a", "s", "d", "f", "g", "h", "j", "k", "l"], 29);
    const shift = makeRow("shift-row", 191, 6);
    shift.appendChild(await makeKey("shift", 44, "function", KEYBOARD_TOOL_SVG.shift));
    await appendLabels(shift, ["z", "x", "c", "v", "b", "n", "m"], 29);
    shift.appendChild(await makeKey("backspace", 44, "function", KEYBOARD_TOOL_SVG.backspace));
    const bottom = makeRow("bottom-row", 239, 5);
    bottom.appendChild(await makeKey("!#1", 44, "function"));
    bottom.appendChild(await makeKey("\uD55C/\uC601", 48, "function"));
    bottom.appendChild(await makeKey(",", 30));
    bottom.appendChild(await makeKey("", 119));
    bottom.appendChild(await makeKey(".", 30));
    bottom.appendChild(await makeKey("enter", 50, "function", KEYBOARD_TOOL_SVG.enter));
    return keyboard;
  }
  async function buildLoginGNB(maps, originY) {
    const W = 1920, H = 56;
    const comp = figma.createComponent();
    comp.name = "LoginGNB";
    comp.layoutMode = "HORIZONTAL";
    comp.primaryAxisSizingMode = "FIXED";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(W, H);
    comp.primaryAxisAlignItems = "SPACE_BETWEEN";
    comp.counterAxisAlignItems = "CENTER";
    comp.paddingLeft = 320;
    comp.paddingRight = 320;
    comp.paddingTop = 12;
    comp.paddingBottom = 12;
    comp.fills = [boundPaint(scv(maps, "color/navigation/bg"))];
    comp.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    comp.strokeAlign = "INSIDE";
    comp.strokeTopWeight = 0;
    comp.strokeRightWeight = 0;
    comp.strokeLeftWeight = 0;
    comp.strokeBottomWeight = 1;
    const left = figma.createFrame();
    left.name = "service-group";
    left.layoutMode = "HORIZONTAL";
    left.primaryAxisSizingMode = "AUTO";
    left.counterAxisSizingMode = "AUTO";
    left.counterAxisAlignItems = "CENTER";
    left.itemSpacing = 11;
    left.fills = [];
    comp.appendChild(left);
    left.layoutSizingHorizontal = "HUG";
    left.layoutSizingVertical = "HUG";
    const svcText = await makeBoundText("[\uC11C\uBE44\uC2A4\uBA85]", 16, "Bold", scv(maps, "color/text/title/primary"));
    svcText.name = "service-name";
    left.appendChild(svcText);
    const right = figma.createFrame();
    right.name = "language-group";
    right.layoutMode = "HORIZONTAL";
    right.primaryAxisSizingMode = "AUTO";
    right.counterAxisSizingMode = "AUTO";
    right.counterAxisAlignItems = "CENTER";
    right.itemSpacing = 8;
    right.fills = [];
    comp.appendChild(right);
    right.layoutSizingHorizontal = "HUG";
    right.layoutSizingVertical = "HUG";
    const globeIcon = await makeIconInstance("globe", scv(maps, "color/icon/gray-dark"), 24, GNB_UTIL_SVGS.lang);
    globeIcon.name = "globe-icon";
    right.appendChild(globeIcon);
    const langText = await makeBoundText("\uD55C\uAD6D\uC5B4", 14, "Medium", scv(maps, "color/icon/gray-dark"));
    langText.name = "language-label";
    right.appendChild(langText);
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "LoginGNB";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "LoginGNB",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH: H + 24,
      rowLabelW: 0
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildWebTabBar(maps, originY) {
    const W = 1920, H = 101;
    const comp = figma.createComponent();
    comp.name = "WebTabBar";
    comp.layoutMode = "VERTICAL";
    comp.primaryAxisSizingMode = "FIXED";
    comp.counterAxisSizingMode = "FIXED";
    comp.resize(W, H);
    comp.itemSpacing = 0;
    comp.paddingTop = 0;
    comp.paddingBottom = 0;
    comp.paddingLeft = 0;
    comp.paddingRight = 0;
    comp.fills = [boundPaint(scv(maps, "color/scroll/bg"))];
    comp.strokes = [boundPaint(scv(maps, "color/line/gray/subtle"))];
    comp.strokeAlign = "INSIDE";
    comp.strokeTopWeight = 0;
    comp.strokeRightWeight = 0;
    comp.strokeLeftWeight = 0;
    comp.strokeBottomWeight = 1;
    const tabRow = figma.createFrame();
    tabRow.name = "tab-row";
    tabRow.layoutMode = "HORIZONTAL";
    tabRow.primaryAxisSizingMode = "FIXED";
    tabRow.counterAxisSizingMode = "FIXED";
    tabRow.resize(W, 38);
    tabRow.primaryAxisAlignItems = "MIN";
    tabRow.counterAxisAlignItems = "MAX";
    tabRow.paddingLeft = 8;
    tabRow.paddingRight = 8;
    tabRow.itemSpacing = 2;
    tabRow.fills = [];
    comp.appendChild(tabRow);
    tabRow.layoutSizingHorizontal = "FILL";
    tabRow.layoutSizingVertical = "FIXED";
    const activeTab = figma.createFrame();
    activeTab.name = "tab-active";
    activeTab.layoutMode = "HORIZONTAL";
    activeTab.primaryAxisSizingMode = "FIXED";
    activeTab.counterAxisSizingMode = "FIXED";
    activeTab.resize(200, 32);
    activeTab.primaryAxisAlignItems = "MIN";
    activeTab.counterAxisAlignItems = "CENTER";
    activeTab.paddingLeft = 10;
    activeTab.paddingRight = 6;
    activeTab.itemSpacing = 6;
    activeTab.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    try {
      activeTab.topLeftRadius = 6;
      activeTab.topRightRadius = 6;
      activeTab.bottomLeftRadius = 0;
      activeTab.bottomRightRadius = 0;
    } catch (e) {
    }
    tabRow.appendChild(activeTab);
    const favicon = figma.createRectangle();
    favicon.name = "favicon";
    favicon.resize(16, 16);
    favicon.cornerRadius = 3;
    favicon.fills = [boundPaint(scv(maps, "color/icon/blue"))];
    activeTab.appendChild(favicon);
    const tabTitle = await makeBoundText("[\uC11C\uBE44\uC2A4\uBA85]", 13, "Regular", scv(maps, "color/text/body/secondary"));
    tabTitle.name = "tab-title";
    activeTab.appendChild(tabTitle);
    const tabClose = await makeIconInstance("remove", scv(maps, "color/icon/gray"), 16, REMOVE_ICON_SVG);
    tabClose.name = "tab-close";
    activeTab.appendChild(tabClose);
    const spacer2 = figma.createFrame();
    spacer2.name = "spacer";
    spacer2.fills = [];
    spacer2.resize(1, 32);
    tabRow.appendChild(spacer2);
    spacer2.layoutSizingHorizontal = "FILL";
    spacer2.layoutSizingVertical = "FIXED";
    const winCtrl = figma.createFrame();
    winCtrl.name = "window-controls";
    winCtrl.layoutMode = "HORIZONTAL";
    winCtrl.primaryAxisSizingMode = "AUTO";
    winCtrl.counterAxisSizingMode = "FIXED";
    winCtrl.resize(96, 38);
    winCtrl.itemSpacing = 20;
    winCtrl.counterAxisAlignItems = "CENTER";
    winCtrl.paddingLeft = 8;
    winCtrl.paddingRight = 8;
    winCtrl.fills = [];
    tabRow.appendChild(winCtrl);
    winCtrl.layoutSizingHorizontal = "HUG";
    winCtrl.layoutSizingVertical = "FILL";
    const winGlyphs = [
      { name: "minimize", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 6.5H10" stroke="#757575" stroke-width="1.2" stroke-linecap="round"/></svg>` },
      { name: "maximize", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2.6" y="2.6" width="6.8" height="6.8" rx="0.6" stroke="#757575" stroke-width="1.2"/></svg>` },
      { name: "close", svg: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 3L9 9M9 3L3 9" stroke="#757575" stroke-width="1.2" stroke-linecap="round"/></svg>` }
    ];
    for (const g of winGlyphs) {
      const ic = makeBoundIcon(g.svg, scv(maps, "color/icon/gray"));
      ic.name = g.name;
      try {
        ic.resize(12, 12);
      } catch (e) {
      }
      winCtrl.appendChild(ic);
    }
    const addrRow = figma.createFrame();
    addrRow.name = "address-row";
    addrRow.layoutMode = "HORIZONTAL";
    addrRow.primaryAxisSizingMode = "FIXED";
    addrRow.counterAxisSizingMode = "FIXED";
    addrRow.resize(W, 63);
    addrRow.primaryAxisAlignItems = "MIN";
    addrRow.counterAxisAlignItems = "CENTER";
    addrRow.paddingLeft = 16;
    addrRow.paddingRight = 16;
    addrRow.itemSpacing = 8;
    addrRow.fills = [boundPaint(scv(maps, "color/bg/level-0"))];
    comp.appendChild(addrRow);
    addrRow.layoutSizingHorizontal = "FILL";
    addrRow.layoutSizingVertical = "FIXED";
    addrRow.appendChild(navIcon(NAV_SVG.chevronLeft, maps));
    addrRow.appendChild(navIcon(NAV_SVG.chevronRight, maps));
    const refreshNode = makeBoundIcon(SHELL_REFRESH_SVG, scv(maps, "color/icon/gray"));
    refreshNode.name = "nav-refresh";
    try {
      refreshNode.resize(24, 24);
    } catch (e) {
    }
    addrRow.appendChild(refreshNode);
    const pill = figma.createFrame();
    pill.name = "address-pill";
    pill.layoutMode = "HORIZONTAL";
    pill.primaryAxisSizingMode = "FIXED";
    pill.counterAxisSizingMode = "FIXED";
    pill.resize(400, 27);
    pill.cornerRadius = 20;
    pill.paddingLeft = 16;
    pill.paddingRight = 16;
    pill.primaryAxisAlignItems = "MIN";
    pill.counterAxisAlignItems = "CENTER";
    pill.fills = [boundPaint(scv(maps, "color/bg/level-3"))];
    addrRow.appendChild(pill);
    pill.layoutSizingHorizontal = "FILL";
    pill.layoutSizingVertical = "FIXED";
    const urlText = await makeBoundText("https://", 13, "Regular", scv(maps, "color/text/body/secondary"));
    urlText.name = "url-text";
    pill.appendChild(urlText);
    setLightMode(comp, maps);
    const set = figma.combineAsVariants([comp], figma.currentPage);
    set.name = "WebTabBar";
    set.x = 0;
    set.y = originY;
    const opts = {
      title: "WebTabBar",
      colHeaders: [""],
      rowLabels: [""],
      cellAt: () => comp,
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: W + 40,
      cellH: H + 24,
      rowLabelW: 0
    };
    const lightBottomY = await decorateSetFlat(set, opts, maps);
    opts.darkOffset = { x: 0, y: lightBottomY + 80 };
    let bottomY = lightBottomY;
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildCI(maps, originY) {
    const S1_COLORS = [
      { color: "White", v: scv(maps, "color/icon/white") },
      { color: "Blue", v: requireVar(maps.foundationColor, "brand/ci", "Foundation Color") },
      { color: "Dark", v: scv(maps, "color/icon/gray") }
    ];
    const SAM_HASHES = [
      { color: "White", hash: "5ef070ce43a101a072964c656c0e666fe81e4f78" },
      { color: "Blue", hash: "8de26dc1976bd0a64ea5b7207b6bf6d9e0396053" },
      { color: "Dark", hash: "100a4d3fdd0a5a9304c8251792f2d96089ac458a" }
    ];
    const CI_COL = 158, CI_ROW = 60;
    const S1_CI_W = 78.75, S1_CI_H = 30;
    const S1_CI_SVG = S1_LOGO_SVG.replace('width="42" height="16"', `width="${S1_CI_W}" height="${S1_CI_H}"`);
    if (S1_CI_SVG === S1_LOGO_SVG) throw new Error("buildCI: S1_LOGO_SVG \uC758 width/height \uCE58\uD658 \uC2E4\uD328 \u2014 svg \uC18D\uC131 \uD45C\uAE30 \uBCC0\uACBD \uD655\uC778 \uD544\uC694");
    const s1Comps = [];
    S1_COLORS.forEach(({ color, v }, i) => {
      const comp = figma.createComponent();
      comp.name = `Brand=\uC5D0\uC2A4\uC6D0, Color=${color}`;
      comp.resize(S1_CI_W, S1_CI_H);
      comp.fills = [];
      comp.x = i * CI_COL;
      comp.y = 0;
      const logo = figma.createNodeFromSvg(S1_CI_SVG);
      logo.name = "logo";
      rebindIconColor(logo, v);
      comp.appendChild(logo);
      setLightMode(comp, maps);
      s1Comps.push(comp);
    });
    const samComps = [];
    SAM_HASHES.forEach(({ color, hash }, i) => {
      const comp = figma.createComponent();
      comp.name = `Brand=\uC0BC\uC131, Color=${color}`;
      comp.resize(134, 36);
      comp.fills = [];
      comp.x = i * CI_COL;
      comp.y = CI_ROW;
      const rect = figma.createRectangle();
      rect.name = `Samsung_Orig_Wordmark_${color.toUpperCase()}_RGB`;
      rect.resize(134, 36);
      rect.fills = [{ type: "IMAGE", scaleMode: "FILL", imageHash: hash }];
      comp.appendChild(rect);
      setLightMode(comp, maps);
      samComps.push(comp);
    });
    const set = figma.combineAsVariants([...s1Comps, ...samComps], figma.currentPage);
    set.name = "CI";
    set.x = 0;
    set.y = originY;
    try {
      set.fills = [boundPaint(requireVar(maps.foundationColor, "gray/50", "Foundation Color"))];
    } catch (e) {
    }
    setLightMode(set, maps);
    const sh = typeof set.height === "number" && set.height > 0 ? set.height : 84;
    return { set, bottomY: originY + sh };
  }
  async function buildMultiToggleElement(maps, originY) {
    const positions = ["first", "middle-left", "middle-right", "last"];
    const states = ["default", "hover", "selected", "disabled"];
    const sizes = [
      { id: "md", h: 44, padX: 12, font: 14, minW: 64 },
      // 최소 width = sizing/64 (사용자 결정 2026-06-26)
      { id: "sm", h: 34, padX: 8, font: 14, minW: 56 }
      // 최소 width = sizing/56
    ];
    const colorSlot = (st) => {
      switch (st) {
        case "default":
          return { bg: "color/button/bg/secondary--default", border: "color/button/border/secondary--default", text: "color/button/label/secondary--default" };
        case "hover":
          return { bg: "color/button/bg/secondary--hover", border: "color/button/border/secondary--hover", text: "color/button/label/secondary--hover" };
        case "selected":
          return { bg: "color/button/bg/primary--default", border: "color/button/border/primary--default", text: "color/button/label/primary--default" };
        case "disabled":
          return { bg: "color/button/bg/disabled", border: "color/button/border/disabled", text: "color/button/label/disabled" };
      }
    };
    const cornerConfig = (pos) => {
      switch (pos) {
        case "first":
          return { tl: 4, tr: 0, bl: 4, br: 0 };
        case "last":
          return { tl: 0, tr: 4, bl: 0, br: 4 };
        case "middle-left":
          return { tl: 0, tr: 0, bl: 0, br: 0 };
        case "middle-right":
          return { tl: 0, tr: 0, bl: 0, br: 0 };
      }
    };
    const strokeSides = (pos) => {
      switch (pos) {
        case "first":
          return { t: 1, r: 0, b: 1, l: 1 };
        case "middle-left":
          return { t: 1, r: 0, b: 1, l: 1 };
        case "middle-right":
          return { t: 1, r: 1, b: 1, l: 0 };
        case "last":
          return { t: 1, r: 1, b: 1, l: 0 };
      }
    };
    const comps = [];
    const cells = [];
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      const sz = sizes[szIdx];
      for (let posIdx = 0; posIdx < positions.length; posIdx++) {
        const pos = positions[posIdx];
        const cor = cornerConfig(pos);
        const sides = strokeSides(pos);
        for (let stIdx = 0; stIdx < states.length; stIdx++) {
          const st = states[stIdx];
          const slot = colorSlot(st);
          const comp = figma.createComponent();
          comp.name = `position=${pos}, state=${st}, size=${sz.id}`;
          comp.layoutMode = "HORIZONTAL";
          comp.primaryAxisAlignItems = "CENTER";
          comp.counterAxisAlignItems = "CENTER";
          comp.primaryAxisSizingMode = "AUTO";
          comp.counterAxisSizingMode = "FIXED";
          comp.paddingLeft = sz.padX;
          comp.paddingRight = sz.padX;
          comp.fills = [boundPaint(scv(maps, slot.bg))];
          comp.strokes = [boundPaint(scv(maps, slot.border))];
          comp.strokeAlign = "INSIDE";
          comp.strokeWeight = 1;
          try {
            comp.strokeTopWeight = sides.t;
            comp.strokeRightWeight = sides.r;
            comp.strokeBottomWeight = sides.b;
            comp.strokeLeftWeight = sides.l;
          } catch (e) {
          }
          comp.topLeftRadius = cor.tl;
          comp.topRightRadius = cor.tr;
          comp.bottomLeftRadius = cor.bl;
          comp.bottomRightRadius = cor.br;
          const txt = await makeBoundText("\uD56D\uBAA9", sz.font, "Medium", scv(maps, slot.text));
          txt.textAlignHorizontal = "CENTER";
          comp.appendChild(txt);
          try {
            txt.layoutGrow = 1;
          } catch (e) {
          }
          comp.resize(comp.width, sz.h);
          try {
            comp.minWidth = sz.minW;
          } catch (e) {
          }
          setLightMode(comp, maps);
          comps.push(comp);
          cells.push({ comp, posIdx, stIdx, szIdx });
          BUILT_COMPS[`MultiToggle:${pos}/${st}/${sz.id}`] = comp;
        }
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Multi Toggle Element";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Multi Toggle Element"] = set;
    const ROW_DEFS = [];
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      for (let posIdx = 0; posIdx < positions.length; posIdx++) {
        ROW_DEFS.push({ pos: positions[posIdx], szId: sizes[szIdx].id, szIdx, posIdx });
      }
    }
    const STATE_LABELS = ["Default", "Hover", "Selected", "Disabled"];
    const opts = {
      title: "Multi Toggle Element",
      colHeaders: STATE_LABELS,
      rowLabels: ROW_DEFS.map((r) => `${r.pos} / ${r.szId}`),
      cellAt: (r, c) => {
        var _a, _b;
        const rd = ROW_DEFS[r];
        return (_b = (_a = cells.find((x) => x.posIdx === rd.posIdx && x.szIdx === rd.szIdx && x.stIdx === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 120,
      cellH: 52,
      rowLabelW: 160
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  async function buildMultiToggle(maps, originY) {
    const sizes = ["md", "sm"];
    const selections = ["Left", "Center", "Right"];
    const cellSpec = (j, selectedIdx) => {
      if (j < selectedIdx) {
        return { pos: j === 0 ? "first" : "middle-left", st: "default" };
      } else if (j === selectedIdx) {
        const pos = j === 0 ? "first" : j === 2 ? "last" : "middle-left";
        return { pos, st: "selected" };
      } else {
        return { pos: j === 2 ? "last" : "middle-right", st: "default" };
      }
    };
    const pickCell = async (pos, st, sz) => {
      const key = `MultiToggle:${pos}/${st}/${sz}`;
      let c = BUILT_COMPS[key];
      if (!c) {
        const s = await getBuiltSet("Multi Toggle Element");
        if (s) c = (s.children || []).find((x) => x.type === "COMPONENT" && x.name === `position=${pos}, state=${st}, size=${sz}`);
      }
      return c;
    };
    const comps = [];
    const specCells = [];
    const mtElementSet = await getBuiltSet("Multi Toggle Element");
    for (let szIdx = 0; szIdx < sizes.length; szIdx++) {
      const sz = sizes[szIdx];
      for (let selIdx = 0; selIdx < selections.length; selIdx++) {
        const selLabel = selections[selIdx];
        const comp = figma.createComponent();
        comp.name = `Size=${sz}, Selected=${selLabel}`;
        comp.layoutMode = "HORIZONTAL";
        comp.primaryAxisAlignItems = "CENTER";
        comp.counterAxisAlignItems = "CENTER";
        comp.primaryAxisSizingMode = "AUTO";
        comp.counterAxisSizingMode = "AUTO";
        comp.itemSpacing = 0;
        comp.fills = [];
        const cellInsts = [];
        for (let j = 0; j < 3; j++) {
          const { pos, st } = cellSpec(j, selIdx);
          const cellComp = await pickCell(pos, st, sz);
          if (cellComp) {
            const inst = cellComp.createInstance();
            cellInsts.push(inst);
          }
        }
        await makeSlot(
          comp,
          "Items",
          "\uD1A0\uAE00 \uCE78\uC774 \uB193\uC774\uB294 \uC790\uB9AC. \uAE30\uBCF8\uC740 3\uCE78\uC774\uBA70, Multi Toggle Element \uC778\uC2A4\uD134\uC2A4\uB97C \uB123\uACE0 \uBE7C\uC11C \uCE78 \uC218\uB97C \uB298\uB9AC\uACE0 \uC904\uC778\uB2E4. \uCE78\uC744 \uBC14\uAFBC \uB4A4\uC5D0\uB294 \uB9E8 \uC55E \uCE78\uC744 position=first, \uB9E8 \uB4A4 \uCE78\uC744 position=last \uB85C \uB9DE\uCD98\uB2E4.",
          cellInsts,
          mtElementSet ? [{ type: "COMPONENT_SET", key: mtElementSet.key }] : [],
          { itemSpacing: 0, counterAxisAlignItems: "CENTER" }
        );
        setLightMode(comp, maps);
        comps.push(comp);
        specCells.push({ comp, selIdx, szIdx });
      }
    }
    const set = figma.combineAsVariants(comps, figma.currentPage);
    set.name = "Multi Toggle";
    set.x = 0;
    set.y = originY;
    BUILT_SETS["Multi Toggle"] = set;
    const SIZE_LABELS = ["md", "sm"];
    const SEL_LABELS = ["Left", "Center", "Right"];
    const opts = {
      title: "Multi Toggle",
      colHeaders: SIZE_LABELS,
      rowLabels: SEL_LABELS,
      cellAt: (r, c) => {
        var _a, _b;
        return (_b = (_a = specCells.find((x) => x.selIdx === r && x.szIdx === c)) == null ? void 0 : _a.comp) != null ? _b : null;
      },
      lightX: SPEC_LIGHT_X,
      darkX: SPEC_DARK_X,
      originY,
      cellW: 220,
      cellH: 56,
      rowLabelW: 80
      // 셀 min-width(md 64×3) 로 넓어진 토글이 옆 컬럼과 겹치지 않게 220
    };
    let bottomY = await decorateSetFlat(set, opts, maps);
    try {
      bottomY = Math.max(bottomY, await buildSpec(opts, maps));
    } catch (e) {
      console.warn(e);
    }
    return { set, bottomY };
  }
  var COMPONENT_CATEGORIES_GRID = [
    [
      { name: "Platform", members: ["StatusBar", "NavBar", "CI", "LoginGNB", "WebTabBar", "Footer"] },
      { name: "Navigation", members: ["GNB", "GNB Sub Menu", "GNB Sub Menu Item", "GNB Utility Icon", "Language Icon", "Mobile Bottom Nav", "Mobile Header"] },
      { name: "Line Tab", members: ["Line Tab Set", "Line Tab"] },
      { name: "Pagination", members: ["Pagination", "Pagination Cell"] },
      { name: "Actions", members: ["Button", "Assist Button", "Text Button"] },
      { name: "Selection", members: ["Checkbox", "Radio", "Toggle", "Multi Toggle", "Multi Toggle Element"] },
      // Dropdown 섹션 = Form Control 에서 분리(사용자 결정 2026-06-26). Selection 아래에 세로 스택 배치(stage 2 STACKED).
      //   Form Control 보다 GRID 앞에 둬서 Select Box(Form Control)의 Dropdown 의존(BUILD_DEPENDENCIES)이 빌드순서로 충족됨.
      { name: "Dropdown", members: ["Dropdown", "Dropdown List"] },
      { name: "Chip", members: ["Chip"] },
      // List Row: 목록 한 줄. 체크·토글을 인스턴스로 붙이므로 Selection 뒤에 둔다.
      { name: "List", members: ["List Row"] },
      // members = 표시(나열) 순서: 메인 컴포넌트 → 그 안을 구성하는 요소 컴포넌트 순. 빌드(생성) 순서는
      //   BUILD_DEPENDENCIES 로 의존성(요소 먼저)이 자동 적용된다 — 표시순서 ≠ 빌드순서 규칙(§ 아래 주석).
      { name: "Form Control", members: ["Input", "Search Input", "Text Area", "Select Box"] },
      { name: "Date Picker", members: ["Date Picker", "Calendar", "Calendar Cell", "Calendar Tile", "Calendar Nav Arrow", "Date Picker Mobile Bottom Sheet"] },
      { name: "Time Picker", members: ["Time Picker", "Time Picker Dropdown", "Time Picker Cell", "Time Picker Mobile Bottom Sheet"] },
      { name: "Table", members: ["Table", "Table Cell"] },
      // Bottom Sheet: 메인 컨테이너(Bottom Sheet) → 요소(Bottom Sheet Option) 표시순서.
      //   빌드는 BUILD_DEPENDENCIES 로 요소(Option)·Checkbox·Radio·Button 이 먼저(카테고리를 Selection·Actions 뒤에 둠).
      { name: "Bottom Sheet", members: ["Bottom Sheet", "Bottom Sheet Option"] },
      // Modal(overlay): 공통 팝업 셸. 코어 Button(Actions, 앞 카테고리)을 인스턴스로 부착 → 카테고리 순서로 선빌드 보장.
      { name: "Modal", members: ["Modal", "Modal Content"] }
    ],
    // Filter Chip은 별도로 (Chip 아래에 배치될 예정)
    [
      { name: "Filter Chip", members: ["Filter Chip"] }
    ]
  ];
  var COMPONENT_CATEGORIES = COMPONENT_CATEGORIES_GRID.reduce((a, r) => a.concat(r), []);
  var BUILD_DEPENDENCIES = {
    "Select Box": ["Dropdown"],
    // Open 상태가 Dropdown 패널 인스턴스 부착
    "Dropdown": ["Dropdown List"],
    // Dropdown 패널이 Dropdown List 옵션 인스턴스 4행 부착
    // Dropdown List 의 체크박스 유형(Type=Checkbox·Checkbox+All)이 Checkbox 인스턴스 부착(2026-08-14).
    //   ⚠️ 이 선언은 **순서를 보장하지 않는다** — buildOrderFor 는 같은 카테고리 안(inCat) 의존만 정렬하고
    //   Checkbox(Selection) ↔ Dropdown List(Dropdown) 는 카테고리가 다르다. 신규 전체 설치는 카테고리
    //   순서(Selection 이 앞)로 충족되고, **재설치(세트 skip)** 는 buildDropdownList 의 reuseVariant 가
    //   캔버스의 기존 Checkbox 를 재등록해 해결한다. 이 줄은 의존 관계를 문서/열화보고에 남기는 용도다.
    "Dropdown List": ["Checkbox"],
    "List Row": ["Checkbox", "Toggle"],
    // Pick·Agree 가 Checkbox, Switch 가 Toggle 인스턴스 부착(타 카테고리=카테고리 순서로 보장)
    "Filter Chip": ["Dropdown"],
    // Selected 상태가 Dropdown 패널 인스턴스 부착(타 카테고리=순서 보장)
    "Time Picker": ["Time Picker Dropdown"],
    // Focus 상태가 Time Picker Dropdown 인스턴스 부착
    "GNB": ["GNB Utility Icon"],
    // GNB 바 유틸 영역이 GNB Utility Icon all-on 인스턴스 부착
    "GNB Utility Icon": ["Language Icon"],
    // language=on 변형이 Language Icon 인스턴스 부착
    "Mobile Header": ["StatusBar"],
    // 하위메뉴 패널이 항목 세트의 변형을 인스턴스로 붙인다 → 항목이 먼저 빌드돼야 한다.
    "GNB Sub Menu": ["GNB Sub Menu Item"],
    "Pagination": ["Pagination Cell"],
    // 완성 바가 Pagination Cell(Arrow·Edge·Number) 인스턴스 조합
    "Multi Toggle": ["Multi Toggle Element"],
    // 조합형태가 Multi Toggle Element 셀 인스턴스 사용 → 요소 먼저 빌드
    "Date Picker": ["Calendar"],
    // Open 상태가 Calendar 패널 인스턴스 부착(BUILT_COMPS["Calendar:Date"])
    "Calendar": ["Calendar Nav Arrow"],
    // 헤더 이전/다음 화살표가 Calendar Nav Arrow 인스턴스 부착(river 결정 2026-09-15)
    // 모바일 바텀시트: Calendar:Date 인스턴스(본문) + Button primary(하단 "적용") 부착 → 둘 다 선빌드 필요.
    "Date Picker Mobile Bottom Sheet": ["Calendar", "Button"],
    // 시간 휠 바텀시트: 하단 "적용" Button + (DateTime 변형) 날짜·시간 Line Tab 인스턴스 부착 → 둘 다 선빌드.
    //   Button(Actions)·Line Tab(Line Tab 카테고리) 은 Time Picker 보다 그리드 앞이라 카테고리 순서로도 보장되나 명시.
    "Time Picker Mobile Bottom Sheet": ["Button", "Line Tab"],
    "Line Tab Set": ["Line Tab"],
    // 탭 3개 묶음 세트가 Line Tab 셀 인스턴스 조합
    // Table 푸터가 완성 Pagination 바(BUILT_COMPS["Pagination:Bar/Middle"]) 인스턴스 부착.
    //   (타 카테고리 의존 = 카테고리 순서로 보장: Pagination 카테고리가 Table 보다 먼저라 선빌드됨.)
    //   Table 본문 칸은 Table Cell 인스턴스 재사용 — 2026-08-02 이전엔 이 의존이 없어 Table(39번째)이
    //   Table Cell(40번째)보다 먼저 빌드됐고, makeTableRow 의 조회가 매번 빈손이라 **72칸 전부 fallback
    //   plain frame**(인스턴스 0)이었다. 즉 셀 컴포넌트를 고쳐도 표에 반영되지 않았다.
    //   🤖 component-verifier 실측으로 원인·해법 확인 후 편입(인스턴스 36/36 · MD→MD·SM→SM 정확 매칭).
    "Table": ["Pagination", "Table Cell"],
    // Bottom Sheet 컨테이너 = Bottom Sheet Option(Text) 리스트 + Button 인스턴스 부착 → 둘 다 선빌드.
    //   Option 은 같은 카테고리(요소 먼저), Button 은 Actions 카테고리(그리드 순서로 선빌드).
    "Bottom Sheet": ["Bottom Sheet Option", "Button"],
    "Modal": ["Button"],
    "Modal Content": ["Button"],
    // 푸터가 코어 Button(XXSM h28) 인스턴스 부착 → Button 선빌드
    // Bottom Sheet Option 의 Checkbox/Radio 행 = Checkbox·Radio 컴포넌트 인스턴스 부착(Selection 카테고리 선빌드).
    "Bottom Sheet Option": ["Checkbox", "Radio"]
  };
  var ATTACH_DEPENDENCIES = {
    // buildTable 이 실제로 붙이는 것들(BUILT_COMPS 조회 기준).
    //   "Table Cell" 은 2026-08-02 에 **편입**했다. 그 전까지는 빌드 순서가 Table→Table Cell 이라
    //   실측 부착 0건이었고(fallback plain frame), 선언하면 거짓 경보가 되므로 일부러 빼 뒀었다.
    //   이제 BUILD_DEPENDENCIES 에 Table→Table Cell 이 있어 실제로 36/36 부착되므로, 셀이 실패하면
    //   Table 이 정말 껍데기가 된다 → 열화 보고 대상이 맞다.
    "Table": ["Pagination", "Checkbox", "Select Box", "Table Cell"],
    "Mobile Header": ["StatusBar"],
    "Calendar": ["Calendar Cell", "Calendar Tile", "Calendar Nav Arrow"]
  };
  var BUILT_BY_PARENT = {
    // buildTimePickerDropdown 이 buildTimePickerCell 을 호출해 셀 세트까지 생성(build-components.ts:2817).
    "Time Picker Cell": "Time Picker Dropdown"
  };
  function buildOrderFor(members) {
    const inCat = new Set(members);
    const visited = /* @__PURE__ */ new Set();
    const out = [];
    const visit = (m) => {
      if (visited.has(m)) return;
      visited.add(m);
      for (const dep of BUILD_DEPENDENCIES[m] || []) {
        if (inCat.has(dep)) visit(dep);
      }
      out.push(m);
    };
    for (const m of members) visit(m);
    return out;
  }
  async function buildAllComponents(maps, onProgress, shouldCancel) {
    for (const key of Object.keys(BUILT_SETS)) delete BUILT_SETS[key];
    for (const key of Object.keys(BUILT_COMPS)) delete BUILT_COMPS[key];
    TEXT_STYLES2 = maps.textStyles || {};
    SPEC_MAPS = maps;
    const page = figma.currentPage;
    bindSurface("page", (paint) => {
      page.backgrounds = [paint];
    });
    if (maps.semanticLightModeNamed !== false && maps.semanticLightModeId) {
      try {
        setMode(page, maps, maps.semanticLightModeId);
      } catch (e) {
      }
    }
    const CANVAS_CONTAINERS = ["SECTION", "FRAME", "GROUP"];
    const INSTALLER_NAME_SUFFIXES = [" \u2014 Spec Light", " \u2014 Spec Dark", ` ${DECO_SUFFIX}`];
    const installerMade = (n) => {
      try {
        if (String(n.type) === "COMPONENT_SET") return true;
      } catch (e) {
      }
      let nm = "";
      try {
        nm = String(n.name);
      } catch (e) {
        return false;
      }
      for (const suffix of INSTALLER_NAME_SUFFIXES) {
        if (nm.length >= suffix.length && nm.slice(nm.length - suffix.length) === suffix) return true;
      }
      return false;
    };
    const canvasNodes = () => {
      const out = [];
      const seen = /* @__PURE__ */ new Set();
      const walk2 = (nodes, depth) => {
        for (const n of nodes) {
          let id = "";
          try {
            id = String(n.id);
          } catch (e) {
          }
          if (id) {
            if (seen.has(id)) continue;
            seen.add(id);
          }
          if (depth <= 1 || installerMade(n)) out.push(n);
          if (depth >= 6) continue;
          let t = "";
          try {
            t = String(n.type);
          } catch (e) {
            continue;
          }
          if (CANVAS_CONTAINERS.indexOf(t) < 0) continue;
          try {
            const kids = n.children;
            if (Array.isArray(kids)) walk2(kids, depth + 1);
          } catch (e) {
          }
        }
      };
      try {
        const kids = page.children;
        if (Array.isArray(kids)) walk2(kids, 0);
      } catch (e) {
      }
      return out;
    };
    const canvasNodesShallow = () => {
      const out = [];
      try {
        const kids = page.children;
        if (!Array.isArray(kids)) return out;
        for (const n of kids) {
          out.push(n);
          if (n.type !== "SECTION") continue;
          try {
            const sk = n.children;
            if (Array.isArray(sk)) for (const c of sk) out.push(c);
          } catch (e) {
          }
        }
      } catch (e) {
      }
      return out;
    };
    const sectionByName = (nm) => {
      try {
        const kids = page.children;
        if (!Array.isArray(kids)) return null;
        for (const n of kids) if (n.type === "SECTION" && n.name === nm) return n;
      } catch (e) {
      }
      return null;
    };
    let existing = /* @__PURE__ */ new Set();
    try {
      const r = page.findAll((n) => n.type === "COMPONENT_SET");
      if (Array.isArray(r)) existing = new Set(r.map((n) => n.name));
    } catch (e) {
    }
    const footprint = (p) => {
      const base = [p, `${p} \u2014 Spec Light`, `${p} \u2014 Spec Dark`];
      if (p === "Time Picker Dropdown") base.push(
        "Time Picker Cell",
        "Time Picker Cell \u2014 Spec Light",
        "Time Picker Cell \u2014 Spec Dark"
      );
      if (p === "GNB") base.push(
        "GNB Menu",
        "GNB Menu \u2014 Spec Light",
        "GNB Menu \u2014 Spec Dark"
      );
      if (p === "StatusBar") base.push("Platform/StatusBar", "Shell/StatusBar");
      if (p === "NavBar") base.push("Platform/NavBar", "Shell/NavBar");
      if (p === "LoginGNB") base.push("Platform/LoginGNB");
      if (p === "WebTabBar") base.push("Platform/WebTabBar");
      if (p === "CI") base.push("C/IMG/Logo/Samsung_30");
      if (p === "Date Picker Mobile Bottom Sheet") base.push(
        "Date Picker Mobile",
        "Date Picker Mobile \u2014 Spec Light",
        "Date Picker Mobile \u2014 Spec Dark"
      );
      return base.concat(base.map((b) => `${b} ${DECO_SUFFIX}`));
    };
    const regionBottom = (p) => {
      const names = new Set(footprint(p));
      const bb = absBBox(canvasNodes().filter((n) => names.has(n.name)));
      return bb ? bb.maxY : null;
    };
    const removeByNames = (list, keepSets) => {
      const names = new Set(list);
      const keep = new Set(keepSets || []);
      for (const n of canvasNodesShallow().filter((x) => names.has(x.name))) {
        if (n.type === "COMPONENT_SET" && keep.has(n.name)) continue;
        try {
          n.remove();
        } catch (e) {
        }
      }
    };
    let created = 0;
    const added = [];
    const skipped = [];
    const noRunner = [];
    const failed = [];
    const rawPaints = [];
    const runners = {
      "Button": (oy) => buildButtonSet(maps, onProgress, 92, 97, oy),
      "Assist Button": (oy) => buildAssistButtonSet(maps, oy),
      "Text Button": (oy) => buildTextButtonSet(maps, oy),
      "Checkbox": (oy) => buildCheckbox(maps, oy),
      "Radio": (oy) => buildRadio(maps, oy),
      "Toggle": (oy) => buildToggle(maps, oy),
      "Multi Toggle Element": (oy) => buildMultiToggleElement(maps, oy),
      "Multi Toggle": (oy) => buildMultiToggle(maps, oy),
      "Chip": (oy) => buildChip(maps, oy),
      "List Row": (oy) => buildListRow(maps, oy),
      "Filter Chip": (oy) => buildFilterChip(maps, oy),
      "Input": (oy) => buildInput(maps, oy, 0),
      "Search Input": (oy) => buildSearch(maps, oy),
      "Text Area": (oy) => buildTextarea(maps, oy),
      "Select Box": (oy) => buildSelect(maps, oy),
      "Dropdown List": (oy) => buildDropdownList(maps, oy),
      "Dropdown": (oy) => buildDropdown(maps, oy),
      "Calendar": (oy) => buildCalendar(maps, oy),
      "Calendar Nav Arrow": (oy) => buildCalendarNavArrow(maps, oy),
      "Date Picker": (oy) => buildDatePicker(maps, oy),
      "Date Picker Mobile Bottom Sheet": (oy) => buildDatePickerBottomSheet(maps, oy),
      "Bottom Sheet": (oy) => buildBottomSheet(maps, oy),
      "Bottom Sheet Option": (oy) => buildBottomSheetOption(maps, oy),
      "Modal": (oy) => buildModalShell(maps, oy),
      "Modal Content": (oy) => buildModalContent(maps, oy),
      "Calendar Cell": (oy) => buildCalendarCellLayout(maps, oy),
      "Calendar Tile": (oy) => buildCalendarTileLayout(maps, oy),
      "Time Picker": (oy) => buildTimePicker(maps, oy),
      "Time Picker Dropdown": (oy) => buildTimePickerDropdown(maps, oy),
      "Time Picker Mobile Bottom Sheet": (oy) => buildTimePickerMobileBottomSheet(maps, oy),
      "Table Cell": (oy) => buildTableCell(maps, oy),
      "Table": (oy) => buildTable(maps, oy),
      "Line Tab": (oy) => buildLineTab(maps, oy),
      "Line Tab Set": (oy) => buildLineTabSet(maps, oy),
      "GNB Utility Icon": (oy) => buildGNBUtilIcon(maps, oy),
      "Language Icon": (oy) => buildLanguageIcon(maps, oy),
      "Mobile Bottom Nav": (oy) => buildMobileBottomNav(maps, oy),
      "Mobile Header": (oy) => buildMobileHeader(maps, oy),
      "GNB": (oy) => buildGNB(maps, oy),
      "GNB Sub Menu": (oy) => buildGNBSubMenu(maps, oy),
      "GNB Sub Menu Item": (oy) => buildGNBSubMenuItem(maps, oy),
      "Pagination": (oy) => buildPaginationBar(maps, oy),
      "Pagination Cell": (oy) => buildPaginationCell(maps, oy),
      "StatusBar": (oy) => buildStatusBar(maps, oy),
      "NavBar": (oy) => buildNavBar(maps, oy),
      "LoginGNB": (oy) => buildLoginGNB(maps, oy),
      "WebTabBar": (oy) => buildWebTabBar(maps, oy),
      "CI": (oy) => buildCI(maps, oy),
      "Footer": (oy) => buildFooter(maps, oy)
    };
    const TOTAL = COMPONENT_CATEGORIES.reduce((s, c) => s + c.members.length, 0);
    const SECTION_TITLE_SPACE = 140;
    const SECTION_GAP = 220;
    const SECTION_PAD = 64;
    let y = 0;
    let done = 0;
    for (const cat of COMPONENT_CATEGORIES) {
      const catTopY = y + SECTION_TITLE_SPACE;
      let catY = catTopY;
      const ownedIds = /* @__PURE__ */ new Set();
      try {
        const oldSec = sectionByName(cat.name);
        const kids = oldSec ? oldSec.children : null;
        if (oldSec && Array.isArray(kids) && kids.length) {
          const keep = kids.map((k) => {
            const b = k.absoluteBoundingBox;
            return { k, x: b && typeof b.x === "number" ? b.x : null, y: b && typeof b.y === "number" ? b.y : null };
          });
          for (const it of keep) {
            try {
              page.appendChild(it.k);
            } catch (e) {
              continue;
            }
            const a = it.k.absoluteBoundingBox;
            if (it.x != null && it.y != null && a && typeof a.x === "number" && typeof it.k.x === "number") {
              it.k.x += it.x - a.x;
              it.k.y += it.y - a.y;
            }
          }
          const bb = absBBox(keep.map((it) => it.k));
          if (bb) {
            const dx = 0 - bb.minX, dy = catTopY - bb.minY;
            if (dx !== 0 || dy !== 0) {
              for (const it of keep) {
                try {
                  it.k.x += dx;
                  it.k.y += dy;
                } catch (e) {
                }
              }
            }
          }
          for (const it of keep) ownedIds.add(it.k.id);
        }
      } catch (e) {
      }
      for (const name of buildOrderFor(cat.members)) {
        if (shouldCancel && shouldCancel()) throw new Error("__INSTALL_CANCELLED__");
        const run = runners[name];
        if (!run) {
          if (!Object.prototype.hasOwnProperty.call(BUILT_BY_PARENT, name)) noRunner.push(name);
          continue;
        }
        done++;
        const isDepSet = name === "Calendar Cell" || name === "Calendar Tile";
        if (existing.has(name) && !isDepSet) {
          const rb = regionBottom(name);
          if (rb != null) catY = Math.max(catY, rb + 140);
          const fnames = new Set(footprint(name));
          for (const n of canvasNodes()) if (fnames.has(n.name)) ownedIds.add(n.id);
          skipped.push(name);
          continue;
        }
        if (onProgress) onProgress(`${name} \uC0DD\uC131 \uC911\u2026`, 92 + Math.round(done / TOTAL * 6));
        removeByNames(footprint(name), isDepSet ? [name] : []);
        let beforeIds = /* @__PURE__ */ new Set();
        try {
          const kids = figma.currentPage.children;
          if (Array.isArray(kids)) beforeIds = new Set(kids.map((n) => n.id));
        } catch (_) {
        }
        try {
          const res = await run(catY);
          created += res.set.children.length;
          added.push(name);
          catY = res.bottomY + 140;
          try {
            const kids = figma.currentPage.children;
            if (Array.isArray(kids)) for (const n of kids) {
              if (beforeIds.has(n.id)) continue;
              ownedIds.add(n.id);
              if (String(n.type) !== "COMPONENT_SET") continue;
              for (const spot of sweepRawPaints(n)) rawPaints.push(`${name}: ${spot}`);
            }
          } catch (_) {
          }
        } catch (e) {
          const reason = e && (e.message || String(e)) || "unknown";
          try {
            const names = new Set(footprint(name));
            const kids = figma.currentPage.children;
            if (Array.isArray(kids)) {
              for (const n of kids.filter((x) => !beforeIds.has(x.id) && names.has(x.name))) {
                try {
                  n.remove();
                } catch (_) {
                }
              }
            }
          } catch (_) {
          }
          failed.push({ name, reason });
          console.error(`[installer] "${name}" \uC0DD\uC131 \uC2E4\uD328 \u2014 \uC774\uBC88 \uC2DC\uB3C4 \uC0B0\uCD9C\uBB3C\uB9CC \uC815\uB9AC\uD558\uACE0 \uACC4\uC18D\uD569\uB2C8\uB2E4: ${reason}`);
        }
      }
      try {
        const pageKids = figma.currentPage.children;
        if (Array.isArray(pageKids)) {
          const kids = canvasNodes().filter((n) => n.type !== "SECTION" && ownedIds.has(n.id));
          const cy = (n) => {
            const b = n.absoluteBoundingBox;
            return b && typeof b.y === "number" && typeof b.height === "number" ? b.y + b.height / 2 : null;
          };
          const seeds = [];
          for (const name of cat.members) {
            const names = new Set(footprint(name));
            const sb = absBBox(kids.filter((n) => names.has(n.name)));
            if (sb) seeds.push({ name, top: sb.minY, bot: sb.maxY });
          }
          if (seeds.length) {
            const byY = [...seeds].sort((a, b) => a.top - b.top);
            const bounds = byY.map((s, i) => ({
              name: s.name,
              lo: i === 0 ? -Infinity : (byY[i - 1].bot + s.top) / 2,
              hi: i === byY.length - 1 ? Infinity : (s.bot + byY[i + 1].top) / 2
            }));
            const nodesByName = {};
            for (const bnd of bounds) {
              nodesByName[bnd.name] = kids.filter((n) => {
                const c = cy(n);
                return c !== null && c > bnd.lo && c <= bnd.hi;
              });
            }
            let layoutY = catTopY;
            for (const name of cat.members) {
              const ns = nodesByName[name];
              if (!ns || !ns.length) continue;
              const bb = absBBox(ns);
              if (!bb) continue;
              const dy = layoutY - bb.minY;
              if (dy !== 0) for (const n of ns) {
                try {
                  n.y += dy;
                } catch (e) {
                }
              }
              layoutY += bb.maxY - bb.minY + 140;
            }
            catY = layoutY;
          }
        }
      } catch (e) {
      }
      await wrapCategoryInSection(
        cat.name,
        canvasNodes().filter((n) => n.type !== "SECTION" && ownedIds.has(n.id)),
        SECTION_TITLE_SPACE,
        SECTION_PAD
      );
      y = catY + SECTION_GAP;
    }
    try {
      const findSec = (nm) => {
        const a = figma.currentPage.findAll((n) => n.type === "SECTION" && n.name === nm);
        return Array.isArray(a) && a.length ? a[0] : null;
      };
      const widthOf = (s) => {
        try {
          const b = s.absoluteBoundingBox;
          if (b && typeof b.width === "number") return b.width;
        } catch (e) {
        }
        return typeof s.width === "number" ? s.width : 0;
      };
      const heightOf = (s) => {
        try {
          const b = s.absoluteBoundingBox;
          if (b && typeof b.height === "number") return b.height;
        } catch (e) {
        }
        return typeof s.height === "number" ? s.height : 0;
      };
      const H_GAP = 120;
      const TOP_Y = 0;
      const ROW = [
        "Platform",
        "Navigation",
        "Line Tab",
        "Pagination",
        "Actions",
        "Selection",
        "Chip",
        "Form Control",
        "Date Picker",
        "Time Picker",
        "Table",
        "Modal"
      ];
      const STACKED = [
        { name: "Filter Chip", below: "Chip", placed: false },
        { name: "Dropdown", below: "Selection", placed: false },
        { name: "Bottom Sheet", below: "Selection", placed: false }
      ];
      let curX = 0;
      for (const nm of ROW) {
        const sec = findSec(nm);
        if (!sec) continue;
        relocateSection(sec, curX, TOP_Y);
        let colWidth = widthOf(sec);
        let stackY = TOP_Y + heightOf(sec) + H_GAP;
        for (const st of STACKED) {
          if (st.below !== nm) continue;
          const ssec = findSec(st.name);
          if (!ssec) continue;
          relocateSection(ssec, curX, stackY);
          colWidth = Math.max(colWidth, widthOf(ssec));
          stackY += heightOf(ssec) + H_GAP;
          st.placed = true;
        }
        curX += colWidth + H_GAP;
      }
      for (const st of STACKED) {
        if (st.placed) continue;
        const ssec = findSec(st.name);
        if (!ssec) continue;
        relocateSection(ssec, curX, TOP_Y);
        curX += widthOf(ssec) + H_GAP;
      }
    } catch (e) {
    }
    if (noRunner.length) {
      console.warn(`[installer] \uBE4C\uB354 \uBBF8\uB4F1\uB85D\uC73C\uB85C \uAC74\uB108\uB700 ${noRunner.length}\uAC1C: ${noRunner.join(", ")}`);
    }
    const degraded = [];
    if (failed.length) {
      const broken = new Set(failed.map((f) => f.name));
      const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k) && Array.isArray(o[k]) ? o[k] : [];
      const depsOf = (p) => Array.from(/* @__PURE__ */ new Set([...own(BUILD_DEPENDENCIES, p), ...own(ATTACH_DEPENDENCIES, p)]));
      const maxRounds = added.length + 1;
      let rounds = 0;
      for (; rounds < maxRounds; rounds++) {
        let changed = false;
        for (const parent of added) {
          if (broken.has(parent)) continue;
          const missing = depsOf(parent).filter((d) => broken.has(d));
          if (missing.length) {
            degraded.push({ name: parent, missing });
            broken.add(parent);
            changed = true;
          }
        }
        if (!changed) break;
      }
      if (rounds >= maxRounds) {
        console.error(`[installer] \uC5F4\uD654 \uC804\uD30C\uAC00 ${maxRounds}\uD68C\uC5D0 \uC218\uB834\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4 \u2014 \uC758\uC874 \uADF8\uB798\uD504\uC5D0 \uC21C\uD658\uC774 \uC788\uB294\uC9C0 \uD655\uC778 \uD544\uC694(\uBCF4\uACE0\uAC00 \uBD88\uC644\uC804\uD560 \uC218 \uC788\uC74C).`);
      }
    }
    if (failed.length) {
      console.error(`[installer] \uC0DD\uC131 \uC2E4\uD328 ${failed.length}\uAC1C: ${failed.map((f) => f.name).join(", ")}`);
    }
    if (degraded.length) {
      console.error(`[installer] \uBD80\uD488 \uB204\uB77D\uC73C\uB85C \uBD88\uC644\uC804 ${degraded.length}\uAC1C: ${degraded.map((d) => `${d.name}(${d.missing.join("\xB7")} \uBE60\uC9D0)`).join(", ")}`);
    }
    if (onProgress) onProgress("\uC61B \uBD80\uD488\uC758 \uBAA8\uB4DC \uACE0\uC815\uC744 \uAC77\uC5B4\uB0B4\uB294 \uC911\u2026", 99);
    try {
      const unpinned = await unpinInstalledMasters(maps);
      if (unpinned) console.log(`[installer] \uC61B \uBD80\uD488 ${unpinned}\uAC1C\uC758 \uBAA8\uB4DC \uACE0\uC815\uC744 \uAC77\uC5B4\uB0C8\uC2B5\uB2C8\uB2E4(\uB2E4\uD06C \uD654\uBA74\uC5D0\uC11C \uB530\uB77C \uB4A4\uC9D1\uD788\uAC8C).`);
    } catch (e) {
      console.warn("[installer] \uBAA8\uB4DC \uACE0\uC815 \uC815\uB9AC \uC2E4\uD328(\uC124\uCE58 \uC790\uCCB4\uB294 \uC815\uC0C1):", e);
    }
    if (onProgress) {
      onProgress(
        `\uC644\uB8CC \u2014 \uCD94\uAC00 ${added.length}\uAC1C \xB7 \uAE30\uC874 \uBCF4\uC874 ${skipped.length}\uAC1C` + (failed.length ? ` \xB7 \uC2E4\uD328 ${failed.length}\uAC1C(${failed.map((f) => f.name).join(", ")})` : "") + (degraded.length ? ` \xB7 \uBD88\uC644\uC804 ${degraded.length}\uAC1C(${degraded.map((d) => d.name).join(", ")})` : ""),
        100
      );
    }
    if (rawPaints.length) {
      console.warn(`[installer] \uD1A0\uD070\uC5D0 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC740 \uC0C9\uC774 \uB0A8\uC740 \uC790\uB9AC ${rawPaints.length}\uACF3: ${rawPaints.join(" / ")}`);
    }
    return { created, added, skipped, noRunner, failed, degraded, rawPaints };
  }
  function absBBox(nodes) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, ok = false;
    for (const n of nodes) {
      const b = n.absoluteBoundingBox;
      if (!b || typeof b.x !== "number" || typeof b.width !== "number") continue;
      ok = true;
      minX = Math.min(minX, b.x);
      minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.width);
      maxY = Math.max(maxY, b.y + b.height);
    }
    return ok ? { minX, minY, maxX, maxY } : null;
  }
  function relocateSection(section, targetX, targetY) {
    let kids = [];
    try {
      const c = section.children;
      if (Array.isArray(c)) kids = c;
    } catch (e) {
      return;
    }
    const sx = typeof section.x === "number" ? section.x : 0;
    const sy = typeof section.y === "number" ? section.y : 0;
    const dx = targetX - sx, dy = targetY - sy;
    const desired = [];
    for (const k of kids) {
      const b = k.absoluteBoundingBox;
      if (b && typeof b.x === "number" && typeof b.y === "number") desired.push({ k, x: b.x + dx, y: b.y + dy });
    }
    try {
      section.x = targetX;
      section.y = targetY;
    } catch (e) {
    }
    for (const d of desired) {
      const b = d.k.absoluteBoundingBox;
      if (b && typeof b.x === "number" && typeof d.k.x === "number") {
        d.k.x += d.x - b.x;
        d.k.y += d.y - b.y;
      }
    }
  }
  async function wrapCategoryInSection(title, nodes, titleSpace, pad) {
    if (typeof figma.createSection !== "function") return;
    if (!nodes || !nodes.length) return;
    const box = absBBox(nodes);
    if (!box) return;
    let section = null;
    try {
      const secs = figma.currentPage.findAll((n) => n.type === "SECTION" && n.name === title);
      if (Array.isArray(secs) && secs.length) section = secs[0];
    } catch (e) {
    }
    if (!section) section = figma.createSection();
    section.name = title;
    if (SPEC_MAPS && SPEC_MAPS.semanticLightModeNamed !== false && SPEC_MAPS.semanticLightModeId) {
      try {
        setMode(section, SPEC_MAPS, SPEC_MAPS.semanticLightModeId);
      } catch (e) {
      }
    }
    const sec = section;
    bindSurface("section", (paint) => {
      sec.fills = [paint];
    });
    if (SPEC_MAPS) {
      const lineVar = SPEC_MAPS.semanticColor[SECTION_STROKE_TOKEN];
      if (lineVar) {
        try {
          sec.strokes = [boundPaint(lineVar)];
          sec.strokeWeight = 1;
        } catch (e) {
        }
      }
    }
    const desired = [];
    for (const n of nodes) {
      const b = n.absoluteBoundingBox;
      if (b && typeof b.x === "number" && typeof b.y === "number") desired.push({ n, x: b.x, y: b.y });
    }
    try {
      section.x = box.minX - pad;
      section.y = box.minY - titleSpace;
    } catch (e) {
    }
    try {
      section.resizeWithoutConstraints(
        Math.max(0.01, box.maxX - box.minX + pad * 2),
        Math.max(0.01, box.maxY - box.minY + titleSpace + pad)
      );
    } catch (e) {
    }
    for (const d of desired) {
      const n = d.n;
      const bx = d.x;
      const by = d.y;
      try {
        section.appendChild(n);
      } catch (e) {
        continue;
      }
      const after = n.absoluteBoundingBox;
      if (bx != null && by != null && after && typeof after.x === "number" && typeof n.x === "number") {
        n.x += bx - after.x;
        n.y += by - after.y;
      }
    }
  }

  // plugins/figma-vars-installer/src/build-token-sheets.ts
  var TOKEN_SHEET_SECTIONS = ["Tokens \xB7 Color", "Tokens \xB7 Typography", "Tokens \xB7 Number"];
  var T = {
    title: "color/text/title/primary",
    body: "color/text/body/primary",
    sub: "color/text/body/secondary",
    meta: "color/text/body/tertiary",
    surface: "color/bg/level-0",
    band: "color/bg/level-2",
    line: "color/line/gray/subtle",
    mark: "color/icon/gray-light"
    // 자·모서리 상자 같은 '표시용 도형'. 바탕색 계열은 흰 판에서 안 보인다(실측 2026-09-22).
  };
  var FONT = TEXT_STYLE_FONT_FAMILY;
  var REQUIRED_STYLES = ["title/16B", "title/14B", "body/12M", "body/12R", "body/10M", "body/10R"];
  function styleDef(key) {
    for (const d of TEXT_STYLES) if (d.name === key) return { fontStyle: d.fontStyle, fontSize: d.fontSize };
    return { fontStyle: "Regular", fontSize: 12 };
  }
  async function loadSheetFonts() {
    for (const style of ["Regular", "Medium", "Bold"]) {
      try {
        await figma.loadFontAsync({ family: FONT, style });
      } catch (e) {
      }
    }
  }
  async function text(maps, chars, styleKey, colorKey, x, y, w, align = "LEFT", noWrap = false) {
    const def = styleDef(styleKey);
    const t = track(figma.createText());
    t.fontName = { family: FONT, style: def.fontStyle };
    t.fontSize = def.fontSize;
    t.characters = chars;
    const ts = maps.textStyles[styleKey];
    if (ts) {
      try {
        await t.setTextStyleIdAsync(ts.id);
      } catch (e) {
      }
    }
    if (noWrap) {
      t.textAutoResize = "WIDTH_AND_HEIGHT";
    } else {
      t.textAutoResize = "HEIGHT";
      t.resize(w, t.height);
    }
    t.textAlignHorizontal = align;
    t.x = x;
    t.y = y;
    const v = maps.semanticColor[colorKey];
    if (v) t.fills = [boundPaint(v)];
    else t.fills = [];
    return t;
  }
  function chip(maps, v, x, y, w, h) {
    const r = track(figma.createRectangle());
    r.x = x;
    r.y = y;
    r.resize(w, h);
    r.fills = v ? [boundPaint(v)] : [];
    const line = maps.semanticColor[T.line];
    if (line) {
      r.strokes = [boundPaint(line)];
      r.strokeWeight = 1;
    }
    const radius = maps.foundationNumber["radius/4"];
    if (radius) {
      for (const corner of ["topLeftRadius", "topRightRadius", "bottomLeftRadius", "bottomRightRadius"]) {
        try {
          r.setBoundVariable(corner, radius);
        } catch (e) {
          r.cornerRadius = 4;
        }
      }
    } else {
      r.cornerRadius = 4;
    }
    return r;
  }
  var PENDING_NODES = [];
  function track(n) {
    PENDING_NODES.push(n);
    return n;
  }
  function groupBand(maps, x, y, w, h) {
    const r = track(figma.createRectangle());
    r.name = "group band";
    r.x = x;
    r.y = y;
    r.resize(w, h);
    const v = maps.semanticColor[T.band];
    r.fills = v ? [boundPaint(v)] : [];
    const radius = maps.foundationNumber["radius/4"];
    if (radius) {
      for (const corner of ["topLeftRadius", "topRightRadius", "bottomLeftRadius", "bottomRightRadius"]) {
        try {
          r.setBoundVariable(corner, radius);
        } catch (e) {
          r.cornerRadius = 4;
        }
      }
    } else {
      r.cornerRadius = 4;
    }
    return r;
  }
  function groupRule(maps, x, y, w) {
    const r = track(figma.createRectangle());
    r.name = "group rule";
    r.x = x;
    r.y = y;
    r.resize(w, 1);
    const v = maps.semanticColor[T.line];
    r.fills = v ? [boundPaint(v)] : [];
    return r;
  }
  function sheetFrame(maps, name, modeId, surfaceKey) {
    const f = track(figma.createFrame());
    f.name = name;
    f.clipsContent = false;
    const v = maps.semanticColor[surfaceKey];
    f.fills = v ? [boundPaint(v)] : [];
    if (modeId) {
      try {
        setMode(f, maps, modeId);
      } catch (e) {
      }
    }
    return f;
  }
  function groupByHead(keys) {
    const order = [];
    const bag = {};
    for (const k of keys) {
      const head = k.indexOf("/") >= 0 ? k.slice(0, k.indexOf("/")) : k;
      if (!Object.prototype.hasOwnProperty.call(bag, head)) {
        bag[head] = [];
        order.push(head);
      }
      bag[head].push(k);
    }
    return order.map((head) => ({ head, members: bag[head] }));
  }
  function groupSemantic(keys) {
    const order = [];
    const bag = {};
    for (const k of keys) {
      const parts = k.split("/");
      const head = parts.length >= 2 ? `${parts[0]}/${parts[1]}` : k;
      if (!Object.prototype.hasOwnProperty.call(bag, head)) {
        bag[head] = [];
        order.push(head);
      }
      bag[head].push(k);
    }
    return order.map((head) => ({ head, members: bag[head] }));
  }
  function semanticUsage() {
    const count = {};
    const bump = (k) => {
      if (!k || k.indexOf("#") === 0 || k.indexOf("rgba") === 0) return;
      count[k] = (Object.prototype.hasOwnProperty.call(count, k) ? count[k] : 0) + 1;
    };
    for (const key of Object.keys(SEMANTIC_COLOR)) {
      const e = SEMANTIC_COLOR[key];
      bump(e.light);
      bump(e.dark);
    }
    return count;
  }
  var PRIMARY_GROUPS = ["blue", "red", "blue-dark", "red-dark"];
  function primaryOfGroup(head, members, usage) {
    if (PRIMARY_GROUPS.indexOf(head) < 0) return null;
    let best = null, bestN = 0;
    for (const k of members) {
      const n = Object.prototype.hasOwnProperty.call(usage, k) ? usage[k] : 0;
      if (n > bestN) {
        best = k;
        bestN = n;
      }
    }
    return bestN > 0 ? best : null;
  }
  var PAD = 40;
  var SHEET_TITLE_H = 60;
  async function buildFoundationColor(maps) {
    const COLS = 11, CW = 116, SW = 104, SH = 56, CH = 124, GROUP_TITLE_H = 30, GROUP_GAP = 24;
    const usage = semanticUsage();
    const f = sheetFrame(maps, "Tokens \xB7 Color \u2014 Foundation", maps.semanticLightModeId, T.surface);
    let y = PAD;
    f.appendChild(await text(maps, "Foundation \xB7 \uAE30\uBCF8 \uD314\uB808\uD2B8", "title/16B", T.title, PAD, y, 600));
    y += SHEET_TITLE_H;
    let count = 0;
    for (const g of groupByHead(Object.keys(FOUNDATION_COLOR))) {
      const primary = primaryOfGroup(g.head, g.members, usage);
      const head = primary ? `${g.head} \u2014 \uB300\uD45C ${primary.slice(primary.indexOf("/") + 1)} (\uC5ED\uD560\uC0C9 ${usage[primary]}\uACF3)` : g.head;
      f.appendChild(await text(maps, head, "title/14B", T.body, PAD, y, 600));
      y += GROUP_TITLE_H;
      for (let i = 0; i < g.members.length; i++) {
        const key = g.members[i];
        const col = i % COLS, row = Math.floor(i / COLS);
        const x = PAD + col * CW, cy = y + row * CH;
        const used = Object.prototype.hasOwnProperty.call(usage, key) ? usage[key] : 0;
        const isPrimary = key === primary;
        const sw = chip(maps, maps.foundationColor[key], x, cy, SW, SH);
        if (isPrimary) {
          const accent = maps.semanticColor["color/line/blue"];
          if (accent) {
            try {
              sw.strokes = [boundPaint(accent)];
              sw.strokeWeight = 3;
            } catch (e) {
            }
          }
        }
        f.appendChild(sw);
        f.appendChild(await text(maps, key.slice(key.indexOf("/") + 1), "body/10M", T.body, x, cy + SH + 6, SW));
        f.appendChild(await text(maps, FOUNDATION_COLOR[key], "body/10R", T.meta, x, cy + SH + 22, SW));
        if (used && primary) {
          f.appendChild(await text(
            maps,
            isPrimary ? `\u2605 \uB300\uD45C \xB7 \uC5ED\uD560\uC0C9 ${used}\uACF3` : `\uC5ED\uD560\uC0C9 ${used}\uACF3`,
            "body/10R",
            isPrimary ? "color/text/state/accent" : T.meta,
            x,
            cy + SH + 38,
            SW
          ));
        }
        count++;
      }
      y += Math.ceil(g.members.length / COLS) * CH + GROUP_GAP;
    }
    f.resize(PAD * 2 + COLS * CW, y + PAD);
    return { frame: f, count };
  }
  async function buildSemanticColor(maps, dark) {
    const ROW_H = 30, COL_W = 560, COL_MAX_H = 3200, GROUP_TITLE_H = 30, GROUP_GAP = 16;
    const modeId = dark ? maps.semanticDarkModeId : maps.semanticLightModeId;
    const f = sheetFrame(maps, `Tokens \xB7 Color \u2014 Semantic ${dark ? "Dark" : "Light"}`, modeId, T.surface);
    f.appendChild(await text(maps, `Semantic \xB7 \uC5ED\uD560\uC0C9 (${dark ? "Dark" : "Light"})`, "title/16B", T.title, PAD, PAD, 600));
    const top = PAD + SHEET_TITLE_H;
    let x = PAD, y = top, maxY = top, count = 0;
    const groups = groupSemantic(Object.keys(SEMANTIC_COLOR));
    for (const g of groups) {
      const blockH = GROUP_TITLE_H + g.members.length * ROW_H + GROUP_GAP;
      if (y > top && y + blockH > COL_MAX_H) {
        x += COL_W;
        y = top;
      }
      f.appendChild(await text(maps, g.head, "title/14B", T.body, x, y, COL_W - 40));
      y += GROUP_TITLE_H;
      for (const key of g.members) {
        f.appendChild(chip(maps, maps.semanticColor[key], x, y, 24, 24));
        f.appendChild(await text(maps, key, "body/12R", T.body, x + 34, y + 4, 300));
        const entry = SEMANTIC_COLOR[key];
        f.appendChild(await text(maps, dark ? entry.dark : entry.light, "body/12R", T.meta, x + 344, y + 4, COL_W - 384));
        y += ROW_H;
        count++;
      }
      y += GROUP_GAP;
      if (y > maxY) maxY = y;
    }
    f.resize(x + COL_W, Math.max(maxY, y) + PAD);
    return { frame: f, count };
  }
  async function buildTypography(maps) {
    const NAME_W = 150, SAMPLE_X = 200, SAMPLE_W = 760, SPEC_X = 1020, SPEC_W = 320;
    const f = sheetFrame(maps, "Tokens \xB7 Typography", maps.semanticLightModeId, T.surface);
    let y = PAD;
    f.appendChild(await text(maps, "Typography \xB7 \uAE00\uC790 \uC2A4\uD0C0\uC77C", "title/16B", T.title, PAD, y, 600));
    y += SHEET_TITLE_H;
    let count = 0;
    for (const d of TEXT_STYLES) {
      const rowH = Math.max(52, Math.round(d.fontSize * (d.lineHeightPercent / 100)) + 28);
      f.appendChild(await text(maps, d.name, "body/12M", T.sub, PAD, y + 8, NAME_W));
      f.appendChild(await text(maps, "\uB2E4\uB78C\uC950 \uD5CC \uCCC7\uBC14\uD034\uC5D0 \uD0C0\uACE0\uD30C AaBbCc 0123", d.name, T.body, SAMPLE_X, y, SAMPLE_W, "LEFT", true));
      const spec = `${d.fontSize}px \xB7 ${d.fontStyle} \xB7 \uD589\uAC04 ${d.lineHeightPercent}% \xB7 \uC790\uAC04 ${d.letterSpacingPercent}%`;
      f.appendChild(await text(maps, spec, "body/12R", T.meta, SPEC_X, y + 8, SPEC_W));
      y += rowH;
      count++;
    }
    f.resize(SPEC_X + SPEC_W + PAD, y + PAD);
    return { frame: f, count };
  }
  var BAR_HEADS = ["spacing", "sizing", "border-width"];
  var BAR_MAX = 320;
  async function buildNumber(maps) {
    const ROW_H = 32, NAME_W = 190, VALUE_W = 70, BAR_X = PAD + NAME_W + VALUE_W + 20;
    const COL_W = BAR_X + BAR_MAX + 60, COL_MAX_H = 2400;
    const BAND_H = 32, BAND_W = COL_W - 60, GROUP_TITLE_H = BAND_H + 12, GROUP_GAP = 44, ROWS_INDENT = 12;
    const f = sheetFrame(maps, "Tokens \xB7 Number", maps.semanticLightModeId, T.surface);
    f.appendChild(await text(maps, "Number \xB7 \uAC04\uACA9 \xB7 \uBC18\uACBD \xB7 \uB450\uAED8", "title/16B", T.title, PAD, PAD, 600));
    const top = PAD + SHEET_TITLE_H;
    let x = PAD, y = top, maxY = top, count = 0;
    const markVar = maps.semanticColor[T.mark];
    for (const g of groupByHead(Object.keys(FOUNDATION_NUMBER))) {
      const blockH = GROUP_TITLE_H + g.members.length * ROW_H + GROUP_GAP;
      if (y > top && y + blockH > COL_MAX_H) {
        x += COL_W;
        y = top;
      }
      f.appendChild(groupBand(maps, x, y, BAND_W, BAND_H));
      f.appendChild(await text(maps, `${g.head} \xB7 ${g.members.length}\uAC1C`, "title/14B", T.body, x + 12, y + 8, 300));
      y += GROUP_TITLE_H;
      for (const key of g.members) {
        const value = FOUNDATION_NUMBER[key];
        const v = maps.foundationNumber[key];
        f.appendChild(await text(maps, key, "body/12R", T.body, x + ROWS_INDENT, y + 6, NAME_W));
        f.appendChild(await text(maps, String(value), "body/12M", T.sub, x + ROWS_INDENT + NAME_W, y + 6, VALUE_W, "RIGHT"));
        if (BAR_HEADS.indexOf(g.head) >= 0 && value > 0) {
          const bar = track(figma.createRectangle());
          bar.name = `${key} bar`;
          bar.x = x + ROWS_INDENT + NAME_W + VALUE_W + 20;
          bar.y = y + 10;
          bar.resize(Math.max(1, Math.min(value, BAR_MAX)), 12);
          bar.fills = markVar ? [boundPaint(markVar)] : [];
          if (v && value <= BAR_MAX) {
            try {
              bar.setBoundVariable("width", v);
            } catch (e) {
            }
          }
          f.appendChild(bar);
        } else if (g.head === "radius") {
          const box = track(figma.createRectangle());
          box.name = `${key} box`;
          box.x = x + ROWS_INDENT + NAME_W + VALUE_W + 20;
          box.y = y + 2;
          box.resize(28, 28);
          box.fills = markVar ? [boundPaint(markVar)] : [];
          if (v) {
            for (const corner of ["topLeftRadius", "topRightRadius", "bottomLeftRadius", "bottomRightRadius"]) {
              try {
                box.setBoundVariable(corner, v);
              } catch (e) {
                box.cornerRadius = Math.min(value, 14);
              }
            }
          } else {
            box.cornerRadius = Math.min(value, 14);
          }
          f.appendChild(box);
        }
        y += ROW_H;
        count++;
      }
      y += 12;
      f.appendChild(groupRule(maps, x, y, BAND_W));
      y += GROUP_GAP;
      if (y > maxY) maxY = y;
    }
    const semKeys = Object.keys(SEMANTIC_NUMBER);
    if (semKeys.length) {
      const blockH = GROUP_TITLE_H + semKeys.length * ROW_H + GROUP_GAP;
      if (y > top && y + blockH > COL_MAX_H) {
        x += COL_W;
        y = top;
      }
      f.appendChild(groupBand(maps, x, y, BAND_W, BAND_H));
      f.appendChild(await text(maps, `Semantic Number \xB7 ${semKeys.length}\uAC1C`, "title/14B", T.body, x + 12, y + 8, 300));
      y += GROUP_TITLE_H;
      for (const key of semKeys) {
        f.appendChild(await text(maps, key, "body/12R", T.body, x + ROWS_INDENT, y + 6, NAME_W + 60));
        f.appendChild(await text(maps, String(SEMANTIC_NUMBER[key]), "body/12R", T.meta, x + ROWS_INDENT + NAME_W + 70, y + 6, 240));
        y += ROW_H;
        count++;
      }
      y += 12;
      f.appendChild(groupRule(maps, x, y, BAND_W));
      y += GROUP_GAP;
      if (y > maxY) maxY = y;
    }
    f.resize(x + COL_W, Math.max(maxY, y) + PAD);
    return { frame: f, count };
  }
  function removeOldSheets() {
    let sections = [];
    try {
      sections = figma.currentPage.findAll(
        (n) => n.type === "SECTION" && TOKEN_SHEET_SECTIONS.indexOf(n.name) >= 0
      );
    } catch (e) {
      return;
    }
    if (!Array.isArray(sections)) return;
    for (const s of sections) {
      try {
        s.remove();
      } catch (e) {
      }
    }
  }
  function originLeftOfContent(totalW, exclude) {
    let minX = Infinity, minY = Infinity;
    const skip = /* @__PURE__ */ new Set();
    for (const n of exclude) {
      try {
        skip.add(String(n.id));
      } catch (e) {
      }
    }
    try {
      const kids = figma.currentPage.children;
      if (Array.isArray(kids)) {
        for (const n of kids) {
          let id = "";
          try {
            id = String(n.id);
          } catch (e) {
          }
          if (id && skip.has(id)) continue;
          const b = n.absoluteBoundingBox;
          if (!b || typeof b.x !== "number") continue;
          if (b.x < minX) minX = b.x;
          if (b.y < minY) minY = b.y;
        }
      }
    } catch (e) {
    }
    if (minX === Infinity) return { x: 0, y: 0 };
    return { x: minX - totalW - 400, y: minY };
  }
  async function buildTokenSheets(maps, onProgress) {
    const result = { sections: [], swatches: 0, styles: 0, numbers: 0, skipped: [] };
    if (typeof figma.createFrame !== "function") return result;
    primeSpecMaps(maps);
    PENDING_NODES = [];
    await loadSheetFonts();
    const hasFoundationColor = Object.keys(maps.foundationColor || {}).length > 0;
    const hasSemanticColor = Object.keys(maps.semanticColor || {}).length > 0;
    const hasNumbers = Object.keys(maps.foundationNumber || {}).length > 0;
    const missingStyles = REQUIRED_STYLES.filter((k) => !maps.textStyles || !maps.textStyles[k]);
    const hasAllStyles = TEXT_STYLES.every((d) => maps.textStyles && maps.textStyles[d.name]);
    if (!hasSemanticColor) {
      result.skipped.push("\uC0C9\xB7\uAE00\uC790\xB7\uC22B\uC790 \u2014 \uC5ED\uD560\uC0C9(Semantic) \uD1A0\uD070\uC774 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4");
      return result;
    }
    if (missingStyles.length) {
      result.skipped.push("\uC0C9\xB7\uAE00\uC790\xB7\uC22B\uC790 \u2014 \uAE00\uC790 \uC2A4\uD0C0\uC77C\uC774 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4");
      return result;
    }
    const hasDarkMode = !!maps.semanticDarkModeId && maps.semanticDarkModeId !== maps.semanticLightModeId;
    const made = [];
    const rows = [];
    try {
      if (onProgress) onProgress("\uD1A0\uD070 \uACAC\uBCF8 \u2014 \uC0C9 \uC2DC\uD2B8 \uADF8\uB9AC\uB294 \uC911\u2026", 96);
      const colorFrames = [];
      if (hasFoundationColor) {
        const r = await buildFoundationColor(maps);
        colorFrames.push(r.frame);
        made.push(r.frame);
        result.swatches += r.count;
      } else {
        result.skipped.push("Foundation \uD314\uB808\uD2B8 \uD310 \u2014 \uAE30\uBCF8 \uD314\uB808\uD2B8 \uBCC0\uC218\uAC00 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4");
      }
      const lightSheet = await buildSemanticColor(maps, false);
      colorFrames.push(lightSheet.frame);
      made.push(lightSheet.frame);
      result.swatches += lightSheet.count;
      if (hasDarkMode) {
        const darkSheet = await buildSemanticColor(maps, true);
        colorFrames.push(darkSheet.frame);
        made.push(darkSheet.frame);
        result.swatches += darkSheet.count;
      } else {
        result.skipped.push("\uC5ED\uD560\uC0C9 Dark \uD310 \u2014 \uC774 \uD30C\uC77C\uC5D0 Dark \uBAA8\uB4DC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4");
      }
      rows.push({ title: "Tokens \xB7 Color", frames: colorFrames });
      if (hasAllStyles) {
        if (onProgress) onProgress("\uD1A0\uD070 \uACAC\uBCF8 \u2014 \uAE00\uC790 \uC2DC\uD2B8 \uADF8\uB9AC\uB294 \uC911\u2026", 97);
        const r = await buildTypography(maps);
        made.push(r.frame);
        result.styles = r.count;
        rows.push({ title: "Tokens \xB7 Typography", frames: [r.frame] });
      } else {
        result.skipped.push("\uAE00\uC790 \uD310 \u2014 \uAE00\uC790 \uC2A4\uD0C0\uC77C \uC77C\uBD80\uAC00 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4");
      }
      if (hasNumbers) {
        if (onProgress) onProgress("\uD1A0\uD070 \uACAC\uBCF8 \u2014 \uC22B\uC790 \uC2DC\uD2B8 \uADF8\uB9AC\uB294 \uC911\u2026", 98);
        const r = await buildNumber(maps);
        made.push(r.frame);
        result.numbers = r.count;
        rows.push({ title: "Tokens \xB7 Number", frames: [r.frame] });
      } else {
        result.skipped.push("\uC22B\uC790 \uD310 \u2014 \uAC04\uACA9\xB7\uBC18\uACBD \uBCC0\uC218\uAC00 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4");
      }
    } catch (e) {
      for (const n of PENDING_NODES) {
        try {
          n.remove();
        } catch (err) {
        }
      }
      PENDING_NODES = [];
      throw e;
    }
    removeOldSheets();
    const GAP = 160, ROW_GAP = 400;
    let totalW = 0;
    for (const row of rows) {
      let w = 0;
      for (let i = 0; i < row.frames.length; i++) w += row.frames[i].width + (i ? GAP : 0);
      if (w > totalW) totalW = w;
    }
    const origin = originLeftOfContent(totalW, made);
    let rowY = origin.y;
    for (const row of rows) {
      let x = origin.x, bottom = rowY;
      for (const f of row.frames) {
        f.x = x;
        f.y = rowY;
        x += f.width + GAP;
        if (rowY + f.height > bottom) bottom = rowY + f.height;
      }
      await wrapCategoryInSection(row.title, row.frames, 140, 64);
      result.sections.push(row.title);
      rowY = bottom + ROW_GAP;
    }
    return result;
  }

  // plugins/figma-vars-installer/src/pattern-data.ts
  var SB = {
    t: "INST",
    n: "StatusBar / App",
    set: "StatusBar",
    pr: { Platform: "App" },
    w: 360,
    h: 27,
    sz: ["FIXED", "FIXED"]
  };
  var CI = {
    t: "INST",
    n: "CI / \uC5D0\uC2A4\uC6D0 / Blue",
    set: "CI",
    pr: { Brand: "\uC5D0\uC2A4\uC6D0", Color: "Blue" },
    w: 78.75,
    h: 30,
    sz: ["FIXED", "FIXED"]
  };
  var LOGO_SLOT = {
    t: "FRAME",
    n: "LogoSlot",
    w: 320,
    h: 90,
    sz: ["FIXED", "FIXED"],
    clip: true,
    al: ["HORIZONTAL", 0, 0, 0, 0, 0, "FIXED", "FIXED", "CENTER", "CENTER"],
    c: [CI]
  };
  function spacer(name, h) {
    return { t: "FRAME", n: `Spacer / ${name}`, w: 320, h, sz: ["FIXED", "FIXED"], clip: true };
  }
  function helperText(label, w) {
    return {
      t: "TEXT",
      n: `Helper / ${label}`,
      w,
      h: 16,
      sz: ["HUG", "HUG"],
      fillVar: "color/text/body/tertiary",
      chars: label,
      tar: "WIDTH_AND_HEIGHT",
      ta: ["LEFT", "TOP"],
      ts: "body/12R"
    };
  }
  var HELPER_SEP = {
    t: "RECT",
    n: "sep",
    w: 1,
    h: 10,
    sz: ["FIXED", "FIXED"],
    fillVar: "color/line/gray/subtle"
  };
  var HELPER_LINKS = {
    t: "FRAME",
    n: "HelperLinks",
    w: 320,
    h: 20,
    sz: ["FIXED", "FIXED"],
    clip: true,
    al: ["HORIZONTAL", 8, 0, 0, 0, 0, "FIXED", "FIXED", "CENTER", "CENTER"],
    c: [
      helperText("\uD68C\uC6D0\uAC00\uC785", 42),
      HELPER_SEP,
      helperText("\uC544\uC774\uB514 \uCC3E\uAE30", 55),
      HELPER_SEP,
      helperText("\uBE44\uBC00\uBC88\uD638 \uCC3E\uAE30", 66)
    ]
  };
  function input(which, state, h, ov, message = "Off") {
    return {
      t: "INST",
      n: `Input / ${which}`,
      set: "Input",
      w: 320,
      h,
      sz: ["FIXED", "HUG"],
      // 캡처 당시 Figma 인스턴스에는 Label="Off" 도 있었지만, 정본 컴포넌트(build-components.ts)의
      // Input 은 Size·State·Message·Break 4축뿐이라 Label 축 자체가 없어졌다(2026-09-02 실측).
      // 없어진 축을 그대로 들고 있으면 변형을 못 찾으므로 뺀다 — 값을 새로 만든 것이 아니라, 사라진 축을 뺀 것.
      pr: {
        "Password Icon": which === "Password",
        Size: "MD",
        State: state,
        Message: message,
        Break: "Mobile"
      },
      ov,
      // 부품의 입력칸(field)은 기본 폭 200 고정이다. 정본 화면은 이걸 FILL 로 넓혀
      // 입력창 전체 폭(320)을 채운다 — 안 넣으면 안내 문구가 두 줄로 접힌다.
      szOv: [["0", "FILL", "FIXED"]]
    };
  }
  function button(label, variant, state) {
    return {
      t: "INST",
      n: `Button / ${label}`,
      set: "Button",
      w: 320,
      h: 48,
      sz: ["FIXED", "FIXED"],
      pr: { Size: "LG", State: state, Variant: variant, Break: "Mobile" },
      ov: [["0", label]]
    };
  }
  var FOOTER = {
    t: "INST",
    n: "Footer / Mobile",
    set: "Footer",
    pr: { Platform: "Mobile" },
    w: 274,
    h: 52,
    sz: ["HUG", "HUG"],
    ov: [["0.2", "\uAC1C\uC778\uC815\uBCF4\uCC98\uB9AC\uBC29\uCE68"], ["0.4", "\uC601\uC0C1\uC815\uBCF4\uCC98\uB9AC\uBC29\uCE68"]]
  };
  var NAVBAR = {
    t: "INST",
    n: "NavBar / App",
    set: "NavBar",
    pr: { Platform: "App" },
    w: 360,
    h: 45,
    sz: ["FIXED", "FIXED"]
  };
  var NAVBAR_KEYBOARD = {
    t: "INST",
    n: "NavBar / App + Keyboard",
    set: "NavBar",
    pr: { Platform: "App + Keyboard" },
    w: 360,
    h: 341,
    sz: ["FIXED", "FIXED"]
  };
  function modalOverlay(modal2) {
    return {
      t: "FRAME",
      n: "ModalOverlay",
      w: 360,
      h: 735,
      abs: true,
      x: 0,
      y: 0,
      sz: ["FIXED", "FIXED"],
      clip: true,
      fillVar: "color/overlay",
      al: ["VERTICAL", 0, 0, 30, 0, 30, "FIXED", "FIXED", "CENTER", "CENTER"],
      c: [modal2]
    };
  }
  function modal(name, h, footer, ov, msgWidth = "FIXED") {
    return {
      t: "INST",
      n: `Modal / ${name}`,
      set: "Modal",
      w: 300,
      h,
      sz: ["FIXED", "HUG"],
      pr: { Break: "Mobile", Footer: footer },
      ov,
      // 본문(message)은 부품 기본이 FIXED/FIXED 인데, 정본은 화면마다 HUG 로 높이를 늘려 쓴다.
      // 문장이 긴 두 화면(4c1·4c3)은 가로도 FILL 이다.
      //
      // 안쪽 content 폭은 건드리지 않는다: 캡처 당시(옛 Modal)는 260, 지금 Modal 은 1px 테두리가
      // 생겨 258 이다. 2px 차이는 '정본 부품이 바뀐 결과'이므로 옛 숫자를 억지로 맞추지 않는다
      // (H6 — 부품이 바뀌면 파생이 따라간다). 2026-09-02 실측.
      szOv: [["0.1.0", msgWidth, "HUG"]]
    };
  }
  function screen(name, x, y, bodyH, bodyChildren, tail) {
    return {
      name,
      x,
      y,
      root: {
        t: "FRAME",
        n: name,
        w: 360,
        h: 780,
        x,
        y,
        clip: true,
        fillVar: "color/bg/level-0",
        c: [{
          t: "FRAME",
          n: "PatternContent",
          w: 360,
          h: 780,
          x: 0,
          y: 0,
          clip: true,
          al: ["VERTICAL", 0, 0, 0, 0, 0, "FIXED", "FIXED", "MIN", "CENTER"],
          c: [
            SB,
            {
              t: "FRAME",
              n: "LoginBody",
              w: 360,
              h: bodyH,
              sz: ["FIXED", "FIXED"],
              clip: true,
              al: ["VERTICAL", 0, 61, 20, 0, 20, "FIXED", "FIXED", "MIN", "CENTER"],
              c: bodyChildren
            },
            ...tail
          ]
        }]
      }
    };
  }
  function loginBody(idInput2, pwInput, loginBtn, withPhone) {
    const base = [
      LOGO_SLOT,
      spacer("Logo-ID", 10),
      idInput2,
      spacer("ID-Password", 12),
      pwInput,
      spacer("Password-Login", 34),
      loginBtn,
      spacer("Login-Helpers", 20),
      HELPER_LINKS
    ];
    if (!withPhone) return base;
    return base.concat([
      spacer("Helpers-Phone", 23),
      button("\uD734\uB300\uC804\uD654\uBC88\uD638\uB85C \uB85C\uADF8\uC778", "Secondary", "Default")
    ]);
  }
  function filledBody() {
    return loginBody(
      input("ID", "Filled", 48, [["0.0", "s1design"]]),
      input("Password", "Filled", 48, [["0.0", "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"]]),
      button("\uB85C\uADF8\uC778", "Primary", "Default"),
      true
    );
  }
  var MOBILE_LOGIN = {
    id: "mobile-login",
    label: "\uBAA8\uBC14\uC77C \uB85C\uADF8\uC778",
    desc: "\uC544\uC774\uB514\xB7\uBE44\uBC00\uBC88\uD638 \uC785\uB825, \uB85C\uADF8\uC778 \uC2E4\uD328, \uC790\uB3D9 \uB85C\uADF8\uC778, \uC0C8 \uAE30\uAE30 \uC778\uC99D\uAE4C\uC9C0 10\uAC1C \uD654\uBA74",
    section: "Pattern / App Login",
    // 화면은 color/bg/level-0(흰색)이라 흰 바탕에 묻힌다 → 섹션은 한 단계 어두운 면(#E9E9E9).
    // 정본 섹션에는 바탕색이 없어 대조할 값이 없으므로, 새 색을 만들지 않고 기존 Semantic 토큰을 쓴다.
    sectionFillVar: "color/bg/level-3",
    requires: ["StatusBar", "NavBar", "CI", "Footer", "Button", "Input", "Modal"],
    source: {
      fileKey: "cysG5U1udpQqVagYY1hWHW",
      pageId: "173:2431",
      sectionId: "1562:2",
      capturedAt: "2026-09-02"
    },
    screens: [
      // ── 기본 흐름 ──
      screen(
        "APP/LOGIN/1 \xB7 \uCD5C\uCD08 \uC9C4\uC785",
        80,
        100,
        656,
        loginBody(
          input("ID", "Default", 48, [["0.0", "\uC544\uC774\uB514\uB97C \uC785\uB825\uD574 \uC8FC\uC138\uC694."]]),
          input("Password", "Default", 48, [["0.0", "\uBE44\uBC00\uBC88\uD638\uB97C \uC785\uB825\uD574 \uC8FC\uC138\uC694."]]),
          button("\uB85C\uADF8\uC778", "Primary", "Disabled"),
          true
        ),
        [FOOTER, NAVBAR]
      ),
      screen(
        "APP/LOGIN/2 \xB7 \uC544\uC774\uB514 \uC785\uB825 \uC911 (\uD0A4\uBCF4\uB4DC)",
        520,
        100,
        412,
        loginBody(
          input("ID", "Focus", 48, [["0.0.0", "s1desig"]]),
          input("Password", "Default", 48, [["0.0", "\uBE44\uBC00\uBC88\uD638\uB97C \uC785\uB825\uD574 \uC8FC\uC138\uC694."]]),
          button("\uB85C\uADF8\uC778", "Primary", "Disabled"),
          false
        ),
        [NAVBAR_KEYBOARD]
      ),
      screen(
        "APP/LOGIN/3 \xB7 \uBE44\uBC00\uBC88\uD638 \uC785\uB825 \uC911 (\uD0A4\uBCF4\uB4DC)",
        960,
        100,
        412,
        loginBody(
          input("ID", "Filled", 48, [["0.0", "s1design"]]),
          input("Password", "Focus", 48, [["0.0.0", "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"]]),
          button("\uB85C\uADF8\uC778", "Primary", "Default"),
          false
        ),
        [NAVBAR_KEYBOARD]
      ),
      screen(
        "APP/LOGIN/4 \xB7 \uC785\uB825 \uC644\uB8CC\xB7\uB85C\uADF8\uC778 \uD65C\uC131",
        1400,
        100,
        656,
        filledBody(),
        [FOOTER, NAVBAR]
      ),
      // ── 분기 a — 로그인 실패 ──
      screen(
        "APP/LOGIN/4a1 \xB7 \uACC4\uC815 \uBD88\uC77C\uCE58 \uC624\uB958",
        80,
        1e3,
        656,
        loginBody(
          input("ID", "Error", 48, [["0.0", "s1design"]]),
          input("Password", "Error", 86, [
            ["0.0", "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"],
            ["1", "\uC544\uC774\uB514 \uB610\uB294 \uBE44\uBC00\uBC88\uD638\uAC00 \uC5C6\uAC70\uB098 \uC798\uBABB \uC785\uB825\uB418\uC5C8\uC2B5\uB2C8\uB2E4.\n\uD655\uC778 \uD6C4 \uB2E4\uC2DC \uB85C\uADF8\uC778 \uD574\uC8FC\uC138\uC694. (1/5)"]
          ], "On"),
          button("\uB85C\uADF8\uC778", "Primary", "Default"),
          true
        ),
        [FOOTER, NAVBAR]
      ),
      // ── 분기 b — 자동 로그인 ──
      screen(
        "APP/LOGIN/4b1 \xB7 \uC790\uB3D9 \uB85C\uADF8\uC778 \uC9C8\uBB38 (\uBAA8\uB2EC)",
        520,
        1e3,
        656,
        filledBody(),
        [FOOTER, NAVBAR, modalOverlay(modal("Login Notice", 187, "Dual", [
          ["0.0", "\uC790\uB3D9 \uB85C\uADF8\uC778 \uC548\uB0B4"],
          ["0.1.0", "\uB2E4\uC74C\uBD80\uD130 \uC790\uB3D9\uC73C\uB85C \uB85C\uADF8\uC778\uD560\uAE4C\uC694?"]
        ]))]
      ),
      screen(
        "APP/LOGIN/4b2 \xB7 \uC790\uB3D9 \uB85C\uADF8\uC778 \uC124\uC815 \uC644\uB8CC (\uBAA8\uB2EC)",
        960,
        1e3,
        656,
        filledBody(),
        [FOOTER, NAVBAR, modalOverlay(modal("Login Notice", 187, "Single", [
          ["0.0", "\uC790\uB3D9 \uB85C\uADF8\uC778 \uC124\uC815 \uC644\uB8CC"],
          ["0.1.0", "\uC790\uB3D9 \uB85C\uADF8\uC778\uC774 \uC124\uC815\uB418\uC5C8\uC5B4\uC694."],
          ["1.0.0", "\uD655\uC778"]
        ]))]
      ),
      // ── 분기 c — 새로운 기기 ──
      screen(
        "APP/LOGIN/4c1 \xB7 \uBCF8\uC778 \uC778\uC99D \uC548\uB0B4 (\uBAA8\uB2EC)",
        1400,
        1e3,
        656,
        filledBody(),
        [FOOTER, NAVBAR, modalOverlay(modal("Login Notice", 229, "Single", [
          ["0.0", "\uBCF8\uC778 \uC778\uC99D \uC548\uB0B4"],
          ["0.1.0", "\uC11C\uBE44\uC2A4\uB97C \uC774\uC6A9\uD558\uB824\uBA74 \uBCF8\uC778 \uC778\uC99D\uC744 \uC9C4\uD589\uD574 \uC8FC\uC138\uC694. \uBCF8\uC778 \uC778\uC99D \uC2DC \uAE30\uC874 \uAE30\uAE30\uB294 \uC778\uC99D\uC774 \uD574\uC81C\uB3FC\uC694."],
          ["1.0.0", "\uD655\uC778"]
        ], "FILL"))]
      ),
      screen(
        "APP/LOGIN/4c2 \xB7 \uAE30\uAE30 \uC778\uC99D \uC644\uB8CC (\uBAA8\uB2EC)",
        1840,
        1e3,
        656,
        filledBody(),
        [FOOTER, NAVBAR, modalOverlay(modal("Login Notice", 208, "Single", [
          ["0.0", "\uAE30\uAE30 \uC778\uC99D \uC644\uB8CC"],
          ["0.1.0", "\uC0AC\uC6A9 \uC911\uC778 \uAE30\uAE30\uB85C \uC778\uC99D\uC774 \uC644\uB8CC\uB410\uC5B4\uC694.\n\uB2E4\uC2DC \uB85C\uADF8\uC778\uD574 \uC8FC\uC138\uC694."],
          ["1.0.0", "\uD655\uC778"]
        ]))]
      ),
      screen(
        "APP/LOGIN/4c3 \xB7 \uAE30\uAE30 \uB4F1\uB85D \uC548\uB0B4 (\uBAA8\uB2EC)",
        2280,
        1e3,
        656,
        filledBody(),
        [FOOTER, NAVBAR, modalOverlay(modal("Device Registration", 250, "Dual", [
          ["0.0", "\uAE30\uAE30 \uB4F1\uB85D \uC548\uB0B4"],
          ["0.1.0", "\uC5D0\uC2A4\uC6D0\uC740 \uACE0\uAC1D\uB2D8\uC758 \uC18C\uC911\uD55C \uC815\uBCF4\uB97C \uBCF4\uD638\uD558\uAE30 \uC704\uD574 \uC778\uC99D \uAE30\uAE30 \uB4F1\uB85D \uD6C4 \uC11C\uBE44\uC2A4\uB97C \uC81C\uACF5\uD558\uACE0 \uC788\uC5B4\uC694.\n\uD604\uC7AC \uC778\uC99D\uD55C \uAE30\uAE30\uB85C \uB4F1\uB85D \uD6C4 \uB85C\uADF8\uC778\uD560\uAE4C\uC694?"]
        ], "FILL"))]
      )
    ]
  };
  var MH_STD = {
    t: "INST",
    n: "Mobile Header",
    set: "Mobile Header",
    pr: { Type: "Standard / No Title", Platform: "Web" },
    x: 0,
    y: 0,
    w: 360,
    h: 149
  };
  var MH_CLOSE = {
    t: "INST",
    n: "Mobile Header",
    set: "Mobile Header",
    pr: { Type: "Standard / No Title + Close", Platform: "Web" },
    x: 0,
    y: 0,
    w: 360,
    h: 149
  };
  var NAV_WEB = {
    t: "INST",
    n: "NavBar",
    set: "NavBar",
    pr: { Platform: "Web" },
    x: 0,
    y: 685,
    w: 360,
    h: 95
  };
  var NAV_WEB_KB = {
    t: "INST",
    n: "NavBar",
    set: "NavBar",
    pr: { Platform: "Web + Keyboard" },
    x: 0,
    y: 439,
    w: 360,
    h: 341
  };
  function dim(h) {
    return { t: "RECT", n: "Overlay Dim", x: 0, y: 0, w: 360, h, fillVar: "color/overlay" };
  }
  function pageTitle(chars, h, ts = "title/24B") {
    return {
      t: "TEXT",
      n: "Page Title",
      x: 20,
      y: 14,
      w: 320,
      h,
      fillVar: "color/text/title/primary",
      chars,
      tar: "HEIGHT",
      ta: ["LEFT", "TOP"],
      ts
    };
  }
  function cta(label, y, state) {
    return {
      t: "INST",
      n: "CTA",
      set: "Button",
      x: 20,
      y,
      w: 320,
      h: 48,
      pr: { Size: "LG", State: state, Variant: "Primary", Break: "Mobile" },
      ov: [["0", label]]
    };
  }
  function fieldLabel(chars, x, y, w) {
    return {
      t: "TEXT",
      n: "\uB77C\uBCA8",
      x,
      y,
      w,
      h: 18,
      fillVar: "color/form-control/label/default",
      chars,
      tar: "WIDTH_AND_HEIGHT",
      ta: ["LEFT", "TOP"],
      ts: "body/14M"
    };
  }
  var MORE_ICON_KEY = "e1ac97aa82f4e52f257ac1c0ea77fd09d0e5f581";
  var CLOSE_ICON_KEY = "54469d54f16ed38de2d7b420b0e2195e4cf7c118";
  function moreIcon(x, y) {
    return { t: "INST", n: "More", remote: true, key: MORE_ICON_KEY, x, y, w: 24, h: 24 };
  }
  function closeIcon(x, y) {
    return { t: "INST", n: "Modal Close", remote: true, key: CLOSE_ICON_KEY, x, y, w: 24, h: 24 };
  }
  function checkbox() {
    return { t: "INST", n: "Checkbox", set: "Checkbox", pr: { State: "Checked" }, x: 0, y: 0, w: 18, h: 18 };
  }
  function agreementLabel(chars, w) {
    return {
      t: "TEXT",
      n: "Agreement Label",
      x: 28,
      y: 0,
      w,
      h: 20,
      fillVar: "color/text/title/primary",
      chars,
      tar: "NONE",
      ta: ["LEFT", "TOP"],
      ts: "title/16B"
    };
  }
  function agreements() {
    return {
      t: "FRAME",
      n: "Agreements",
      x: 20,
      y: 98,
      w: 320,
      h: 233,
      clip: true,
      c: [
        {
          t: "FRAME",
          n: "Agreement Row / All",
          x: 0,
          y: 8,
          w: 320,
          h: 20,
          clip: true,
          c: [checkbox(), agreementLabel("\uC804\uCCB4 \uB3D9\uC758\uD558\uAE30", 292)]
        },
        { t: "RECT", n: "Divider", x: 0, y: 50, w: 320, h: 1, fillVar: "color/line/gray/subtle" },
        {
          t: "FRAME",
          n: "Agreement Row / Terms",
          x: 0,
          y: 78,
          w: 320,
          h: 24,
          clip: true,
          c: [checkbox(), agreementLabel("\uD68C\uC6D0 \uC57D\uAD00 \uB3D9\uC758(\uD544\uC218)", 258), moreIcon(296, 0)]
        },
        {
          t: "FRAME",
          n: "Agreement Row / Privacy",
          x: 0,
          y: 126,
          w: 320,
          h: 24,
          clip: true,
          c: [checkbox(), agreementLabel("\uAC1C\uC778\uC815\uBCF4 \uC218\uC9D1 \uBC0F \uC774\uC6A9 \uB3D9\uC758(\uD544\uC218)", 258), moreIcon(296, 0)]
        },
        {
          t: "FRAME",
          n: "Agreement Row / Age",
          x: 0,
          y: 171,
          w: 320,
          h: 62,
          clip: true,
          c: [
            checkbox(),
            agreementLabel("\uB9CC 14\uC138 \uC774\uC0C1\uC774\uC5D0\uC694(\uD544\uC218)", 258),
            {
              t: "TEXT",
              n: "Agreement Description",
              x: 28,
              y: 26,
              w: 272,
              h: 32,
              fillVar: "color/text/body/tertiary",
              chars: "\uB9CC 14\uC138 \uC774\uC0C1\uBD80\uD130 \uD68C\uC6D0\uAC00\uC785\uC774 \uAC00\uB2A5\uD569\uB2C8\uB2E4. \uD574\uB2F9 \uC815\uBCF4\uB294\n\uC800\uC7A5\uB418\uC9C0 \uC54A\uC73C\uBA70, \uB9CC 14\uC138 \uC774\uC0C1 \uD655\uC778 \uC6A9\uB3C4\uB85C\uB9CC \uC0AC\uC6A9\uD569\uB2C8\uB2E4.",
              tar: "HEIGHT",
              ta: ["LEFT", "TOP"],
              ts: "body/12R"
            }
          ]
        }
      ]
    };
  }
  function idInput() {
    return {
      t: "INST",
      n: "ID Input",
      set: "Input",
      x: 20,
      y: 106,
      w: 320,
      h: 70,
      pr: { "Password Icon": false, Size: "MD", State: "Focus", Message: "On", Break: "Mobile" },
      ov: [["0.0.0", "s1design"], ["1", "\uC601\uC5B4 \uC18C\uBB38\uC790, \uC22B\uC790\uB97C \uC870\uD569\uD558\uC5EC 4~12\uC790 \uC785\uB825\uD574 \uC8FC\uC138\uC694."]],
      szOv: [["0", "FILL", "FIXED"]]
    };
  }
  function passwordContent() {
    return {
      t: "FRAME",
      n: "Content",
      x: 0,
      y: 149,
      w: 360,
      h: 294,
      c: [
        pageTitle("\uBE44\uBC00\uBC88\uD638\uB97C\n\uC785\uB825\uD574 \uC8FC\uC138\uC694", 62),
        {
          t: "TEXT",
          n: "Password Condition Link",
          x: 263,
          y: 98,
          w: 77,
          h: 20,
          fillVar: "color/text/body/tertiary",
          chars: "\uBE44\uBC00\uBC88\uD638 \uC870\uAC74",
          tar: "NONE",
          ta: ["LEFT", "TOP"],
          ts: "body/14M"
        },
        fieldLabel("\uBE44\uBC00\uBC88\uD638", 20, 98, 48),
        {
          t: "INST",
          n: "Password Input",
          set: "Input",
          x: 20,
          y: 122,
          w: 320,
          h: 70,
          pr: { "Password Icon": true, Size: "MD", State: "Focus", Message: "On", Break: "Mobile" },
          ov: [["0.0.0", ""], ["1", "\uC601\uBB38, \uC22B\uC790, \uD2B9\uC218\uBB38\uC790\uB97C \uC870\uD569\uD558\uC5EC 8~15\uC790\uB85C \uC785\uB825\uD574 \uC8FC\uC138\uC694."]],
          szOv: [["0", "FILL", "FIXED"]]
        },
        fieldLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778", 20, 222, 75),
        {
          t: "INST",
          n: "Password Confirm Input",
          set: "Input",
          x: 20,
          y: 246,
          w: 320,
          h: 48,
          pr: { "Password Icon": true, Size: "MD", State: "Default", Message: "Off", Break: "Mobile" },
          ov: [["0.0", "\uC785\uB825\uD574 \uC8FC\uC138\uC694"]],
          szOv: [["0", "FILL", "FIXED"]]
        }
      ]
    };
  }
  function emailContent() {
    return {
      t: "FRAME",
      n: "Content",
      x: 0,
      y: 149,
      w: 360,
      h: 240,
      clip: true,
      c: [
        pageTitle("\uC774\uBA54\uC77C\uC744\n\uC785\uB825\uD574 \uC8FC\uC138\uC694", 62),
        {
          t: "INST",
          n: "Local Part Input",
          set: "Input",
          x: 20,
          y: 106,
          w: 140,
          h: 48,
          pr: { "Password Icon": false, Size: "MD", State: "Focus", Message: "Off", Break: "Mobile" },
          szOv: [["0", "FILL", "FIXED"]]
        },
        {
          t: "TEXT",
          n: "Email At",
          x: 170,
          y: 119,
          w: 20,
          h: 21,
          fillVar: "color/text/title/primary",
          chars: "@",
          tar: "HEIGHT",
          ta: ["LEFT", "TOP"],
          ts: "body/16R"
        },
        {
          t: "INST",
          n: "Domain Select",
          set: "Select Box",
          x: 200,
          y: 106,
          w: 140,
          h: 48,
          pr: { Size: "MD", State: "Filled", Break: "Mobile" },
          ov: [["0.0", "\uC9C1\uC811 \uC785\uB825"]]
        },
        {
          t: "INST",
          n: "Domain Input",
          set: "Input",
          x: 20,
          y: 164,
          w: 320,
          h: 48,
          pr: { "Password Icon": false, Size: "MD", State: "Default", Message: "Off", Break: "Mobile" },
          ov: [["0.0", "\uB3C4\uBA54\uC778\uC744 \uC785\uB825\uD574 \uC8FC\uC138\uC694."]],
          szOv: [["0", "FILL", "FIXED"]]
        }
      ]
    };
  }
  function signupScreen(name, x, y, children, al) {
    const root = { t: "FRAME", n: name, w: 360, h: 780, x, y, clip: true, fillVar: "color/bg/level-0", c: children };
    if (al) root.al = al;
    return { name, x, y, root };
  }
  var MOBILE_WEB_SIGNUP = {
    id: "mobile-web-signup",
    label: "\uBAA8\uBC14\uC77C\uC6F9 \uD68C\uC6D0\uAC00\uC785",
    desc: "\uC57D\uAD00 \uB3D9\uC758, \uC678\uBD80 \uBCF8\uC778\uC778\uC99D, \uC544\uC774\uB514\xB7\uBE44\uBC00\uBC88\uD638\xB7\uC774\uBA54\uC77C \uC785\uB825, \uC571 \uC124\uCE58 \uC548\uB0B4\uAE4C\uC9C0 11\uAC1C \uD654\uBA74",
    section: "Pattern / Mobile Web Signup",
    sectionFillVar: "color/bg/level-3",
    requires: ["Mobile Header", "NavBar", "Checkbox", "Button", "Input", "Select Box", "Modal", "Bottom Sheet", "Bottom Sheet Option"],
    source: {
      fileKey: "cysG5U1udpQqVagYY1hWHW",
      pageId: "173:2431",
      sectionId: "1744:1782",
      capturedAt: "2026-09-02"
    },
    screens: [
      // ── 기본 흐름 ──
      signupScreen("MWEB/SIGNUP/1 \xB7 \uC57D\uAD00 \uC804\uCCB4 \uB3D9\uC758", 80, 100, [
        MH_STD,
        NAV_WEB,
        {
          t: "FRAME",
          n: "Content",
          x: 0,
          y: 149,
          w: 360,
          h: 536,
          clip: true,
          c: [pageTitle("\uC11C\uBE44\uC2A4 \uC57D\uAD00\uC5D0 \n\uB3D9\uC758\uD574 \uC8FC\uC138\uC694", 62), agreements()]
        },
        cta("\uBCF8\uC778 \uC778\uC99D", 614, "Default")
      ]),
      signupScreen("MWEB/SIGNUP/2 \xB7 \uC678\uBD80 \uBCF8\uC778\uC778\uC99D (\uD50C\uB808\uC774\uC2A4\uD640\uB354)", 480, 100, [
        {
          t: "FRAME",
          n: "ExternalAuthPlaceholder",
          sz: ["FIXED", "HUG"],
          w: 320,
          h: 147,
          clip: true,
          r: 8,
          al: ["VERTICAL", 24, 32, 20, 32, 20, "AUTO", "FIXED", "MIN", "CENTER"],
          fillVar: "color/bg/level-0",
          strokeVar: "color/line/gray/subtle",
          strokeW: 1,
          strokeAlign: "INSIDE",
          c: [
            {
              t: "TEXT",
              n: "[\uC678\uBD80 \uBCF8\uC778\uC778\uC99D \uC0AC\uC774\uD2B8 \uD45C\uCD9C]",
              sz: ["HUG", "HUG"],
              w: 171,
              h: 21,
              fillVar: "color/text/body/secondary",
              chars: "[\uC678\uBD80 \uBCF8\uC778\uC778\uC99D \uC0AC\uC774\uD2B8 \uD45C\uCD9C]",
              tar: "WIDTH_AND_HEIGHT",
              ta: ["CENTER", "TOP"],
              ts: "title/16M"
            },
            {
              t: "FRAME",
              n: "PlaceholderActions",
              sz: ["HUG", "HUG"],
              w: 156,
              h: 38,
              clip: true,
              al: ["HORIZONTAL", 8, 0, 0, 0, 0, "AUTO", "AUTO", "MIN", "CENTER"],
              c: [
                {
                  t: "FRAME",
                  n: "PlaceholderAction / \uCDE8\uC18C",
                  sz: ["HUG", "HUG"],
                  w: 74,
                  h: 38,
                  clip: true,
                  r: 6,
                  al: ["HORIZONTAL", 0, 10, 20, 10, 20, "AUTO", "AUTO", "MIN", "CENTER"],
                  fillVar: "color/bg/level-1",
                  strokeVar: "color/line/gray/subtle",
                  strokeW: 1,
                  strokeAlign: "INSIDE",
                  c: [{
                    t: "TEXT",
                    n: "[\uCDE8\uC18C]",
                    sz: ["HUG", "HUG"],
                    w: 34,
                    h: 18,
                    fillVar: "color/text/body/tertiary",
                    chars: "[\uCDE8\uC18C]",
                    tar: "WIDTH_AND_HEIGHT",
                    ta: ["LEFT", "TOP"],
                    ts: "body/14M"
                  }]
                },
                {
                  t: "FRAME",
                  n: "PlaceholderAction / \uB2E4\uC74C",
                  sz: ["HUG", "HUG"],
                  w: 74,
                  h: 38,
                  clip: true,
                  r: 6,
                  al: ["HORIZONTAL", 0, 10, 20, 10, 20, "AUTO", "AUTO", "MIN", "CENTER"],
                  fillVar: "color/bg/level-1",
                  strokeVar: "color/line/gray/subtle",
                  strokeW: 1,
                  strokeAlign: "INSIDE",
                  c: [{
                    t: "TEXT",
                    n: "[\uB2E4\uC74C]",
                    sz: ["HUG", "HUG"],
                    w: 34,
                    h: 18,
                    fillVar: "color/text/body/tertiary",
                    chars: "[\uB2E4\uC74C]",
                    tar: "WIDTH_AND_HEIGHT",
                    ta: ["LEFT", "TOP"],
                    ts: "body/14M"
                  }]
                }
              ]
            }
          ]
        }
      ], ["VERTICAL", 0, 0, 0, 0, 0, "FIXED", "FIXED", "CENTER", "CENTER"]),
      signupScreen("MWEB/SIGNUP/3 \xB7 \uC544\uC774\uB514 \uC785\uB825 \uC911 (\uD0A4\uBCF4\uB4DC)", 880, 100, [
        MH_STD,
        NAV_WEB_KB,
        {
          t: "FRAME",
          n: "Content",
          x: 0,
          y: 149,
          w: 360,
          h: 240,
          clip: true,
          c: [pageTitle("\uC544\uC774\uB514\uB97C\n\uC785\uB825\uD574 \uC8FC\uC138\uC694", 62), idInput()]
        },
        cta("\uD655\uC778", 333, "Default")
      ]),
      signupScreen("MWEB/SIGNUP/4 \xB7 \uBE44\uBC00\uBC88\uD638 \uC785\uB825 \uC911 (\uD0A4\uBCF4\uB4DC)", 1280, 100, [
        MH_STD,
        passwordContent(),
        NAV_WEB_KB,
        cta("\uD655\uC778", 392, "Disabled")
      ]),
      signupScreen("MWEB/SIGNUP/5 \xB7 \uC774\uBA54\uC77C \uC785\uB825 \uC911 (\uD0A4\uBCF4\uB4DC)", 1680, 100, [
        MH_STD,
        NAV_WEB_KB,
        emailContent(),
        cta("\uD655\uC778", 333, "Disabled")
      ]),
      signupScreen("MWEB/SIGNUP/6 \xB7 \uC571 \uC124\uCE58 \uC548\uB0B4", 2080, 100, [
        MH_STD,
        NAV_WEB,
        {
          t: "FRAME",
          n: "App Icon",
          x: 140,
          y: 269,
          w: 80,
          h: 80,
          clip: true,
          r: 20,
          fillVar: "color/bg/level-3",
          c: [{
            t: "TEXT",
            n: "App Icon Label",
            x: 10,
            y: 31,
            w: 60,
            h: 16,
            fillVar: "color/text/body/tertiary",
            chars: "\uC571 \uC544\uC774\uCF58",
            tar: "HEIGHT",
            ta: ["CENTER", "TOP"],
            ts: "body/12R"
          }]
        },
        {
          t: "TEXT",
          n: "Welcome",
          x: 20,
          y: 373,
          w: 320,
          h: 26,
          fillVar: "color/text/state/accent",
          chars: "\uD64D\uAE38\uB3D9\uB2D8, \uD658\uC601\uD569\uB2C8\uB2E4!",
          tar: "HEIGHT",
          ta: ["CENTER", "TOP"],
          ts: "title/20B"
        },
        {
          t: "TEXT",
          n: "Instruction",
          x: 20,
          y: 425,
          w: 320,
          h: 42,
          fillVar: "color/text/title/primary",
          chars: "\uC11C\uBE44\uC2A4\uB97C \uC774\uC6A9\uD558\uC2DC\uB824\uBA74\n\uC571\uC744 \uC124\uCE58\uD574 \uC8FC\uC138\uC694",
          tar: "HEIGHT",
          ta: ["CENTER", "TOP"],
          ts: "body/16R"
        },
        {
          t: "INST",
          n: "Secondary",
          set: "Button",
          x: 20,
          y: 615,
          w: 156,
          h: 48,
          pr: { Size: "LG", State: "Default", Variant: "Secondary", Break: "Mobile" },
          ov: [["0", "\uB2E4\uC74C\uC5D0 \uC124\uCE58"]]
        },
        {
          t: "INST",
          n: "Primary",
          set: "Button",
          x: 184,
          y: 615,
          w: 156,
          h: 48,
          pr: { Size: "LG", State: "Default", Variant: "Primary", Break: "Mobile" },
          ov: [["0", "\uC571 \uC124\uCE58"]]
        }
      ]),
      // ── 분기 ──
      signupScreen("MWEB/SIGNUP/1a1 \xB7 \uD68C\uC6D0 \uC57D\uAD00 \uC0C1\uC138", 80, 1e3, [
        MH_CLOSE,
        NAV_WEB,
        {
          t: "FRAME",
          n: "Content",
          x: 0,
          y: 149,
          w: 360,
          h: 536,
          clip: true,
          c: [
            pageTitle("\uD68C\uC6D0 \uC57D\uAD00 \uB3D9\uC758", 26, "title/20B"),
            {
              t: "TEXT",
              n: "Article Title",
              x: 20,
              y: 58,
              w: 320,
              h: 21,
              fillVar: "color/text/title/primary",
              chars: "\uC81C 1\uC870(\uBAA9\uC801)",
              tar: "HEIGHT",
              ta: ["LEFT", "TOP"],
              ts: "title/16B"
            },
            {
              t: "TEXT",
              n: "Article Body",
              x: 20,
              y: 81,
              w: 320,
              h: 64,
              fillVar: "color/text/title/primary",
              chars: `\uBCF8 \uC57D\uAD00\uC740 '\uC8FC\uC2DD\uD68C\uC0AC \uC5D0\uC2A4\uC6D0(\uC774\uD558 "\uD68C\uC0AC")'\uC5D0\uC11C \uC6B4\uC601\uD558\uB294 '\uC5D0\uC2A4\uC6D0 \uC778\uD130\uB137 \uD648\uD398\uC774\uC9C0 www.s1.co.kr (\uC774\uD558 "\uD648\uD398\uC774\uC9C0")'\uC640 \u2018\uC5D0\uC2A4\uC6D0 \uBAA8\uBC14\uC77C \uC571(\uC774\uD558 "\uBAA8\uBC14\uC77C \uC571")' \uC11C\uBE44\uC2A4\uC758 \uC774\uC6A9 \uBC0F \uC81C\uACF5\uC5D0 \uAD00\uD55C \uC81C\uBC18 \uC0AC\uD56D\uC758 \uADDC\uC815\uC744 \uBAA9\uC801\uC73C\uB85C \uD569\uB2C8\uB2E4.`,
              tar: "HEIGHT",
              ta: ["LEFT", "TOP"],
              ts: "body/12R"
            },
            {
              t: "TEXT",
              n: "Article Title",
              x: 20,
              y: 173,
              w: 320,
              h: 21,
              fillVar: "color/text/title/primary",
              chars: "\uC81C 2\uC870(\uC57D\uAD00\uD6A8\uB825 \uBC0F \uBCC0\uACBD)",
              tar: "HEIGHT",
              ta: ["LEFT", "TOP"],
              ts: "title/16B"
            },
            {
              t: "TEXT",
              n: "Article Body",
              x: 20,
              y: 196,
              w: 320,
              h: 320,
              fillVar: "color/text/title/primary",
              chars: "(1) \uD68C\uC0AC\uB294 \uBCF8 \uC57D\uAD00\uC758 \uB0B4\uC6A9\uC744 \uD68C\uC6D0\uC774 \uC27D\uAC8C \uC54C \uC218 \uC788\uB3C4\uB85D \uD648\uD398\uC774\uC9C0\uC640 \uBAA8\uBC14\uC77C \uC571\uC758 \uCD08\uAE30 \uC11C\uBE44\uC2A4\uD654\uBA74\uC5D0 \uAC8C\uC2DC\uD569\uB2C8\uB2E4.\n(2) \uD68C\uC0AC\uB294 \uC57D\uAD00\uC758 \uADDC\uC81C\uC5D0 \uAD00\uD55C \uBC95\uB960, \uC804\uC790\uBB38\uC11C \uBC0F \uC804\uC790\uAC70\uB798\uAE30\uBCF8\uBC95, \uC804\uC790\uC11C\uBA85\uBC95, \uC815\uBCF4\uD1B5\uC2E0\uB9DD \uC774\uC6A9\uCD09\uC9C4 \uBC0F \uC815\uBCF4\uBCF4\uD638 \uB4F1\uC5D0 \uAD00\uD55C \uBC95\uB960 \uB4F1 \uAD00\uB828\uBC95\uC744 \uC704\uBC30\uD558\uC9C0 \uC54A\uB294 \uBC94\uC704\uC5D0\uC11C \uBCF8 \uC57D\uAD00\uC744 \uAC1C\uC815\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.\n(3) \uD68C\uC0AC\uB294 \uBCF8 \uC57D\uAD00\uC744 \uAC1C\uC815\uD560 \uACBD\uC6B0\uC5D0\uB294 \uC801\uC6A9\uC77C\uC790 \uBC0F \uAC1C\uC815\uC0AC\uC720\uB97C \uBA85\uC2DC\uD558\uC5EC \uD604\uD589 \uC57D\uAD00\uACFC \uD568\uAED8 \uD68C\uC0AC\uAC00 \uC81C\uACF5\uD558\uB294 \uC11C\uBE44\uC2A4 \uC0AC\uC774\uD2B8\uC758 \uCD08\uAE30 \uD654\uBA74\uC5D0 \uADF8 \uC801\uC6A9\uC77C\uC790 7\uC77C \uC774\uC804\uBD80\uD130 \uC801\uC6A9\uC77C\uC790 \uC804\uC77C\uAE4C\uC9C0 \uACF5\uC9C0\uD569\uB2C8\uB2E4.\n\uB2E4\uB9CC, \uD68C\uC6D0\uC5D0\uAC8C \uBD88\uB9AC\uD558\uAC8C \uC57D\uAD00\uB0B4\uC6A9\uC744 \uBCC0\uACBD\uD558\uB294 \uACBD\uC6B0\uC5D0\uB294 \uCD5C\uC18C\uD55C 30\uC77C \uC774\uC0C1\uC758 \uC0AC\uC804 \uC720\uC608\uAE30\uAC04\uC744 \uB450\uACE0 \uACF5\uC9C0\uD569\uB2C8\uB2E4. \uC774 \uACBD\uC6B0 \uD68C\uC0AC\uB294 \uAC1C\uC815 \uC804 \uB0B4\uC6A9\uACFC \uAC1C\uC815 \uD6C4 \uB0B4\uC6A9\uC744 \uBA85\uD655\uD558\uAC8C \uBE44\uAD50\uD558\uC5EC \uD68C\uC6D0\uC774 \uC54C\uAE30 \uC27D\uB3C4\uB85D \uD45C\uC2DC\uD569\uB2C8\uB2E4.\n(4) \uD68C\uC6D0\uC740 \uAC1C\uC815\uB41C \uC57D\uAD00\uC5D0 \uB300\uD574 \uAC70\uBD80\uD560 \uAD8C\uB9AC\uAC00 \uC788\uC2B5\uB2C8\uB2E4. \uD68C\uC6D0\uC740 \uAC1C\uC815\uB41C \uC57D\uAD00\uC5D0 \uB3D9\uC758\uD558\uC9C0 \uC54A\uC744 \uACBD\uC6B0 \uC11C\uBE44\uC2A4 \uC774\uC6A9\uC744 \uC911\uB2E8\uD558\uACE0 \uD68C\uC6D0\uC744 \uD0C8\uD1F4\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.\n\uB2E8, \uAC1C\uC815\uB41C \uC57D\uAD00\uC758 \uD6A8\uB825 \uBC1C\uC0DD\uC77C \uC774\uD6C4\uC5D0\uB3C4 \uC11C\uBE44\uC2A4\uB97C \uACC4\uC18D \uC774\uC6A9\uD560 \uACBD\uC6B0\uC5D0\uB294 \uC57D\uAD00\uC758 \uBCC0\uACBD\uC0AC\uD56D\uC5D0 \uB3D9\uC758\uD55C \uAC83\uC73C\uB85C \uAC04\uC8FC\uD569\uB2C8\uB2E4.\n(5) \uBCF8 \uC870\uC5D0 \uB530\uB77C \uD68C\uC0AC\uAC00 \uBCC0\uACBD\uB41C \uC57D\uAD00\uC758 \uB0B4\uC6A9\uC744 \uACF5\uC9C0\uD558\uC600\uC74C\uC5D0\uB3C4 \uBCC0\uACBD\uB41C \uC57D\uAD00\uC5D0 \uB300\uD55C \uC815\uBCF4\uB97C \uC54C\uC9C0 \uBABB\uD574 \uBC1C\uC0DD\uD558\uB294 \uD68C\uC6D0\uC758 \uD53C\uD574\uB294 \uD68C\uC0AC\uAC00 \uCC45\uC784\uC9C0\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.",
              tar: "HEIGHT",
              ta: ["LEFT", "TOP"],
              ts: "body/12R"
            }
          ]
        }
      ]),
      signupScreen("MWEB/SIGNUP/2a1 \xB7 \uAC00\uC785 \uD68C\uC6D0 \uC548\uB0B4 (\uBAA8\uB2EC)", 480, 1e3, [
        MH_STD,
        NAV_WEB,
        {
          t: "FRAME",
          n: "Content",
          x: 0,
          y: 149,
          w: 360,
          h: 536,
          clip: true,
          c: [pageTitle("\uC11C\uBE44\uC2A4 \uC57D\uAD00\uC5D0 \n\uB3D9\uC758\uD574 \uC8FC\uC138\uC694", 62), agreements()]
        },
        cta("\uBCF8\uC778 \uC778\uC99D", 614, "Default"),
        dim(685),
        {
          t: "INST",
          n: "Mobile Modal",
          set: "Modal",
          x: 30,
          y: 286,
          w: 300,
          h: 208,
          pr: { Break: "Mobile", Footer: "Dual" },
          ov: [["0.0", "\uC774\uBBF8 \uD68C\uC6D0\uC73C\uB85C \uAC00\uC785\uB418\uC5B4 \uC788\uC2B5\uB2C8\uB2E4.\n\uC544\uC774\uB514 : abcdefg"], ["1.0.0", "\uCDE8\uC18C"], ["1.1.0", "\uD655\uC778"]],
          szOv: [["0", "FIXED", "FIXED"], ["0.0", "FIXED", "HUG"]]
        },
        closeIcon(282, 265)
      ]),
      signupScreen("MWEB/SIGNUP/2b1 \xB7 \uAE30\uC874 \uC544\uC774\uB514 \uC120\uD0DD (\uBC14\uD140\uC2DC\uD2B8)", 880, 1e3, [
        MH_STD,
        {
          t: "FRAME",
          n: "Content",
          x: 0,
          y: 149,
          w: 360,
          h: 240,
          clip: true,
          c: [pageTitle("\uC544\uC774\uB514\uB97C\n\uC785\uB825\uD574 \uC8FC\uC138\uC694", 62), idInput()]
        },
        cta("\uD655\uC778", 333, "Default"),
        dim(735),
        NAV_WEB_KB,
        {
          t: "INST",
          n: "Bottom Sheet",
          set: "Bottom Sheet",
          x: 0,
          y: 402,
          w: 360,
          h: 378,
          pr: { Footer: "Dual" },
          ov: [["0.0.0", "\uAE30\uC874 \uC544\uC774\uB514\uB97C \uC0AC\uC6A9\uD558\uC2DC\uACA0\uC5B4\uC694?"], ["1.0.0", "\uC0C8 \uC544\uC774\uB514 \uC0AC\uC6A9"], ["1.1.0", "\uC544\uC774\uB514 \uC120\uD0DD"]],
          szOv: [["0", "FILL", "FIXED"]]
        },
        {
          t: "FRAME",
          n: "Bottom Sheet Extension",
          x: 0,
          y: 456,
          w: 360,
          h: 256,
          al: ["VERTICAL", 0, 0, 0, 0, 0, "FIXED", "FIXED", "MIN", "MIN"],
          c: [
            {
              t: "TEXT",
              n: "Bottom Sheet Description",
              x: 20,
              y: 0,
              abs: true,
              sz: ["FIXED", "FIXED"],
              w: 320,
              h: 42,
              fillVar: "color/text/body/tertiary",
              chars: "\uD648\uD398\uC774\uC9C0 \uB610\uB294 \uC6F9\uBDF0\uC5B4\uC5D0 \uC785\uB825\uD558\uC2E0 \uC815\uBCF4\uB85C \uAC00\uC785\uB41C \uC544\uC774\uB514\uAC00 \uC788\uC5B4\uC694. \uAE30\uC874 \uC544\uC774\uB514\uB97C \uC0AC\uC6A9\uD558\uACE0 \uC2F6\uC73C\uC2DC\uBA74 \uC544\uB798\uC5D0\uC11C \uC120\uD0DD\uD574 \uC8FC\uC138\uC694.",
              tar: "NONE",
              ta: ["LEFT", "TOP"],
              ts: "body/16R"
            },
            {
              t: "INST",
              n: "Bottom Sheet Option",
              set: "Bottom Sheet Option",
              x: 0,
              y: 64,
              abs: true,
              sz: ["FIXED", "FIXED"],
              w: 360,
              h: 48,
              pr: { Type: "Text", State: "Selected" },
              ov: [["0", "s1secom1"]]
            },
            {
              t: "INST",
              n: "Bottom Sheet Option",
              set: "Bottom Sheet Option",
              x: 0,
              y: 112,
              abs: true,
              sz: ["FIXED", "FIXED"],
              w: 360,
              h: 48,
              pr: { Type: "Text", State: "Default" },
              ov: [["0", "s1secom2"]]
            },
            {
              t: "INST",
              n: "Bottom Sheet Option",
              set: "Bottom Sheet Option",
              x: 0,
              y: 160,
              abs: true,
              sz: ["FIXED", "FIXED"],
              w: 360,
              h: 48,
              pr: { Type: "Text", State: "Default" },
              ov: [["0", "s1secom3"]]
            },
            {
              t: "INST",
              n: "Bottom Sheet Option",
              set: "Bottom Sheet Option",
              x: 0,
              y: 208,
              abs: true,
              sz: ["FIXED", "FIXED"],
              w: 360,
              h: 48,
              pr: { Type: "Text", State: "Disabled" },
              ov: [["0", "s1secom4(\uC774\uBBF8 \uC0AC\uC6A9\uC911\uC778 \uC544\uC774\uB514)"]]
            }
          ]
        }
      ]),
      signupScreen("MWEB/SIGNUP/4a1 \xB7 \uBE44\uBC00\uBC88\uD638 \uC870\uAC74 \uC548\uB0B4 (\uB2E4\uC774\uC5BC\uB85C\uADF8)", 1280, 1e3, [
        MH_STD,
        passwordContent(),
        cta("\uD655\uC778", 392, "Disabled"),
        dim(735),
        NAV_WEB_KB,
        {
          t: "INST",
          n: "Mobile Modal",
          set: "Modal",
          x: 30,
          y: 220,
          w: 300,
          h: 293,
          pr: { Break: "Mobile", Footer: "Single" },
          ov: [
            ["0.0", "\uBE44\uBC00\uBC88\uD638 \uC870\uAC74"],
            ["0.1.0", "\u2022 \uC601\uBB38(\uB300\uC18C\uBB38\uC790 \uAD6C\uBD84), \uC22B\uC790, \uD2B9\uC218\uBB38\uC790 \uC870\uD569\uD558\uC5EC 8~15\uC790\n\u2022 \uD2B9\uC218\uBB38\uC790 !@#$%^&* \uC0AC\uC6A9 \uAC00\uB2A5\n\u2022 3\uC790 \uC774\uC0C1 \uC5F0\uC18D\uB41C \uC22B\uC790\xB7\uBB38\uC790 \uC0AC\uC6A9(\uC608: 123, abc) \uBD88\uAC00\n\u2022 \uC0DD\uC77C, \uC804\uD654\uBC88\uD638, \uC544\uC774\uB514 \uC0AC\uC6A9 \uBBF8\uAD8C\uC7A5"],
            ["1.0.0", "\uD655\uC778"]
          ],
          szOv: [["0.1.0", "FIXED", "HUG"]]
        },
        closeIcon(282, 244)
      ]),
      signupScreen("MWEB/SIGNUP/5a1 \xB7 \uC774\uBA54\uC77C \uB3C4\uBA54\uC778 \uC120\uD0DD (\uBC14\uD140\uC2DC\uD2B8)", 1680, 1e3, [
        MH_STD,
        emailContent(),
        cta("\uD655\uC778", 333, "Disabled"),
        dim(735),
        NAV_WEB_KB,
        {
          t: "INST",
          n: "Bottom Sheet",
          set: "Bottom Sheet",
          x: 0,
          y: 394,
          w: 360,
          h: 302,
          pr: { Footer: "None" },
          ov: [
            ["0.0.0", "\uC774\uBA54\uC77C"],
            ["0.1.0.0", "naver.com"],
            ["0.1.1.0", "kakao.com"],
            ["0.1.2.0", "gmail.com"],
            ["0.1.3.0", "nate.com"]
          ]
        },
        {
          t: "INST",
          n: "Bottom Sheet Option",
          set: "Bottom Sheet Option",
          x: 0,
          y: 654,
          w: 360,
          h: 48,
          pr: { Type: "Text", State: "Default" },
          ov: [["0", "\uC9C1\uC811 \uC785\uB825"]]
        }
      ])
    ]
  };
  var PATTERNS = [MOBILE_LOGIN, MOBILE_WEB_SIGNUP];

  // plugins/figma-vars-installer/src/build-patterns.ts
  var loadedFonts = /* @__PURE__ */ new Set();
  async function loadFont(f) {
    const key = `${f.family}__${f.style}`;
    if (loadedFonts.has(key)) return true;
    try {
      await figma.loadFontAsync(f);
      loadedFonts.add(key);
      return true;
    } catch (e) {
      return false;
    }
  }
  async function loadFontsOf(node) {
    const fonts = [];
    try {
      for (const s of node.getStyledTextSegments(["fontName"])) fonts.push(s.fontName);
    } catch (e) {
    }
    if (fonts.length === 0 && node.fontName !== figma.mixed) fonts.push(node.fontName);
    for (const f of fonts) await loadFont(f);
  }
  function bindFill(node, maps, varName, warnings) {
    const v = maps.colorVars[varName];
    if (!v) {
      warnings.push(`\uC0C9 \uBCC0\uC218\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${varName} (${node.name})`);
      return;
    }
    try {
      const base = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
      const bound = figma.variables.setBoundVariableForPaint(base, "color", v);
      node.fills = [bound];
    } catch (e) {
      warnings.push(`\uC0C9 \uC5F0\uACB0 \uC2E4\uD328: ${varName} (${node.name}) \u2014 ${e.message}`);
    }
  }
  function bindStroke(node, maps, varName, warnings) {
    const v = maps.colorVars[varName];
    if (!v) {
      warnings.push(`\uD14C\uB450\uB9AC \uC0C9 \uBCC0\uC218\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${varName} (${node.name})`);
      return;
    }
    try {
      const base = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
      const bound = figma.variables.setBoundVariableForPaint(base, "color", v);
      node.strokes = [bound];
    } catch (e) {
      warnings.push(`\uD14C\uB450\uB9AC \uC0C9 \uC5F0\uACB0 \uC2E4\uD328: ${varName} (${node.name}) \u2014 ${e.message}`);
    }
  }
  function childAt(root, path) {
    let cur = root;
    for (const part of path.split(".")) {
      const i = Number(part);
      const kids = cur.children;
      if (!kids || !kids[i]) return null;
      cur = kids[i];
    }
    return cur;
  }
  async function applyOverrides(inst, ov, warnings) {
    for (const [path, value] of ov) {
      const target = childAt(inst, path);
      if (!target) {
        warnings.push(`\uB36E\uC5B4\uC4F8 \uC790\uB9AC\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${inst.name} / ${path}`);
        continue;
      }
      if (value === null) {
        target.visible = false;
        continue;
      }
      if (target.type !== "TEXT") {
        warnings.push(`\uAE00\uC790 \uC790\uB9AC\uAC00 \uC544\uB2D9\uB2C8\uB2E4: ${inst.name} / ${path} (${target.type})`);
        continue;
      }
      await loadFontsOf(target);
      try {
        target.characters = value;
      } catch (e) {
        warnings.push(`\uAE00\uC790\uB97C \uB123\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${inst.name} / ${path} \u2014 ${e.message}`);
      }
    }
  }
  function applySizeOverrides(inst, szOv, warnings) {
    for (const entry of szOv) {
      const path = entry[0];
      const h = entry[1];
      const v = entry[2];
      const w = entry[3];
      const ht = entry[4];
      const target = childAt(inst, path);
      if (!target) {
        warnings.push(`\uD06C\uAE30\uB97C \uBC14\uAFC0 \uC790\uB9AC\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${inst.name} / ${path}`);
        continue;
      }
      if (!("layoutSizingHorizontal" in target)) {
        warnings.push(`\uD06C\uAE30\uB97C \uBC14\uAFC0 \uC218 \uC5C6\uB294 \uC790\uB9AC\uC785\uB2C8\uB2E4: ${inst.name} / ${path} (${target.type})`);
        continue;
      }
      try {
        if (w !== void 0 || ht !== void 0) {
          target.resize(w === void 0 ? target.width : w, ht === void 0 ? target.height : ht);
        }
        target.layoutSizingHorizontal = h;
        target.layoutSizingVertical = v;
      } catch (e) {
        warnings.push(`\uD06C\uAE30 \uBC29\uC2DD\uC744 \uBC14\uAFB8\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${inst.name} / ${path} \u2014 ${e.message}`);
      }
    }
  }
  async function makeInstance(spec, maps, warnings) {
    if (spec.remote && spec.key) {
      try {
        const comp2 = await figma.importComponentByKeyAsync(spec.key);
        return comp2.createInstance();
      } catch (e) {
        warnings.push(`\uC678\uBD80 \uBD80\uD488\uC744 \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.n} \u2014 ${e.message}`);
        return null;
      }
    }
    const set = maps.sets[spec.set];
    if (!set) {
      warnings.push(`\uCEF4\uD3EC\uB10C\uD2B8\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.set} (${spec.n})`);
      return null;
    }
    let defs = {};
    try {
      defs = set.componentPropertyDefinitions;
    } catch (e) {
    }
    const keyByName = {};
    const typeByName = {};
    for (const key of Object.keys(defs)) {
      const name = key.split("#")[0];
      keyByName[name] = key;
      typeByName[name] = defs[key].type;
    }
    const knownDefs = Object.keys(defs).length > 0;
    const pr = spec.pr || {};
    const variantWanted = {};
    const otherWanted = {};
    for (const name of Object.keys(pr)) {
      if (knownDefs && !typeByName[name]) {
        warnings.push(`\uC9C0\uAE08 \uBD80\uD488\uC5D0 \uC5C6\uB294 \uC18D\uC131\uC774\uB77C \uAC74\uB108\uB6F0\uC5C8\uC2B5\uB2C8\uB2E4: ${spec.set} \xB7 ${name} (${spec.n})`);
        continue;
      }
      const t = typeByName[name] || (typeof pr[name] === "string" ? "VARIANT" : "BOOLEAN");
      if (t === "VARIANT") variantWanted[name] = String(pr[name]);
      else otherWanted[keyByName[name] || name] = pr[name];
    }
    const comp = set.children.find((c) => {
      if (c.type !== "COMPONENT") return false;
      const vp = c.variantProperties || {};
      return Object.keys(variantWanted).every((k) => vp[k] === variantWanted[k]);
    });
    if (!comp) {
      const want = Object.keys(variantWanted).map((k) => `${k}=${variantWanted[k]}`).join(", ");
      warnings.push(`\uBCC0\uD615\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.set} (${want})`);
      return null;
    }
    const inst = comp.createInstance();
    if (Object.keys(otherWanted).length) {
      try {
        inst.setProperties(otherWanted);
      } catch (e) {
        warnings.push(`\uC18D\uC131\uC744 \uAC78\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.n} \u2014 ${e.message}`);
      }
    }
    return inst;
  }
  async function makeText(spec, maps, warnings) {
    const t = figma.createText();
    const style = spec.ts ? maps.textStyles[spec.ts] : void 0;
    if (spec.ts && !style) warnings.push(`\uAE00\uC790 \uC2A4\uD0C0\uC77C\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.ts} (${spec.n})`);
    const font = style ? style.fontName : { family: "Pretendard", style: "Regular" };
    const ok = await loadFont(font);
    if (!ok) warnings.push(`\uD3F0\uD2B8\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${font.family} ${font.style} (${spec.n})`);
    if (style) {
      try {
        await t.setTextStyleIdAsync(style.id);
      } catch (e) {
        warnings.push(`\uAE00\uC790 \uC2A4\uD0C0\uC77C\uC744 \uC801\uC6A9\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.ts} (${spec.n})`);
      }
    } else if (ok) {
      t.fontName = font;
    }
    await loadFontsOf(t);
    try {
      if (spec.tar) t.textAutoResize = spec.tar;
      if (spec.ta) {
        t.textAlignHorizontal = spec.ta[0];
        t.textAlignVertical = spec.ta[1];
      }
    } catch (e) {
      warnings.push(`\uAE00\uC790 \uC815\uB82C\uC744 \uAC78\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.n} \u2014 ${e.message}`);
    }
    try {
      if (spec.chars !== void 0) t.characters = spec.chars;
    } catch (e) {
      warnings.push(`\uAE00\uC790\uB97C \uB123\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.n} \u2014 ${e.message}`);
    }
    return t;
  }
  async function renderNode(spec, parent, parentAuto, maps, warnings) {
    let node = null;
    if (spec.t === "INST") node = await makeInstance(spec, maps, warnings);
    else if (spec.t === "TEXT") node = await makeText(spec, maps, warnings);
    else if (spec.t === "RECT") node = figma.createRectangle();
    else node = figma.createFrame();
    if (!node) return null;
    node.name = spec.n;
    parent.appendChild(node);
    if (spec.abs && "layoutPositioning" in node) node.layoutPositioning = "ABSOLUTE";
    if (spec.al && node.type === "FRAME") {
      const [mode, gap, pt, pr, pb, pl, pri, ctr, pa, ca] = spec.al;
      node.layoutMode = mode;
      node.itemSpacing = gap;
      node.paddingTop = pt;
      node.paddingRight = pr;
      node.paddingBottom = pb;
      node.paddingLeft = pl;
      node.primaryAxisSizingMode = pri;
      node.counterAxisSizingMode = ctr;
      node.primaryAxisAlignItems = pa;
      node.counterAxisAlignItems = ca;
    }
    if (spec.w !== void 0 && spec.h !== void 0 && "resize" in node) {
      const hHug = spec.sz && spec.sz[0] === "HUG";
      const vHug = spec.sz && spec.sz[1] === "HUG";
      const w = hHug ? node.width : spec.w;
      const h = vHug ? node.height : spec.h;
      try {
        node.resize(w, h);
      } catch (e) {
        warnings.push(`\uD06C\uAE30\uB97C \uB9DE\uCD94\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${spec.n} \u2014 ${e.message}`);
      }
    }
    if ((!parentAuto || spec.abs) && spec.x !== void 0 && spec.y !== void 0) {
      node.x = spec.x;
      node.y = spec.y;
    }
    if (spec.sz && "layoutSizingHorizontal" in node && (parentAuto || spec.abs)) {
      try {
        if (!spec.abs) {
          node.layoutSizingHorizontal = spec.sz[0];
          node.layoutSizingVertical = spec.sz[1];
        }
      } catch (e) {
        warnings.push(`\uB298\uB9BC/\uC904\uC784 \uC124\uC815 \uC2E4\uD328: ${spec.n} \u2014 ${e.message}`);
      }
    }
    if (node.type !== "INSTANCE" && "clipsContent" in node) node.clipsContent = spec.clip === true;
    if (spec.r !== void 0 && "cornerRadius" in node) node.cornerRadius = spec.r;
    if (spec.fillVar) bindFill(node, maps, spec.fillVar, warnings);
    else if (spec.t === "FRAME" || spec.t === "RECT") node.fills = [];
    else if (spec.t === "TEXT") warnings.push(`\uAE00\uC790\uC0C9\uC774 \uD1A0\uD070\uC5D0 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4: ${spec.n}`);
    if (spec.strokeVar) {
      bindStroke(node, maps, spec.strokeVar, warnings);
      if (spec.strokeW !== void 0) node.strokeWeight = spec.strokeW;
      if (spec.strokeAlign) node.strokeAlign = spec.strokeAlign;
    }
    if (spec.t === "INST" && spec.szOv && spec.szOv.length) {
      applySizeOverrides(node, spec.szOv, warnings);
    }
    if (spec.t === "INST" && spec.ov && spec.ov.length) {
      await applyOverrides(node, spec.ov, warnings);
    }
    if (spec.c && "appendChild" in node) {
      const auto = spec.al !== void 0;
      for (const child of spec.c) {
        await renderNode(child, node, auto, maps, warnings);
      }
    }
    return node;
  }
  function uniqueSectionName(page, base) {
    const used = new Set(page.children.map((c) => c.name));
    if (!used.has(base)) return base;
    let i = 2;
    while (used.has(`${base} ${i}`)) i++;
    return `${base} ${i}`;
  }
  async function buildPattern(def, page, maps, onProgress) {
    const warnings = [];
    const missing = def.requires.filter((name) => !maps.sets[name]);
    if (missing.length) {
      throw new Error(
        `\uC774 \uD328\uD134\uC5D0 \uD544\uC694\uD55C \uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4: ${missing.join(", ")}
\uBA3C\uC800 '\uAC00\uC774\uB4DC\uC124\uCE58' \uD0ED\uC5D0\uC11C \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uC124\uCE58\uD55C \uB4A4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.`
      );
    }
    const section = figma.createSection();
    section.name = uniqueSectionName(page, def.section);
    page.appendChild(section);
    const sectionVar = def.sectionFillVar || "color/bg/level-3";
    bindFill(section, maps, sectionVar, warnings);
    try {
      const f = section.fills;
      const bound = Array.isArray(f) && f.length > 0 && f.every((p) => p.type === "SOLID" && !!p.boundVariables && !!p.boundVariables.color);
      if (!bound) {
        section.fills = [];
        warnings.push(`\uC139\uC158 \uBC14\uD0D5\uC0C9\uC744 \uD1A0\uD070(${sectionVar})\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD574 \uC0C9 \uC5C6\uC774 \uB450\uC5C8\uC2B5\uB2C8\uB2E4: ${section.name}`);
      }
    } catch (e) {
    }
    try {
      const st = section.strokes;
      if (Array.isArray(st) && st.length > 0) {
        bindStroke(section, maps, "color/line/gray/subtle", warnings);
        const after = section.strokes;
        const bound = Array.isArray(after) && after.length > 0 && after.every((p) => p.type === "SOLID" && !!p.boundVariables && !!p.boundVariables.color);
        if (!bound) {
          section.strokes = [];
          warnings.push(`\uC139\uC158 \uD14C\uB450\uB9AC\uC0C9\uC744 \uD1A0\uD070\uC5D0 \uC5F0\uACB0\uD558\uC9C0 \uBABB\uD574 \uC120 \uC5C6\uC774 \uB450\uC5C8\uC2B5\uB2C8\uB2E4: ${section.name}`);
        }
      }
    } catch (e) {
    }
    let maxX = 0, maxY = 0;
    for (const s of def.screens) {
      if (s.x + 360 > maxX) maxX = s.x + 360;
      if (s.y + 780 > maxY) maxY = s.y + 780;
    }
    section.resizeWithoutConstraints(maxX + 80, maxY + 100);
    const GAP = 220;
    let top = 200;
    for (const other of page.children) {
      if (other.id === section.id) continue;
      const bottom = other.y + other.height + GAP;
      if (bottom > top) top = bottom;
    }
    section.x = 200;
    section.y = top;
    let done = 0;
    for (const screen2 of def.screens) {
      if (onProgress) onProgress(done, def.screens.length, screen2.name);
      await renderScreen(screen2, section, maps, warnings);
      done++;
    }
    if (onProgress) onProgress(done, def.screens.length, "");
    for (const spot of sweepRawPaints(section)) {
      warnings.push(`\uD1A0\uD070\uC5D0 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC740 \uC0C9\uC774 \uB0A8\uC558\uC2B5\uB2C8\uB2E4: ${spot}`);
    }
    return { sectionId: section.id, screenCount: def.screens.length, warnings };
  }
  async function renderScreen(screen2, section, maps, warnings) {
    const frame = await renderNode(screen2.root, section, false, maps, warnings);
    if (frame) {
      frame.x = screen2.x;
      frame.y = screen2.y;
    }
  }

  // plugins/figma-vars-installer/src/legacy-map-data.ts
  var LEGACY_MAP = [
    {
      "source": "A",
      "set": "pc_button",
      "setId": "540:4440",
      "role": "PC \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Button"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "medium"
            }
          ],
          "set": "Button",
          "then": {
            "Size": "MD"
          },
          "from": "medium"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xsmall"
            }
          ],
          "set": "Button",
          "then": {
            "Size": "XSM"
          },
          "from": "xsmall"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xxsmall"
            }
          ],
          "set": "Button",
          "then": {
            "Size": "XXSM"
          },
          "from": "xxsmall"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "primary"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Primary"
          },
          "from": "primary"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "secondary"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Secondary"
          },
          "from": "secondary"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "blue-line"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Blue-Line"
          },
          "from": "blue-line"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "icon=on/off \uB294 \uC815\uBCF8\uC5D0\uC11C \uC544\uC774\uCF58 \uBD80\uD488 \uC720\uBB34 \xB7 \uC815\uBCF8 pressed \uC0C1\uD0DC\xB7lg \uD06C\uAE30\uB294 \uC774 \uC138\uD2B8\uC5D0 \uC5C6\uC74C"
    },
    {
      "source": "A",
      "set": "mobile_button",
      "setId": "540:4626",
      "role": "\uBAA8\uBC14\uC77C \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Button"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "pressed"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Pressed"
          },
          "from": "pressed"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "primary"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Primary"
          },
          "from": "primary"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "secondary"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Secondary"
          },
          "from": "secondary"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "blue-line"
            }
          ],
          "set": "Button",
          "then": {
            "Variant": "Blue-Line"
          },
          "from": "blue-line"
        }
      ],
      "notes": [
        {
          "from": "mobile",
          "then": {
            "Size": "LG",
            "Break": "Mobile"
          },
          "set": "Button"
        }
      ],
      "basis": [
        {
          "id": "D-12",
          "what": "\uBAA8\uBC14\uC77C \uBC84\uD2BC \uD06C\uAE30",
          "quote": "\uC815\uBCF8\uB300\uB85C \uD655\uC815 \u2014 \uBAA8\uBC14\uC77C \uBC84\uD2BC = LG\xB7Mobile"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "default",
      "setId": "16:1880",
      "role": "PC \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Button"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "pressed",
              "value": "on"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Pressed"
          },
          "from": "pressed=on"
        },
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-21",
          "what": "B\uD30C\uC77C \uBC84\uD2BC \uC0C9 \uC774\uB984",
          "quote": "mix\uB294 \uBC84\uD2BC \uB450\uAC1C\uAC00 \uBAA8\uB4C8\uB85C\uC788\uB294 \uC720\uD615\uC774\uBA70, \uBCC0\uD658\uC2DC \uD558\uC704 \uB450\uAC1C \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\uACFC \uD06C\uAE30\uC5D0  \uB9DE\uAC8C \uBCC0\uD615\uB418\uB3C4\uB85D \uD574\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4.",
      "note": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4."
    },
    {
      "source": "B",
      "set": "m_button",
      "setId": "307:8861",
      "role": "\uBAA8\uBC14\uC77C \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Button"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "pressed",
              "value": "on"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Pressed"
          },
          "from": "pressed=on"
        },
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Button",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-21",
          "what": "B\uD30C\uC77C \uBC84\uD2BC \uC0C9 \uC774\uB984",
          "quote": "mix\uB294 \uBC84\uD2BC \uB450\uAC1C\uAC00 \uBAA8\uB4C8\uB85C\uC788\uB294 \uC720\uD615\uC774\uBA70, \uBCC0\uD658\uC2DC \uD558\uC704 \uB450\uAC1C \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\uACFC \uD06C\uAE30\uC5D0  \uB9DE\uAC8C \uBCC0\uD615\uB418\uB3C4\uB85D \uD574\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4.",
      "note": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4."
    },
    {
      "source": "B",
      "set": "m_subbutton",
      "setId": "1744:8493",
      "role": "\uBAA8\uBC14\uC77C \uBCF4\uC870 \uBC84\uD2BC",
      "kind": "not-a-part",
      "status": "legacy-only",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-13",
          "what": "\uBCF4\uC870 \uBC84\uD2BC\xB7\uD14D\uC2A4\uD2B8 \uBC84\uD2BC",
          "quote": "\uC815\uBCF8\uC5D0 \uCD94\uAC00\uD558\uB294 \uC791\uC5C5 \uCD94\uD6C4 \uC9C4\uD589\uD574\uC57C\uD568"
        }
      ],
      "why": "\uBAA8\uBC14\uC77C \uC11C\uBE0C\uBC84\uD2BC\uC740 \uC774\uBC88 \uBC94\uC704 \uBC16 \u2014 \uBCC4\uAC74(2026-09-08 river)",
      "note": ""
    },
    {
      "source": "A",
      "set": "checkbox",
      "setId": "540:3134",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Checkbox"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "checked"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Checked"
          },
          "from": "checked"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "label=on/off \uB294 \uC815\uBCF8\uC758 \uC120\uD0DD \uBD80\uD488(\uB77C\uBCA8) \uC720\uBB34 \xB7 \uC815\uBCF8 hover \uB294 \uB808\uAC70\uC2DC\uC5D0 \uC5C6\uC74C"
    },
    {
      "source": "B",
      "set": "checkbox",
      "setId": "42:3313",
      "role": "\uCCB4\uD06C\uBC15\uC2A4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Checkbox"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "checked",
              "value": "on"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Checked"
          },
          "from": "checked=on,disabled=off"
        },
        {
          "when": [
            {
              "axis": "checked",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Disabled"
          },
          "from": "checked=off,disabled=on"
        },
        {
          "when": [
            {
              "axis": "checked",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Default"
          },
          "from": "checked=off,disabled=off"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC2A4\uC704\uCE58 2\uAC1C \uC870\uD569 \u2192 \uC815\uBCF8\uC740 \uC0C1\uD0DC \uD558\uB098\uB85C \uD1B5\uD569"
    },
    {
      "source": "B",
      "set": "m_checkbox",
      "setId": "109:24686",
      "role": "\uBAA8\uBC14\uC77C \uCCB4\uD06C\uBC15\uC2A4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Checkbox"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "checked",
              "value": "on"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Checked"
          },
          "from": "checked=on,disabled=off"
        },
        {
          "when": [
            {
              "axis": "checked",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Disabled"
          },
          "from": "checked=off,disabled=on"
        },
        {
          "when": [
            {
              "axis": "checked",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Checkbox",
          "then": {
            "State": "Default"
          },
          "from": "checked=off,disabled=off"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8\uC740 PC/\uBAA8\uBC14\uC77C \uAD6C\uBD84 \uC5C6\uC774 checkbox \uD558\uB098"
    },
    {
      "source": "A",
      "set": "chip",
      "setId": "540:3189",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Chip"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-sm"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "SM"
          },
          "from": "pc-sm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "mobile"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "SM",
            "Break": "Mobile"
          },
          "from": "mobile"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "line"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Line"
          },
          "from": "line"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "solid"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Solid"
          },
          "from": "solid"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-01",
          "what": "\uCE69\uC758 \uBAA8\uBC14\uC77C \uD06C\uAE30",
          "quote": "\uC815\uBCF8\uB300\uB85C \uD655\uC815 \u2014 mobile = SM\xB7Mobile"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_chips",
      "setId": "1747:9127",
      "role": "\uBAA8\uBC14\uC77C \uCE69",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Chip"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "checked",
              "value": "on"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Selected"
          },
          "from": "checked=on"
        },
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        },
        {
          "when": [
            {
              "axis": "solid",
              "value": "on"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Solid"
          },
          "from": "solid=on"
        },
        {
          "when": [
            {
              "axis": "solid",
              "value": "off"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Line"
          },
          "from": "solid=off"
        }
      ],
      "notes": [
        {
          "from": "mobile",
          "then": {
            "Size": "SM",
            "Break": "Mobile"
          },
          "set": "Chip"
        }
      ],
      "basis": [
        {
          "id": "D-01",
          "what": "\uCE69\uC758 \uBAA8\uBC14\uC77C \uD06C\uAE30",
          "quote": "\uC815\uBCF8\uB300\uB85C \uD655\uC815 \u2014 mobile = SM\xB7Mobile"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "datepicker_input",
      "setId": "540:3794",
      "role": "\uB0A0\uC9DC \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Date Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "completed"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Open"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Date Picker",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xsm"
            }
          ],
          "set": "Date Picker",
          "then": {
            "Size": "XSM"
          },
          "from": "pc-xsm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xxsm"
            }
          ],
          "set": "Date Picker",
          "then": {
            "Size": "XXSM"
          },
          "from": "pc-xxsm"
        }
      ],
      "notes": [
        {
          "from": "editing(day)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "editing(month)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "editing(year)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        }
      ],
      "basis": [
        {
          "id": "D-10",
          "what": "\uB0A0\uC9DC \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "selected = open(\uB2EC\uB825 \uC5F4\uB9BC) \xB7 editing 3\uC885 = \uBAA8\uB450 open \xB7 completed = filled"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "mobile_datepicker_bottomsheet",
      "setId": "540:3835",
      "role": "\uBAA8\uBC14\uC77C \uB0A0\uC9DC \uBC14\uD140\uC2DC\uD2B8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Bottom Sheet",
        "Bottom Sheet Option",
        "Date Picker Mobile Bottom Sheet",
        "Time Picker Mobile Bottom Sheet"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-05",
          "what": "\uBC14\uD140\uC2DC\uD2B8",
          "quote": "\uBC14\uD140\uC2DC\uD2B8 \uC815\uBCF8\uC5D0 \uC788\uC73C\uB2C8 \uCC3E\uC544\uBCFC\uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "DatePicker/Calendar Cell",
      "setId": "540:4167",
      "role": "\uB2EC\uB825 \uB0A0\uC9DC \uCE78",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Calendar Cell",
        "Calendar Tile",
        "Calendar"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "range"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "Type": "Range"
          },
          "from": "range"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-11",
          "what": "\uB2EC\uB825 \uC548\uCABD \uBD80\uD488\uB4E4",
          "quote": "\uBD80\uD488\uB3C4 \uC815\uBCF8\uC5D0 \uC788\uC5B4\uC57C\uD558\uACE0 \uC124\uCE58\uAE30\uC5D0\uB3C4 \uC788\uC74C. \uC5C6\uB2E4\uBA74 \uC788\uB294\uAC8C \uB9DE\uC74C"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900).",
      "note": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900)."
    },
    {
      "source": "A",
      "set": "calendar_arrow",
      "setId": "540:4196",
      "role": "\uB2EC\uB825 \uC774\uC804/\uB2E4\uC74C \uD654\uC0B4\uD45C",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Calendar Cell",
        "Calendar Tile",
        "Calendar"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-11",
          "what": "\uB2EC\uB825 \uC548\uCABD \uBD80\uD488\uB4E4",
          "quote": "\uBD80\uD488\uB3C4 \uC815\uBCF8\uC5D0 \uC788\uC5B4\uC57C\uD558\uACE0 \uC124\uCE58\uAE30\uC5D0\uB3C4 \uC788\uC74C. \uC5C6\uB2E4\uBA74 \uC788\uB294\uAC8C \uB9DE\uC74C"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900).",
      "note": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900)."
    },
    {
      "source": "A",
      "set": "DatePicker/Calendar Tile",
      "setId": "540:4209",
      "role": "\uB2EC\uB825 \uD0C0\uC77C",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Calendar Cell",
        "Calendar Tile",
        "Calendar"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-11",
          "what": "\uB2EC\uB825 \uC548\uCABD \uBD80\uD488\uB4E4",
          "quote": "\uBD80\uD488\uB3C4 \uC815\uBCF8\uC5D0 \uC788\uC5B4\uC57C\uD558\uACE0 \uC124\uCE58\uAE30\uC5D0\uB3C4 \uC788\uC74C. \uC5C6\uB2E4\uBA74 \uC788\uB294\uAC8C \uB9DE\uC74C"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900).",
      "note": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900)."
    },
    {
      "source": "A",
      "set": "pc_datepicker_calendar",
      "setId": "540:4216",
      "role": "PC \uB2EC\uB825 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Calendar Cell",
        "Calendar Tile",
        "Calendar"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Calendar Cell",
          "then": {
            "State": "Default"
          },
          "from": "default"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-11",
          "what": "\uB2EC\uB825 \uC548\uCABD \uBD80\uD488\uB4E4",
          "quote": "\uBD80\uD488\uB3C4 \uC815\uBCF8\uC5D0 \uC788\uC5B4\uC57C\uD558\uACE0 \uC124\uCE58\uAE30\uC5D0\uB3C4 \uC788\uC74C. \uC5C6\uB2E4\uBA74 \uC788\uB294\uAC8C \uB9DE\uC74C"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900).",
      "note": "\uB808\uAC70\uC2DC\uC758 \uD654\uC0B4\uD45C\uB294 \uBCC4\uB3C4 \uC138\uD2B8\uAC00 \uC544\uB2C8\uB77C \uB2EC\uB825 \uBA38\uB9AC\uC758 \uC544\uC774\uCF58\uC774\uB2E4(2026-09-04 \uACB0\uC815 \uB2F9\uC2DC \uAE30\uC900)."
    },
    {
      "source": "B",
      "set": "calendar",
      "setId": "73:4022",
      "role": "\uB2EC\uB825 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Date Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "default"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "completed"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing(day)"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Open"
          },
          "from": "editing(day)"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing(month)"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Open"
          },
          "from": "editing(month)"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing(year)"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Open"
          },
          "from": "editing(year)"
        }
      ],
      "notes": [
        {
          "from": "selected",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        }
      ],
      "basis": [
        {
          "id": "D-10",
          "what": "\uB0A0\uC9DC \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "selected = open(\uB2EC\uB825 \uC5F4\uB9BC) \xB7 editing 3\uC885 = \uBAA8\uB450 open \xB7 completed = filled"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_calendar_input",
      "setId": "159:5733",
      "role": "\uBAA8\uBC14\uC77C \uB2EC\uB825 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Date Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Date Picker",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [
        {
          "from": "selected",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "editing(day)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "editing(month)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "editing(year)",
          "then": {
            "State": "Open"
          },
          "set": "Date Picker"
        },
        {
          "from": "completed",
          "then": {
            "State": "Filled"
          },
          "set": "Date Picker"
        }
      ],
      "basis": [
        {
          "id": "D-10",
          "what": "\uB0A0\uC9DC \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "selected = open(\uB2EC\uB825 \uC5F4\uB9BC) \xB7 editing 3\uC885 = \uBAA8\uB450 open \xB7 completed = filled"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "dropdown_option",
      "setId": "540:3425",
      "role": "\uC120\uD0DD \uBAA9\uB85D\uC758 \uD55C \uC904",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Dropdown List"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Dropdown List",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Dropdown List",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Dropdown List",
          "then": {
            "State": "Selected",
            "Type": "Text"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Dropdown List",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-08",
          "what": "\uB4DC\uB86D\uB2E4\uC6B4 \uD55C \uC904\uC758 selected",
          "quote": "selected = selectedText (\uAE00\uC790\uB85C \uD45C\uC2DC)"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uAE00\uC790\uD615 \uC120\uD0DD \uD45C\uC2DC\uB2E4 \u2014 \uC815\uBCF8\uC5D0\uC11C\uB294 Type=Text \uC758 State=Selected.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uAE00\uC790\uD615 \uC120\uD0DD \uD45C\uC2DC\uB2E4 \u2014 \uC815\uBCF8\uC5D0\uC11C\uB294 Type=Text \uC758 State=Selected."
    },
    {
      "source": "A",
      "set": "pc_dropdown",
      "setId": "540:3442",
      "role": "\uD3BC\uCCD0\uC9C4 \uBAA9\uB85D \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Dropdown List"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Dropdown List",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        }
      ],
      "notes": [
        {
          "from": "selected",
          "then": {
            "State": "Selected",
            "Type": "Text"
          },
          "set": "Dropdown List"
        }
      ],
      "basis": [
        {
          "id": "D-08",
          "what": "\uB4DC\uB86D\uB2E4\uC6B4 \uD55C \uC904\uC758 selected",
          "quote": "selected = selectedText (\uAE00\uC790\uB85C \uD45C\uC2DC)"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uAE00\uC790\uD615 \uC120\uD0DD \uD45C\uC2DC\uB2E4 \u2014 \uC815\uBCF8\uC5D0\uC11C\uB294 Type=Text \uC758 State=Selected.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uAE00\uC790\uD615 \uC120\uD0DD \uD45C\uC2DC\uB2E4 \u2014 \uC815\uBCF8\uC5D0\uC11C\uB294 Type=Text \uC758 State=Selected."
    },
    {
      "source": "A",
      "set": "filter-chip label only",
      "setId": "540:3226",
      "role": "\uB77C\uBCA8\uB9CC \uC788\uB294 \uD615\uD0DC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Chip",
        "Filter Chip"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-sm"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "SM"
          },
          "from": "pc-sm"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "line"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Line"
          },
          "from": "line"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "solid"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Solid"
          },
          "from": "solid"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-02",
          "what": "\uD544\uD130\uCE69\uC758 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740' \uD615\uD0DC",
          "quote": "\uB808\uAC70\uC2DC\uC5D0\uC11C\uB294 \uCE69 \uC138\uD2B8 \uC548\uC5D0 \uD568\uAED8 \uAD00\uB9AC\uD588\uC73C\uB098 \uC9C0\uAE08\uC740 \uCE69, \uD544\uD130\uCE69\uC73C\uB85C \uAD6C\uBD84\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uB294 \uD55C \uC138\uD2B8\uC5D0 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740'\uC744 \uD568\uAED8 \uB480\uB2E4. \uC815\uBCF8\uC740 Chip \uACFC Filter Chip \uB450 \uC138\uD2B8\uB85C \uAC08\uB77C\uC838 \uC788\uACE0, '\uC81C\uBAA9 \uBD99\uC740' \uC740 Filter Chip \uC758 Title=On \uC774\uB2E4.",
      "note": "\uB808\uAC70\uC2DC\uB294 \uD55C \uC138\uD2B8\uC5D0 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740'\uC744 \uD568\uAED8 \uB480\uB2E4. \uC815\uBCF8\uC740 Chip \uACFC Filter Chip \uB450 \uC138\uD2B8\uB85C \uAC08\uB77C\uC838 \uC788\uACE0, '\uC81C\uBAA9 \uBD99\uC740' \uC740 Filter Chip \uC758 Title=On \uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "filter-chip with title",
      "setId": "574:3520",
      "role": "\uC81C\uBAA9\uC774 \uBD99\uC740 \uD615\uD0DC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Chip",
        "Filter Chip"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Chip",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-sm"
            }
          ],
          "set": "Chip",
          "then": {
            "Size": "SM"
          },
          "from": "pc-sm"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "line"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Line"
          },
          "from": "line"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "solid"
            }
          ],
          "set": "Chip",
          "then": {
            "Variant": "Solid"
          },
          "from": "solid"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-02",
          "what": "\uD544\uD130\uCE69\uC758 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740' \uD615\uD0DC",
          "quote": "\uB808\uAC70\uC2DC\uC5D0\uC11C\uB294 \uCE69 \uC138\uD2B8 \uC548\uC5D0 \uD568\uAED8 \uAD00\uB9AC\uD588\uC73C\uB098 \uC9C0\uAE08\uC740 \uCE69, \uD544\uD130\uCE69\uC73C\uB85C \uAD6C\uBD84\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uB294 \uD55C \uC138\uD2B8\uC5D0 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740'\uC744 \uD568\uAED8 \uB480\uB2E4. \uC815\uBCF8\uC740 Chip \uACFC Filter Chip \uB450 \uC138\uD2B8\uB85C \uAC08\uB77C\uC838 \uC788\uACE0, '\uC81C\uBAA9 \uBD99\uC740' \uC740 Filter Chip \uC758 Title=On \uC774\uB2E4.",
      "note": "\uB808\uAC70\uC2DC\uB294 \uD55C \uC138\uD2B8\uC5D0 '\uB77C\uBCA8\uB9CC'\uACFC '\uC81C\uBAA9 \uBD99\uC740'\uC744 \uD568\uAED8 \uB480\uB2E4. \uC815\uBCF8\uC740 Chip \uACFC Filter Chip \uB450 \uC138\uD2B8\uB85C \uAC08\uB77C\uC838 \uC788\uACE0, '\uC81C\uBAA9 \uBD99\uC740' \uC740 Filter Chip \uC758 Title=On \uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "pc_gnb",
      "setId": "540:5942",
      "role": "\uC0C1\uB2E8 \uBC14",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "GNB",
        "GNB Menu",
        "GNB Utility Icon",
        "Language Icon"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "md"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "sm"
          },
          "from": "sm"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xsm"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "xsm"
          },
          "from": "xsm"
        },
        {
          "when": [
            {
              "axis": "align",
              "value": "center-between"
            }
          ],
          "set": "GNB",
          "then": {
            "Align": "Center-Between"
          },
          "from": "center-between"
        },
        {
          "when": [
            {
              "axis": "align",
              "value": "start"
            }
          ],
          "set": "GNB",
          "then": {
            "Align": "Start"
          },
          "from": "start"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8 gnb \uC758 bar \uBCC0\uD615\uACFC \uD06C\uAE30\xB7\uC815\uB82C \uAC12\uC774 \uC815\uD655\uD788 \uC77C\uCE58 \xB7 viewport=1280/1440/1920 \uC740 \uC815\uBCF8\uC5D0 \uCD95 \uC5C6\uC74C"
    },
    {
      "source": "A",
      "set": "slots_menu",
      "setId": "540:6069",
      "role": "\uC0C1\uB2E8 \uBC14 \uBA54\uB274 \uD55C \uCE78",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "GNB",
        "GNB Menu",
        "GNB Utility Icon",
        "Language Icon"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "GNB Menu",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "GNB Menu",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "GNB Menu",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "md"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "sm"
          },
          "from": "sm"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xsm"
            }
          ],
          "set": "GNB",
          "then": {
            "Size": "xsm"
          },
          "from": "xsm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8 gnb \uC758 menuSlot \uBCC0\uD615\uACFC \uD06C\uAE30\xB7\uC0C1\uD0DC\uAC00 \uC815\uD655\uD788 \uC77C\uCE58"
    },
    {
      "source": "B",
      "set": "gnb",
      "setId": "5:10245",
      "role": "\uC0C1\uB2E8 \uBC14",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "GNB Sub Menu",
        "GNB Sub Menu Item"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "sub menu",
              "value": "1depth"
            }
          ],
          "set": "GNB Sub Menu Item",
          "then": {
            "Depth": "1depth"
          },
          "from": "1depth"
        },
        {
          "when": [
            {
              "axis": "sub menu",
              "value": "2depth"
            }
          ],
          "set": "GNB Sub Menu Item",
          "then": {
            "Depth": "2depth"
          },
          "from": "2depth"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-18",
          "what": "\uC0C1\uB2E8\uBC14 \uBA54\uB274 \uBAA9\uB85D\xB7\uD558\uC704\uBA54\uB274 \uAE4A\uC774",
          "quote": "\uD558\uC704\uBA54\uB274 \uAE4A\uC774\uC5D0 \uB300\uD55C \uB0B4\uC6A9\uB3C4 \uCD94\uAC00 \uD544\uC694"
        }
      ],
      "why": "\uAE4A\uC774 \uCD95\uC740 \uD56D\uBAA9(GNB Sub Menu Item)\uC5D0 \uC788\uACE0, \uD3BC\uCE68 \uD328\uB110\uC740 Type(regular\xB7compact-1\xB7compact-2)\uC73C\uB85C \uB098\uB25C\uB2E4.",
      "note": "\uAE4A\uC774 \uCD95\uC740 \uD56D\uBAA9(GNB Sub Menu Item)\uC5D0 \uC788\uACE0, \uD3BC\uCE68 \uD328\uB110\uC740 Type(regular\xB7compact-1\xB7compact-2)\uC73C\uB85C \uB098\uB25C\uB2E4."
    },
    {
      "source": "A",
      "set": "input+btn",
      "setId": "641:4055",
      "role": "\uC785\uB825\uCC3D+\uBC84\uD2BC \uC870\uD569",
      "kind": "not-a-part",
      "status": "pattern",
      "canonSets": [
        "Input",
        "Button"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-03",
          "what": "\uC785\uB825\uCC3D+\uBC84\uD2BC \uC870\uD569",
          "quote": "input + button \uC870\uD569 \u2014 \uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC544\uB2C8\uB77C \uD328\uD134"
        }
      ],
      "why": "\uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC544\uB2C8\uB77C \uC785\uB825\uCC3D\uACFC \uBC84\uD2BC\uC744 \uB098\uB780\uD788 \uB193\uB294 \uBC30\uCE58\uB2E4.",
      "note": ""
    },
    {
      "source": "A",
      "set": "Inputbox_large",
      "setId": "641:4060",
      "role": "\uD070 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Text Area"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "type",
              "value": "default"
            }
          ],
          "set": "Text Area",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "complete_long"
            }
          ],
          "set": "Text Area",
          "then": {
            "State": "Filled"
          },
          "from": "complete_long"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "selected"
            }
          ],
          "set": "Text Area",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "type",
              "value": "disabled"
            }
          ],
          "set": "Text Area",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-04",
          "what": "\uD070 \uC785\uB825\uCC3D(Inputbox_large)",
          "quote": "\uB808\uAC70\uC2DC\uC758 \uB77C\uC9C0\uC778\uD48B\uC740 \uD14D\uC2A4\uD2B8\uBC15\uC2A4\uC784"
        }
      ],
      "why": "\uD06C\uAE30 \uB300\uC751\uC774 \uC544\uB2C8\uB77C \uC885\uB958 \uB300\uC751 \u2014 \uB808\uAC70\uC2DC '\uD070 \uC785\uB825\uCC3D' \uC740 \uC815\uBCF8\uC758 \uD14D\uC2A4\uD2B8\uBC15\uC2A4\uB2E4.",
      "note": "\uD06C\uAE30 \uB300\uC751\uC774 \uC544\uB2C8\uB77C \uC885\uB958 \uB300\uC751 \u2014 \uB808\uAC70\uC2DC '\uD070 \uC785\uB825\uCC3D' \uC740 \uC815\uBCF8\uC758 \uD14D\uC2A4\uD2B8\uBC15\uC2A4\uB2E4."
    },
    {
      "source": "A",
      "set": "mobile_input field with helper text",
      "setId": "641:4075",
      "role": "\uBAA8\uBC14\uC77C \uC785\uB825\uCC3D(\uB3C4\uC6C0\uB9D0 \uD3EC\uD568)",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "status",
              "value": "default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "complete"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "complete"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "selected"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "success"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Correct"
          },
          "from": "success"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "type=normal/password \uB294 \uC815\uBCF8\uC5D0\uC11C HTML \uC785\uB825 \uC885\uB958\uB85C \uCC98\uB9AC(\uBCC0\uD615 \uC544\uB2D8)"
    },
    {
      "source": "A",
      "set": "pc_input field with helper text",
      "setId": "659:5066",
      "role": "PC \uC785\uB825\uCC3D(\uB3C4\uC6C0\uB9D0 \uD3EC\uD568)",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "status",
              "value": "default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "complete"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "complete"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "selected"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "success"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Correct"
          },
          "from": "success"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "status",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "medium"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "MD"
          },
          "from": "medium"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xsmall"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "XSM"
          },
          "from": "xsmall"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xxsmall"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "XXSM"
          },
          "from": "xxsmall"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "Login input",
      "setId": "540:3328",
      "role": "\uB85C\uADF8\uC778 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "complete"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "complete"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "MD",
            "Break": "PC"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xsm"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "XXSM",
            "Break": "PC"
          },
          "from": "pc-xsm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-sm"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "XSM",
            "Break": "PC"
          },
          "from": "pc-sm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "mobile"
            }
          ],
          "set": "Input",
          "then": {
            "Size": "MD",
            "Break": "Mobile"
          },
          "from": "mobile"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-06",
          "what": "\uB85C\uADF8\uC778 \uC785\uB825\uCC3D\uC758 pc-sm \uD06C\uAE30",
          "quote": "\uB808\uAC70\uC2DC pc-sm\uC758 height \uAC12\uC744 \uBCF4\uACE0 \uCD5C\uC2E0\uB370\uC774\uD130\uC640 \uBE44\uAD50\uD558\uC5EC \uB9E4\uCE6D\uD558\uBA74\uB428. \uD639\uC2DC\uB098 \uCD5C\uC2E0\uB370\uC774\uD130 \uB192\uC774\uAC12\uC911 \uB9E4\uCE6D\uB418\uB294\uAC8C \uC5C6\uB2E4\uBA74 \uAC00\uC7A5 \uAC00\uAE4C\uC6B4 height\uAC12\uC73C\uB85C \uC9C0\uC815\uD558\uBA74 \uB428"
        }
      ],
      "why": "river \uADDC\uCE59: \uB192\uC774 \uAC12\uC73C\uB85C \uB9DE\uCD94\uACE0, \uAC19\uC740 \uB192\uC774\uAC00 \uC5C6\uC73C\uBA74 \uAC00\uC7A5 \uAC00\uAE4C\uC6B4 \uB192\uC774. \uC2E4\uCE21 mobile 48 \xB7 pc-md 44 \xB7 pc-sm 34 \xB7 pc-xsm 28.",
      "note": "river \uADDC\uCE59: \uB192\uC774 \uAC12\uC73C\uB85C \uB9DE\uCD94\uACE0, \uAC19\uC740 \uB192\uC774\uAC00 \uC5C6\uC73C\uBA74 \uAC00\uC7A5 \uAC00\uAE4C\uC6B4 \uB192\uC774. \uC2E4\uCE21 mobile 48 \xB7 pc-md 44 \xB7 pc-sm 34 \xB7 pc-xsm 28."
    },
    {
      "source": "B",
      "set": "login_Input box",
      "setId": "269:4116",
      "role": "\uB85C\uADF8\uC778 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "completed"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "correct"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Correct"
          },
          "from": "correct"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": 'option=correct \uAC00 \uC815\uBCF8 \uC774\uB984\uACFC \uADF8\uB300\uB85C \uC77C\uCE58 \xB7 "completed" \uC640 \uB2E4\uB978 \uC138\uD2B8\uC758 "edit-completed" \uAC00 \uAC19\uC740 \uB73B\uC73C\uB85C \uD63C\uC6A9\uB428'
    },
    {
      "source": "B",
      "set": "Input box",
      "setId": "269:3675",
      "role": "PC \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "edit-completed"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "edit-completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "correct"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Correct"
          },
          "from": "correct"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "label=left/top/off \uB294 \uC815\uBCF8\uC5D0\uC11C \uB77C\uBCA8 \uBC30\uCE58(\uC815\uBCF8 \uCD95 \uC544\uB2D8) \xB7 button/icon \uC740 \uBD80\uD488 \uC720\uBB34"
    },
    {
      "source": "B",
      "set": "m_certification_inputbox",
      "setId": "307:6051",
      "role": "\uBAA8\uBC14\uC77C \uC778\uC99D\uBC88\uD638 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "completed"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_macrocheck_Input box",
      "setId": "351:7086",
      "role": "\uBAA8\uBC14\uC77C \uB9E4\uD06C\uB85C\uD655\uC778 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "edit-completed"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "edit-completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_Input box",
      "setId": "307:9313",
      "role": "\uBAA8\uBC14\uC77C \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Input",
        "Search Input"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "default"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "edit-completed"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Filled"
          },
          "from": "edit-completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "correct"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Correct"
          },
          "from": "correct"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Focus"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "error"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Error"
          },
          "from": "error"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Input",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": '"default + guide" \uB294 \uC0C1\uD0DC\uAC00 \uC544\uB2C8\uB77C \uB3C4\uC6C0\uB9D0 \uD45C\uC2DC \uC5EC\uBD80 \xB7 168\uBCC0\uD615\uC73C\uB85C \uB450 \uD30C\uC77C \uD1B5\uD2C0\uC5B4 \uAC00\uC7A5 \uD070 \uC138\uD2B8'
    },
    {
      "source": "A",
      "set": "mobile_bottom-nav",
      "setId": "540:6025",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Mobile Bottom Nav"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Mobile Bottom Nav",
          "then": {
            "state": "selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "unselected"
            }
          ],
          "set": "Mobile Bottom Nav",
          "then": {
            "state": "unselected"
          },
          "from": "unselected"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "mobile_header",
      "setId": "540:6112",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Mobile Header"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-17",
          "what": "\uBAA8\uBC14\uC77C \uC0C1\uB2E8\uBC14 6\uC885 \uB300\uC751",
          "quote": "\uC544\uC774\uCF58 \uB450\uAC1C\uC788\uB294 \uBC84\uC804\uACFC \uC571\uBC14\uB294 \uC0AC\uC6A9\uD558\uC9C0\uC54A\uC74C.  \uADF8\uB7F0\uB370 \uB2E4\uC2DC\uBCF4\uB2C8 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC774 \uB204\uB77D\uB428. \uC81C\uC791\uD6C4 \uC0AD\uC81C\uB41C \uB450\uAC1C\uC720\uD615\uC740 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC73C\uB85C \uBCC0\uACBD\uD558\uBA74\uB428"
        }
      ],
      "why": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4.",
      "note": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "mobile_modal",
      "setId": "540:5731",
      "role": "\uBAA8\uBC14\uC77C \uBAA8\uB2EC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "button type",
              "value": "single"
            }
          ],
          "set": "Modal",
          "then": {
            "Footer": "Single"
          },
          "from": "single"
        },
        {
          "when": [
            {
              "axis": "button type",
              "value": "dual"
            }
          ],
          "set": "Modal",
          "then": {
            "Footer": "Dual"
          },
          "from": "dual"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "button type=single/dual \uC774 \uC815\uBCF8 \uBCC0\uD615\uACFC \uC815\uD655\uD788 \uC77C\uCE58 \xB7 title line=1/2 \uB294 \uC815\uBCF8\uC5D0 \uCD95 \uC5C6\uC74C"
    },
    {
      "source": "A",
      "set": "pc_modal",
      "setId": "540:5815",
      "role": "PC \uBAA8\uB2EC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Modal Content",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "lg"
            }
          ],
          "set": "Modal Content",
          "then": {
            "Size": "LG"
          },
          "from": "lg"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "xl"
            }
          ],
          "set": "Modal Content",
          "then": {
            "Size": "XL"
          },
          "from": "xl"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "mobile_modal component",
      "setId": "682:5938",
      "role": "\uBAA8\uBC14\uC77C \uBAA8\uB2EC(\uBD80\uD488)",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [],
      "notes": [
        {
          "from": "md",
          "then": {
            "Size": "MD"
          },
          "set": "Modal Content"
        },
        {
          "from": "lg",
          "then": {
            "Size": "LG"
          },
          "set": "Modal Content"
        },
        {
          "from": "xl",
          "then": {
            "Size": "XL"
          },
          "set": "Modal Content"
        }
      ],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "modal_small",
      "setId": "6706:4218",
      "role": "\uC791\uC740 \uBAA8\uB2EC(\uC6A9\uB3C4\uBCC4)",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [],
      "notes": [
        {
          "from": "md",
          "then": {
            "Size": "MD"
          },
          "set": "Modal Content"
        },
        {
          "from": "lg",
          "then": {
            "Size": "LG"
          },
          "set": "Modal Content"
        },
        {
          "from": "xl",
          "then": {
            "Size": "XL"
          },
          "set": "Modal Content"
        }
      ],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "B",
      "set": "dialog",
      "setId": "53:1814",
      "role": "\uB2E4\uC774\uC5BC\uB85C\uADF8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [],
      "notes": [
        {
          "from": "md",
          "then": {
            "Size": "MD"
          },
          "set": "Modal Content"
        },
        {
          "from": "lg",
          "then": {
            "Size": "LG"
          },
          "set": "Modal Content"
        },
        {
          "from": "xl",
          "then": {
            "Size": "XL"
          },
          "set": "Modal Content"
        }
      ],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "B",
      "set": "popup",
      "setId": "78:3071",
      "role": "\uD31D\uC5C5",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [],
      "notes": [
        {
          "from": "md",
          "then": {
            "Size": "MD"
          },
          "set": "Modal Content"
        },
        {
          "from": "lg",
          "then": {
            "Size": "LG"
          },
          "set": "Modal Content"
        },
        {
          "from": "xl",
          "then": {
            "Size": "XL"
          },
          "set": "Modal Content"
        }
      ],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "B",
      "set": "dialog",
      "setId": "151:4106",
      "role": "\uBAA8\uBC14\uC77C \uB2E4\uC774\uC5BC\uB85C\uADF8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Modal Content"
      ],
      "rules": [],
      "notes": [
        {
          "from": "md",
          "then": {
            "Size": "MD"
          },
          "set": "Modal Content"
        },
        {
          "from": "lg",
          "then": {
            "Size": "LG"
          },
          "set": "Modal Content"
        },
        {
          "from": "xl",
          "then": {
            "Size": "XL"
          },
          "set": "Modal Content"
        }
      ],
      "basis": [
        {
          "id": "D-15",
          "what": "\uBAA8\uB2EC \uD06C\uAE30",
          "quote": "\uD06C\uAE30\uB294 \uC9C0\uAE08\uB3C4 \uC788\uC5B4\uC57C \uD568 \u2014 \uC815\uBCF8 \uBCF4\uAC15 \uB300\uC0C1"
        }
      ],
      "why": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4.",
      "note": "\uD655\uC778 \uACC4\uC5F4 Modal \uC5D0\uB294 \uD06C\uAE30 \uCD95\uC774 \uC5C6\uB2E4. \uB808\uAC70\uC2DC \uBAA8\uB2EC \uD06C\uAE30 \uCCB4\uACC4\uB294 \uCF58\uD150\uCE20 \uACC4\uC5F4 \uAC83\uC774\uB2E4."
    },
    {
      "source": "A",
      "set": "pc_multi-toggle",
      "setId": "540:4733",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Multi Toggle",
        "Multi Toggle Element"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Multi Toggle Element",
          "then": {
            "state": "default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Multi Toggle Element",
          "then": {
            "state": "hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Multi Toggle Element",
          "then": {
            "state": "selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Multi Toggle Element",
          "then": {
            "state": "disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Multi Toggle",
          "then": {
            "Size": "md"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "Multi Toggle",
          "then": {
            "Size": "sm"
          },
          "from": "sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "position=first/middle-left/middle-right/last \uB294 \uC815\uBCF8\uC5D0\uC11C \uC704\uCE58 \uC790\uB3D9 \uCC98\uB9AC"
    },
    {
      "source": "A",
      "set": "pagination_number",
      "setId": "540:6302",
      "role": "\uD398\uC774\uC9C0 \uBC88\uD638",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination",
        "Pagination Cell"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "hover/selected \uB97C \uAC01\uAC01 on/off \uC2A4\uC704\uCE58\uB85C \uCABC\uAC20 \uAD6C\uC870 \u2192 \uC815\uBCF8\uC740 \uC0C1\uD0DC \uD558\uB098\uB85C \uD1B5\uD569"
    },
    {
      "source": "A",
      "set": "pagination_arrow",
      "setId": "540:6311",
      "role": "\uD398\uC774\uC9C0 \uD654\uC0B4\uD45C",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination",
        "Pagination Cell"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "Property 1",
              "value": "default"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "Property 1",
              "value": "hover"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "Property 1",
              "value": "disabled"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": 'direction \uAC12 <<,<,>,>> \uC774 \uC815\uBCF8 arrow \uBCC0\uD615\uACFC \uC815\uD655\uD788 \uC77C\uCE58 \xB7 \uC18D\uC131 \uC774\uB984\uC774 "Property 1"(\uC774\uB984 \uC5C6\uC74C) \u2014 \uC815\uBCF8\uC740 state'
    },
    {
      "source": "A",
      "set": "pc_pagination",
      "setId": "540:6382",
      "role": "\uD398\uC774\uC9C0 \uC774\uB3D9 \uBC14 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination",
        "Pagination Cell"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8 pagination \uC758 bar \uBCC0\uD615 \xB7 \uC815\uBCF8 \uC0C1\uD0DC single/first/last/middle \uC774 \uB808\uAC70\uC2DC\uC5D0 \uC5C6\uC74C"
    },
    {
      "source": "B",
      "set": "page_arrow",
      "setId": "2504:15084",
      "role": "\uD398\uC774\uC9C0 \uD654\uC0B4\uD45C",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination",
        "Pagination Cell"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "condition",
              "value": "hover"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "condition",
              "value": "disabled"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "option \uAC12 <<,<,>,>> \uC774 \uC815\uBCF8 arrow \uBCC0\uD615\uACFC \uC77C\uCE58 \xB7 \uC18D\uC131 \uC774\uB984\uC774 A(direction)\uC640 B(option)\uB85C \uC11C\uB85C \uB2E4\uB984"
    },
    {
      "source": "B",
      "set": "page_num",
      "setId": "2504:15156",
      "role": "\uD398\uC774\uC9C0 \uBC88\uD638",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination",
        "Pagination Cell"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "selected"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Pagination Cell",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": '\u26A0\uFE0F "Default" \uAC12\uC774 \uB450 \uBC88 \uC911\uBCF5 \uC815\uC758\uB3FC \uC788\uC74C(\uB808\uAC70\uC2DC \uB370\uC774\uD130 \uC624\uB958)'
    },
    {
      "source": "B",
      "set": "pagenation",
      "setId": "2504:15164",
      "role": "\uD398\uC774\uC9C0 \uC774\uB3D9 \uBC14 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Pagination"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "single page"
            }
          ],
          "set": "Pagination",
          "then": {
            "State": "Single"
          },
          "from": "single page"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "1st page"
            }
          ],
          "set": "Pagination",
          "then": {
            "State": "First"
          },
          "from": "1st page"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "normal"
            }
          ],
          "set": "Pagination",
          "then": {
            "State": "Middle"
          },
          "from": "normal"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-23",
          "what": "\uD398\uC774\uC9C0 \uC774\uB3D9 \uBC14\uC758 '\uB9C8\uC9C0\uB9C9 \uD398\uC774\uC9C0'",
          "quote": "\uB808\uAC70\uC2DC \uB204\uB77D \u2014 \uC815\uBCF8\uC774 \uB9DE\uACE0 \uB808\uAC70\uC2DC\uC5D0 \uBE60\uC9C4 \uAC83"
        }
      ],
      "why": "\uB808\uAC70\uC2DC\uC5D0 '\uB9C8\uC9C0\uB9C9 \uD398\uC774\uC9C0' \uAC00 \uBE60\uC838 \uC788\uB2E4 \u2014 \uC815\uBCF8\uC774 \uB9DE\uB2E4.",
      "note": "\uB808\uAC70\uC2DC\uC5D0 '\uB9C8\uC9C0\uB9C9 \uD398\uC774\uC9C0' \uAC00 \uBE60\uC838 \uC788\uB2E4 \u2014 \uC815\uBCF8\uC774 \uB9DE\uB2E4."
    },
    {
      "source": "A",
      "set": "radio",
      "setId": "540:3113",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Radio"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "checked"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Selected"
          },
          "from": "checked"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "label=on/off \uB294 \uC815\uBCF8\uC758 \uC120\uD0DD \uBD80\uD488(\uB77C\uBCA8) \uC720\uBB34 \xB7 \uC815\uBCF8 hover \uB294 \uB808\uAC70\uC2DC\uC5D0 \uC5C6\uC74C(\uB808\uAC70\uC2DC \uB204\uB77D)"
    },
    {
      "source": "B",
      "set": "radiobutton",
      "setId": "42:3283",
      "role": "\uB77C\uB514\uC624 \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Radio"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        },
        {
          "when": [
            {
              "axis": "pressed",
              "value": "on"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Selected"
          },
          "from": "pressed"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-22",
          "what": "B\uD30C\uC77C \uB77C\uB514\uC624\uC758 pressed",
          "quote": "pressed = selected (\uC120\uD0DD\uB41C \uC0C1\uD0DC\uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83)"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_radiobutton",
      "setId": "109:24654",
      "role": "\uBAA8\uBC14\uC77C \uB77C\uB514\uC624",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Radio"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        },
        {
          "when": [
            {
              "axis": "pressed",
              "value": "on"
            }
          ],
          "set": "Radio",
          "then": {
            "State": "Selected"
          },
          "from": "pressed"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-22",
          "what": "B\uD30C\uC77C \uB77C\uB514\uC624\uC758 pressed",
          "quote": "pressed = selected (\uC120\uD0DD\uB41C \uC0C1\uD0DC\uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83)"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "select",
      "setId": "540:3397",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Select Box"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Open"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Select Box",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xsm"
            }
          ],
          "set": "Select Box",
          "then": {
            "Size": "XSM"
          },
          "from": "pc-xsm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xxsm"
            }
          ],
          "set": "Select Box",
          "then": {
            "Size": "XXSM"
          },
          "from": "pc-xxsm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-07",
          "what": "\uC120\uD0DD\uCC3D\uC758 selected",
          "quote": "selected = open (\uD3BC\uCCD0\uC9C4 \uBAA8\uC2B5)"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "combobox",
      "setId": "73:3247",
      "role": "\uCF64\uBCF4\uBC15\uC2A4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Select Box",
        "Dropdown"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "completed"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Open"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-20",
          "what": "\uCF64\uBCF4\uBC15\uC2A4",
          "quote": "\uCF64\uBCF4\uBC15\uC2A4\uB294 \uC140\uB809, \uB4DC\uB86D\uB2E4\uC6B4 \uC870\uD569\uC73C\uB85C, \uBCC0\uD658\uC2DC\uC5D0\uB294 \uAC01\uAC01 \uCD5C\uC2E0 \uC140\uB809\uBC15\uC2A4\uC640 \uB4DC\uB86D\uB2E4\uC6B4\uC73C\uB85C \uBC14\uAFD4\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4.",
      "note": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4."
    },
    {
      "source": "B",
      "set": "m_combobox",
      "setId": "109:26455",
      "role": "\uBAA8\uBC14\uC77C \uCF64\uBCF4\uBC15\uC2A4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Select Box",
        "Dropdown"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "completed"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "editing"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Open"
          },
          "from": "editing"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-20",
          "what": "\uCF64\uBCF4\uBC15\uC2A4",
          "quote": "\uCF64\uBCF4\uBC15\uC2A4\uB294 \uC140\uB809, \uB4DC\uB86D\uB2E4\uC6B4 \uC870\uD569\uC73C\uB85C, \uBCC0\uD658\uC2DC\uC5D0\uB294 \uAC01\uAC01 \uCD5C\uC2E0 \uC140\uB809\uBC15\uC2A4\uC640 \uB4DC\uB86D\uB2E4\uC6B4\uC73C\uB85C \uBC14\uAFD4\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4.",
      "note": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4."
    },
    {
      "source": "A",
      "set": "tab",
      "setId": "540:6032",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "unselected"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Unselected"
          },
          "from": "unselected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Selected"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "pressed"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Selected"
          },
          "from": "pressed"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "pc-md"
            }
          ],
          "set": "Line Tab",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "variant",
              "value": "pc-sm"
            }
          ],
          "set": "Line Tab",
          "then": {
            "Size": "SM"
          },
          "from": "pc-sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_tab1",
      "setId": "5:10574",
      "role": "\uD0ED 1\uD615",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "selected",
              "value": "on"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Selected"
          },
          "from": "selected=on"
        },
        {
          "when": [
            {
              "axis": "hover",
              "value": "on"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Hover"
          },
          "from": "hover=on"
        }
      ],
      "notes": [
        {
          "from": "unselected",
          "then": {
            "State": "Unselected"
          },
          "set": "Line Tab"
        },
        {
          "from": "pressed",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        }
      ],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_tab2",
      "setId": "5:10603",
      "role": "\uD0ED 2\uD615",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "selected",
              "value": "on"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Selected"
          },
          "from": "selected=on"
        },
        {
          "when": [
            {
              "axis": "hover",
              "value": "on"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Hover"
          },
          "from": "hover=on"
        }
      ],
      "notes": [
        {
          "from": "unselected",
          "then": {
            "State": "Unselected"
          },
          "set": "Line Tab"
        },
        {
          "from": "pressed",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        }
      ],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "tab",
      "setId": "1008:10175",
      "role": "\uD0ED",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [],
      "notes": [
        {
          "from": "unselected",
          "then": {
            "State": "Unselected"
          },
          "set": "Line Tab"
        },
        {
          "from": "hover",
          "then": {
            "State": "Hover"
          },
          "set": "Line Tab"
        },
        {
          "from": "pressed",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        },
        {
          "from": "selected",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        }
      ],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_tab_title",
      "setId": "42:2381",
      "role": "\uBAA8\uBC14\uC77C \uD0ED \uC81C\uBAA9",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "selected",
              "value": "on"
            }
          ],
          "set": "Line Tab",
          "then": {
            "State": "Selected"
          },
          "from": "selected=on"
        }
      ],
      "notes": [
        {
          "from": "unselected",
          "then": {
            "State": "Unselected"
          },
          "set": "Line Tab"
        },
        {
          "from": "hover",
          "then": {
            "State": "Hover"
          },
          "set": "Line Tab"
        },
        {
          "from": "pressed",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        }
      ],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "tab",
      "setId": "1008:10723",
      "role": "\uD0ED",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Line Tab"
      ],
      "rules": [],
      "notes": [
        {
          "from": "unselected",
          "then": {
            "State": "Unselected"
          },
          "set": "Line Tab"
        },
        {
          "from": "hover",
          "then": {
            "State": "Hover"
          },
          "set": "Line Tab"
        },
        {
          "from": "pressed",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        },
        {
          "from": "selected",
          "then": {
            "State": "Selected"
          },
          "set": "Line Tab"
        }
      ],
      "basis": [
        {
          "id": "D-16",
          "what": "\uD0ED\uC758 pressed",
          "quote": "pressed = selected \uB97C \uADF8\uB807\uAC8C \uBD80\uB978 \uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_table_body",
      "setId": "540:4851",
      "role": "\uC77C\uBC18 \uD45C \uBCF8\uBB38",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table",
        "Table Cell"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Table Cell",
          "then": {
            "Variant": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Table Cell",
          "then": {
            "Variant": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "SM"
          },
          "from": "sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_table_header",
      "setId": "540:4940",
      "role": "\uC77C\uBC18 \uD45C \uBA38\uB9AC\uAE00",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table",
        "Table Cell"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Table Cell",
          "then": {
            "Variant": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Table Cell",
          "then": {
            "Variant": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "SM"
          },
          "from": "sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "check box / icon / align / position \uC740 \uC815\uBCF8\uC5D0\uC11C \uC140 \uC18D\uC131\uC73C\uB85C \uCC98\uB9AC"
    },
    {
      "source": "A",
      "set": "pc_grid-table_header",
      "setId": "540:5309",
      "role": "\uADF8\uB9AC\uB4DC \uD45C \uBA38\uB9AC\uAE00",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "SM"
          },
          "from": "sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_grid-table_body",
      "setId": "540:5502",
      "role": "\uADF8\uB9AC\uB4DC \uD45C \uBCF8\uBB38",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "sm"
            }
          ],
          "set": "Table",
          "then": {
            "Size": "SM"
          },
          "from": "sm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_embeded-table_header",
      "setId": "540:5593",
      "role": "\uC0BD\uC785\uD615 \uD45C \uBA38\uB9AC\uAE00",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_embeded-table_body",
      "setId": "540:5618",
      "role": "\uC0BD\uC785\uD615 \uD45C \uBCF8\uBB38",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "table",
      "setId": "2504:15196",
      "role": "\uD45C(\uC18D\uC131 \uC5C6\uC74C)",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "table",
      "setId": "2504:15255",
      "role": "\uD45C",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Table"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-14",
          "what": "\uADF8\uB9AC\uB4DC \uD45C\xB7\uC0BD\uC785\uD615 \uD45C",
          "quote": "\uADF8\uB9AC\uB4DC\xB7\uC0BD\uC785\uD615\uC740 \uBCC4\uAC1C \u2014 \uC815\uBCF8\uC5D0 \uC544\uC9C1 \uC5C6\uB294 \uAC83\uC73C\uB85C \uAE30\uB85D"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "timepicker_input_component",
      "setId": "540:3469",
      "role": "\uC2DC\uAC04 \uC785\uB825\uCC3D \uBD80\uD488",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Time Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        }
      ],
      "notes": [
        {
          "from": "completed",
          "then": {
            "State": "Filled"
          },
          "set": "Time Picker"
        }
      ],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4."
    },
    {
      "source": "A",
      "set": "timepicker_select_number",
      "setId": "540:3476",
      "role": "\uC2DC/\uBD84 \uC22B\uC790 \uBAA9\uB85D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Time Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "hover"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Hover"
          },
          "from": "hover"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Time Picker",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        }
      ],
      "notes": [
        {
          "from": "completed",
          "then": {
            "State": "Filled"
          },
          "set": "Time Picker"
        }
      ],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4."
    },
    {
      "source": "A",
      "set": "timepicker_select_dropdown",
      "setId": "540:3489",
      "role": "\uC2DC\uAC04 \uC120\uD0DD \uD3BC\uCE68",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Time Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "size",
              "value": "md"
            }
          ],
          "set": "Time Picker",
          "then": {
            "Size": "MD"
          },
          "from": "md"
        }
      ],
      "notes": [
        {
          "from": "selected",
          "then": {
            "State": "Focus"
          },
          "set": "Time Picker"
        },
        {
          "from": "completed",
          "then": {
            "State": "Filled"
          },
          "set": "Time Picker"
        }
      ],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4."
    },
    {
      "source": "A",
      "set": "pc_timepicker_input_dropdown",
      "setId": "540:3506",
      "role": "PC \uC2DC\uAC04 \uC785\uB825 \uD3BC\uCE68",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Time Picker"
      ],
      "rules": [],
      "notes": [
        {
          "from": "selected",
          "then": {
            "State": "Focus"
          },
          "set": "Time Picker"
        },
        {
          "from": "completed",
          "then": {
            "State": "Filled"
          },
          "set": "Time Picker"
        }
      ],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4."
    },
    {
      "source": "A",
      "set": "timepicker_select",
      "setId": "540:3636",
      "role": "\uC2DC\uAC04 \uC120\uD0DD",
      "kind": "not-a-part",
      "status": "legacy-only",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uC2DC\xB7\uBD84\uC744 \uAC01\uAC01 \uD654\uC0B4\uD45C \uCE78\uC73C\uB85C \uACE0\uB974\uB294 \uD615\uD0DC \u2014 \uC815\uBCF8\uC5D0 \uC5C6\uACE0 \uB9CC\uB4E4\uC9C0 \uC54A\uB294\uB2E4(2026-09-17 river)",
      "note": ""
    },
    {
      "source": "A",
      "set": "timepicker_input",
      "setId": "540:3690",
      "role": "\uC2DC\uAC04 \uC785\uB825\uCC3D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Time Picker"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "default"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Default"
          },
          "from": "default"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "completed"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Filled"
          },
          "from": "completed"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "selected"
            }
          ],
          "set": "Time Picker",
          "then": {
            "State": "Focus"
          },
          "from": "selected"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-md"
            }
          ],
          "set": "Time Picker",
          "then": {
            "Size": "MD"
          },
          "from": "pc-md"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xsm"
            }
          ],
          "set": "Time Picker",
          "then": {
            "Size": "XSM"
          },
          "from": "pc-xsm"
        },
        {
          "when": [
            {
              "axis": "platform",
              "value": "pc-xxsm"
            }
          ],
          "set": "Time Picker",
          "then": {
            "Size": "XXSM"
          },
          "from": "pc-xxsm"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-09",
          "what": "\uC2DC\uAC04 \uC120\uD0DD\uC758 selected \xB7 editing",
          "quote": "\uB808\uAC70\uC2DC\uB294 \uCD5C\uD558\uC704\uC758 \uB4DC\uB86D\uB2E4\uC6B4\uAE4C\uC9C0 \uD55C \uC138\uD2B8\uC5D0 \uB4E4\uC5B4\uC788\uACE0, \uCD5C\uC2E0\uAC83\uC740 \uC2DC\uAC04 \uB4DC\uB86D\uB2E4\uC6B4\uC774 \uBCC4\uAC1C\uB85C \uC138\uD305\uB418\uC5B4\uC788\uC5B4. \uBE44\uAD50\uD558\uAE30\uC5D4 \uB381\uC2A4\uAC00 \uC548\uB9DE\uC73C\uB2C8 \uB2E4\uC2DC\uD655\uC778\uD574\uC11C \uAC80\uC218\uD560\uC218\uC788\uAC8C \uD574\uC918"
        }
      ],
      "why": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4.",
      "note": "\uB808\uAC70\uC2DC selected \uB294 \uC2DC\uAC04 \uBAA9\uB85D\uC774 \uC5F4\uB9B0 \uC0C1\uD0DC\uC774\uACE0, \uC815\uBCF8\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB97C Focus \uB85C \uD45C\uD604\uD55C\uB2E4."
    },
    {
      "source": "A",
      "set": "mobile_timepicker_bottomsheet",
      "setId": "540:3729",
      "role": "\uBAA8\uBC14\uC77C \uC2DC\uAC04 \uBC14\uD140\uC2DC\uD2B8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Bottom Sheet",
        "Bottom Sheet Option",
        "Date Picker Mobile Bottom Sheet",
        "Time Picker Mobile Bottom Sheet"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-05",
          "what": "\uBC14\uD140\uC2DC\uD2B8",
          "quote": "\uBC14\uD140\uC2DC\uD2B8 \uC815\uBCF8\uC5D0 \uC788\uC73C\uB2C8 \uCC3E\uC544\uBCFC\uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_combobox_time",
      "setId": "230:4052",
      "role": "\uBAA8\uBC14\uC77C \uC2DC\uAC04 \uCF64\uBCF4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Select Box",
        "Dropdown"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "option",
              "value": "Default"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Default"
          },
          "from": "Default"
        },
        {
          "when": [
            {
              "axis": "option",
              "value": "disabled"
            }
          ],
          "set": "Select Box",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "D-20",
          "what": "\uCF64\uBCF4\uBC15\uC2A4",
          "quote": "\uCF64\uBCF4\uBC15\uC2A4\uB294 \uC140\uB809, \uB4DC\uB86D\uB2E4\uC6B4 \uC870\uD569\uC73C\uB85C, \uBCC0\uD658\uC2DC\uC5D0\uB294 \uAC01\uAC01 \uCD5C\uC2E0 \uC140\uB809\uBC15\uC2A4\uC640 \uB4DC\uB86D\uB2E4\uC6B4\uC73C\uB85C \uBC14\uAFD4\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4.",
      "note": "\uB808\uAC70\uC2DC \uCF64\uBCF4\uBC15\uC2A4 = \uC815\uBCF8 \uC120\uD0DD\uCC3D + \uBAA9\uB85D \uD328\uB110 \uC870\uD569. \uC62E\uAE38 \uB54C \uAC01\uAC01 \uCD5C\uC2E0 \uAC83\uC73C\uB85C \uBC14\uAFBC\uB2E4."
    },
    {
      "source": "A",
      "set": "toggle",
      "setId": "540:3159",
      "role": "\uCEF4\uD3EC\uB10C\uD2B8 \uC804\uCCB4",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Toggle"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "state",
              "value": "off"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "Off"
          },
          "from": "off"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "on"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "On"
          },
          "from": "on"
        },
        {
          "when": [
            {
              "axis": "state",
              "value": "disabled"
            }
          ],
          "set": "Toggle",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "platform=mobile/pc \uCD95\uC740 \uC815\uBCF8\uC5D0\uC11C \uC0AC\uB77C\uC9D0(\uD06C\uAE30 \uB2E8\uC77C\uD654) \xB7 \uC815\uBCF8 disabledOn \uC740 \uB808\uAC70\uC2DC\uC5D0 \uC5C6\uC74C"
    },
    {
      "source": "B",
      "set": "toggle",
      "setId": "42:3328",
      "role": "\uD1A0\uAE00",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Toggle"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "on/off",
              "value": "on"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "On"
          },
          "from": "on/off=on,disabled=off"
        },
        {
          "when": [
            {
              "axis": "on/off",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "off"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "Off"
          },
          "from": "on/off=off,disabled=off"
        },
        {
          "when": [
            {
              "axis": "on/off",
              "value": "off"
            },
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Toggle",
          "then": {
            "State": "Disabled"
          },
          "from": "on/off=off,disabled=on"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8 disabledOn \uAE4C\uC9C0 \uB300\uC751\uB428(\uB808\uAC70\uC2DC A \uC5D0\uB294 \uC5C6\uB358 \uC0C1\uD0DC)"
    },
    {
      "source": "B",
      "set": "m_toggle",
      "setId": "109:24703",
      "role": "\uBAA8\uBC14\uC77C \uD1A0\uAE00",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Toggle"
      ],
      "rules": [
        {
          "when": [
            {
              "axis": "on/off",
              "value": "on"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "On"
          },
          "from": "on/off=on"
        },
        {
          "when": [
            {
              "axis": "on/off",
              "value": "off"
            }
          ],
          "set": "Toggle",
          "then": {
            "Pressed": "Off"
          },
          "from": "on/off=off"
        },
        {
          "when": [
            {
              "axis": "disabled",
              "value": "on"
            }
          ],
          "set": "Toggle",
          "then": {
            "State": "Disabled"
          },
          "from": "disabled=on"
        }
      ],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "",
      "note": "\uC815\uBCF8\uC740 PC/\uBAA8\uBC14\uC77C \uAD6C\uBD84 \uC5C6\uC774 toggle \uD558\uB098"
    },
    {
      "source": "A",
      "set": "mobile_bottomsheet",
      "setId": "670:4386",
      "role": "\uBAA8\uBC14\uC77C \uBC14\uD140\uC2DC\uD2B8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Bottom Sheet",
        "Bottom Sheet Option",
        "Date Picker Mobile Bottom Sheet",
        "Time Picker Mobile Bottom Sheet"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-05",
          "what": "\uBC14\uD140\uC2DC\uD2B8",
          "quote": "\uBC14\uD140\uC2DC\uD2B8 \uC815\uBCF8\uC5D0 \uC788\uC73C\uB2C8 \uCC3E\uC544\uBCFC\uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "pc_assist_button",
      "setId": "540:4650",
      "role": "\uBCF4\uC870 \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Assist Button",
        "Text Button"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-13",
          "what": "\uBCF4\uC870 \uBC84\uD2BC\xB7\uD14D\uC2A4\uD2B8 \uBC84\uD2BC",
          "quote": "\uC815\uBCF8\uC5D0 \uCD94\uAC00\uD558\uB294 \uC791\uC5C5 \uCD94\uD6C4 \uC9C4\uD589\uD574\uC57C\uD568"
        }
      ],
      "why": "\uBCF4\uC870 \uBC84\uD2BC\uC740 Button \uC758 \uBCC0\uD615\uC774 \uC544\uB2C8\uB77C \uBCC4\uB3C4 \uC138\uD2B8\uB2E4(\uD06C\uAE30 1\uC885).",
      "note": "\uBCF4\uC870 \uBC84\uD2BC\uC740 Button \uC758 \uBCC0\uD615\uC774 \uC544\uB2C8\uB77C \uBCC4\uB3C4 \uC138\uD2B8\uB2E4(\uD06C\uAE30 1\uC885)."
    },
    {
      "source": "A",
      "set": "pc_text_button",
      "setId": "540:4705",
      "role": "\uD14D\uC2A4\uD2B8 \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Assist Button",
        "Text Button"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-13",
          "what": "\uBCF4\uC870 \uBC84\uD2BC\xB7\uD14D\uC2A4\uD2B8 \uBC84\uD2BC",
          "quote": "\uC815\uBCF8\uC5D0 \uCD94\uAC00\uD558\uB294 \uC791\uC5C5 \uCD94\uD6C4 \uC9C4\uD589\uD574\uC57C\uD568"
        }
      ],
      "why": "\uBCF4\uC870 \uBC84\uD2BC\uC740 Button \uC758 \uBCC0\uD615\uC774 \uC544\uB2C8\uB77C \uBCC4\uB3C4 \uC138\uD2B8\uB2E4(\uD06C\uAE30 1\uC885).",
      "note": "\uBCF4\uC870 \uBC84\uD2BC\uC740 Button \uC758 \uBCC0\uD615\uC774 \uC544\uB2C8\uB77C \uBCC4\uB3C4 \uC138\uD2B8\uB2E4(\uD06C\uAE30 1\uC885)."
    },
    {
      "source": "A",
      "set": "dataview",
      "setId": "540:5681",
      "role": "\uB370\uC774\uD130 \uBCF4\uAE30",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.** (\uC815\uBCF8\uC5D0 \uB300\uC751 \uCEF4\uD3EC\uB10C\uD2B8 \uC5C6\uC74C. state \uC774\uB984\uC774 state3/state4 \uB85C \uBBF8\uC644\uC131)",
      "note": ""
    },
    {
      "source": "A",
      "set": "bottomsheet_option",
      "setId": "540:5862",
      "role": "\uBC14\uD140\uC2DC\uD2B8 \uD56D\uBAA9",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Bottom Sheet",
        "Bottom Sheet Option",
        "Date Picker Mobile Bottom Sheet",
        "Time Picker Mobile Bottom Sheet"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-05",
          "what": "\uBC14\uD140\uC2DC\uD2B8",
          "quote": "\uBC14\uD140\uC2DC\uD2B8 \uC815\uBCF8\uC5D0 \uC788\uC73C\uB2C8 \uCC3E\uC544\uBCFC\uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "mobile_bottomsheet",
      "setId": "540:5903",
      "role": "\uBAA8\uBC14\uC77C \uBC14\uD140\uC2DC\uD2B8",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Bottom Sheet",
        "Bottom Sheet Option",
        "Date Picker Mobile Bottom Sheet",
        "Time Picker Mobile Bottom Sheet"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-05",
          "what": "\uBC14\uD140\uC2DC\uD2B8",
          "quote": "\uBC14\uD140\uC2DC\uD2B8 \uC815\uBCF8\uC5D0 \uC788\uC73C\uB2C8 \uCC3E\uC544\uBCFC\uAC83"
        }
      ],
      "why": "",
      "note": ""
    },
    {
      "source": "A",
      "set": "toolbar_link",
      "setId": "540:6101",
      "role": "\uD234\uBC14 \uB9C1\uD06C",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "slot_utility",
      "setId": "540:6219",
      "role": "\uC0C1\uB2E8 \uBC14 \uC720\uD2F8\uB9AC\uD2F0 \uC2AC\uB86F",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "language_set",
      "setId": "540:6238",
      "role": "\uC5B8\uC5B4 \uC120\uD0DD",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "breadcrumb_element",
      "setId": "540:6273",
      "role": "\uACBD\uB85C \uD45C\uC2DC \uC870\uAC01",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "toolbar_text",
      "setId": "540:6288",
      "role": "\uD234\uBC14 \uD14D\uC2A4\uD2B8",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "mobile_dot-nav",
      "setId": "540:6360",
      "role": "\uBAA8\uBC14\uC77C \uC810 \uB124\uBE44",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "gnb list",
      "setId": "540:6398",
      "role": "\uC0C1\uB2E8 \uBC14 \uBA54\uB274 \uBAA9\uB85D",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "GNB Sub Menu",
        "GNB Sub Menu Item"
      ],
      "rules": [],
      "notes": [
        {
          "from": "1depth",
          "then": {
            "Depth": "1depth"
          },
          "set": "GNB Sub Menu Item"
        },
        {
          "from": "2depth",
          "then": {
            "Depth": "2depth"
          },
          "set": "GNB Sub Menu Item"
        }
      ],
      "basis": [
        {
          "id": "D-18",
          "what": "\uC0C1\uB2E8\uBC14 \uBA54\uB274 \uBAA9\uB85D\xB7\uD558\uC704\uBA54\uB274 \uAE4A\uC774",
          "quote": "\uD558\uC704\uBA54\uB274 \uAE4A\uC774\uC5D0 \uB300\uD55C \uB0B4\uC6A9\uB3C4 \uCD94\uAC00 \uD544\uC694"
        }
      ],
      "why": "\uAE4A\uC774 \uCD95\uC740 \uD56D\uBAA9(GNB Sub Menu Item)\uC5D0 \uC788\uACE0, \uD3BC\uCE68 \uD328\uB110\uC740 Type(regular\xB7compact-1\xB7compact-2)\uC73C\uB85C \uB098\uB25C\uB2E4.",
      "note": "\uAE4A\uC774 \uCD95\uC740 \uD56D\uBAA9(GNB Sub Menu Item)\uC5D0 \uC788\uACE0, \uD3BC\uCE68 \uD328\uB110\uC740 Type(regular\xB7compact-1\xB7compact-2)\uC73C\uB85C \uB098\uB25C\uB2E4."
    },
    {
      "source": "A",
      "set": "breadcrumb",
      "setId": "540:6470",
      "role": "\uACBD\uB85C \uD45C\uC2DC \uC804\uCCB4",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "toobar",
      "setId": "540:6501",
      "role": "\uD234\uBC14 \uC804\uCCB4",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "A",
      "set": "state_emoji",
      "setId": "540:7291",
      "role": "\uD45C\uC815 \uC544\uC774\uCF58",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "form_label",
      "setId": "78:5137",
      "role": "\uD3FC \uB77C\uBCA8",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "form_elements",
      "setId": "78:5977",
      "role": "\uD3FC \uBB36\uC74C(\uC5EC\uB7EC \uCEF4\uD3EC\uB10C\uD2B8 \uC870\uD569)",
      "kind": "not-a-part",
      "status": "pattern",
      "canonSets": [
        "Input",
        "Select Box",
        "Radio",
        "Date Picker",
        "Text Area"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-19",
          "what": "\uD3FC \uBB36\uC74C(form)",
          "quote": "\uD328\uD134\uC73C\uB85C \uBCFC\uC9C0 \uCEF4\uD3EC\uB10C\uD2B8\uB85C \uBCFC\uC9C0 \uBAA8\uD638\uD574\uC11C \uB17C\uC758 \uD544\uC694"
        }
      ],
      "why": "\uB77C\uBCA8\uACFC \uC785\uB825 \uC694\uC18C\uB97C \uD55C \uC904\uB85C \uB193\uB294 \uBC30\uCE58 \uADDC\uCE59\uC774\uB2E4. \uBD80\uD488\uC73C\uB85C \uB9CC\uB4E4\uC9C0 \uC54A\uB294\uB2E4(2026-09-17 river).",
      "note": ""
    },
    {
      "source": "B",
      "set": "form",
      "setId": "611:8618",
      "role": "\uD3FC \uD2C0",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_category_v1",
      "setId": "89:2614",
      "role": "\uCE74\uD14C\uACE0\uB9AC \uD2B8\uB9AC v1",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_category_v1_sub",
      "setId": "89:2874",
      "role": "\uCE74\uD14C\uACE0\uB9AC \uD2B8\uB9AC v1 \uD558\uC704",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_category_v2",
      "setId": "89:3036",
      "role": "\uCE74\uD14C\uACE0\uB9AC \uD2B8\uB9AC v2",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "elements_category_v2_sub",
      "setId": "101:2050",
      "role": "\uCE74\uD14C\uACE0\uB9AC \uD2B8\uB9AC v2 \uD558\uC704",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "search",
      "setId": "16:1975",
      "role": "\uAC80\uC0C9\uCC3D",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "popup_button",
      "setId": "49:1870",
      "role": "\uD31D\uC5C5 \uBC84\uD2BC",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Button"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-21",
          "what": "B\uD30C\uC77C \uBC84\uD2BC \uC0C9 \uC774\uB984",
          "quote": "mix\uB294 \uBC84\uD2BC \uB450\uAC1C\uAC00 \uBAA8\uB4C8\uB85C\uC788\uB294 \uC720\uD615\uC774\uBA70, \uBCC0\uD658\uC2DC \uD558\uC704 \uB450\uAC1C \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\uACFC \uD06C\uAE30\uC5D0  \uB9DE\uAC8C \uBCC0\uD615\uB418\uB3C4\uB85D \uD574\uC57C\uD568"
        }
      ],
      "why": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4.",
      "note": "\uB808\uAC70\uC2DC mix \uB294 \uBC84\uD2BC \uB450 \uAC1C\uAC00 \uD55C \uB369\uC5B4\uB9AC\uC778 \uC720\uD615\uC774\uB2E4. \uC62E\uAE38 \uB54C \uD558\uC704 \uBC84\uD2BC\uC744 \uAC01\uAC01 \uC720\uD615\xB7\uD06C\uAE30\uC5D0 \uB9DE\uCDB0 \uBC14\uAFBC\uB2E4. blue\xB7white\xB7red \uB0B1\uAC1C \uB300\uC751\uC740 \uACB0\uC815\uB418\uC9C0 \uC54A\uC558\uB2E4."
    },
    {
      "source": "B",
      "set": "m_list",
      "setId": "205:4399",
      "role": "\uBAA8\uBC14\uC77C \uBAA9\uB85D",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_tooltip",
      "setId": "611:17145",
      "role": "\uBAA8\uBC14\uC77C \uD234\uD301",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "slider",
      "setId": "168:4453",
      "role": "\uC2AC\uB77C\uC774\uB354",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "window",
      "setId": "1008:10146",
      "role": "\uCC3D \uD2C0",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "login",
      "setId": "1008:10149",
      "role": "\uB85C\uADF8\uC778 \uD654\uBA74",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "footer",
      "setId": "288:4456",
      "role": "\uD478\uD130",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "serch tab",
      "setId": "78:2971",
      "role": "\uAC80\uC0C9 \uD0ED",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "lnb",
      "setId": "281:6829",
      "role": "\uC88C\uCE21 \uBA54\uB274(LNB)",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "menutree",
      "setId": "114:4602",
      "role": "\uBA54\uB274 \uD2B8\uB9AC",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "appbar_sub",
      "setId": "42:1974",
      "role": "\uBAA8\uBC14\uC77C \uD558\uC704 \uC0C1\uB2E8\uBC14",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Mobile Header"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-17",
          "what": "\uBAA8\uBC14\uC77C \uC0C1\uB2E8\uBC14 6\uC885 \uB300\uC751",
          "quote": "\uC544\uC774\uCF58 \uB450\uAC1C\uC788\uB294 \uBC84\uC804\uACFC \uC571\uBC14\uB294 \uC0AC\uC6A9\uD558\uC9C0\uC54A\uC74C.  \uADF8\uB7F0\uB370 \uB2E4\uC2DC\uBCF4\uB2C8 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC774 \uB204\uB77D\uB428. \uC81C\uC791\uD6C4 \uC0AD\uC81C\uB41C \uB450\uAC1C\uC720\uD615\uC740 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC73C\uB85C \uBCC0\uACBD\uD558\uBA74\uB428"
        }
      ],
      "why": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4.",
      "note": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4."
    },
    {
      "source": "B",
      "set": "appbar_main",
      "setId": "42:3100",
      "role": "\uBAA8\uBC14\uC77C \uBA54\uC778 \uC0C1\uB2E8\uBC14",
      "kind": "decided",
      "status": "matched",
      "canonSets": [
        "Mobile Header"
      ],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "D-17",
          "what": "\uBAA8\uBC14\uC77C \uC0C1\uB2E8\uBC14 6\uC885 \uB300\uC751",
          "quote": "\uC544\uC774\uCF58 \uB450\uAC1C\uC788\uB294 \uBC84\uC804\uACFC \uC571\uBC14\uB294 \uC0AC\uC6A9\uD558\uC9C0\uC54A\uC74C.  \uADF8\uB7F0\uB370 \uB2E4\uC2DC\uBCF4\uB2C8 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC774 \uB204\uB77D\uB428. \uC81C\uC791\uD6C4 \uC0AD\uC81C\uB41C \uB450\uAC1C\uC720\uD615\uC740 \uD648+\uD0C0\uC774\uD2C0+\uC544\uC774\uCF58 \uC720\uD615\uC73C\uB85C \uBCC0\uACBD\uD558\uBA74\uB428"
        }
      ],
      "why": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4.",
      "note": "\uC5C6\uC564 \uB450 \uC720\uD615 \uC790\uB9AC\uB97C \uC544\uC774\uCF58 1\uAC1C \uC720\uD615 \uD558\uB098\uB85C \uCC44\uC6E0\uB2E4. \uC774 \uC870\uD569\uC740 \uB808\uAC70\uC2DC \uB450 \uD30C\uC77C \uC5B4\uB514\uC5D0\uB3C4 \uC5C6\uC5B4 \uC0C8\uB85C \uB9CC\uB4E0 \uAC83\uC774\uB2E4."
    },
    {
      "source": "B",
      "set": "m_base",
      "setId": "1008:10639",
      "role": "\uBAA8\uBC14\uC77C \uAE30\uBCF8 \uD2C0",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_footer",
      "setId": "203:4854",
      "role": "\uBAA8\uBC14\uC77C \uD478\uD130",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_bar",
      "setId": "204:4428",
      "role": "\uBAA8\uBC14\uC77C \uBC14",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "keyboard",
      "setId": "813:8566",
      "role": "\uD0A4\uBCF4\uB4DC",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "phone_navi",
      "setId": "2362:12251",
      "role": "\uD3F0 \uB124\uBE44\uAC8C\uC774\uC158",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_card",
      "setId": "1008:10726",
      "role": "\uBAA8\uBC14\uC77C \uCE74\uB4DC",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_dashboard",
      "setId": "1008:10729",
      "role": "\uBAA8\uBC14\uC77C \uB300\uC2DC\uBCF4\uB4DC",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    },
    {
      "source": "B",
      "set": "m_slider",
      "setId": "1796:13956",
      "role": "\uBAA8\uBC14\uC77C \uC2AC\uB77C\uC774\uB354",
      "kind": "undecided",
      "status": "undecided",
      "canonSets": [],
      "rules": [],
      "notes": [],
      "basis": [
        {
          "id": "\uD45C",
          "what": "\uB808\uAC70\uC2DC \uC18D\uC131\uD45C\uC5D0 \uC801\uD78C \uC9DD",
          "quote": ""
        }
      ],
      "why": "\uC790\uB3D9 \uD6D1\uAE30\uB85C\uB294 \uC9C0\uAE08 \uAC83\uC5D0\uC11C \uC9DD\uC744 \uBABB \uCC3E\uC558\uC2B5\uB2C8\uB2E4 \u2014 **\uC0AC\uB78C\uC774 \uC815\uD55C \uBC14\uB294 \uC5C6\uC2B5\uB2C8\uB2E4.**",
      "note": ""
    }
  ];

  // registry/figma/allowed-remote-keys.json
  var allowed_remote_keys_default = {
    $comment: "\uC678\uBD80 \uB77C\uC774\uBE0C\uB7EC\uB9AC(remote:true) \uC911 '\uD5C8\uC6A9\uB418\uB294' \uCEF4\uD3EC\uB10C\uD2B8 \uD0A4\uC758 \uB2E8\uC77C \uCD9C\uCC98. Figma \uD654\uBA74/\uB77C\uC774\uBE0C\uB7EC\uB9AC \uBE4C\uB4DC \uC2DC \uC778\uC2A4\uD134\uC2A4\uC758 mainComponent.remote===true \uC778 \uAC83\uC740 \uC774 \uBAA9\uB85D\uC758 key \uC77C \uB54C\uB9CC \uD5C8\uC6A9\uD558\uACE0, \uADF8 \uC678\uB294 \uC804\uBD80 \uC678\uBD80 \uB77C\uC774\uBE0C\uB7EC\uB9AC \uC704\uBC18(\u274C)\uC73C\uB85C \uBCF8\uB2E4. \uC774\uB984(ic_ \uC811\uB450\uC0AC \uB4F1)\uC73C\uB85C \uD310\uB2E8\uD558\uC9C0 \uB9D0 \uAC83 \u2014 \uC678\uBD80 \uB77C\uC774\uBE0C\uB7EC\uB9AC\uB3C4 \uAC19\uC740 \uC774\uB984\uC744 \uC4F4\uB2E4(2026-06-19 \uC624\uD0D0/\uB204\uC218\uC758 \uADFC\uBCF8 \uC6D0\uC778). \uD0A4 \uAE30\uC900\uB9CC \uC2E0\uB8B0\uD55C\uB2E4.",
    lastSynced: "2026-09-15",
    source: "installer \uC544\uC774\uCF58 20\uD0A4 = plugins/figma-vars-installer/src/build-components.ts ICON_KEYS(2026-09-04 eye_show \uCD94\uAC00 \u2014 \uC6F9 Password \uC635\uC158\uC758 \uD45C\uC2DC \uC911 \uC544\uC774\uCF58 \xB7 2026-09-14 navSearch\xB7navNotification\xB7navSettings \uCD94\uAC00 \u2014 \uD558\uB2E8 \uB0B4\uBE44 \uCE78\uBCC4 \uC544\uC774\uCF58, river \uC2B9\uC778). V3.0-only \uCD94\uAC00\uBD84(password-eye)\uC740 ICON_KEYS \uBC16\uC774\uBA70 V3.0 Login Input \uC5D0\uC11C \uC9C1\uC811 \uC0AC\uC6A9. video-only \uCD94\uAC00\uBD84(refresh)\uC740 ICON_KEYS \uBC16\uC774\uBA70 Video/Widget Header(figma-library-build)\uC5D0\uC11C \uC9C1\uC811 \uC0AC\uC6A9 \u2014 \uC774 \uD30C\uC77C\uC774 provenance \uD5C8\uC6A9\uBAA9\uB85D\uC758 \uC815\uBCF8. \xB7 2026-09-15 check24 \uCD94\uAC00 \u2014 ic_\uD655\uC778 \uC758 24 \uD504\uB808\uC784 \uD45C\uCD9C\uC774\uB77C check \uACFC **\uAC19\uC740 key** \uB97C \uAC00\uB9AC\uD0A8\uB2E4(\uC0C8 \uC678\uBD80 \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uD5C8\uC6A9\uD558\uB294 \uAC83\uC774 \uC544\uB2C8\uB77C \uC774\uB984 \uD558\uB098\uB97C \uB354 \uB450\uB294 \uAC83). 16 \uD504\uB808\uC784 \uC790\uC0B0\uC744 24 \uB85C \uD655\uB300\uD558\uBA74 \uC120 \uAD75\uAE30\uAE4C\uC9C0 1.5\uBC30\uAC00 \uB418\uC5B4 \uC815\uBCF8\uBCF4\uB2E4 \uAD75\uC5B4\uC9C0\uBBC0\uB85C \uD504\uB808\uC784\uBCC4\uB85C \uC790\uC0B0\uC744 \uB098\uB208\uB2E4.",
    iconLibraryFileKey: "YcBbW9e0MTR9T3W5Sz0Ukx",
    iconLibraryName: "\uC544\uC774\uCF58 \uB77C\uC774\uBE0C\uB7EC\uB9AC V2.2 (14.UI \uC139\uC158)",
    allowedRemoteComponentKeys: {
      remove: "24b2df622d341e0af21cd4b23b4a7d23b97a5ea7",
      check: "5ab251e0d90adb555ee2fa316f84e86041f19916",
      check24: "5ab251e0d90adb555ee2fa316f84e86041f19916",
      search: "6b764af642b8883e892754281950da0e971224d7",
      clock: "ca1d043ac09be07f827e939be3d8c3c7af8a8dd9",
      calendar: "ea0ffc118c38048f2cdfb5620be31c120426bb7a",
      menu: "5157e9edc76358e2e6bc1a5ebc1539ccf5f2e787",
      account: "a423e2e05cfff2f93062d6a83d6f3bdf79ca9647",
      chevron: "e1ac97aa82f4e52f257ac1c0ea77fd09d0e5f581",
      globe: "dee16df7e4ccddbd5dd7aa1d2fbf93f841f5dee2",
      home: "6bf422c937034ce15f6814e5c430d8f85953ed4e",
      home_set: "c99f913689cd068deb2a5499154fed423ec9579f",
      close: "2a1abbd3597b536e34fd9523fb61eade3afe9934",
      eye_hide: "d4e9eb5b7e193ee291aa2a7e04396c8de2d2dae7",
      eye_show: "b130623bad9bf035e273501b404bf7a245af1460",
      edge_set: "606d0de897175059f133427bf62bb3635d18a860",
      lock: "28aa6b1615f3afb29ff22cf2767f0c771c941fdc",
      lock_set: "b3ccc4b275de6aac8e3940df2ae97fbb00168624",
      refresh: "e9a3d9b7e0c60b93fc10e2f6485ab77bd06329f0",
      refresh_set: "617757d927a1bae7df6ccdf0d24cc0e3c5a04255",
      mobileHeaderBack: "7190e284d345ae19a679a16ed7bceafbd54073ca",
      mobileHeaderClose: "54469d54f16ed38de2d7b420b0e2195e4cf7c118",
      mobileHeaderNotification: "13cf1b580ec982fda488f9318c6821930ddfb26e",
      mobileHeaderArrowDown: "6babc3f493e48be1e7191a7b8a68945833039fe8",
      navSearch: "e86d0bce3a9de2bf1ed37b29ee56278bf4927cb9",
      navNotification: "0994ea9c97ad4c65a9d461a0f0b7381675946973",
      navSettings: "175fb8933701ad7db5485a44dd07e26d34dfeef2"
    },
    note: "\uD5C8\uC6A9\uBAA9\uB85D\uC5D0 \uC5C6\uB294 ic_* \uC778\uC2A4\uD134\uC2A4(\uC608: ic_\uB2EB\uAE30\xB7ic_\uC7A0\uAE40 \uB4F1)\uB294 \uC815\uC2DD V2.2 \uC544\uC774\uCF58\uC77C \uC218 \uC788\uC73C\uB098 \uC6B0\uB9AC \uC124\uCE58\uAE30\uC5D0 \uBBF8\uB4F1\uB85D \uC0C1\uD0DC\uB2E4. \uC790\uB3D9\uC73C\uB85C '\uC704\uBC18' \uB2E8\uC815\uD558\uC9C0 \uB9D0\uACE0 (c)\uC560\uB9E4\uB85C \uBD84\uB958\uD574 \uC0AC\uC6A9\uC790 \uD655\uC778 \uD6C4, \uC815\uC2DD \uC544\uC774\uCF58\uC774\uBA74 build-components.ts ICON_KEYS + \uC774 \uD30C\uC77C\uC5D0 \uD0A4\uB97C \uCD94\uAC00\uD55C\uB2E4. edge_set \uC740 componentSet \uD0A4(importComponentSetByKeyAsync) \u2014 \uAC1C\uBCC4 variant \uD0A4\uAC00 \uC544\uB2D8\uC5D0 \uC8FC\uC758.",
    nameAliases: {
      eye: "eye_hide",
      _note: "\uC124\uCE58\uAE30 ICON_KEYS \uC758 \uC774\uB984 \u2194 \uD5C8\uC6A9\uBAA9\uB85D\uC758 \uC774\uB984\uC774 \uB2E4\uB978 \uACBD\uC6B0\uC758 \uB300\uC751\uD45C. \uAC12(\uCEF4\uD3EC\uB10C\uD2B8 \uD0A4)\uC774 \uAC19\uC544\uC57C\uB9CC \uBCC4\uCE6D\uC73C\uB85C \uC778\uC815\uD55C\uB2E4(Gate 31 \uC774 \uAC12 \uC77C\uCE58\uAE4C\uC9C0 \uD655\uC778). eye: \uC124\uCE58\uAE30\uB294 \uBE44\uBC00\uBC88\uD638 \uC785\uB825\uC758 \uAE30\uBCF8 \uC544\uC774\uCF58\uC774\uB77C eye \uB85C \uBD80\uB974\uACE0, \uD5C8\uC6A9\uBAA9\uB85D\uC740 \uD45C\uC2DC/\uBBF8\uD45C\uC2DC \uC30D\uC744 \uAD6C\uBD84\uD574 eye_hide/eye_show \uB85C \uBD80\uB978\uB2E4 \u2014 \uAC19\uC740 \uB178\uB4DC(d4e9eb5b\u2026)."
    }
  };

  // registry/components/component-facts.json
  var component_facts_default = {
    _meta: {
      generated: true,
      source: "plugins/figma-vars-installer/src/build-components.ts",
      method: "mock-execution",
      sourceHash: "cee35c96b1bd",
      unknownValuePolicy: [
        "unknown",
        "not-defined",
        "figma-unconfirmed"
      ]
    },
    iconLibrary: {
      source: "S1 Icon Library (V2.2 remote component keys used by installer)",
      allowed: [
        "account",
        "calendar",
        "check",
        "chevron",
        "clock",
        "close",
        "eye",
        "eye_show",
        "globe",
        "home",
        "menu",
        "mobileHeaderArrowDown",
        "mobileHeaderBack",
        "mobileHeaderClose",
        "mobileHeaderNotification",
        "navNotification",
        "navSearch",
        "navSettings",
        "remove",
        "search"
      ]
    },
    components: {
      StatusBar: {
        variantAxes: {
          Platform: [
            "App",
            "Web"
          ]
        },
        geometry: [
          {
            when: {
              Platform: "App"
            },
            target: "root",
            width: 360,
            height: 27,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "16",
            paddingBottom: "0",
            paddingLeft: "20"
          },
          {
            when: {
              Platform: "Web"
            },
            target: "root",
            width: 360,
            height: 77,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0"
          }
        ],
        anatomy: [
          "browser-url-bar",
          "status-right",
          "status-row"
        ],
        tokenBindings: [
          "color/bg/level-0",
          "color/bg/level-2",
          "color/icon/gray-dark",
          "color/text/body/secondary",
          "color/text/body/tertiary"
        ],
        composition: {
          buildDependencies: []
        }
      },
      NavBar: {
        variantAxes: {
          Platform: [
            "App",
            "Web",
            "App + Keyboard",
            "Web + Keyboard"
          ]
        },
        geometry: [
          {
            when: {
              Platform: "App"
            },
            target: "root",
            width: 360,
            height: 45,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "48",
            paddingBottom: "0",
            paddingLeft: "48"
          },
          {
            when: {
              Platform: "Web"
            },
            target: "root",
            width: 360,
            height: 95,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0"
          },
          {
            when: {
              Platform: "App + Keyboard"
            },
            target: "root",
            width: 360,
            height: 341,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0"
          },
          {
            when: {
              Platform: "Web + Keyboard"
            },
            target: "root",
            width: 360,
            height: 391,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0"
          }
        ],
        anatomy: [
          "android-nav",
          "browser-toolbar",
          "icon",
          "keyboard"
        ],
        tokenBindings: [
          "color/bg/level-0",
          "color/bg/level-1",
          "color/bg/level-2",
          "color/icon/gray",
          "color/text/body/primary",
          "radius/4"
        ],
        composition: {
          buildDependencies: []
        }
      },
      CI: {
        variantAxes: {
          Brand: [
            "\uC5D0\uC2A4\uC6D0",
            "\uC0BC\uC131"
          ],
          Color: [
            "White",
            "Blue",
            "Dark"
          ]
        },
        geometry: [
          {
            when: {
              Brand: "\uC5D0\uC2A4\uC6D0"
            },
            target: "root",
            width: 78.75,
            height: 30
          },
          {
            when: {
              Brand: "\uC0BC\uC131"
            },
            target: "root",
            width: 134,
            height: 36
          }
        ],
        anatomy: [
          "Samsung_Orig_Wordmark_BLUE_RGB",
          "Samsung_Orig_Wordmark_DARK_RGB",
          "Samsung_Orig_Wordmark_WHITE_RGB",
          "logo"
        ],
        tokenBindings: [],
        composition: {
          buildDependencies: []
        }
      },
      LoginGNB: {
        variantAxes: "not-defined",
        geometry: [
          {
            when: "all",
            target: "root",
            width: 1920,
            height: 56,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "12",
            paddingRight: "320",
            paddingBottom: "12",
            paddingLeft: "320",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "language-group",
          "service-group"
        ],
        tokenBindings: [
          "color/icon/gray-dark",
          "color/line/gray/subtle",
          "color/navigation/bg",
          "color/text/title/primary"
        ],
        composition: {
          buildDependencies: []
        }
      },
      WebTabBar: {
        variantAxes: "not-defined",
        geometry: [
          {
            when: "all",
            target: "root",
            width: 1920,
            height: 101,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "address-row",
          "tab-row"
        ],
        tokenBindings: [
          "color/bg/level-0",
          "color/bg/level-3",
          "color/icon/blue",
          "color/line/gray/subtle",
          "color/scroll/bg",
          "color/text/body/secondary"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Footer: {
        variantAxes: {
          Platform: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Platform: "PC"
            },
            target: "root",
            width: 1920,
            height: 116,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "spacing/28",
            paddingRight: "320",
            paddingBottom: "spacing/28",
            paddingLeft: "320",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Platform: "Mobile"
            },
            target: "sep",
            width: 1,
            height: 10
          }
        ],
        anatomy: [
          "C/IMG/Logo/S1_g",
          "content-left",
          "links"
        ],
        tokenBindings: [
          "color/icon/gray-light",
          "color/line/gray/subtle",
          "color/navigation/bg",
          "color/text/body/tertiary",
          "spacing/28",
          "spacing/4"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Language Icon": {
        variantAxes: {
          Language: [
            "English",
            "Korean"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "globe",
            width: 32,
            height: 32
          }
        ],
        anatomy: [
          "globe"
        ],
        tokenBindings: [
          "color/text/body/primary"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "GNB Utility Icon": {
        variantAxes: {
          language: [
            "on",
            "off"
          ],
          menu: [
            "on",
            "off"
          ],
          user: [
            "on",
            "off"
          ]
        },
        geometry: [
          {
            when: {
              user: "on"
            },
            target: "account",
            width: 32,
            height: 32,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER"
          },
          {
            when: {
              language: "on",
              menu: "off",
              user: "off"
            },
            target: "globe",
            width: 32,
            height: 32
          }
        ],
        anatomy: [
          "Language=Korean",
          "account",
          "menu"
        ],
        tokenBindings: [
          "color/text/body/primary"
        ],
        composition: {
          buildDependencies: [
            "Language Icon"
          ]
        }
      },
      "GNB Menu": {
        variantAxes: {
          Size: [
            "md",
            "sm",
            "xsm"
          ],
          State: [
            "Default",
            "Hover",
            "Selected"
          ]
        },
        geometry: [
          {
            when: {
              Size: "md"
            },
            target: "root",
            width: 116,
            height: 56
          },
          {
            when: {
              Size: "sm"
            },
            target: "root",
            width: 116,
            height: 48
          },
          {
            when: {
              Size: "xsm"
            },
            target: "root",
            width: 116,
            height: 36
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/navigation/indicator/selected",
          "color/navigation/label/default-alt",
          "color/navigation/label/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      GNB: {
        variantAxes: {
          Align: [
            "Center-Between",
            "Start"
          ],
          Size: [
            "md",
            "sm",
            "xsm"
          ]
        },
        geometry: [
          {
            when: {
              Size: "md"
            },
            target: "root",
            width: 1920,
            height: 56,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "20",
            paddingBottom: "0",
            paddingLeft: "24"
          },
          {
            when: {
              Size: "sm"
            },
            target: "root",
            width: 1920,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "20",
            paddingBottom: "0",
            paddingLeft: "24"
          },
          {
            when: {
              Size: "xsm"
            },
            target: "root",
            width: 1920,
            height: 36,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "24",
            paddingBottom: "0",
            paddingLeft: "20"
          }
        ],
        anatomy: [
          "Menus",
          "border",
          "language=on, menu=on, user=on",
          "leading"
        ],
        tokenBindings: [
          "color/line/gray/subtle",
          "color/navigation/bg",
          "color/navigation/indicator/selected",
          "color/navigation/label/default-alt",
          "color/navigation/label/selected",
          "color/text/body/primary",
          "color/text/title/primary"
        ],
        composition: {
          buildDependencies: [
            "GNB Utility Icon"
          ]
        },
        slots: [
          "Menus"
        ]
      },
      "GNB Sub Menu Item": {
        variantAxes: {
          Depth: [
            "1depth",
            "2depth"
          ],
          State: [
            "Default",
            "Hover",
            "Selected"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "AUTO",
            counterAxisAlignItems: "CENTER"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/navigation/label/default",
          "color/navigation/label/selected",
          "color/navigation/submenu/label/default"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "GNB Sub Menu": {
        variantAxes: {
          Type: [
            "regular",
            "compact-1",
            "compact-2"
          ]
        },
        geometry: [
          {
            when: {
              Type: "regular"
            },
            target: "root",
            width: 1920,
            height: 100,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "MIN",
            itemSpacing: "0",
            paddingTop: "spacing/32",
            paddingRight: "spacing/24",
            paddingBottom: "spacing/64",
            paddingLeft: "spacing/24",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Type: [
                "compact-1",
                "compact-2"
              ]
            },
            target: "root",
            width: 1920,
            height: 100,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "MIN",
            itemSpacing: "0",
            paddingTop: "spacing/24",
            paddingRight: "spacing/24",
            paddingBottom: "spacing/24",
            paddingLeft: "spacing/24",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "Columns"
        ],
        tokenBindings: [
          "color/line/gray/subtle",
          "color/navigation/bg",
          "color/navigation/label/default",
          "color/navigation/label/selected",
          "color/navigation/submenu/label/default",
          "spacing/20",
          "spacing/24",
          "spacing/32",
          "spacing/64",
          "spacing/80"
        ],
        composition: {
          buildDependencies: [
            "GNB Sub Menu Item"
          ]
        },
        slots: [
          "Columns"
        ]
      },
      "Mobile Bottom Nav": {
        variantAxes: {
          icon: [
            "home",
            "search",
            "notification",
            "settings"
          ],
          state: [
            "unselected",
            "selected"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 60,
            height: 60,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "4"
          }
        ],
        anatomy: [
          "home",
          "navNotification",
          "navSearch",
          "navSettings"
        ],
        tokenBindings: [
          "color/navigation/label/default",
          "color/navigation/label/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Mobile Header": {
        variantAxes: {
          Type: [
            "Home / Title",
            "Home / Title + 1 Icon",
            "Home / Title + Subtitle + 1 Icon",
            "Standard / Title",
            "Standard / Title + Close",
            "Standard / No Title",
            "Standard / No Title + Close"
          ],
          Platform: [
            "App",
            "Web"
          ]
        },
        geometry: [
          {
            when: {
              Platform: "App"
            },
            target: "root",
            width: 360,
            height: 99,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "16"
          },
          {
            when: {
              Platform: "Web"
            },
            target: "root",
            width: 360,
            height: 149,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "16"
          }
        ],
        anatomy: [
          "AppBar",
          "StatusBar"
        ],
        tokenBindings: [
          "color/bg/home",
          "color/bg/level-0",
          "color/bg/level-2",
          "color/icon/gray-dark",
          "color/text/body/secondary",
          "color/text/body/tertiary",
          "color/text/title/primary"
        ],
        composition: {
          buildDependencies: [
            "StatusBar"
          ]
        }
      },
      "Line Tab": {
        variantAxes: {
          Size: [
            "SM",
            "MD",
            "XSM"
          ],
          State: [
            "Unselected",
            "Hover",
            "Selected"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "SM",
              Break: "PC"
            },
            target: "root",
            width: 76,
            height: 42,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0",
            minWidth: "76"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "root",
            width: 76,
            height: 44,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0",
            minWidth: "76"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "root",
            width: 76,
            height: 40,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0",
            minWidth: "76"
          },
          {
            when: {
              Size: "SM",
              Break: "Mobile"
            },
            target: "root",
            width: 76,
            height: 32,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0",
            minWidth: "76"
          }
        ],
        anatomy: [
          "label"
        ],
        tokenBindings: [
          "color/navigation/indicator/default",
          "color/navigation/indicator/hover",
          "color/navigation/indicator/selected",
          "color/navigation/label/default",
          "color/navigation/label/hover",
          "color/navigation/label/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Line Tab Set": {
        variantAxes: {
          Size: [
            "MD",
            "SM",
            "XSM"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "rectangle",
            width: 76,
            height: 2
          }
        ],
        anatomy: [
          "Tabs"
        ],
        tokenBindings: [
          "color/navigation/indicator/default",
          "color/navigation/indicator/selected",
          "color/navigation/label/default",
          "color/navigation/label/selected"
        ],
        composition: {
          buildDependencies: [
            "Line Tab"
          ]
        },
        slots: [
          "Tabs"
        ]
      },
      "Pagination Cell": {
        variantAxes: {
          Element: [
            "Arrow",
            "Edge",
            "Number"
          ],
          State: [
            "Default",
            "Hover",
            "Disabled",
            "Selected"
          ]
        },
        geometry: [
          {
            when: {
              Element: [
                "Arrow",
                "Edge"
              ],
              State: [
                "Default",
                "Hover",
                "Disabled"
              ]
            },
            target: "root",
            width: 28,
            height: 28,
            cornerRadius: "2",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Element: "Number",
              State: [
                "Default",
                "Hover",
                "Selected"
              ]
            },
            target: "root",
            width: 28,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            cornerRadius: "2"
          }
        ],
        anatomy: [
          "chevron"
        ],
        tokenBindings: [
          "color/pagination/control/bg/default",
          "color/pagination/control/bg/disabled",
          "color/pagination/control/bg/hover",
          "color/pagination/control/border/default",
          "color/pagination/control/border/disabled",
          "color/pagination/number/default",
          "color/pagination/number/hover",
          "color/pagination/number/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Pagination: {
        variantAxes: {
          State: [
            "Single",
            "First",
            "Last",
            "Middle"
          ]
        },
        geometry: [
          {
            when: {
              State: "Single"
            },
            target: "root",
            width: 164,
            height: 28
          },
          {
            when: {
              State: [
                "First",
                "Last",
                "Middle"
              ]
            },
            target: "root",
            width: 304,
            height: 28
          }
        ],
        anatomy: [
          "pg-first",
          "pg-last",
          "pg-next",
          "pg-num-1",
          "pg-num-2",
          "pg-num-3",
          "pg-num-4",
          "pg-num-5",
          "pg-num-6",
          "pg-prev"
        ],
        tokenBindings: [
          "color/pagination/control/bg/default",
          "color/pagination/control/bg/disabled",
          "color/pagination/control/border/default",
          "color/pagination/control/border/disabled",
          "color/pagination/number/default",
          "color/pagination/number/selected"
        ],
        composition: {
          buildDependencies: [
            "Pagination Cell"
          ]
        }
      },
      Button: {
        variantAxes: {
          Size: [
            "MD",
            "XSM",
            "XXSM",
            "LG"
          ],
          State: [
            "Default",
            "Hover",
            "Pressed",
            "Disabled"
          ],
          Variant: [
            "Primary",
            "Secondary",
            "Blue-Line"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "root",
            width: 80,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "spacing/16",
            paddingBottom: "0",
            paddingLeft: "spacing/16",
            minWidth: "80",
            topLeftRadius: "radius/4",
            topRightRadius: "radius/4",
            bottomLeftRadius: "radius/4",
            bottomRightRadius: "radius/4",
            strokeWeight: "border-width/1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "root",
            width: 64,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "spacing/8",
            paddingBottom: "0",
            paddingLeft: "spacing/8",
            minWidth: "64",
            topLeftRadius: "radius/4",
            topRightRadius: "radius/4",
            bottomLeftRadius: "radius/4",
            bottomRightRadius: "radius/4",
            strokeWeight: "border-width/1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "root",
            width: 56,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "spacing/8",
            paddingBottom: "0",
            paddingLeft: "spacing/8",
            minWidth: "56",
            topLeftRadius: "radius/4",
            topRightRadius: "radius/4",
            bottomLeftRadius: "radius/4",
            bottomRightRadius: "radius/4",
            strokeWeight: "border-width/1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "LG",
              Break: "Mobile"
            },
            target: "root",
            width: 80,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "spacing/16",
            paddingBottom: "0",
            paddingLeft: "spacing/16",
            minWidth: "80",
            topLeftRadius: "radius/4",
            topRightRadius: "radius/4",
            bottomLeftRadius: "radius/4",
            bottomRightRadius: "radius/4",
            strokeWeight: "border-width/1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "border-width/1",
          "color/button/bg/blue-line--default",
          "color/button/bg/blue-line--hover",
          "color/button/bg/disabled",
          "color/button/bg/primary--default",
          "color/button/bg/primary--hover",
          "color/button/bg/secondary--default",
          "color/button/bg/secondary--hover",
          "color/button/border/blue-line--default",
          "color/button/border/blue-line--hover",
          "color/button/border/disabled",
          "color/button/border/primary--default",
          "color/button/border/primary--hover",
          "color/button/border/secondary--default",
          "color/button/border/secondary--hover",
          "color/button/label/blue-line--default",
          "color/button/label/blue-line--hover",
          "color/button/label/disabled",
          "color/button/label/primary--default",
          "color/button/label/primary--hover",
          "color/button/label/secondary--default",
          "color/button/label/secondary--hover",
          "radius/4",
          "spacing/16",
          "spacing/8"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Assist Button": {
        variantAxes: {
          State: [
            "Default",
            "Hover",
            "Pressed",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 60,
            height: 32,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "spacing/12",
            paddingBottom: "0",
            paddingLeft: "spacing/12",
            minWidth: "60",
            topLeftRadius: "radius/4",
            topRightRadius: "radius/4",
            bottomLeftRadius: "radius/4",
            bottomRightRadius: "radius/4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/button/bg/disabled",
          "color/button/bg/secondary--default",
          "color/button/bg/secondary--hover",
          "color/button/border/assist--hover",
          "color/button/border/disabled",
          "color/button/border/secondary--default",
          "color/button/label/assist--default",
          "color/button/label/assist--hover",
          "color/button/label/disabled",
          "radius/4",
          "spacing/12"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Text Button": {
        variantAxes: {
          Variant: [
            "Primary",
            "Secondary"
          ],
          State: [
            "Default",
            "Hover",
            "Pressed",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/text/body/tertiary",
          "color/text/state/accent",
          "color/text/state/disabled"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Checkbox: {
        variantAxes: {
          State: [
            "Default",
            "Hover",
            "Checked",
            "Disabled",
            "Dis+Checked"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 18,
            height: 18,
            cornerRadius: "2",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "check"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/disabled",
          "color/control/bg/hover",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/disabled",
          "color/control/border/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Radio: {
        variantAxes: {
          State: [
            "Default",
            "Hover",
            "Selected",
            "Disabled",
            "Dis+Selected"
          ],
          Label: [
            "Off",
            "On"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "circle",
            width: 18,
            height: 18,
            cornerRadius: "9",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "circle"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/disabled",
          "color/control/bg/hover",
          "color/control/border/default",
          "color/control/border/disabled",
          "color/control/border/selected",
          "color/control/indicator/disabled",
          "color/control/indicator/selected-alt",
          "color/control/label/default",
          "color/control/label/disabled"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Toggle: {
        variantAxes: {
          Pressed: [
            "Off",
            "On"
          ],
          State: [
            "Default",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 40,
            height: 20,
            cornerRadius: "10"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/control/bg/disabled",
          "color/control/bg/selected",
          "color/control/indicator/disabled",
          "color/control/indicator/selected",
          "color/control/indicator/unselected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Multi Toggle Element": {
        variantAxes: {
          position: [
            "first",
            "middle-left",
            "middle-right",
            "last"
          ],
          state: [
            "default",
            "hover",
            "selected",
            "disabled"
          ],
          size: [
            "md",
            "sm"
          ]
        },
        geometry: [
          {
            when: {
              position: "first",
              size: "md"
            },
            target: "root",
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            minWidth: "64",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              position: [
                "middle-left",
                "middle-right"
              ],
              size: "md"
            },
            target: "root",
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            minWidth: "64",
            topLeftRadius: "0",
            topRightRadius: "0",
            bottomLeftRadius: "0",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              position: "last",
              size: "md"
            },
            target: "root",
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            minWidth: "64",
            topLeftRadius: "0",
            topRightRadius: "4",
            bottomLeftRadius: "0",
            bottomRightRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              position: "first",
              size: "sm"
            },
            target: "root",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "8",
            paddingLeft: "8",
            minWidth: "56",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              position: [
                "middle-left",
                "middle-right"
              ],
              size: "sm"
            },
            target: "root",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "8",
            paddingLeft: "8",
            minWidth: "56",
            topLeftRadius: "0",
            topRightRadius: "0",
            bottomLeftRadius: "0",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              position: "last",
              size: "sm"
            },
            target: "root",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "8",
            paddingLeft: "8",
            minWidth: "56",
            topLeftRadius: "0",
            topRightRadius: "4",
            bottomLeftRadius: "0",
            bottomRightRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/button/bg/disabled",
          "color/button/bg/primary--default",
          "color/button/bg/secondary--default",
          "color/button/bg/secondary--hover",
          "color/button/border/disabled",
          "color/button/border/primary--default",
          "color/button/border/secondary--default",
          "color/button/border/secondary--hover",
          "color/button/label/disabled",
          "color/button/label/primary--default",
          "color/button/label/secondary--default",
          "color/button/label/secondary--hover"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Multi Toggle": {
        variantAxes: {
          Size: [
            "md",
            "sm"
          ],
          Selected: [
            "Left",
            "Center",
            "Right"
          ]
        },
        geometry: [
          {
            when: {
              Size: "md",
              Selected: "Left"
            },
            target: "position=first, state=selected, size=md",
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            minWidth: "64",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "md",
              Selected: [
                "Center",
                "Right"
              ]
            },
            target: "position=first, state=default, size=md",
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            minWidth: "64",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "sm",
              Selected: "Left"
            },
            target: "position=first, state=selected, size=sm",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "8",
            paddingLeft: "8",
            minWidth: "56",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "sm",
              Selected: [
                "Center",
                "Right"
              ]
            },
            target: "position=first, state=default, size=sm",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "8",
            paddingLeft: "8",
            minWidth: "56",
            topLeftRadius: "4",
            topRightRadius: "0",
            bottomLeftRadius: "4",
            bottomRightRadius: "0",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "Items"
        ],
        tokenBindings: [
          "color/button/bg/primary--default",
          "color/button/bg/secondary--default",
          "color/button/border/primary--default",
          "color/button/border/secondary--default",
          "color/button/label/primary--default",
          "color/button/label/secondary--default"
        ],
        composition: {
          buildDependencies: [
            "Multi Toggle Element"
          ]
        },
        slots: [
          "Items"
        ]
      },
      "Dropdown List": {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          Type: [
            "Text",
            "Checkbox",
            "Checkbox+All"
          ],
          State: [
            "Default",
            "Hover",
            "Selected"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Type: "Text"
            },
            target: "root",
            width: 100,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "XXSM",
              Type: "Checkbox"
            },
            target: "root",
            width: 100,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "XXSM",
              Type: "Checkbox+All"
            },
            target: "root",
            width: 100,
            height: 28,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0"
          },
          {
            when: {
              Size: "XSM",
              Type: "Text"
            },
            target: "root",
            width: 100,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "XSM",
              Type: "Checkbox"
            },
            target: "root",
            width: 100,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "XSM",
              Type: "Checkbox+All"
            },
            target: "root",
            width: 100,
            height: 34,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0"
          },
          {
            when: {
              Size: "MD",
              Type: "Text"
            },
            target: "root",
            width: 100,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "MD",
              Type: "Checkbox"
            },
            target: "root",
            width: 100,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "12"
          },
          {
            when: {
              Size: "MD",
              Type: "Checkbox+All"
            },
            target: "root",
            width: 100,
            height: 44,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "0"
          }
        ],
        anatomy: [
          "checkbox",
          "divider",
          "option"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/hover",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/selected",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected"
        ],
        composition: {
          buildDependencies: [
            "Checkbox"
          ]
        }
      },
      Dropdown: {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          Type: [
            "Text",
            "Checkbox"
          ],
          State: [
            "Default"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM"
            },
            target: "root",
            width: 100,
            height: 120,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "4",
            paddingBottom: "4",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "OUTSIDE"
          },
          {
            when: {
              Size: "XSM"
            },
            target: "root",
            width: 100,
            height: 144,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "4",
            paddingBottom: "4",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "OUTSIDE"
          },
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 100,
            height: 184,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            itemSpacing: "0",
            paddingTop: "4",
            paddingBottom: "4",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "OUTSIDE"
          }
        ],
        anatomy: [
          "Options"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/hover",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/selected",
          "color/dropdown/list/bg",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected"
        ],
        composition: {
          buildDependencies: [
            "Dropdown List"
          ]
        },
        slots: [
          "Options"
        ]
      },
      Chip: {
        variantAxes: {
          Size: [
            "SM",
            "MD"
          ],
          State: [
            "Default",
            "Hover",
            "Selected",
            "Disabled"
          ],
          Variant: [
            "Line",
            "Solid"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "SM",
              Break: "PC"
            },
            target: "root",
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "16",
            paddingLeft: "16",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "SM",
              Break: "Mobile"
            },
            target: "root",
            height: 30,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "root",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "16",
            paddingLeft: "16",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/chip/line/bg/default",
          "color/chip/line/bg/disabled",
          "color/chip/line/bg/hover",
          "color/chip/line/bg/selected",
          "color/chip/line/border/default",
          "color/chip/line/border/disabled",
          "color/chip/line/border/selected",
          "color/chip/line/label/default",
          "color/chip/line/label/disabled",
          "color/chip/line/label/selected",
          "color/chip/solid/bg/default",
          "color/chip/solid/bg/disabled",
          "color/chip/solid/bg/hover",
          "color/chip/solid/bg/selected",
          "color/chip/solid/border/default",
          "color/chip/solid/border/disabled",
          "color/chip/solid/border/selected",
          "color/chip/solid/label/default",
          "color/chip/solid/label/disabled",
          "color/chip/solid/label/selected",
          "radius/full"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "List Row": {
        variantAxes: {
          Type: [
            "Nav",
            "Value",
            "Read",
            "Pick",
            "Agree",
            "Switch",
            "Thumb"
          ],
          State: [
            "Default",
            "Pressed",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 360,
            height: 1,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "spacing/12",
            paddingTop: "spacing/12",
            paddingRight: "spacing/20",
            paddingBottom: "spacing/12",
            paddingLeft: "spacing/20"
          }
        ],
        anatomy: [
          "text",
          "\uADF8\uB9BC",
          "\uC624\uB978\uCABD \uCE78",
          "\uC67C\uCABD \uCE78"
        ],
        tokenBindings: [
          "color/bg/level-0",
          "color/bg/level-1",
          "color/bg/level-2",
          "color/control/bg/default",
          "color/control/bg/disabled",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/disabled",
          "color/control/indicator/disabled",
          "color/control/indicator/selected",
          "color/text/body/primary",
          "color/text/body/tertiary",
          "color/text/state/disabled",
          "color/text/title/primary",
          "radius/4",
          "sizing/40",
          "sizing/44",
          "spacing/12",
          "spacing/2",
          "spacing/20",
          "spacing/8"
        ],
        composition: {
          buildDependencies: [
            "Checkbox",
            "Toggle"
          ]
        },
        slots: [
          "\uADF8\uB9BC",
          "\uC624\uB978\uCABD \uCE78",
          "\uC67C\uCABD \uCE78"
        ]
      },
      Input: {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          State: [
            "Default",
            "Filled",
            "Focus",
            "Error",
            "Correct",
            "Read-Only",
            "Disabled"
          ],
          Message: [
            "Off",
            "On"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "field",
            width: 200,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "12",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "field",
            width: 200,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "12",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "field",
            width: 200,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "field",
            width: 200,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "field"
        ],
        tokenBindings: [
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/hover",
          "color/form-control/bg/selected",
          "color/form-control/border/correct",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/border/error",
          "color/form-control/border/selected",
          "color/form-control/text-cursor",
          "color/form-control/text/default",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "color/form-control/text/read-only",
          "color/form-control/text/selected",
          "color/text/state/caption",
          "color/text/state/caution",
          "color/text/state/correct",
          "color/text/state/disabled",
          "radius/4"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Search Input": {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          State: [
            "Default",
            "Filled",
            "Disabled"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "root",
            width: 200,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "12",
            minWidth: "200",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "root",
            width: 200,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "12",
            minWidth: "200",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "root",
            width: 200,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "16",
            minWidth: "200",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "root",
            width: 200,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "0",
            paddingBottom: "0",
            paddingLeft: "16",
            minWidth: "200",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "search-action",
          "trail"
        ],
        tokenBindings: [
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/hover",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/text/default",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "radius/4"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Text Area": {
        variantAxes: {
          State: [
            "Default",
            "Focus",
            "Filled",
            "Disabled",
            "Readonly"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 240,
            height: 80,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "MIN",
            paddingTop: "10",
            paddingRight: "12",
            paddingBottom: "10",
            paddingLeft: "12",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "lead"
        ],
        tokenBindings: [
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/selected",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/border/selected",
          "color/form-control/text-cursor",
          "color/form-control/text/default",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "color/form-control/text/read-only",
          "color/form-control/text/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Select Box": {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          State: [
            "Default",
            "Hover",
            "Open",
            "Filled",
            "Disabled"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "trigger",
            width: 140,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "trigger",
            width: 140,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "trigger",
            width: 140,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "trigger",
            width: 140,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "dropdown",
          "trigger"
        ],
        tokenBindings: [
          "color/dropdown/list/bg",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected",
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/hover",
          "color/form-control/bg/selected",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/border/selected",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "color/form-control/text/selected"
        ],
        composition: {
          buildDependencies: [
            "Dropdown"
          ]
        },
        slots: [
          "Options"
        ]
      },
      "Calendar Nav Arrow": {
        variantAxes: {
          State: [
            "Default",
            "Hover",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 24,
            height: 24,
            cornerRadius: "4"
          }
        ],
        anatomy: [
          "chevron"
        ],
        tokenBindings: [
          "color/date-picker/cell/bg/hover"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Calendar Cell": {
        variantAxes: {
          Size: [
            "MD",
            "SM"
          ],
          Type: [
            "Standard",
            "Range"
          ],
          State: [
            "Default",
            "Hover",
            "Today",
            "Selected",
            "Selected Hover",
            "Disabled",
            "Start",
            "End"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 44,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER"
          },
          {
            when: {
              Size: "SM"
            },
            target: "root",
            width: 33,
            height: 33,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER"
          }
        ],
        anatomy: [
          "band",
          "inner"
        ],
        tokenBindings: [
          "color/date-picker/cell/bg/hover",
          "color/date-picker/cell/bg/range",
          "color/date-picker/cell/bg/selected",
          "color/date-picker/cell/bg/selected-hover",
          "color/date-picker/cell/bg/today",
          "color/date-picker/cell/border/today",
          "color/date-picker/text/disabled",
          "color/date-picker/text/secondary",
          "color/date-picker/text/selected",
          "color/date-picker/text/today",
          "radius/full"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Calendar Tile": {
        variantAxes: {
          Size: [
            "MD",
            "SM"
          ],
          State: [
            "Default",
            "Hover",
            "Selected",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 88,
            height: 56,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "SM"
            },
            target: "root",
            width: 68,
            height: 40,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "label"
        ],
        tokenBindings: [
          "color/date-picker/cell/border/today",
          "color/date-picker/text/disabled",
          "color/date-picker/text/primary",
          "color/date-picker/text/today",
          "color/date-picker/tile/bg/default",
          "color/date-picker/tile/bg/disabled",
          "color/date-picker/tile/bg/hover",
          "color/date-picker/tile/bg/selected",
          "color/date-picker/tile/border/default",
          "color/date-picker/tile/border/disabled"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Calendar: {
        variantAxes: {
          Size: [
            "MD",
            "SM"
          ],
          State: [
            "Date",
            "Year",
            "Month"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 356,
            height: 352,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "20",
            paddingRight: "24",
            paddingBottom: "20",
            paddingLeft: "24",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "SM",
              State: "Date"
            },
            target: "root",
            width: 267,
            height: 266,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "16",
            paddingRight: "18",
            paddingBottom: "16",
            paddingLeft: "18",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "SM",
              State: [
                "Year",
                "Month"
              ]
            },
            target: "root",
            width: 267,
            height: 276,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "16",
            paddingRight: "18",
            paddingBottom: "20",
            paddingLeft: "18",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "content"
        ],
        tokenBindings: [
          "color/date-picker/cell/bg/selected",
          "color/date-picker/cell/bg/today",
          "color/date-picker/cell/border/today",
          "color/date-picker/panel/bg",
          "color/date-picker/panel/border",
          "color/date-picker/text/disabled",
          "color/date-picker/text/primary",
          "color/date-picker/text/saturday",
          "color/date-picker/text/secondary",
          "color/date-picker/text/selected",
          "color/date-picker/text/sunday",
          "color/date-picker/text/today",
          "color/date-picker/tile/bg/default",
          "color/date-picker/tile/bg/disabled",
          "color/date-picker/tile/border/default",
          "color/date-picker/tile/border/disabled",
          "radius/full"
        ],
        composition: {
          buildDependencies: [
            "Calendar Nav Arrow"
          ]
        }
      },
      "Date Picker": {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          State: [
            "Default",
            "Filled",
            "Open",
            "Disabled"
          ],
          Break: [
            "PC",
            "Mobile"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "trigger",
            width: 180,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "trigger",
            width: 180,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "trigger",
            width: 180,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "trigger",
            width: 180,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "calendar",
          "trigger"
        ],
        tokenBindings: [
          "color/date-picker/cell/bg/selected",
          "color/date-picker/cell/bg/today",
          "color/date-picker/cell/border/today",
          "color/date-picker/panel/bg",
          "color/date-picker/panel/border",
          "color/date-picker/text/disabled",
          "color/date-picker/text/primary",
          "color/date-picker/text/saturday",
          "color/date-picker/text/secondary",
          "color/date-picker/text/selected",
          "color/date-picker/text/sunday",
          "color/date-picker/text/today",
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/selected",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/border/selected",
          "color/form-control/text/default",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "color/form-control/text/selected",
          "radius/full"
        ],
        composition: {
          buildDependencies: [
            "Calendar"
          ]
        }
      },
      "Date Picker Mobile Bottom Sheet": {
        variantAxes: {
          Platform: [
            "Mobile"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 360,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "20",
            paddingRight: "0",
            paddingBottom: "20",
            paddingLeft: "0",
            topLeftRadius: "8",
            topRightRadius: "8",
            bottomLeftRadius: "0",
            bottomRightRadius: "0"
          }
        ],
        anatomy: [
          "action",
          "calendar-wrap",
          "header"
        ],
        tokenBindings: [
          "border-width/1",
          "color/button/bg/primary--default",
          "color/button/border/primary--default",
          "color/button/label/primary--default",
          "color/date-picker/cell/bg/selected",
          "color/date-picker/cell/bg/today",
          "color/date-picker/cell/border/today",
          "color/date-picker/panel/bg",
          "color/date-picker/text/disabled",
          "color/date-picker/text/primary",
          "color/date-picker/text/saturday",
          "color/date-picker/text/secondary",
          "color/date-picker/text/selected",
          "color/date-picker/text/sunday",
          "color/date-picker/text/today",
          "color/surface/raised",
          "color/text/title/primary",
          "radius/4",
          "radius/full",
          "spacing/16"
        ],
        composition: {
          buildDependencies: [
            "Calendar",
            "Button"
          ]
        }
      },
      "Time Picker Cell": {
        variantAxes: {
          State: [
            "Default",
            "Hover",
            "Selected"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 44,
            height: 32,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "CENTER",
            counterAxisAlignItems: "CENTER",
            paddingRight: "12",
            paddingLeft: "12",
            cornerRadius: "4"
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/bg/selected",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Time Picker Dropdown": {
        variantAxes: {
          Type: [
            "24h",
            "12h"
          ],
          State: [
            "\uC2DC Hover",
            "\uC2DC Selected",
            "\uBD84 Hover",
            "\uBD84 Selected"
          ]
        },
        geometry: [
          {
            when: {
              Type: "24h"
            },
            target: "root",
            width: 121,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "12",
            paddingBottom: "0",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Type: "12h"
            },
            target: "root",
            width: 194,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "0",
            paddingTop: "12",
            paddingBottom: "0",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "Option",
          "cols",
          "footer-sep"
        ],
        tokenBindings: [
          "color/dropdown/list/bg",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/bg/selected",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected",
          "color/line/gray/subtle",
          "color/text/state/accent",
          "color/text/state/disabled"
        ],
        composition: {
          buildDependencies: []
        }
      },
      "Time Picker": {
        variantAxes: {
          Size: [
            "XXSM",
            "XSM",
            "MD"
          ],
          State: [
            "Default",
            "Hover",
            "Focus",
            "Filled",
            "Disabled"
          ],
          Break: [
            "PC",
            "Mobile"
          ],
          Type: [
            "24h",
            "12h"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XXSM",
              Break: "PC"
            },
            target: "trigger",
            width: 150,
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "6",
            paddingBottom: "0",
            paddingLeft: "10",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XSM",
              Break: "PC"
            },
            target: "trigger",
            width: 150,
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "12",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "trigger",
            width: 150,
            height: 44,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "8",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "trigger",
            width: 150,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "0",
            paddingRight: "12",
            paddingBottom: "0",
            paddingLeft: "16",
            cornerRadius: "4",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "tpd",
          "trigger"
        ],
        tokenBindings: [
          "color/dropdown/list/bg",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/selected",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/selected",
          "color/form-control/bg/default",
          "color/form-control/bg/disabled",
          "color/form-control/bg/hover",
          "color/form-control/border/default",
          "color/form-control/border/disabled",
          "color/form-control/border/selected",
          "color/form-control/text/default",
          "color/form-control/text/disabled",
          "color/form-control/text/placeholder",
          "color/line/gray/subtle",
          "color/text/state/disabled"
        ],
        composition: {
          buildDependencies: [
            "Time Picker Dropdown"
          ]
        }
      },
      "Time Picker Mobile Bottom Sheet": {
        variantAxes: {
          Content: [
            "TimeOnly",
            "DateTime"
          ]
        },
        geometry: [
          {
            when: "all",
            target: "root",
            width: 360,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "20",
            paddingRight: "0",
            paddingBottom: "20",
            paddingLeft: "0",
            topLeftRadius: "8",
            topRightRadius: "8",
            bottomLeftRadius: "0",
            bottomRightRadius: "0"
          }
        ],
        anatomy: [
          "action",
          "header",
          "tab-row",
          "wheel"
        ],
        tokenBindings: [
          "border-width/1",
          "color/button/bg/primary--default",
          "color/button/border/primary--default",
          "color/button/label/primary--default",
          "color/navigation/indicator/default",
          "color/navigation/indicator/selected",
          "color/navigation/label/default",
          "color/navigation/label/selected",
          "color/overlay/wheel-fade",
          "color/surface/raised",
          "color/text/state/accent",
          "color/text/title/primary",
          "radius/4",
          "spacing/16"
        ],
        composition: {
          buildDependencies: [
            "Button",
            "Line Tab"
          ]
        }
      },
      "Table Cell": {
        variantAxes: {
          Size: [
            "XSM",
            "SM",
            "MD"
          ],
          Type: [
            "Cell",
            "Header"
          ],
          Variant: [
            "Default",
            "Hover",
            "Selected"
          ],
          Align: [
            "Left",
            "Center"
          ]
        },
        geometry: [
          {
            when: {
              Size: "XSM"
            },
            target: "root",
            width: 130,
            height: 34
          },
          {
            when: {
              Size: "SM"
            },
            target: "root",
            width: 130,
            height: 38
          },
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 130,
            height: 44
          }
        ],
        anatomy: [],
        tokenBindings: [
          "color/table/border/default",
          "color/table/cell/default",
          "color/table/cell/hover",
          "color/table/cell/selected",
          "color/table/header/bg",
          "color/text/body/primary",
          "color/text/body/secondary"
        ],
        composition: {
          buildDependencies: []
        }
      },
      Table: {
        variantAxes: {
          Size: [
            "MD",
            "SM",
            "XSM"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 828,
            height: 440
          },
          {
            when: {
              Size: "SM"
            },
            target: "root",
            width: 828,
            height: 386
          },
          {
            when: {
              Size: "XSM"
            },
            target: "root",
            width: 828,
            height: 350
          }
        ],
        anatomy: [
          "edge-bottom",
          "edge-top",
          "header",
          "row-1",
          "row-2",
          "row-3",
          "row-4",
          "row-5",
          "row-6",
          "row-7",
          "row-8",
          "table-footer"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/hover",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/selected",
          "color/form-control/bg/default",
          "color/form-control/border/default",
          "color/form-control/text/placeholder",
          "color/pagination/control/bg/default",
          "color/pagination/control/border/default",
          "color/pagination/number/default",
          "color/pagination/number/selected",
          "color/table/border/default",
          "color/table/border/strong",
          "color/table/cell/default",
          "color/table/cell/hover",
          "color/table/cell/selected",
          "color/table/header/bg",
          "color/text/body/primary",
          "color/text/body/secondary"
        ],
        composition: {
          buildDependencies: [
            "Pagination",
            "Table Cell"
          ]
        }
      },
      "Bottom Sheet Option": {
        variantAxes: {
          Type: [
            "Text",
            "Checkbox",
            "Radio",
            "List"
          ],
          State: [
            "Default",
            "Selected",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: {
              Type: [
                "Text",
                "Checkbox",
                "Radio"
              ]
            },
            target: "root",
            width: 360,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "MIN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "8",
            paddingRight: "20",
            paddingBottom: "8",
            paddingLeft: "20"
          },
          {
            when: {
              Type: "Text",
              State: "Selected"
            },
            target: "root",
            width: 360,
            height: 48,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "8",
            paddingTop: "8",
            paddingRight: "20",
            paddingBottom: "8",
            paddingLeft: "20"
          },
          {
            when: {
              Type: "List",
              State: [
                "Default",
                "Disabled"
              ]
            },
            target: "root",
            width: 360,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "AUTO",
            primaryAxisAlignItems: "SPACE_BETWEEN",
            counterAxisAlignItems: "CENTER",
            paddingTop: "12",
            paddingRight: "20",
            paddingBottom: "12",
            paddingLeft: "20"
          }
        ],
        anatomy: [
          "check",
          "checkbox",
          "chevron",
          "list-left"
        ],
        tokenBindings: [
          "color/control/bg/default",
          "color/control/bg/selected",
          "color/control/border/default",
          "color/control/border/selected",
          "color/icon/gray-light",
          "color/surface/raised",
          "color/text/body/primary",
          "color/text/body/secondary",
          "color/text/state/accent",
          "color/text/state/disabled"
        ],
        composition: {
          buildDependencies: [
            "Checkbox",
            "Radio"
          ]
        }
      },
      "Bottom Sheet": {
        variantAxes: {
          Footer: [
            "None",
            "Single",
            "Dual"
          ]
        },
        geometry: [
          {
            when: {
              Footer: "None"
            },
            target: "root",
            width: 360,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "48",
            paddingTop: "20",
            paddingRight: "0",
            paddingBottom: "40",
            paddingLeft: "0",
            topLeftRadius: "8",
            topRightRadius: "8",
            bottomLeftRadius: "0",
            bottomRightRadius: "0"
          },
          {
            when: {
              Footer: [
                "Single",
                "Dual"
              ]
            },
            target: "root",
            width: 360,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "48",
            paddingTop: "20",
            paddingRight: "0",
            paddingBottom: "20",
            paddingLeft: "0",
            topLeftRadius: "8",
            topRightRadius: "8",
            bottomLeftRadius: "0",
            bottomRightRadius: "0"
          }
        ],
        anatomy: [
          "content",
          "footer"
        ],
        tokenBindings: [
          "border-width/1",
          "color/button/bg/primary--default",
          "color/button/bg/secondary--default",
          "color/button/border/primary--default",
          "color/button/border/secondary--default",
          "color/button/label/primary--default",
          "color/button/label/secondary--default",
          "color/surface/raised",
          "color/text/body/primary",
          "color/text/state/accent",
          "color/text/title/primary",
          "radius/4",
          "spacing/16"
        ],
        composition: {
          buildDependencies: [
            "Bottom Sheet Option",
            "Button"
          ]
        },
        slots: [
          "Content"
        ]
      },
      Modal: {
        variantAxes: {
          Break: [
            "PC",
            "Mobile"
          ],
          Footer: [
            "Single",
            "Dual"
          ]
        },
        geometry: [
          {
            when: {
              Break: "PC"
            },
            target: "root",
            width: 360,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "20",
            paddingRight: "0",
            paddingBottom: "20",
            paddingLeft: "0",
            topLeftRadius: "radius/8",
            topRightRadius: "radius/8",
            bottomLeftRadius: "radius/8",
            bottomRightRadius: "radius/8",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Break: "Mobile"
            },
            target: "root",
            width: 300,
            height: 100,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "30",
            paddingTop: "20",
            paddingRight: "20",
            paddingBottom: "20",
            paddingLeft: "20",
            topLeftRadius: "radius/8",
            topRightRadius: "radius/8",
            bottomLeftRadius: "radius/8",
            bottomRightRadius: "radius/8",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "content",
          "footer"
        ],
        tokenBindings: [
          "border-width/1",
          "color/button/bg/primary--default",
          "color/button/bg/secondary--default",
          "color/button/border/primary--default",
          "color/button/border/secondary--default",
          "color/button/label/primary--default",
          "color/button/label/secondary--default",
          "color/modal/panel/border",
          "color/surface/raised",
          "color/text/body/primary",
          "color/text/title/primary",
          "radius/4",
          "radius/8",
          "spacing/16",
          "spacing/8"
        ],
        composition: {
          buildDependencies: [
            "Button"
          ]
        },
        slots: [
          "Content"
        ]
      },
      "Modal Content": {
        variantAxes: {
          Size: [
            "MD",
            "LG",
            "XL"
          ],
          Footer: [
            "Single",
            "Dual"
          ]
        },
        geometry: [
          {
            when: {
              Size: "MD"
            },
            target: "root",
            width: 520,
            height: 336,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "spacing/20",
            paddingBottom: "spacing/20",
            topLeftRadius: "radius/8",
            topRightRadius: "radius/8",
            bottomLeftRadius: "radius/8",
            bottomRightRadius: "radius/8",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "LG"
            },
            target: "root",
            width: 1e3,
            height: 587,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "spacing/20",
            paddingBottom: "spacing/20",
            topLeftRadius: "radius/8",
            topRightRadius: "radius/8",
            bottomLeftRadius: "radius/8",
            bottomRightRadius: "radius/8",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "XL"
            },
            target: "root",
            width: 1200,
            height: 587,
            layoutMode: "VERTICAL",
            primaryAxisSizingMode: "FIXED",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "32",
            paddingTop: "spacing/20",
            paddingBottom: "spacing/20",
            topLeftRadius: "radius/8",
            topRightRadius: "radius/8",
            bottomLeftRadius: "radius/8",
            bottomRightRadius: "radius/8",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "content",
          "content-area",
          "footer",
          "header"
        ],
        tokenBindings: [
          "border-width/1",
          "color/bg/level-3",
          "color/button/bg/primary--default",
          "color/button/bg/secondary--default",
          "color/button/border/primary--default",
          "color/button/border/secondary--default",
          "color/button/label/primary--default",
          "color/button/label/secondary--default",
          "color/modal/panel/border",
          "color/surface/raised",
          "color/text/body/tertiary",
          "color/text/title/primary",
          "radius/4",
          "radius/8",
          "spacing/20",
          "spacing/24",
          "spacing/32",
          "spacing/8"
        ],
        composition: {
          buildDependencies: [
            "Button"
          ]
        },
        slots: [
          "Content"
        ]
      },
      "Filter Chip": {
        variantAxes: {
          Size: [
            "SM",
            "MD"
          ],
          Break: [
            "PC",
            "Mobile"
          ],
          Variant: [
            "Line",
            "Solid"
          ],
          Title: [
            "Off",
            "On"
          ],
          State: [
            "Default",
            "Hover",
            "Selected",
            "Complete",
            "Disabled"
          ]
        },
        geometry: [
          {
            when: {
              Size: "SM",
              Break: "PC"
            },
            target: "chip",
            height: 28,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "4",
            paddingRight: "6",
            paddingLeft: "12",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "PC"
            },
            target: "chip",
            height: 34,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "4",
            paddingRight: "8",
            paddingLeft: "16",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          },
          {
            when: {
              Size: "MD",
              Break: "Mobile"
            },
            target: "chip",
            height: 30,
            layoutMode: "HORIZONTAL",
            primaryAxisSizingMode: "AUTO",
            counterAxisSizingMode: "FIXED",
            counterAxisAlignItems: "CENTER",
            itemSpacing: "4",
            paddingRight: "6",
            paddingLeft: "12",
            topLeftRadius: "radius/full",
            topRightRadius: "radius/full",
            bottomLeftRadius: "radius/full",
            bottomRightRadius: "radius/full",
            strokeWeight: "1",
            strokeAlign: "INSIDE"
          }
        ],
        anatomy: [
          "chip",
          "dropdown"
        ],
        tokenBindings: [
          "color/chip/line/bg/default",
          "color/chip/line/bg/disabled",
          "color/chip/line/bg/hover",
          "color/chip/line/bg/selected",
          "color/chip/line/border/default",
          "color/chip/line/border/disabled",
          "color/chip/line/border/selected",
          "color/chip/line/label/default",
          "color/chip/line/label/disabled",
          "color/chip/line/label/selected",
          "color/chip/solid/bg/default",
          "color/chip/solid/bg/disabled",
          "color/chip/solid/bg/hover",
          "color/chip/solid/bg/selected",
          "color/chip/solid/border/default",
          "color/chip/solid/border/disabled",
          "color/chip/solid/border/selected",
          "color/chip/solid/label/default",
          "color/chip/solid/label/disabled",
          "color/chip/solid/label/selected",
          "color/dropdown/list/bg",
          "color/dropdown/list/border",
          "color/dropdown/option/bg/default",
          "color/dropdown/option/bg/hover",
          "color/dropdown/option/label/default",
          "color/dropdown/option/label/hover",
          "color/dropdown/option/label/selected",
          "radius/full"
        ],
        composition: {
          buildDependencies: [
            "Dropdown"
          ]
        },
        slots: [
          "Options"
        ]
      }
    }
  };

  // registry/governance/dummy-chrome-parts.json
  var dummy_chrome_parts_default = {
    $comment: "\uC124\uCE58\uAE30\uAC00 \uD654\uBA74 \uC608\uC2DC\uC6A9\uC73C\uB85C \uC5B9\uB294 '\uB354\uBBF8 \uD06C\uB86C'(\uD734\uB300\uD3F0 \uC0C1\uD0DC\uBC14\xB7\uC548\uB4DC\uB85C\uC774\uB4DC \uB0B4\uBE44\uBC14/\uD0A4\uBCF4\uB4DC\xB7\uC6F9 \uBE0C\uB77C\uC6B0\uC800 \uD0ED\uBC14)\uC758 \uB2E8\uC77C \uCD9C\uCC98. \uC774 \uC548\uC5D0 \uC788\uB294 \uAC83\uC740 \uC6B0\uB9AC \uB514\uC790\uC778\uC2DC\uC2A4\uD15C \uBD80\uD488\uC774 \uC544\uB2C8\uB77C OS/\uBE0C\uB77C\uC6B0\uC800 \uAECD\uB370\uAE30\uB97C \uD749\uB0B4 \uB0B8 \uBC30\uACBD \uC18C\uD488\uC774\uB77C, \uAC80\uC218\uAE30\uAC00 \uD1A0\uD070\xB7\uC544\uC774\uCF58\xB7\uBD80\uD488 \uAD50\uCCB4 \uB300\uC0C1\uC73C\uB85C \uC62C\uB9AC\uC9C0 \uC54A\uB294\uB2E4.",
    decidedAt: "2026-09-10",
    decidedBy: "river",
    quote: "\uC544 \uADF8\uB7EC\uBA74 \uB354\uBBF8\uB85C \uC5B9\uC5B4\uC9C0\uB294 \uD0A4\uBCF4\uB4DC, \uC0C1\uD0DC\uBC14, \uB0B4\uBE44\uBC14 \uB4F1\uC5D0 \uADF8\uB824\uC9C4 \uC544\uC774\uCF58\uC740 \uAC80\uC218\uC5D0\uC11C \uC81C\uC678\uD558\uB3C4\uB85D \uD558\uC790",
    rationale: "\uC774 \uC18C\uD488\uC758 \uC544\uC774\uCF58\uC740 OS \uADDC\uACA9 \uAE00\uB9AC\uD504(\uCD5C\uADFC\uC571\xB7\uC548\uB4DC\uB85C\uC774\uB4DC \uD648\xB7\uC790\uD310 Shift/\uC9C0\uC6B0\uAE30/\uC5D4\uD130\xB7\uCC3D \uCD5C\uC18C\uD654/\uCD5C\uB300\uD654 \uB4F1)\uB77C \uC6B0\uB9AC \uC544\uC774\uCF58 \uB77C\uC774\uBE0C\uB7EC\uB9AC\uC5D0 \uB300\uC751\uBB3C\uC774 \uC5C6\uAC70\uB098, \uC788\uC5B4\uB3C4 OS \uD749\uB0B4\uB77C\uB294 \uBAA9\uC801\uC0C1 \uC6B0\uB9AC \uC544\uC774\uCF58\uC73C\uB85C \uBC14\uAFB8\uB294 \uAC83\uC774 \uC633\uC9C0 \uC54A\uB2E4. \uC0C9\uC740 \uC774\uBBF8 Semantic \uD1A0\uD070\uC5D0 \uBC14\uC778\uB529\uB3FC \uC788\uC73C\uBBC0\uB85C \uC0C9 \uAC80\uC218\uAE4C\uC9C0 \uB04C \uD544\uC694\uB294 \uC5C6\uC5C8\uC73C\uB098, river \uACB0\uC815\uC73C\uB85C \uC774 \uC18C\uD488 \uC804\uCCB4\uB97C \uAC80\uC218 \uB300\uC0C1\uC5D0\uC11C \uC81C\uC678\uD55C\uB2E4.",
    excludedRootNames: [
      "StatusBar",
      "NavBar",
      "WebTabBar"
    ],
    innerPartNames: [
      "status-row",
      "status-right",
      "android-nav",
      "keyboard",
      "toolbar",
      "browser-toolbar",
      "browser-url-bar",
      "window-controls",
      "tab-row",
      "nav-refresh",
      "tabs"
    ],
    note: "excludedRootNames = \uC124\uCE58\uAE30\uAC00 \uB9CC\uB4DC\uB294 \uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC774\uB984(\uD654\uBA74\uC5D0\uC11C\uB294 \uAC19\uC740 \uC774\uB984\uC758 \uC778\uC2A4\uD134\uC2A4\uB85C \uC5B9\uD78C\uB2E4). innerPartNames = \uADF8 \uC548\uCABD \uD504\uB808\uC784 \uC774\uB984\uC73C\uB85C, \uD06C\uB86C \uC870\uAC01\uC774 \uC138\uD2B8 \uBC16\uC73C\uB85C \uB5A8\uC5B4\uC838 \uC4F0\uC77C \uB54C\uB97C \uC704\uD55C \uBCF4\uC870 \uD310\uC815\uC774\uB2E4. \uD310\uC815\uC740 \uC774\uB984 \uAE30\uC900\uC774\uB77C \uC815\uBCF8(build-components.ts)\uC758 \uC774\uB984\uC744 \uBC14\uAFB8\uBA74 \uC774 \uBAA9\uB85D\uB3C4 \uAC19\uC774 \uACE0\uCCD0\uC57C \uD55C\uB2E4."
  };

  // plugins/figma-vars-installer/src/audit-engine.ts
  var V2_COLLECTION_NAMES = [
    FOUNDATION_COLLECTION,
    SEMANTIC_COLOR_COLLECTION,
    SEMANTIC_NUMBER_COLLECTION,
    SEMANTIC_SHADOW_COLLECTION
  ];
  function refNameKey(name) {
    return (name || "").toLowerCase().replace(/[\s_\-\/]+/g, "");
  }
  var CANONICAL_NAME_SET = (() => {
    const m = {};
    for (const cat of COMPONENT_CATEGORIES) {
      for (const name of cat.members) {
        m[refNameKey(name)] = true;
      }
    }
    const comps = component_facts_default.components || {};
    for (const name of Object.keys(comps)) m[refNameKey(name)] = true;
    return m;
  })();
  function staleFactsReason() {
    const comps = component_facts_default.components || {};
    const have = {};
    for (const name of Object.keys(comps)) have[refNameKey(name)] = true;
    if (Object.keys(have).length === 0) return "\uAC80\uC218 \uAE30\uC900\uD45C(\uBD80\uD488 \uC0AC\uC2E4\uD45C)\uAC00 \uBE44\uC5B4 \uC788\uC2B5\uB2C8\uB2E4";
    const missing = [];
    for (const cat of COMPONENT_CATEGORIES) {
      for (const name of cat.members) {
        if (!have[refNameKey(name)]) missing.push(name);
      }
    }
    if (missing.length === 0) return null;
    const head = missing.slice(0, 5).join(" \xB7 ");
    return `\uAC80\uC218 \uAE30\uC900\uD45C\uAC00 \uB0A1\uC558\uC2B5\uB2C8\uB2E4 \u2014 ${missing.length}\uAC1C \uBD80\uD488(${head}${missing.length > 5 ? " \u2026" : ""})\uC774 \uAE30\uC900\uD45C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4`;
  }
  function assertFactsFresh() {
    const reason = staleFactsReason();
    if (reason) throw new Error(`${reason}. \uC124\uCE58\uAE30\uB97C \uB2E4\uC2DC \uC9C0\uC5B4 \uC8FC\uC138\uC694(npm run components:facts:write \uD6C4 npm run installer:build).`);
  }
  var INSTALLER_REMOTE_KEY_SET = (() => {
    const m = {};
    const src = allowed_remote_keys_default.allowedRemoteComponentKeys || {};
    for (const name of Object.keys(src)) {
      const k = src[name];
      if (k) m[k] = true;
    }
    return m;
  })();
  function isInstallerRemotePart(main) {
    if (main.key && INSTALLER_REMOTE_KEY_SET[main.key]) return true;
    const parent = main.parent;
    if (parent && parent.type === "COMPONENT_SET") {
      const setKey = parent.key;
      if (setKey && INSTALLER_REMOTE_KEY_SET[setKey]) return true;
    }
    return false;
  }
  var DUMMY_CHROME_ROOTS = (() => {
    const m = {};
    const d = dummy_chrome_parts_default;
    for (const n of d.excludedRootNames || []) m[n.toLowerCase()] = true;
    for (const n of d.innerPartNames || []) m[n.toLowerCase()] = true;
    return m;
  })();
  function isDummyChromePart(node) {
    let cur = node;
    let depth = 0;
    while (cur && cur.type !== "PAGE" && cur.type !== "DOCUMENT" && depth < 24) {
      const raw = (cur.name || "").toLowerCase();
      const base = raw.split("/")[0].trim();
      if (DUMMY_CHROME_ROOTS[raw] || DUMMY_CHROME_ROOTS[base]) return true;
      cur = cur.parent;
      depth++;
    }
    return false;
  }
  var OFF_GUIDE_THRESHOLD = 12;
  function nearestFoundationDistance(hex, v2All) {
    let best = 999;
    for (const v of v2All) {
      if (v.collectionName !== FOUNDATION_COLLECTION) continue;
      const modes = Object.keys(v.hexByMode);
      if (modes.length === 0) continue;
      const d = hexDistance(hex, v.hexByMode[modes[0]]);
      if (d < best) best = d;
    }
    return best;
  }
  function rgbToHex(rgb) {
    const to = (n) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, "0");
    return `#${to(rgb.r)}${to(rgb.g)}${to(rgb.b)}`.toUpperCase();
  }
  async function loadV2Vars() {
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const modesByCollectionId = /* @__PURE__ */ new Map();
    for (const c of collections) modesByCollectionId.set(c.id, c.modes.map((m) => ({ modeId: m.modeId, name: m.name })));
    const v2Cols = collections.filter((c) => V2_COLLECTION_NAMES.indexOf(c.name) >= 0);
    const v2CollectionIds = new Set(v2Cols.map((c) => c.id));
    const v2 = [];
    for (const col of v2Cols) {
      for (const variableId of col.variableIds) {
        const v = await figma.variables.getVariableByIdAsync(variableId);
        if (!v || v.resolvedType !== "COLOR") continue;
        const hexByMode = {};
        const hexByModeName = {};
        for (const m of col.modes) {
          try {
            const val = v.valuesByMode[m.modeId];
            let hex = "";
            if (val && typeof val === "object" && "type" in val && val.type === "VARIABLE_ALIAS") {
              let cur = val;
              for (let i = 0; i < 10; i++) {
                if (typeof cur === "object" && "type" in cur && cur.type === "VARIABLE_ALIAS") {
                  const next = await figma.variables.getVariableByIdAsync(cur.id);
                  if (!next) break;
                  let nextModeId = m.modeId;
                  const nextValues = next.valuesByMode || {};
                  if (!(nextModeId in nextValues)) {
                    const nextModes = modesByCollectionId.get(next.variableCollectionId) || [];
                    const sameName = nextModes.filter((one) => one.name === m.name)[0];
                    const keys = Object.keys(nextValues);
                    nextModeId = sameName ? sameName.modeId : keys.length ? keys[0] : nextModeId;
                  }
                  cur = nextValues[nextModeId];
                  continue;
                }
                break;
              }
              if (cur && typeof cur === "object" && "r" in cur) {
                hex = rgbToHex(cur);
              }
            } else if (val && typeof val === "object" && "r" in val) {
              hex = rgbToHex(val);
            }
            if (hex) {
              hexByMode[m.modeId] = hex;
              hexByModeName[m.name] = hex;
            }
          } catch (e) {
          }
        }
        const modeIds = Object.keys(hexByMode);
        v2.push({
          id: v.id,
          name: v.name,
          collectionName: col.name,
          hexByMode,
          hexByModeName,
          fallbackHex: modeIds.length ? hexByMode[modeIds[0]] : "",
          modeCount: col.modes.length
        });
      }
    }
    const byHex = {};
    for (const v of v2) {
      for (const modeId in v.hexByMode) {
        const h = v.hexByMode[modeId];
        if (!byHex[h]) byHex[h] = [];
        if (byHex[h].indexOf(v) === -1) byHex[h].push(v);
      }
    }
    return { v2, v2CollectionIds, byHex };
  }
  var v2Cache = null;
  async function loadV2VarsCached() {
    if (!v2Cache) v2Cache = await loadV2Vars();
    return v2Cache;
  }
  var collectionsCache = null;
  async function loadCollectionsCached() {
    if (!collectionsCache) collectionsCache = await figma.variables.getLocalVariableCollectionsAsync();
    return collectionsCache;
  }
  function clearV2Cache() {
    v2Cache = null;
    collectionsCache = null;
  }
  function buildByHexForMode(v2, modeName) {
    const byHex = {};
    for (const v of v2) {
      const hex = v.modeCount > 1 ? v.hexByModeName[modeName] : v.hexByModeName[modeName] || v.fallbackHex;
      if (!hex) continue;
      if (!byHex[hex]) byHex[hex] = [];
      if (byHex[hex].indexOf(v) === -1) byHex[hex].push(v);
    }
    return byHex;
  }
  var MOBILE_BREAKPOINT = FOUNDATION_NUMBER["breakpoint/md"];
  function pinnedModeId(node, collectionId, includeSelf) {
    let cur = includeSelf ? node : node.parent;
    while (cur) {
      const pins = cur.explicitVariableModes;
      if (pins && pins[collectionId]) return pins[collectionId];
      if (cur.type === "PAGE" || cur.type === "DOCUMENT") break;
      cur = cur.parent;
    }
    return null;
  }
  function backgroundPaintOf(node) {
    if (!("fills" in node)) return { hex: "", bound: false };
    const fills = node.fills;
    if (!Array.isArray(fills)) return { hex: "", bound: false };
    for (let i = fills.length - 1; i >= 0; i--) {
      const paint = fills[i];
      if (paint && paint.type === "SOLID" && paint.visible !== false) {
        const bound = !!(paint.boundVariables && paint.boundVariables.color);
        return { hex: rgbToHex(paint.color), bound };
      }
    }
    return { hex: "", bound: false };
  }
  async function detectScreenContext(rootsOverride) {
    const roots = rootsOverride ? normalizeSelectionRoots(rootsOverride) : selectedRoots();
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const semantic = collections.filter((col) => col.name === SEMANTIC_COLOR_COLLECTION)[0] || null;
    const { v2 } = await loadV2VarsCached();
    const lightBg = {};
    const darkBg = {};
    for (const v of v2) {
      if (v.collectionName !== SEMANTIC_COLOR_COLLECTION) continue;
      if (v.name.toLowerCase().indexOf("color/bg/") !== 0) continue;
      const light = v.hexByModeName[LIGHT_MODE];
      const dark = v.hexByModeName[DARK_MODE];
      if (light) lightBg[light] = true;
      if (dark) darkBg[dark] = true;
    }
    const out = [];
    for (const root of roots) {
      const width = "width" in root ? Math.round(root.width) : 0;
      const parentType = root.parent ? root.parent.type : "";
      const isWholeScreen = (parentType === "PAGE" || parentType === "SECTION") && (root.type === "FRAME" || root.type === "COMPONENT" || root.type === "INSTANCE");
      let platform = "unknown";
      let platformReason = "\uAC00\uB85C \uD06C\uAE30\uB97C \uC77D\uC744 \uC218 \uC5C6\uC5B4 \uD654\uBA74 \uC885\uB958\uB97C \uC815\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4";
      if (!isWholeScreen) {
        platformReason = "\uD654\uBA74 \uD55C \uC7A5\uC774 \uC544\uB2C8\uB77C \uADF8 \uC548\uC758 \uC77C\uBD80\uB97C \uACE8\uB77C, \uD654\uBA74 \uC885\uB958\uB294 \uD310\uC815\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4";
      } else if (width > 0) {
        platform = width >= MOBILE_BREAKPOINT ? "PC" : "Mobile";
        platformReason = `\uAC00\uB85C ${width} \u2014 \uC815\uBCF8 \uAE30\uC900\uC120 ${MOBILE_BREAKPOINT}(breakpoint/md) ${width >= MOBILE_BREAKPOINT ? "\uC774\uC0C1" : "\uBBF8\uB9CC"}`;
      }
      let mode = "";
      let modeReason = "Semantic Color \uCEEC\uB809\uC158\uC774 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC5B4 \uBAA8\uB4DC\uB97C \uC815\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4";
      if (semantic) {
        const pinned = pinnedModeId(root, semantic.id, true);
        const effective = pinned || semantic.defaultModeId;
        const found = semantic.modes.filter((m) => m.modeId === effective)[0];
        mode = found ? found.name : "";
        modeReason = pinned ? `\uC774 \uD2C0\uC5D0 '${mode}' \uBAA8\uB4DC\uAC00 \uC9C0\uC815\uB3FC \uC788\uC2B5\uB2C8\uB2E4` : `\uB530\uB85C \uC9C0\uC815\uD55C \uBAA8\uB4DC\uAC00 \uC5C6\uC5B4 \uAE30\uBCF8\uAC12 '${mode}'\uB85C \uBD05\uB2C8\uB2E4`;
      }
      const bg = backgroundPaintOf(root);
      const toneHex = bg.bound ? "" : bg.hex;
      let tone = "unknown";
      if (toneHex) {
        const isLight = !!lightBg[toneHex];
        const isDark = !!darkBg[toneHex];
        if (isDark && !isLight) tone = "dark";
        else if (isLight && !isDark) tone = "light";
      }
      const toneMismatch = tone !== "unknown" && !!mode && tone !== mode.toLowerCase();
      const platformLabel = platform === "PC" ? "PC" : platform === "Mobile" ? "\uBAA8\uBC14\uC77C" : isWholeScreen ? "\uD654\uBA74 \uC885\uB958 \uBBF8\uD655\uC778" : "\uD654\uBA74 \uC77C\uBD80";
      const modeLabel = mode === DARK_MODE ? "\uB2E4\uD06C" : mode === LIGHT_MODE ? "\uB77C\uC774\uD2B8" : "\uBAA8\uB4DC \uBBF8\uD655\uC778";
      out.push({
        rootId: root.id,
        rootName: root.name,
        width,
        platform,
        platformReason,
        mode,
        modeReason,
        tone,
        toneHex,
        toneMismatch,
        label: platform === "unknown" && !isWholeScreen ? `\uD654\uBA74 \uC77C\uBD80 \xB7 ${modeLabel} \uBAA8\uB4DC` : `${platformLabel} \xB7 ${modeLabel} \uD654\uBA74`
      });
    }
    return out;
  }
  function isFrameLike(n) {
    return "children" in n;
  }
  function walk(node, acc = []) {
    if ("id" in node && node.id !== figma.currentPage.id) acc.push(node);
    if (isFrameLike(node)) {
      for (const c of node.children) walk(c, acc);
    }
    return acc;
  }
  function normalizeSelectionRoots(selection) {
    const selected = Array.from(selection);
    const ids = new Set(selected.map((n) => n.id));
    return selected.filter((node) => {
      let parent = node.parent;
      while (parent && parent.id !== figma.currentPage.id) {
        if (ids.has(parent.id)) return false;
        parent = parent.parent;
      }
      return true;
    });
  }
  function selectedRoots() {
    return normalizeSelectionRoots(figma.currentPage.selection);
  }
  function collectUniqueSelectedNodes(rootsOverride) {
    const roots = rootsOverride ? Array.from(rootsOverride) : selectedRoots();
    const byId = /* @__PURE__ */ new Map();
    for (const root of roots) {
      const branch = [];
      walk(root, branch);
      for (const node of branch) byId.set(node.id, node);
    }
    return Array.from(byId.values());
  }
  var AUDIT_UNIT_NAME = /(^|[\s_\-/])(icon|ic|button|btn|아이콘|버튼)(?=$|[\s_\-/])/i;
  function isVectorOnlyBranch(node) {
    if (node.type === "VECTOR" || node.type === "BOOLEAN_OPERATION") return true;
    if (!("children" in node)) return false;
    const children = Array.from(node.children);
    return children.length > 0 && children.every((child) => isVectorOnlyBranch(child));
  }
  function resolveAuditUnit(node) {
    let cur = node;
    let vectorContainer = null;
    while (cur && cur.type !== "PAGE" && cur.type !== "DOCUMENT") {
      if (cur.type === "INSTANCE") return vectorContainer || cur;
      if ("id" in cur && AUDIT_UNIT_NAME.test(cur.name || "")) return cur;
      if ("id" in cur && (cur.type === "GROUP" || cur.type === "FRAME" || cur.type === "BOOLEAN_OPERATION") && isVectorOnlyBranch(cur)) vectorContainer = cur;
      cur = cur.parent;
    }
    return vectorContainer || node;
  }
  function classifyNode(node) {
    if (node.type === "TEXT") return "text";
    if (node.type === "VECTOR" || node.type === "BOOLEAN_OPERATION") return "icon";
    const iconNamePattern = /(^|[_/\s-])ic([_-]|on\b)|icon/i;
    if (iconNamePattern.test(node.name || "")) return "icon";
    let cur = node.parent;
    let depth = 0;
    while (cur && cur.id !== figma.currentPage.id && depth < 5) {
      if (iconNamePattern.test(cur.name || "")) return "icon";
      cur = cur.parent;
      depth++;
    }
    return "shape";
  }
  function guessPartKind(node, depth = 0) {
    const num = (v) => typeof v === "number" && isFinite(v) ? v : null;
    const self = () => {
      let w = num(node.width), h = num(node.height);
      if (w === null || h === null || h <= 0 || w <= 0) return null;
      let radius = num(node.cornerRadius);
      let fills = [], strokes = [];
      try {
        fills = node.fills;
      } catch (e) {
        fills = [];
      }
      try {
        strokes = node.strokes;
      } catch (e) {
        strokes = [];
      }
      const hasFill = Array.isArray(fills) && fills.some((p) => p && p.visible !== false);
      const hasStroke = Array.isArray(strokes) && strokes.some((p) => p && p.visible !== false);
      const texts = [];
      const collect = (n, d) => {
        if (d > 2) return;
        let kids;
        try {
          kids = n.children;
        } catch (e) {
          return;
        }
        if (!Array.isArray(kids)) return;
        for (const c of kids) {
          if (c.type === "TEXT") texts.push(c);
          else collect(c, d + 1);
        }
      };
      collect(node, 0);
      const oneText = texts.length === 1 ? texts[0] : null;
      const centeredByAlign = !!oneText && (() => {
        try {
          return oneText.textAlignHorizontal === "CENTER";
        } catch (e) {
          return false;
        }
      })();
      const centeredByLayout = (() => {
        try {
          const f = node;
          if (f.layoutMode === "HORIZONTAL") return f.primaryAxisAlignItems === "CENTER";
          if (f.layoutMode === "VERTICAL") return f.counterAxisAlignItems === "CENTER";
          return false;
        } catch (e) {
          return false;
        }
      })();
      const centeredByPlace = !!oneText && (() => {
        try {
          const nb = node.absoluteBoundingBox;
          const tb = oneText.absoluteBoundingBox;
          if (!nb || !tb || !nb.width || !tb.width) return false;
          const gapLeft = tb.x - nb.x;
          const gapRight = nb.x + nb.width - (tb.x + tb.width);
          if (gapLeft < 0 || gapRight < 0) return false;
          return Math.abs(gapLeft - gapRight) <= Math.max(8, nb.width * 0.08);
        } catch (e) {
          return false;
        }
      })();
      const centered = centeredByAlign || centeredByLayout || centeredByPlace;
      const leftAligned = !!oneText && !centered;
      const vividFill = (() => {
        try {
          if (!Array.isArray(fills)) return false;
          for (const paint of fills) {
            if (!paint || paint.type !== "SOLID" || paint.visible === false) continue;
            const c = paint.color;
            if (!c) continue;
            const max = Math.max(c.r, c.g, c.b), min = Math.min(c.r, c.g, c.b);
            if (max - min > 0.12) return true;
            if (max < 0.6) return true;
          }
        } catch (e) {
        }
        return false;
      })();
      const pill = radius !== null && radius >= h / 2 - 1;
      if (h >= 20 && h <= 40 && pill && oneText && hasFill) {
        return { category: "chip", label: "\uCE69", why: `${Math.round(w)}\xD7${Math.round(h)} \uB465\uADFC \uC54C\uC57D\uC5D0 \uAE00\uC790 1\uAC1C` };
      }
      if (hasFill && oneText && centered && h >= 24 && h <= 60 && w >= h * 1.6) {
        return { category: "button", label: "\uBC84\uD2BC", why: `${Math.round(w)}\xD7${Math.round(h)} \uCC44\uC6C0 + \uAC00\uC6B4\uB370 \uAE00\uC790` };
      }
      if (hasFill && vividFill && h >= 24 && h <= 60 && w >= h * 1.6) {
        return { category: "button", label: "\uBC84\uD2BC", why: `${Math.round(w)}\xD7${Math.round(h)} \uB610\uB837\uD55C \uC0C9\uC73C\uB85C \uCC44\uC6B4 \uBA74` };
      }
      if (hasStroke && !vividFill && h >= 24 && h <= 60 && w >= h * 1.6 && (!oneText || leftAligned)) {
        return { category: "form-control", label: "\uC785\uB825\uCE78", why: `${Math.round(w)}\xD7${Math.round(h)} \uD14C\uB450\uB9AC + \uC67C\uCABD \uAE00\uC790` };
      }
      if (hasFill && (w >= 320 && h >= 320 || w * h >= 320 * 480 * 0.6)) {
        return { category: "bg", label: "\uBC30\uACBD", why: `${Math.round(w)}\xD7${Math.round(h)} \uD070 \uBA74` };
      }
      return null;
    };
    const mine = self();
    if (mine) {
      const hint = stateHintOf(node);
      return hint ? { category: mine.category, label: mine.label, why: mine.why, state: hint } : mine;
    }
    if (depth >= 3) return null;
    const parent = node.parent;
    if (!parent || !("id" in parent) || parent.type === "PAGE" || parent.type === "DOCUMENT") return null;
    return guessPartKind(parent, depth + 1);
  }
  var PART_TOKENS = (() => {
    const comps = component_facts_default.components || {};
    const names = Object.keys(comps);
    const raw = {};
    for (const name of names) {
      const bindings = comps[name] && comps[name].tokenBindings;
      const toks = [];
      if (Array.isArray(bindings)) {
        for (const ref of bindings) {
          if (typeof ref !== "string" || ref.indexOf("color/") !== 0) continue;
          const t = ref.toLowerCase();
          if (toks.indexOf(t) < 0) toks.push(t);
        }
      }
      raw[name] = toks;
    }
    const depsOf = (name) => {
      const comp = comps[name] || {};
      const list = comp.composition && comp.composition.buildDependencies;
      return Array.isArray(list) ? list.filter((x) => typeof x === "string" && !!raw[x]) : [];
    };
    const inheritedOf = (name, seen = {}) => {
      const out = {};
      for (const dep of depsOf(name)) {
        if (seen[dep]) continue;
        seen[dep] = true;
        for (const t of raw[dep]) out[t] = true;
        const deeper = inheritedOf(dep, seen);
        for (const t of Object.keys(deeper)) out[t] = true;
      }
      return out;
    };
    const m = {};
    for (const name of names) {
      const toks = raw[name];
      if (!toks.length) continue;
      const inh = inheritedOf(name);
      m[refNameKey(name)] = { own: toks.filter((t) => !inh[t]), inherited: toks.filter((t) => !!inh[t]) };
    }
    return m;
  })();
  function partTokenScopes(setName) {
    const direct = PART_TOKENS[refNameKey(setName)];
    const merged = { own: [], inherited: [] };
    const add = (pt) => {
      for (const t of pt.own) if (merged.own.indexOf(t) < 0) merged.own.push(t);
      for (const t of pt.inherited) if (merged.inherited.indexOf(t) < 0) merged.inherited.push(t);
    };
    if (direct) add(direct);
    else {
      const rows = LEGACY_INDEX[normalizeName(setName)] || [];
      for (const row of rows) for (const canon of row.canonSets || []) {
        const pt = PART_TOKENS[refNameKey(canon)];
        if (pt) add(pt);
      }
    }
    const out = [];
    if (merged.own.length) out.push(merged.own);
    if (merged.inherited.length) out.push(merged.inherited);
    return out;
  }
  function partTokenCategories(setName) {
    const out = [];
    for (const scope of partTokenScopes(setName)) {
      for (const t of scope) {
        const cat = categoryOf(t);
        if (out.indexOf(cat) < 0) out.push(cat);
      }
    }
    const words = setName.toLowerCase().split(/[\s_\/]+/).filter(Boolean);
    return out.filter((c) => words.indexOf(c) >= 0).concat(out.filter((c) => words.indexOf(c) < 0));
  }
  function isLibraryPartName(setName, nodeName, remote) {
    if (remote) return true;
    for (const nm of [setName, nodeName]) {
      if (!nm) continue;
      if (CANONICAL_NAME_SET[refNameKey(nm)]) return true;
      if (LEGACY_INDEX[normalizeName(nm)]) return true;
    }
    return false;
  }
  var partSegmentsCache = /* @__PURE__ */ new Map();
  async function partSegmentsOf(n) {
    const hit = partSegmentsCache.get(n.id);
    if (hit) return hit;
    const splitName = (name) => (name || "").split(/[/_\s,+]+/).map((s) => s.trim().toLowerCase()).filter(Boolean);
    let setName = n.name;
    let remote = false;
    if (n.type === "INSTANCE") {
      let main = null;
      try {
        main = await n.getMainComponentAsync();
      } catch (e) {
        main = null;
      }
      if (main) {
        setName = main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.name : main.name;
        try {
          remote = main.remote === true;
        } catch (e) {
          remote = false;
        }
      }
    } else if (n.type === "COMPONENT" && n.parent && n.parent.type === "COMPONENT_SET") {
      setName = n.parent.name;
    }
    const out = [];
    const scopes = [];
    if (isLibraryPartName(setName, n.name, remote)) {
      const push = (seg) => {
        if (out.indexOf(seg) < 0) out.push(seg);
      };
      for (const sc of partTokenScopes(setName)) scopes.push(sc);
      if (setName !== n.name && scopes.length === 0) for (const sc of partTokenScopes(n.name)) scopes.push(sc);
      const cats = [];
      for (const cat of partTokenCategories(setName)) if (cats.indexOf(cat) < 0) cats.push(cat);
      if (setName !== n.name) {
        for (const cat of partTokenCategories(n.name)) if (cats.indexOf(cat) < 0) cats.push(cat);
      }
      for (const cat of cats) push(cat);
      const known = cats.length > 0;
      for (const seg of splitName(n.name).concat(splitName(setName))) {
        if (known && isRoleCategory(seg)) continue;
        push(seg);
      }
    }
    const ctx = { segs: out, scopes };
    partSegmentsCache.set(n.id, ctx);
    return ctx;
  }
  async function getComponentContext(node) {
    const isComponentLike = (n) => n.type === "COMPONENT" || n.type === "COMPONENT_SET" || n.type === "INSTANCE";
    const out = [];
    const scopes = [];
    const push = (pc) => {
      for (const seg of pc.segs) if (out.indexOf(seg) < 0) out.push(seg);
      for (const sc of pc.scopes) scopes.push(sc);
    };
    if (isComponentLike(node)) push(await partSegmentsOf(node));
    let cur = node.parent;
    while (cur && cur.id !== figma.currentPage.id) {
      if (isComponentLike(cur)) push(await partSegmentsOf(cur));
      cur = cur.parent;
    }
    return { segs: out, scopes };
  }
  var KNOWN_ROLES = ["text", "label", "icon", "bg", "surface", "border", "line", "stroke", "fill"];
  function isRoleCategory(cat) {
    return KNOWN_ROLES.indexOf(cat) >= 0;
  }
  function decideRoles(nodeKind, paintProp, externalVarName) {
    const roles = [];
    if (externalVarName) {
      const segs = externalVarName.toLowerCase().split("/").filter(Boolean);
      for (const seg of segs) {
        if (KNOWN_ROLES.indexOf(seg) >= 0 && roles.indexOf(seg) === -1) {
          roles.push(seg);
        }
      }
    }
    if (nodeKind === "text") {
      if (roles.indexOf("text") === -1) roles.push("text");
      if (roles.indexOf("label") === -1) roles.push("label");
    } else if (nodeKind === "icon") {
      if (roles.indexOf("icon") === -1) roles.push("icon");
    } else {
      if (paintProp === "fills") {
        if (roles.indexOf("bg") === -1) roles.push("bg");
        if (roles.indexOf("surface") === -1) roles.push("surface");
      } else {
        if (roles.indexOf("border") === -1) roles.push("border");
        if (roles.indexOf("line") === -1) roles.push("line");
      }
    }
    return roles;
  }
  function rolesInName(name) {
    const segs = (name || "").toLowerCase().split(/[/\-]+/).filter(Boolean);
    const out = [];
    for (const seg of segs) {
      if (KNOWN_ROLES.indexOf(seg) >= 0 && out.indexOf(seg) === -1) out.push(seg);
    }
    return out;
  }
  function roleFitOf(name, preferred) {
    const found = rolesInName(name);
    if (found.length === 0) return 1;
    for (const r of found) {
      if (preferred.indexOf(r) >= 0) return 0;
    }
    return 2;
  }
  function hexDistance(a, b) {
    if (!a || !b || a.length < 7 || b.length < 7) return 999;
    const ar = parseInt(a.slice(1, 3), 16);
    const ag = parseInt(a.slice(3, 5), 16);
    const ab = parseInt(a.slice(5, 7), 16);
    const br = parseInt(b.slice(1, 3), 16);
    const bg = parseInt(b.slice(3, 5), 16);
    const bb = parseInt(b.slice(5, 7), 16);
    return Math.sqrt((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2);
  }
  var KNOWN_STATES = ["default", "hover", "pressed", "selected", "disabled", "focus", "error", "correct", "active", "caution"];
  function stateOf(varName) {
    const lower = (varName || "").toLowerCase();
    const tail = lower.split("/").filter(Boolean).pop() || "";
    const afterDouble = tail.indexOf("--") >= 0 ? tail.slice(tail.indexOf("--") + 2) : tail;
    if (KNOWN_STATES.indexOf(afterDouble) >= 0) return afterDouble;
    for (const seg of lower.split(/[/-]+/)) {
      if (KNOWN_STATES.indexOf(seg) >= 0) return seg;
    }
    return "";
  }
  function stateHintOf(node) {
    try {
      const o = node.opacity;
      if (typeof o === "number" && o > 0 && o <= 0.6) return "disabled";
    } catch (e) {
    }
    let nm = "";
    try {
      nm = String(node.name || "").toLowerCase();
    } catch (e) {
      nm = "";
    }
    const dict = {
      hover: "hover",
      "\uD638\uBC84": "hover",
      pressed: "pressed",
      "\uB20C": "pressed",
      selected: "selected",
      "\uC120\uD0DD": "selected",
      active: "selected",
      disabled: "disabled",
      "\uBE44\uD65C\uC131": "disabled",
      off: "disabled",
      focus: "focus",
      "\uD3EC\uCEE4": "focus",
      error: "error",
      "\uC624\uB958": "error"
    };
    for (const key of Object.keys(dict)) {
      if (nm.indexOf(key) >= 0) return dict[key];
    }
    return "";
  }
  function categoryOf(varName) {
    const segs = varName.toLowerCase().split("/").filter(Boolean);
    if (segs.length < 2) return "etc";
    if (segs[0] !== "color") return segs[0];
    return segs[1];
  }
  function pickSuggestions(hex, byHex, v2All, paintProp, nodeKind, contextSegments, externalVarName, guess, modeName, partBound) {
    const hexOfVar = (v) => {
      if (modeName && v.hexByModeName && v.hexByModeName[modeName]) return v.hexByModeName[modeName];
      return v.fallbackHex || "";
    };
    const distOfVar = (v) => {
      const h = hexOfVar(v);
      return h ? hexDistance(hex, h) : 9999;
    };
    const roles = decideRoles(nodeKind, paintProp, externalVarName);
    const preferredRoles = nodeKind === "shape" ? ["bg", "surface", "border", "line", "stroke", "fill"] : decideRoles(nodeKind, paintProp);
    const exactList = byHex[hex] || [];
    const exactIds = new Set(exactList.map((v) => v.id));
    const result = [];
    const added = /* @__PURE__ */ new Set();
    for (const v of v2All) {
      if (v.collectionName !== SEMANTIC_COLOR_COLLECTION) continue;
      const lower = v.name.toLowerCase();
      let hasRoleMatch = false;
      for (const role of roles) {
        if (lower.indexOf(`/${role}/`) >= 0 || lower.indexOf(`/${role}--`) >= 0) {
          hasRoleMatch = true;
          break;
        }
      }
      const boundByPart = !!partBound && partBound.has(lower);
      if (!hasRoleMatch && !boundByPart) continue;
      const cat = categoryOf(v.name);
      const isComponentMatch = contextSegments.indexOf(cat) >= 0;
      const isExact = exactIds.has(v.id);
      let matchType;
      let confidence;
      if (isComponentMatch || boundByPart) {
        matchType = "role+component";
        confidence = "high";
      } else {
        matchType = "role";
        confidence = "medium";
      }
      if (isExact) confidence = "high";
      result.push({
        variableId: v.id,
        variableName: v.name,
        collectionName: v.collectionName,
        confidence,
        exact: isExact,
        dist: isExact ? 0 : distOfVar(v),
        state: stateOf(v.name),
        matchType,
        category: cat,
        // 역할 낱말이 아예 없는 부품 토큰(table/cell/* · navigation/indicator/* · pagination/number/*)만 부품 근거로
        //   «맞음»으로 올린다. 역할이 명시된 배경·테두리 토큰(chip/line/bg 등)은 글자·아이콘 자리에서 종전대로
        //   «어긋남»으로 막는다 — 강제로 0 을 주면 흰 라벨에 배경 토큰이 걸린다(🤖 적발 2026-09-22).
        roleFit: (() => {
          const fit = roleFitOf(v.name, preferredRoles);
          return boundByPart && fit === 1 ? 0 : fit;
        })()
      });
      added.add(v.id);
    }
    for (const v of exactList) {
      if (added.has(v.id)) continue;
      result.push({
        variableId: v.id,
        variableName: v.name,
        collectionName: v.collectionName,
        confidence: "medium",
        exact: true,
        dist: 0,
        state: stateOf(v.name),
        matchType: "exact",
        category: v.collectionName === FOUNDATION_COLLECTION ? "foundation" : categoryOf(v.name),
        roleFit: roleFitOf(v.name, preferredRoles)
      });
      added.add(v.id);
    }
    const nears = [];
    for (const v of v2All) {
      if (v.collectionName !== FOUNDATION_COLLECTION) continue;
      if (added.has(v.id)) continue;
      const modes = Object.keys(v.hexByMode);
      if (modes.length === 0) continue;
      const vHex = v.hexByMode[modes[0]];
      const d = hexDistance(hex, vHex);
      nears.push({ v, dist: d });
    }
    nears.sort((a, b) => a.dist - b.dist);
    for (const n of nears.slice(0, 10)) {
      result.push({
        variableId: n.v.id,
        variableName: n.v.name,
        collectionName: n.v.collectionName,
        confidence: "low",
        matchType: "near",
        matchInfo: `\u0394${Math.round(n.dist)}`,
        category: "foundation",
        // 유사색도 거리를 남긴다 — 가까운 색부터 서게 한다(river 지시 2026-09-21).
        dist: n.dist,
        roleFit: roleFitOf(n.v.name, preferredRoles)
      });
      added.add(n.v.id);
    }
    const orderMap = { "role+component": 0, "role": 1, "exact": 2, "near": 3 };
    const presentCats = new Set(result.map((r) => r.category));
    const ctxCats = contextSegments.filter((c) => presentCats.has(c));
    const hasCtx = ctxCats.length > 0;
    const guessRank = (cat) => {
      if (hasCtx) {
        const i = ctxCats.indexOf(cat);
        return i >= 0 ? i : ctxCats.length + 3;
      }
      if (isRoleCategory(cat)) return 0;
      if (cat === "foundation") return 1;
      if (guess && guess.category === cat) return 2;
      return 3;
    };
    const exactRank = (x) => x.exact ? 0 : 1;
    const stateRank = (x) => {
      if (guess && guess.state) return x.state === guess.state ? 0 : 1;
      return x.state === "default" || x.state === "" ? 0 : 1;
    };
    const fitRank = (x) => typeof x.roleFit === "number" ? x.roleFit : 1;
    result.sort((a, b) => {
      var _a, _b;
      const ag = guessRank(a.category), bg = guessRank(b.category);
      if (ag !== bg) return ag - bg;
      const af = fitRank(a), bf = fitRank(b);
      if (af !== bf) return af - bf;
      {
        const ae = exactRank(a), be = exactRank(b);
        if (ae !== be) return ae - be;
        const ad = typeof a.dist === "number" ? a.dist : 9999;
        const bd = typeof b.dist === "number" ? b.dist : 9999;
        if (Math.abs(ad - bd) > 0.5) return ad - bd;
        const as = stateRank(a), bs = stateRank(b);
        if (as !== bs) return as - bs;
      }
      const aCtx = contextSegments.indexOf(a.category) >= 0 ? 0 : 1;
      const bCtx = contextSegments.indexOf(b.category) >= 0 ? 0 : 1;
      if (aCtx !== bCtx) return aCtx - bCtx;
      const ao = (_a = orderMap[a.matchType]) != null ? _a : 9;
      const bo = (_b = orderMap[b.matchType]) != null ? _b : 9;
      if (ao !== bo) return ao - bo;
      if (a.category !== b.category) return a.category.localeCompare(b.category);
      return a.variableName.localeCompare(b.variableName);
    });
    return result;
  }
  async function audit(rootOverride, modeName) {
    assertFactsFresh();
    const sel = rootOverride ? Array.isArray(rootOverride) ? rootOverride : [rootOverride] : selectedRoots();
    if (sel.length === 0) {
      return { issues: [], stats: { scanned: 0, issuesCount: 0, highCount: 0 } };
    }
    const { v2, v2CollectionIds, byHex: byHexAllModes } = await loadV2VarsCached();
    const byHex = modeName ? buildByHexForMode(v2, modeName) : byHexAllModes;
    const allNodes = collectUniqueSelectedNodes(sel);
    const issues = [];
    const groupedIssues = /* @__PURE__ */ new Map();
    let issueCounter = 0;
    const pushGroupedIssue = (leaf, issue) => {
      const unit = resolveAuditUnit(leaf);
      const key = [unit.id, issue.property, issue.reasonKind, issue.hex, issue.sourceLabel].join("|");
      const target = { nodeId: leaf.id, property: issue.property, paintIndex: issue.paintIndex };
      const existing = groupedIssues.get(key);
      if (existing) {
        if (!existing.targets) existing.targets = [];
        if (!existing.targets.some((item) => item.nodeId === target.nodeId && item.property === target.property && item.paintIndex === target.paintIndex)) {
          existing.targets.push(target);
        }
        return;
      }
      const created = __spreadProps(__spreadValues({}, issue), {
        id: "i" + ++issueCounter,
        nodeId: unit.id,
        nodeName: unit.name,
        targets: [target]
      });
      groupedIssues.set(key, created);
      issues.push(created);
    };
    partSegmentsCache = /* @__PURE__ */ new Map();
    for (const n of allNodes) {
      if (isDummyChromePart(n)) continue;
      const partCtx = await getComponentContext(n);
      const ctx = partCtx.segs;
      const partScopes = partCtx.scopes;
      const partBound = /* @__PURE__ */ new Set();
      for (const sc of partScopes) for (const t of sc) partBound.add(t);
      const kind = classifyNode(n);
      for (const prop of ["fills", "strokes"]) {
        if (!(prop in n)) continue;
        const arr = n[prop];
        if (!Array.isArray(arr)) continue;
        for (let i = 0; i < arr.length; i++) {
          const p = arr[i];
          if (!p || p.type !== "SOLID") continue;
          if (p.visible === false || p.opacity === 0) continue;
          let isMaskShape = false;
          try {
            isMaskShape = n.isMask === true;
          } catch (e) {
          }
          if (isMaskShape) continue;
          const rgb = p.color;
          const hex = rgbToHex(rgb);
          const bound = p.boundVariables && p.boundVariables.color;
          let externalVarName;
          if (bound) {
            const vTemp = await figma.variables.getVariableByIdAsync(bound.id);
            if (vTemp && !v2CollectionIds.has(vTemp.variableCollectionId)) {
              externalVarName = vTemp.name;
            }
          }
          const guess = kind === "shape" || kind === "text" || kind === "icon" ? guessPartKind(n) : null;
          const suggestions = pickSuggestions(hex, byHex, v2, prop, kind, ctx, externalVarName, guess, modeName, partBound);
          const hasComponentMatch = ctx.length > 0;
          const hasExact = suggestions.some((s) => s.matchType === "exact");
          const nearestDistance = nearestFoundationDistance(hex, v2);
          const offGuide = !hasExact && nearestDistance > OFF_GUIDE_THRESHOLD;
          if (bound) {
            const v = await figma.variables.getVariableByIdAsync(bound.id);
            if (!v) continue;
            if (v2CollectionIds.has(v.variableCollectionId)) continue;
            pushGroupedIssue(n, {
              nodeKind: kind,
              guess: guess || void 0,
              property: prop,
              paintIndex: i,
              reasonKind: "external-var",
              hex,
              sourceLabel: v.name,
              componentContext: ctx,
              partTokens: partScopes.length ? partScopes : void 0,
              hasComponentMatch,
              suggestions,
              offGuide,
              nearestDistance
            });
          } else {
            pushGroupedIssue(n, {
              nodeKind: kind,
              guess: guess || void 0,
              property: prop,
              paintIndex: i,
              reasonKind: "unbound-hex",
              hex,
              sourceLabel: hex,
              componentContext: ctx,
              partTokens: partScopes.length ? partScopes : void 0,
              hasComponentMatch,
              suggestions,
              offGuide,
              nearestDistance
            });
          }
        }
      }
    }
    for (const issue of issues) {
      const icon = iconAutoPick(issue);
      if (icon) {
        issue.autoPick = icon.index;
        issue.autoWhy = icon.why;
        continue;
      }
      const pick = autoPickIndex(issue);
      if (pick !== null) {
        issue.autoPick = pick;
        issue.autoWhy = "\uC0C9\uC774 \uAC19\uC740 \uD6C4\uBCF4\uAC00 \uD558\uB098\uBFD0";
      }
    }
    const highCount = issues.filter((x) => typeof x.autoPick === "number").length;
    return { issues, stats: { scanned: allNodes.length, issuesCount: issues.length, highCount } };
  }
  function normalizeWeight(styleName) {
    const lower = (styleName || "").toLowerCase();
    if (lower.indexOf("bold") >= 0 || lower.indexOf("black") >= 0 || lower.indexOf("heavy") >= 0) return "Bold";
    if (lower.indexOf("semi") >= 0 || lower.indexOf("demi") >= 0 || lower.indexOf("medium") >= 0) return "Medium";
    if (lower.indexOf("regular") >= 0 || lower.indexOf("normal") >= 0 || lower.indexOf("light") >= 0 || lower.indexOf("thin") >= 0) return "Regular";
    return "";
  }
  function suggestCanonicalTextStyle(node) {
    const size = typeof node.fontSize === "number" ? node.fontSize : 0;
    if (!size) return null;
    const fontName = node.fontName;
    const rawStyle = fontName === figma.mixed ? "" : fontName.style;
    const weight = normalizeWeight(rawStyle);
    if (!weight) return null;
    const sameWeight = TEXT_STYLES.filter((s) => s.fontStyle === weight);
    if (sameWeight.length === 0) return null;
    let pool = sameWeight.filter((s) => s.fontSize === size);
    const exact = pool.length > 0;
    if (!exact) {
      let bestGap = Infinity;
      for (const s of sameWeight) bestGap = Math.min(bestGap, Math.abs(s.fontSize - size));
      pool = sameWeight.filter((s) => Math.abs(s.fontSize - size) === bestGap);
    }
    if (pool.length > 1) {
      const ls = node.letterSpacing;
      if (ls !== figma.mixed && ls && ls.unit === "PERCENT") {
        const value = ls.value;
        const narrowed = pool.filter((s) => Math.abs(s.letterSpacingPercent - value) < 0.01);
        if (narrowed.length > 0) pool = narrowed;
      }
    }
    if (pool.length > 1) {
      const lh = node.lineHeight;
      if (lh !== figma.mixed && lh && lh.unit === "PERCENT") {
        const value = lh.value;
        const narrowed = pool.filter((s) => Math.abs(s.lineHeightPercent - value) < 0.01);
        if (narrowed.length > 0) pool = narrowed;
      }
    }
    return { def: pool[0], exact, alternatives: pool };
  }
  async function findCanonicalTextStyle(name) {
    const locals = await figma.getLocalTextStylesAsync();
    for (const s of locals) {
      if (s.name === name) return s;
    }
    return null;
  }
  async function applyTextStyleFix(styleName, targetIds) {
    const style = await findCanonicalTextStyle(styleName);
    if (!style) return { ok: 0, fail: targetIds.length, reason: `\uAC00\uC774\uB4DC \uD14D\uC2A4\uD2B8 \uC2A4\uD0C0\uC77C \xAB${styleName}\xBB \uC774 \uC774 \uD30C\uC77C\uC5D0 \uC5C6\uC2B5\uB2C8\uB2E4 \u2014 \uBA3C\uC800 \uAC00\uC774\uB4DC\uB97C \uC124\uCE58\uD558\uC138\uC694` };
    try {
      await figma.loadFontAsync(style.fontName);
    } catch (e) {
      return { ok: 0, fail: targetIds.length, reason: "Pretendard \uAE00\uAF34\uC744 \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4" };
    }
    let ok = 0;
    let fail = 0;
    for (const id of targetIds) {
      const node = await figma.getNodeByIdAsync(id);
      if (!node || node.type !== "TEXT") {
        fail++;
        continue;
      }
      const text2 = node;
      try {
        const used = text2.characters.length > 0 ? text2.getRangeAllFontNames(0, text2.characters.length) : [];
        for (const f of used) {
          try {
            await figma.loadFontAsync(f);
          } catch (e) {
          }
        }
        text2.fontName = style.fontName;
        await text2.setTextStyleIdAsync(style.id);
        ok++;
      } catch (e) {
        fail++;
      }
    }
    return { ok, fail };
  }
  async function auditChecklistFacts(colorIssues, rootsOverride, context) {
    const nodes = collectUniqueSelectedNodes(rootsOverride);
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const collectionById = new Map(collections.map((c) => [c.id, c.name]));
    const variableCache = /* @__PURE__ */ new Map();
    const styleCache = /* @__PURE__ */ new Map();
    const getVariable = async (id) => {
      if (!variableCache.has(id)) variableCache.set(id, await figma.variables.getVariableByIdAsync(id));
      return variableCache.get(id) || null;
    };
    const alphaCache = /* @__PURE__ */ new Map();
    const variableAlphas = async (v, depth = 0) => {
      if (!v || depth > 4) return [];
      const hit = alphaCache.get(v.id);
      if (hit !== void 0) return hit;
      const out = [];
      try {
        const byMode = v.valuesByMode || {};
        for (const modeId of Object.keys(byMode)) {
          const val = byMode[modeId];
          if (val && val.type === "VARIABLE_ALIAS") {
            for (const a of await variableAlphas(await getVariable(val.id), depth + 1)) out.push(a);
            continue;
          }
          if (val && typeof val.a === "number" && val.a < 0.999) out.push(val.a);
        }
      } catch (e) {
      }
      alphaCache.set(v.id, out);
      return out;
    };
    const getStyle = async (id) => {
      if (!styleCache.has(id)) styleCache.set(id, await figma.getStyleByIdAsync(id));
      return styleCache.get(id) || null;
    };
    const colorDetails = [];
    const textIssues = [];
    const shadowIssues = [];
    const canonicalTextStyleNames = new Set(TEXT_STYLES.map((style) => style.name));
    const canonicalShadowGroups = [];
    for (const entry of Object.values(SEMANTIC_SHADOW)) {
      canonicalShadowGroups.push(parseCssShadow(entry.light), parseCssShadow(entry.dark));
    }
    const near = (a, b) => Math.abs(a - b) < 1e-3;
    const textStyleFix = (textNode) => {
      const picked = suggestCanonicalTextStyle(textNode);
      if (!picked) return void 0;
      const name = picked.def.name;
      return {
        kind: "text-style",
        styleName: name,
        label: picked.exact ? `${name} \uAC78\uAE30` : `\uAC00\uC7A5 \uAC00\uAE4C\uC6B4 ${name}(${picked.def.fontSize}px) \uAC78\uAE30`,
        exact: picked.exact,
        alternatives: picked.alternatives.length > 1 ? picked.alternatives.map((d) => d.name) : void 0,
        targetIds: [textNode.id]
      };
    };
    const shadowGroupMatchesCanon = (effects) => canonicalShadowGroups.some((group) => {
      if (group.length !== effects.length) return false;
      return group.every((layer, index) => {
        const effect = effects[index];
        if (!effect || effect.type !== "DROP_SHADOW") return false;
        return near(effect.offset.x, layer.offsetX) && near(effect.offset.y, layer.offsetY) && near(effect.radius, layer.blur) && near(effect.spread || 0, layer.spread) && near(effect.color.r, layer.color.r) && near(effect.color.g, layer.color.g) && near(effect.color.b, layer.color.b) && near(effect.color.a, layer.color.a);
      });
    });
    let detailSeq = 0;
    const detailSeen = /* @__PURE__ */ new Map();
    const add = (target, checklistId, category, node, detail, fix) => {
      const unit = resolveAuditUnit(node);
      const key = `${checklistId}|${unit.id}`;
      const existing = detailSeen.get(key);
      if (existing) {
        if (existing.fix && fix && existing.fix.styleName === fix.styleName) {
          for (const id of fix.targetIds) {
            if (existing.fix.targetIds.indexOf(id) < 0) existing.fix.targetIds.push(id);
          }
        } else if (existing.fix) {
          existing.fix = void 0;
        }
        return;
      }
      const created = { id: `c${checklistId}-${++detailSeq}`, checklistId, category, nodeId: unit.id, nodeName: unit.name, detail, fix };
      detailSeen.set(key, created);
      target.push(created);
    };
    for (const issue of colorIssues) {
      if (issue.reasonKind !== "unbound-hex") continue;
      const node = await figma.getNodeByIdAsync(issue.nodeId);
      if (node && "type" in node) add(colorDetails, 1, "color", node, `${issue.property} ${issue.hex}\uAC00 \uBCC0\uC218\uC5D0 \uC5F0\uACB0\uB418\uC9C0 \uC54A\uC74C`);
    }
    for (const node of nodes) {
      if (isDummyChromePart(node)) continue;
      for (const prop of ["fills", "strokes"]) {
        if (!(prop in node)) continue;
        const paints = node[prop];
        if (!Array.isArray(paints)) continue;
        for (const paint of paints) {
          if (!paint || paint.type !== "SOLID") continue;
          const bound = paint.boundVariables && paint.boundVariables.color;
          if (bound) {
            const variable = await getVariable(bound.id);
            const colName = variable ? collectionById.get(variable.variableCollectionId) : void 0;
            const isBrandVar = !!variable && variable.name.slice(0, 6) === "brand/";
            const isSetSurface = String(node.type) === "COMPONENT_SET";
            if (colName === FOUNDATION_COLLECTION && !isBrandVar && !isSetSurface) {
              add(colorDetails, 2, "color", node, `Foundation \uBCC0\uC218 ${variable.name} \uC9C1\uC811 \uC0AC\uC6A9`);
            }
            if (typeof paint.opacity === "number" && paint.opacity < 0.999) {
              const tokenAlphas = await variableAlphas(variable);
              const fromToken = tokenAlphas.some((a) => Math.abs(a - paint.opacity) < 0.02);
              if (!fromToken) {
                add(colorDetails, 4, "color", node, `\uBCC0\uC218 \uC0C9\uC5D0 \uBD88\uD22C\uBA85\uB3C4 ${Math.round(paint.opacity * 100)}% \uC801\uC6A9`);
              }
            }
          }
        }
      }
      for (const prop of ["fillStyleId", "strokeStyleId", "textStyleId"]) {
        if (!(prop in node)) continue;
        const styleId = node[prop];
        if (typeof styleId !== "string" || !styleId) continue;
        const style = await getStyle(styleId);
        const isCanonicalLocalTextStyle = prop === "textStyleId" && style && style.type === "TEXT" && canonicalTextStyleNames.has(style.name);
        if (style && !style.remote && !isCanonicalLocalTextStyle) {
          const category = prop === "textStyleId" ? "text" : "color";
          add(category === "text" ? textIssues : colorDetails, category === "text" ? 5 : 3, category, node, `\uB77C\uC774\uBE0C\uB7EC\uB9AC\uAC00 \uC544\uB2CC \uB85C\uCEEC \uC2A4\uD0C0\uC77C ${style.name} \uC0AC\uC6A9`);
        }
      }
      if (node.type === "TEXT") {
        const textNode = node;
        const textStyleId = textNode.textStyleId;
        if (typeof textStyleId !== "string" || !textStyleId) {
          add(textIssues, 5, "text", node, "text style \uBBF8\uC801\uC6A9 \uB610\uB294 \uD63C\uD569 \uC801\uC6A9", textStyleFix(textNode));
        }
        const fontSize = textNode.fontSize;
        const allowedSizes = new Set(TEXT_STYLES.map((s) => s.fontSize));
        if (typeof fontSize === "number" && !allowedSizes.has(fontSize)) {
          add(textIssues, 6, "text", node, `\uC815\uC758 \uBC16 \uD3F0\uD2B8 \uD06C\uAE30 ${fontSize}px`, textStyleFix(textNode));
        }
        if (typeof textStyleId === "string" && textStyleId) {
          const style = await getStyle(textStyleId);
          if (style && style.type === "TEXT") {
            const textStyle = style;
            const overridden = typeof textNode.fontSize === "number" && textNode.fontSize !== textStyle.fontSize || textNode.fontName !== figma.mixed && JSON.stringify(textNode.fontName) !== JSON.stringify(textStyle.fontName) || textNode.lineHeight !== figma.mixed && JSON.stringify(textNode.lineHeight) !== JSON.stringify(textStyle.lineHeight) || textNode.letterSpacing !== figma.mixed && JSON.stringify(textNode.letterSpacing) !== JSON.stringify(textStyle.letterSpacing);
            if (overridden) {
              const backFix = canonicalTextStyleNames.has(textStyle.name) ? { kind: "text-style", styleName: textStyle.name, label: `${textStyle.name} \uAC12\uC73C\uB85C \uB418\uB3CC\uB9AC\uAE30`, exact: true, targetIds: [textNode.id] } : textStyleFix(textNode);
              add(textIssues, 7, "text", node, `text style ${textStyle.name} \uAC12 \uB36E\uC5B4\uC4F0\uAE30`, backFix);
            }
          }
        }
        const fontName = textNode.fontName;
        if (fontName === figma.mixed) {
          const families = textNode.getRangeAllFontNames(0, textNode.characters.length).map((font) => font.family);
          const nonPretendard = families.find((family) => family !== TEXT_STYLE_FONT_FAMILY);
          if (nonPretendard) add(textIssues, 8, "text", node, `${nonPretendard} \uB4F1 Pretendard\uAC00 \uC544\uB2CC \uAE00\uAF34\uC774 \uC11E\uC5EC \uC788\uC74C`, textStyleFix(textNode));
        } else if (fontName.family !== TEXT_STYLE_FONT_FAMILY) {
          add(textIssues, 8, "text", node, `${fontName.family} \uC0AC\uC6A9`, textStyleFix(textNode));
        }
      }
      if ("effects" in node && Array.isArray(node.effects)) {
        const shadows = node.effects.filter(
          (effect) => effect && effect.visible !== false && (effect.type === "DROP_SHADOW" || effect.type === "INNER_SHADOW")
        );
        if (shadows.length > 0 && !shadowGroupMatchesCanon(shadows)) {
          add(shadowIssues, 9, "shadow", node, "\uAC00\uC774\uB4DC\uC5D0 \uB4F1\uB85D\uB418\uC9C0 \uC54A\uC740 \uADF8\uB9BC\uC790 \uC0AC\uC6A9");
        }
      }
    }
    const modeIssues = [];
    {
      const rootIds = new Set((rootsOverride ? normalizeSelectionRoots(rootsOverride) : selectedRoots()).map((node) => node.id));
      const themedCols = collections.filter((col) => V2_COLLECTION_NAMES.indexOf(col.name) >= 0 && col.modes.length > 1);
      const modeNameOf = (col, modeId) => {
        if (!modeId) return "";
        const found = col.modes.filter((m) => m.modeId === modeId)[0];
        return found ? found.name : "";
      };
      const inheritedModeId = (node, collectionId) => pinnedModeId(node, collectionId, false);
      const screenModeLabel = context && context.mode === DARK_MODE ? "\uB2E4\uD06C" : context && context.mode === LIGHT_MODE ? "\uB77C\uC774\uD2B8" : "";
      let modeSeq = 0;
      for (const node of nodes) {
        if (rootIds.has(node.id)) continue;
        if (isDummyChromePart(node)) continue;
        const pins = node.explicitVariableModes;
        if (!pins) continue;
        if (hasInstanceAncestor(node)) continue;
        if (node.type === "INSTANCE") {
          let masterPins;
          try {
            const master = await node.getMainComponentAsync();
            masterPins = master ? master.explicitVariableModes : void 0;
          } catch (e) {
            masterPins = void 0;
          }
          const sameAsMaster = !!masterPins && Object.keys(pins).every((cid) => masterPins[cid] === pins[cid]);
          if (sameAsMaster) continue;
        }
        let pickedDetail = "";
        for (const col of themedCols) {
          const pinned = pins[col.id];
          if (!pinned) continue;
          const inherited = inheritedModeId(node, col.id) || col.defaultModeId;
          if (pinned === inherited) continue;
          const pinnedName = modeNameOf(col, pinned) || "\uACE0\uC815";
          const inheritedName = modeNameOf(col, inherited) || "\uBC14\uAE65";
          const pinnedLabel = pinnedName === DARK_MODE ? "\uB2E4\uD06C" : pinnedName === LIGHT_MODE ? "\uB77C\uC774\uD2B8" : pinnedName;
          pickedDetail = screenModeLabel ? `\uC774 \uD654\uBA74\uC740 ${screenModeLabel}\uC778\uB370 \uC774 \uBD80\uBD84\uB9CC ${pinnedLabel}\uB85C \uBC15\uD600 \uC788\uC5B4 \uC548 \uBC14\uB01D\uB2C8\uB2E4` : `'${pinnedName}' \uBAA8\uB4DC\uB85C \uACE0\uC815 \u2014 \uBC14\uAE65\uC740 '${inheritedName}'\uC774\uB77C \uC774 \uBD80\uBD84\uB9CC \uC548 \uBC14\uB01D\uB2C8\uB2E4`;
          break;
        }
        if (!pickedDetail) continue;
        modeIssues.push({
          id: `c10-${++modeSeq}`,
          checklistId: 10,
          category: "mode",
          nodeId: node.id,
          nodeName: node.name,
          detail: pickedDetail
        });
      }
    }
    const platformIssues = [];
    if (context && (context.platform === "PC" || context.platform === "Mobile")) {
      const screenLabel = context.platform === "PC" ? "PC" : "\uBAA8\uBC14\uC77C";
      const setHasPlatform = /* @__PURE__ */ new Map();
      for (const node of nodes) {
        if (node.type !== "INSTANCE") continue;
        if (isDummyChromePart(node)) continue;
        const vp = node.variantProperties || {};
        const used = vp["Platform"];
        if (used !== "PC" && used !== "Mobile") continue;
        if (used === context.platform) continue;
        const main = await node.getMainComponentAsync();
        const set = main && main.parent && main.parent.type === "COMPONENT_SET" ? main.parent : null;
        let hasTarget = false;
        if (set) {
          const cacheKey = `${set.id}|${context.platform}`;
          if (setHasPlatform.has(cacheKey)) {
            hasTarget = !!setHasPlatform.get(cacheKey);
          } else {
            hasTarget = set.children.some((child) => child.type === "COMPONENT" && (child.variantProperties || {})["Platform"] === context.platform);
            setHasPlatform.set(cacheKey, hasTarget);
          }
        }
        const usedLabel = used === "PC" ? "PC" : "\uBAA8\uBC14\uC77C";
        platformIssues.push({
          id: `c11-${platformIssues.length + 1}`,
          checklistId: 11,
          category: "platform",
          nodeId: node.id,
          nodeName: node.name,
          detail: hasTarget ? `${screenLabel} \uD654\uBA74\uC778\uB370 ${usedLabel}\uC6A9 \uBCC0\uD615\uC744 \uC4F0\uACE0 \uC788\uC2B5\uB2C8\uB2E4 \u2014 ${screenLabel}\uC6A9 \uBCC0\uD615\uC774 \uC788\uC2B5\uB2C8\uB2E4` : `${usedLabel} \uC804\uC6A9 \uBD80\uD488\uC785\uB2C8\uB2E4 \u2014 ${screenLabel} \uD654\uBA74\uC5D0 \uC4F0\uB294 \uAC83\uC774 \uB9DE\uB294\uC9C0 \uD655\uC778\uD558\uC138\uC694`
        });
      }
    }
    const allDetails = [...colorDetails, ...textIssues, ...shadowIssues, ...modeIssues, ...platformIssues];
    const count = (id) => allDetails.filter((issue) => issue.checklistId === id).length;
    const items = [
      { id: 1, count: count(1), status: count(1) ? "fail" : "pass", coverage: "full" },
      { id: 2, count: count(2), status: count(2) ? "warning" : "pass", coverage: "full" },
      { id: 3, count: count(3), status: count(3) ? "fail" : "pass", coverage: "full" },
      { id: 4, count: count(4), status: count(4) ? "warning" : "pass", coverage: "partial" },
      { id: 5, count: count(5), status: count(5) ? "fail" : "pass", coverage: "full" },
      { id: 6, count: count(6), status: count(6) ? "choice" : "pass", coverage: "partial" },
      { id: 7, count: count(7), status: count(7) ? "fail" : "pass", coverage: "partial" },
      { id: 8, count: count(8), status: count(8) ? "fail" : "pass", coverage: "full" },
      { id: 9, count: count(9), status: count(9) ? "fail" : "pass", coverage: "partial" },
      { id: 10, count: count(10), status: count(10) ? "warning" : "pass", coverage: "full" },
      {
        id: 11,
        count: count(11),
        status: context && (context.platform === "PC" || context.platform === "Mobile") ? count(11) ? "warning" : "pass" : "unjudged",
        coverage: "full"
      }
    ];
    return { items, colorDetails, textIssues, shadowIssues, modeIssues, platformIssues };
  }
  async function resolveVarHexes(variable, depth = 0) {
    if (!variable || depth > 4) return [];
    const out = [];
    try {
      const byMode = variable.valuesByMode || {};
      for (const modeId of Object.keys(byMode)) {
        const val = byMode[modeId];
        if (!val) continue;
        if (val.type === "VARIABLE_ALIAS") {
          const next = await figma.variables.getVariableByIdAsync(val.id);
          if (next) for (const hex of await resolveVarHexes(next, depth + 1)) out.push(hex);
          continue;
        }
        if (typeof val.r === "number") out.push(rgbToHex(val));
      }
    } catch (e) {
    }
    return out;
  }
  async function applyPairedPaint(issue, sug) {
    const otherProp = issue.property === "fills" ? "strokes" : "fills";
    const name = sug.variableName;
    const candidates = [];
    if (issue.property === "fills") {
      candidates.push(name.replace("/bg/", "/border/"), name.replace("/bg/", "/line/"));
    } else {
      candidates.push(name.replace("/border/", "/bg/"), name.replace("/line/", "/bg/"));
    }
    const wanted = candidates.filter((c) => c && c !== name);
    if (!wanted.length) return 0;
    let pairVar = null;
    try {
      const all = await figma.variables.getLocalVariablesAsync("COLOR");
      for (const v of all) {
        if (wanted.indexOf(v.name) >= 0) {
          pairVar = v;
          break;
        }
      }
    } catch (e) {
      return 0;
    }
    if (!pairVar) return 0;
    const pairHexes = await resolveVarHexes(pairVar);
    if (!pairHexes.length) return 0;
    let changed = 0;
    const nodeIds = /* @__PURE__ */ new Set();
    nodeIds.add(issue.nodeId);
    for (const t of issue.targets || []) nodeIds.add(t.nodeId);
    for (const nodeId of Array.from(nodeIds)) {
      const node = await figma.getNodeByIdAsync(nodeId);
      if (!node || !("type" in node)) continue;
      let arr;
      try {
        arr = node[otherProp];
      } catch (e) {
        continue;
      }
      if (!Array.isArray(arr)) continue;
      const next = JSON.parse(JSON.stringify(arr));
      let touched = false;
      for (let i = 0; i < next.length; i++) {
        const paint = next[i];
        if (!paint || paint.type !== "SOLID") continue;
        if (paint.boundVariables && paint.boundVariables.color) continue;
        if (pairHexes.indexOf(rgbToHex(paint.color)) < 0) continue;
        next[i] = figma.variables.setBoundVariableForPaint(paint, "color", pairVar);
        touched = true;
      }
      if (!touched) continue;
      try {
        node[otherProp] = next;
        changed++;
      } catch (e) {
      }
    }
    return changed;
  }
  async function applyOne(issue, suggestionIndex, out) {
    const sug = issue.suggestions[suggestionIndex];
    if (!sug) return false;
    const v2 = await figma.variables.getVariableByIdAsync(sug.variableId);
    if (!v2) return false;
    const targets = issue.targets && issue.targets.length ? issue.targets : [{ nodeId: issue.nodeId, property: issue.property, paintIndex: issue.paintIndex }];
    const grouped = /* @__PURE__ */ new Map();
    for (const target of targets) {
      const node = await figma.getNodeByIdAsync(target.nodeId);
      if (!node) return false;
      const key = `${target.nodeId}|${target.property}`;
      let group = grouped.get(key);
      if (!group) {
        const arr = node[target.property];
        if (!Array.isArray(arr)) return false;
        group = {
          node,
          property: target.property,
          original: JSON.parse(JSON.stringify(arr)),
          next: JSON.parse(JSON.stringify(arr))
        };
        grouped.set(key, group);
      }
      const paint = group.next[target.paintIndex];
      if (!paint || paint.type !== "SOLID") return false;
      group.next[target.paintIndex] = figma.variables.setBoundVariableForPaint(paint, "color", v2);
    }
    const applied = [];
    for (const group of grouped.values()) {
      try {
        group.node[group.property] = group.next;
        applied.push({ node: group.node, property: group.property, original: group.original });
      } catch (e) {
        for (const prior of applied.reverse()) {
          try {
            prior.node[prior.property] = prior.original;
          } catch (e2) {
          }
        }
        return false;
      }
    }
    try {
      const paired = await applyPairedPaint(issue, sug);
      if (out) out.paired = paired;
    } catch (e) {
    }
    return true;
  }
  var NEAR_SAME = 12;
  function iconAutoPick(issue) {
    if (issue.nodeKind !== "icon") return null;
    const isIconToken = (s) => s.roleFit === 0 && rolesInName(s.variableName).indexOf("icon") >= 0;
    const pickNearest = (idxs) => {
      if (idxs.length === 0) return null;
      if (idxs.length === 1) return idxs[0];
      const distOf = (i) => {
        const d = issue.suggestions[i].dist;
        return typeof d === "number" ? d : 9999;
      };
      const sorted = idxs.slice().sort((a, b) => distOf(a) - distOf(b));
      const best = distOf(sorted[0]);
      if (best > NEAR_SAME) return null;
      const tied = sorted.filter((i) => distOf(i) - best <= 0.5);
      if (tied.length === 1) return tied[0];
      if (issue.guess && issue.guess.state) {
        const byHint = tied.filter((i) => issue.suggestions[i].state === issue.guess.state);
        if (byHint.length === 1) return byHint[0];
      }
      const defaults = tied.filter((i) => {
        const st = issue.suggestions[i].state;
        return st === "default" || st === "";
      });
      return defaults.length === 1 ? defaults[0] : null;
    };
    const idxsOfCategory = (cat) => {
      const out = [];
      for (let i = 0; i < issue.suggestions.length; i++) {
        const s = issue.suggestions[i];
        if (s.category === cat && isIconToken(s)) out.push(i);
      }
      return out;
    };
    for (const scope of issue.partTokens || []) {
      const idxs = [];
      for (let i = 0; i < issue.suggestions.length; i++) {
        const s = issue.suggestions[i];
        if (scope.indexOf(s.variableName.toLowerCase()) >= 0 && isIconToken(s)) idxs.push(i);
      }
      if (idxs.length === 0) continue;
      const pick2 = pickNearest(idxs);
      if (pick2 !== null) return { index: pick2, why: "\uAC10\uC2FC \uBD80\uD488\uC774 \uC4F0\uB294 \uD1A0\uD070" };
      return null;
    }
    for (const cat of issue.componentContext) {
      const pick2 = pickNearest(idxsOfCategory(cat));
      if (pick2 !== null) return { index: pick2, why: `${cat} \uBD80\uD488 \uC548 \uC544\uC774\uCF58` };
    }
    const generic = [];
    for (let i = 0; i < issue.suggestions.length; i++) {
      if (issue.suggestions[i].variableName.toLowerCase().indexOf("color/icon/") === 0) generic.push(i);
    }
    const pick = pickNearest(generic);
    if (pick !== null) return { index: pick, why: "\uBD80\uD488\uC744 \uBABB \uC77D\uC5B4 \uACF5\uD1B5 \uC544\uC774\uCF58\uC0C9" };
    return null;
  }
  function autoPickIndex(issue) {
    const icon = iconAutoPick(issue);
    if (icon) return icon.index;
    if (issue.suggestions.length > 0 && issue.suggestions[0].roleFit === 2) return null;
    if (issue.suggestions.length === 1 && issue.suggestions[0].confidence === "high") return 0;
    const ctx = (issue.componentContext || []).filter((c) => issue.suggestions.some((s) => s.category === c));
    const hasCtx = ctx.length > 0;
    const stateHint = issue.guess && issue.guess.state ? issue.guess.state : "";
    const narrowByState = (idxs) => {
      if (idxs.length === 1) return idxs[0];
      if (idxs.length === 0) return null;
      if (stateHint) {
        const byState = idxs.filter((i) => issue.suggestions[i].state === stateHint);
        if (byState.length === 1) return byState[0];
      }
      const defaults = idxs.filter((i) => issue.suggestions[i].state === "default" || issue.suggestions[i].state === "");
      return defaults.length === 1 ? defaults[0] : null;
    };
    const tokenScopes = issue.partTokens || [];
    const inPart = tokenScopes.length > 0 || hasCtx;
    const scopes = tokenScopes.length ? tokenScopes.map((t) => ({ tokens: t })) : hasCtx ? ctx.map((c) => ({ cats: [c] })) : [{ cats: KNOWN_ROLES.slice() }];
    const collect = (scope, pred) => {
      const idxs = [];
      for (let i = 0; i < issue.suggestions.length; i++) {
        const s = issue.suggestions[i];
        if (s.roleFit === 2) continue;
        if (scope.tokens && scope.tokens.indexOf(s.variableName.toLowerCase()) < 0) continue;
        if (scope.cats && scope.cats.indexOf(s.category) < 0) continue;
        if (pred(s)) idxs.push(i);
      }
      return idxs;
    };
    for (const scope of scopes) {
      const hits = collect(scope, (s) => s.exact === true);
      if (hits.length > 0) return narrowByState(hits);
    }
    if (!inPart) return null;
    for (const scope of scopes) {
      const near = collect(scope, (s) => typeof s.dist === "number" && s.dist <= NEAR_SAME);
      if (near.length > 0) return narrowByState(near);
    }
    return null;
  }
  async function applyHighConfidence(issues) {
    let n = 0;
    for (const i of issues) {
      const pick = autoPickIndex(i);
      if (pick === null) continue;
      if (await applyOne(i, pick)) n++;
    }
    return n;
  }
  async function applyMulti(picks) {
    let ok = 0;
    let fail = 0;
    const applied = [];
    for (const p of picks) {
      if (await applyOne(p.issue, p.suggestionIndex)) {
        ok++;
        applied.push({ issueId: p.issue.id, suggestionIndex: p.suggestionIndex });
      } else {
        fail++;
      }
    }
    return { ok, fail, applied };
  }
  async function setVariablesMode(mode) {
    const sel = figma.currentPage.selection;
    if (sel.length === 0) {
      return { count: 0, skipped: 0, message: "\uC120\uD0DD\uB41C \uB178\uB4DC \uC5C6\uC74C" };
    }
    if (mode === "clear") {
      let cleared = 0;
      let skipped2 = 0;
      const visit = (n) => {
        const modes = n.explicitVariableModes;
        if (modes) {
          const collectionIds = Object.keys(modes);
          for (const cid of collectionIds) {
            try {
              n.clearExplicitVariableModeForCollection(cid);
              cleared++;
            } catch (e) {
              skipped2++;
            }
          }
        }
        if ("children" in n) {
          for (const c of n.children) visit(c);
        }
      };
      for (const root of sel) visit(root);
      if (cleared === 0 && skipped2 === 0) {
        return { count: 0, skipped: 0, cleared: 0, message: "\uCD08\uAE30\uD654\uD560 \uBAA8\uB4DC override \uC5C6\uC74C" };
      }
      return { count: sel.length, skipped: skipped2, cleared };
    }
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const semantic = collections.find((c) => c.name === SEMANTIC_COLOR_COLLECTION);
    if (!semantic) {
      return { count: 0, skipped: 0, message: "Semantic Color V2 \uCEEC\uB809\uC158 \uC5C6\uC74C" };
    }
    const targetName = mode === "light" ? "Light" : "Dark";
    const found = semantic.modes.find((m) => m.name === targetName);
    if (!found) {
      return { count: 0, skipped: 0, message: `${targetName} \uBAA8\uB4DC\uB97C \uCC3E\uC9C0 \uBABB\uD568` };
    }
    let count = 0;
    let skipped = 0;
    for (const node of sel) {
      try {
        node.setExplicitVariableModeForCollection(semantic.id, found.modeId);
        count++;
      } catch (e) {
        skipped++;
      }
    }
    return { count, skipped };
  }
  var REFERENCE_NAME_CLASHES = [];
  function isClashingName(name) {
    return REFERENCE_NAME_CLASHES.indexOf(refNameKey(name)) >= 0;
  }
  function collectComponents(root, sourceFileName) {
    const acc = [];
    const visit = (n) => {
      if (n.type === "COMPONENT_SET") {
        acc.push({ id: n.id, key: n.key, name: n.name, type: "COMPONENT_SET", sourceFileName });
        return;
      }
      if (n.type === "COMPONENT") {
        if (n.parent && n.parent.type === "COMPONENT_SET") return;
        acc.push({ id: n.id, key: n.key, name: n.name, type: "COMPONENT", sourceFileName });
        return;
      }
      if ("children" in n) {
        for (const c of n.children) visit(c);
      }
    };
    visit(root);
    return acc;
  }
  function collectInstances(root) {
    const acc = [];
    const visit = (n) => {
      if (n.type === "INSTANCE") {
        acc.push(n);
      }
      if ("children" in n) {
        for (const c of n.children) visit(c);
      }
    };
    visit(root);
    return acc;
  }
  function hasInstanceAncestor(n) {
    let p = n.parent;
    while (p && p.type !== "PAGE" && p.type !== "DOCUMENT") {
      if (p.type === "INSTANCE") return true;
      p = p.parent;
    }
    return false;
  }
  function normalizeName(s) {
    return (s || "").toLowerCase().replace(/[\s_\-\/]+/g, "").trim();
  }
  function findReferenceMatch(name, pool) {
    const lower = name.toLowerCase();
    const exact = pool.find((p) => p.name.toLowerCase() === lower);
    if (exact) return { match: exact, matchType: "exact" };
    const norm = normalizeName(name);
    const normMatch = pool.find((p) => normalizeName(p.name) === norm);
    if (normMatch) return { match: normMatch, matchType: "normalized" };
    if (norm.length >= 3) {
      const part = pool.find((p) => {
        const pn = normalizeName(p.name);
        return pn.length >= 3 && (pn.indexOf(norm) >= 0 || norm.indexOf(pn) >= 0);
      });
      if (part) return { match: part, matchType: "partial" };
    }
    return { match: null, matchType: null };
  }
  function bigrams(s) {
    const out = [];
    for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  }
  function diceCoefficient(a, b) {
    if (a === b) return 1;
    const A = bigrams(a), B = bigrams(b);
    if (A.length === 0 || B.length === 0) return 0;
    const freq = {};
    for (const g of A) freq[g] = (freq[g] || 0) + 1;
    let hit = 0;
    for (const g of B) {
      if (freq[g] > 0) {
        freq[g]--;
        hit++;
      }
    }
    return 2 * hit / (A.length + B.length);
  }
  function tokenizeName(s) {
    return (s || "").toLowerCase().split(/[\s_\-\/,.]+/).filter((t) => t.length > 0);
  }
  function scoreNameSimilarity(legacy, canon) {
    const ln = normalizeName(legacy), cn = normalizeName(canon);
    if (!ln || !cn) return 0;
    if (ln === cn) return 1;
    let score = diceCoefficient(ln, cn);
    const lt = new Set(tokenizeName(legacy));
    const ct = tokenizeName(canon);
    if (ct.length) {
      let overlap = 0;
      for (const t of ct) if (lt.has(t)) overlap++;
      score = Math.max(score, overlap / ct.length);
    }
    if (ln.indexOf(cn) >= 0 || cn.indexOf(ln) >= 0) score = Math.max(score, 0.6);
    return score;
  }
  var MODULE_NESTED_THRESHOLD = 5;
  function hasVisiblePaint(n) {
    const visiblePaint = (ps) => Array.isArray(ps) && ps.some((p) => p && p.visible !== false && (p.opacity === void 0 || p.opacity > 0));
    const g = n;
    return visiblePaint(g.fills) || visiblePaint(g.strokes);
  }
  function containsVisibleText(n) {
    if (n.visible === false) return false;
    if (n.type === "TEXT") return true;
    if ("children" in n) {
      for (const c of n.children) if (containsVisibleText(c)) return true;
    }
    return false;
  }
  function collectPartLikeBranches(n, acc) {
    if (n.visible === false) return;
    const frameLike = n.type === "FRAME" || n.type === "COMPONENT" || n.type === "INSTANCE" || n.type === "GROUP";
    if (frameLike && hasVisiblePaint(n) && containsVisibleText(n)) {
      const inner = [];
      if ("children" in n) for (const c of n.children) collectPartLikeBranches(c, inner);
      if (inner.length >= 2) {
        for (const b of inner) acc.push(b);
      } else acc.push(n);
      return;
    }
    if ("children" in n) for (const c of n.children) collectPartLikeBranches(c, acc);
  }
  function countSimilarSizedParts(inst) {
    const acc = [];
    for (const c of inst.children) collectPartLikeBranches(c, acc);
    if (acc.length < 2) return acc.length;
    const hs = acc.map((b) => b.height).filter((h) => typeof h === "number" && h > 0).sort((a, b) => a - b);
    let best = hs.length > 0 ? 1 : 0, run = 1;
    for (let i = 1; i < hs.length; i++) {
      if (hs[i] - hs[i - 1] <= Math.max(4, hs[i] * 0.15)) {
        run++;
        if (run > best) best = run;
      } else run = 1;
    }
    return best;
  }
  var MOBILE_MAX_WIDTH = 600;
  function mediumFromAxes(axes) {
    for (const [axis, value] of Object.entries(axes || {})) {
      if (normAxisName(axis) !== "break") continue;
      const v = (value || "").toLowerCase();
      if (v === "mobile") return "mobile";
      if (v === "pc") return "pc";
    }
    return null;
  }
  function detectMedium(roots, votes) {
    let mobile = 0, pc = 0;
    for (const v of votes) {
      if (v === "mobile") mobile++;
      else if (v === "pc") pc++;
    }
    let byVote = null;
    if (mobile >= 2 && mobile >= pc * 2) byVote = "mobile";
    else if (pc >= 2 && pc >= mobile * 2) byVote = "pc";
    let width = 0;
    for (const r of roots) {
      const w = r.width;
      if (typeof w === "number" && w > width) width = w;
    }
    const byWidth = width ? width <= MOBILE_MAX_WIDTH ? "mobile" : "pc" : null;
    if (byVote && byWidth && byVote !== byWidth) return { medium: null, why: "" };
    const medium = byVote || byWidth;
    if (!medium) return { medium: null, why: "" };
    const label = medium === "mobile" ? "\uBAA8\uBC14\uC77C" : "PC";
    if (byVote) return { medium, why: `\uD654\uBA74 \uC548 \uBD80\uD488 ${medium === "mobile" ? mobile : pc}\uAC1C\uC5D0 \uAC78\uB9B0 \uACB0\uC815\uC774 ${label} \uC744 \uAC00\uB9AC\uD0B5\uB2C8\uB2E4` };
    return { medium, why: `\uACE0\uB978 \uD654\uBA74 \uD3ED\uC774 ${Math.round(width)} \uC774\uB77C ${label} \uB85C \uBD24\uC2B5\uB2C8\uB2E4` };
  }
  var LEGACY_INDEX = (() => {
    const m = {};
    for (const e of LEGACY_MAP) {
      const k = normalizeName(e.set);
      if (!k) continue;
      (m[k] = m[k] || []).push(e);
    }
    return m;
  })();
  function sameLegacyValue(a, b) {
    return (a || "").trim().toLowerCase() === (b || "").trim().toLowerCase();
  }
  function legacyRuleHits(rule, vp) {
    if (!rule.when.length) return false;
    if (!vp) return false;
    return rule.when.every((cond) => {
      if (cond.axis) {
        const key = Object.keys(vp).find((a) => normAxisName(a) === normAxisName(cond.axis));
        return !!key && sameLegacyValue(vp[key], cond.value);
      }
      return Object.keys(vp).some((a) => sameLegacyValue(vp[a], cond.value));
    });
  }
  function applyLegacyRules(entry, vp) {
    const hits = (entry.rules || []).filter((r) => legacyRuleHits(r, vp)).sort((a, b) => a.when.length - b.when.length);
    const axes = {};
    let set = null;
    for (const r of hits) {
      for (const [axis, value] of Object.entries(r.then)) axes[axis] = value;
      if (r.set) set = r.set;
    }
    if (!set && entry.canonSets.length === 1) set = entry.canonSets[0];
    return { axes, set };
  }
  function lookupLegacyDecision(names, vp) {
    for (const name of names) {
      const rows = LEGACY_INDEX[normalizeName(name || "")];
      if (!rows || !rows.length) continue;
      const signature = (e) => `${e.kind}|${e.canonSets.join("+")}`;
      const distinct = rows.filter((e, i) => rows.findIndex((o) => signature(o) === signature(e)) === i);
      if (distinct.length > 1) {
        return {
          kind: "ambiguous",
          legacy: rows.map((e) => `${e.source}:${e.set}`)[0],
          role: rows[0].role || "",
          canonSets: [],
          axes: {},
          basis: [],
          notes: [],
          why: "\uAC19\uC740 \uC774\uB984\uC758 \uB808\uAC70\uC2DC \uBD80\uD488\uC774 \uC5EC\uB7EC \uAC1C\uC774\uACE0 \uBD99\uB294 \uACF3\uC774 \uB2E4\uB985\uB2C8\uB2E4 \u2014 \uC5B4\uB290 \uAC83\uC778\uC9C0 \uBC1D\uD600\uC57C \uD569\uB2C8\uB2E4.",
          choices: rows.map((e) => ({ source: e.source, set: e.set, setId: e.setId, canonSets: e.canonSets }))
        };
      }
      const entry = rows[0];
      const applied = entry.kind === "decided" ? applyLegacyRules(entry, vp) : { axes: {}, set: null };
      const canonSets = applied.set ? [applied.set] : entry.canonSets;
      return {
        kind: entry.kind,
        legacy: `${entry.source}:${entry.set}`,
        role: entry.role || "",
        canonSets,
        axes: applied.axes,
        basis: entry.basis || [],
        notes: (entry.notes || []).map((n) => ({ from: n.from, then: n.then })),
        why: entry.why || entry.note || ""
      };
    }
    return null;
  }
  function legacyVariantProps(inst) {
    const vp = inst.variantProperties;
    return vp && Object.keys(vp).length ? vp : null;
  }
  function pinDecidedSuggestion(verdict, ranked, pool) {
    if (!verdict || verdict.kind !== "decided" || !verdict.canonSets.length) return ranked;
    const wanted = verdict.canonSets.map((n) => normalizeName(n));
    const decided = pool.filter((p) => wanted.indexOf(normalizeName(p.name)) >= 0);
    if (!decided.length) return ranked;
    const head = decided.map((p) => ({ id: p.id, key: p.key, type: p.type, name: p.name, source: p.sourceFileName, score: 1, decided: true }));
    const headIds = {};
    for (const h of head) headIds[h.id] = true;
    return head.concat(ranked.filter((r) => !headIds[r.id]));
  }
  function rankSuggestions(legacyName, pool) {
    return pool.map((p) => ({ id: p.id, key: p.key, type: p.type, name: p.name, source: p.sourceFileName, score: Math.round(scoreNameSimilarity(legacyName, p.name) * 100) / 100 })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  }
  function containsInstanceNode(n) {
    if (n.type === "INSTANCE") return true;
    if ("children" in n) {
      for (const c of n.children) if (containsInstanceNode(c)) return true;
    }
    return false;
  }
  async function collectModuleParts(root, pool, mediumVote) {
    const parts = [];
    const vote = mediumVote || function() {
    };
    const partId = (nodeId) => `p-${nodeId.replace(/[^a-zA-Z0-9]/g, "_")}`;
    const walk2 = async (node, path) => {
      if (node.visible === false) return;
      if (node.type === "INSTANCE") {
        const inst = node;
        const main = await inst.getMainComponentAsync();
        const compareName = main ? main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.name : main.name : inst.name;
        const currentTopId = main ? main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.id : main.id : "";
        if (main && (isInstallerRemotePart(main) || isDummyChromePart(inst))) {
          parts.push({ id: partId(inst.id), nodeId: inst.id, nodeName: inst.name, currentMainName: compareName, kind: "canonical", path, suggestions: [] });
          return;
        }
        let found = findReferenceMatch(compareName, pool);
        if (!found.match && inst.name && inst.name !== compareName) found = findReferenceMatch(inst.name, pool);
        let ranked = rankSuggestions(inst.name && inst.name !== compareName ? `${compareName} ${inst.name}` : compareName, pool);
        const isCanonAlready = pool.some((pc) => pc.id === currentTopId);
        const verdict = isCanonAlready ? null : lookupLegacyDecision([compareName, inst.name], legacyVariantProps(inst));
        if (verdict && verdict.kind === "decided") vote(mediumFromAxes(verdict.axes));
        if (verdict && verdict.kind === "not-a-part") {
          parts.push({
            id: partId(inst.id),
            nodeId: inst.id,
            nodeName: inst.name,
            currentMainName: compareName,
            kind: "manual",
            path,
            suggestions: [],
            decision: verdict,
            note: verdict.why || "\uC815\uBCF8\uC73C\uB85C \uBC14\uAFC0 \uB300\uC0C1\uC774 \uC544\uB2D9\uB2C8\uB2E4."
          });
          return;
        }
        if (verdict && verdict.kind === "decided") {
          ranked = pinDecidedSuggestion(verdict, ranked, pool);
          const wanted = verdict.canonSets.map((n) => normalizeName(n));
          const decidedMissing = !pool.some((pc) => wanted.indexOf(normalizeName(pc.name)) >= 0);
          parts.push({
            id: partId(inst.id),
            nodeId: inst.id,
            nodeName: inst.name,
            currentMainName: compareName,
            kind: "manual",
            path,
            suggestions: ranked,
            decision: verdict,
            decidedMissing
          });
          return;
        }
        const partIsCanonName = CANONICAL_NAME_SET[refNameKey(compareName)] === true;
        if (partIsCanonName && found.match && normalizeName(found.match.name) !== normalizeName(compareName)) {
          found = { match: null, matchType: null };
        }
        let partIsRemote = false;
        try {
          partIsRemote = !!main && main.remote === true;
        } catch (e) {
          partIsRemote = false;
        }
        const partIsLibrary = partIsRemote || pool.some((pc) => pc.id === currentTopId);
        if (found.match && found.match.id === currentTopId) {
          parts.push({ id: partId(inst.id), nodeId: inst.id, nodeName: inst.name, currentMainName: compareName, kind: "canonical", path, suggestions: [] });
        } else if (partIsCanonName && partIsLibrary && !found.match) {
          parts.push({ id: partId(inst.id), nodeId: inst.id, nodeName: inst.name, currentMainName: compareName, kind: "canonical", path, suggestions: [] });
        } else if (found.match) {
          const picked = found.match;
          const rest = ranked.filter((r) => r.id !== picked.id);
          const head = { id: picked.id, key: picked.key, type: picked.type, name: picked.name, source: picked.sourceFileName, score: 1 };
          parts.push({
            id: partId(inst.id),
            nodeId: inst.id,
            nodeName: inst.name,
            currentMainName: compareName,
            kind: "auto",
            path,
            suggestions: [head].concat(rest),
            // 위 자동 교체와 같은 잣대 — 이름이 겹치면 한 번에 돌리지 않고 사람이 보고 누르게 남긴다.
            needsCheck: isClashingName(picked.name) ? "\uC774 \uD30C\uC77C\uC5D0 \uAC19\uC740 \uC774\uB984\uC758 \uBD80\uD488\uC774 \uB458 \uC774\uC0C1\uC774\uB77C \uC5B4\uB290 \uAC83\uC774 \uAE30\uC900\uC778\uC9C0 \uAC00\uB9B4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4 \u2014 \uBC14\uB014 \uBAA8\uC2B5\uC744 \uBCF4\uACE0 \uBC14\uAFD4\uC8FC\uC138\uC694." : void 0
          });
        } else {
          parts.push({ id: partId(inst.id), nodeId: inst.id, nodeName: inst.name, currentMainName: compareName, kind: "manual", path, suggestions: ranked, decision: verdict || void 0 });
        }
        return;
      }
      const frameLike = node.type === "FRAME" || node.type === "COMPONENT" || node.type === "GROUP";
      if (frameLike && !containsInstanceNode(node) && hasVisiblePaint(node) && containsVisibleText(node)) {
        parts.push({
          id: partId(node.id),
          nodeId: node.id,
          nodeName: node.name,
          currentMainName: "(\uCEF4\uD3EC\uB10C\uD2B8 \uC544\uB2D8)",
          kind: "raw",
          path,
          suggestions: rankSuggestions(node.name, pool),
          note: "\uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC544\uB2C8\uB77C \uC9C1\uC811 \uADF8\uB9B0 \uC870\uAC01\uC774\uB77C \uAD50\uCCB4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC815\uBCF8 \uBD80\uD488\uC744 \uC606\uC5D0 \uAC00\uC838\uC640 \uBC14\uAFD4 \uADF8\uB9AC\uC138\uC694."
        });
        return;
      }
      if ("children" in node) {
        const kids = node.children;
        for (let i = 0; i < kids.length; i++) await walk2(kids[i], path.concat(i));
      }
    };
    if ("children" in root) {
      const kids = root.children;
      for (let i = 0; i < kids.length; i++) await walk2(kids[i], [i]);
    }
    return parts;
  }
  function resolveByPath(root, path) {
    let cur = root;
    for (const idx of path) {
      if (!("children" in cur)) return null;
      const kids = cur.children;
      if (idx < 0 || idx >= kids.length) return null;
      cur = kids[idx];
    }
    return cur;
  }
  var VARIANT_VALUE_SYNONYMS = {
    small: "sm",
    sm: "sm",
    medium: "md",
    md: "md",
    large: "lg",
    lg: "lg"
  };
  function normAxisName(a) {
    return (a || "").toLowerCase().replace(/[\s_\-]+/g, "");
  }
  function normVariantValue(v) {
    const base = (v || "").toLowerCase().replace(/[\s_\-]+/g, "");
    return VARIANT_VALUE_SYNONYMS[base] || base;
  }
  function pickVariantTarget(set, legacyVP) {
    const variants = set.children.filter((c) => c.type === "COMPONENT");
    if (variants.length === 0) return { target: null, reason: "no-variant-match", axisLoss: 0 };
    const def = set.defaultVariant || variants[0];
    if (!legacyVP) return { target: def, reason: null, axisLoss: 0 };
    const defVP = def.variantProperties || {};
    const canonAxes = Object.keys(defVP);
    const canonByNorm = {};
    for (const a of canonAxes) canonByNorm[normAxisName(a)] = a;
    const shared = [];
    let axisLoss = 0;
    for (const la of Object.keys(legacyVP)) {
      const ca = canonByNorm[normAxisName(la)];
      if (ca) shared.push({ canon: ca, want: normVariantValue(legacyVP[la]) });
      else axisLoss++;
    }
    if (shared.length === 0) {
      if (variants.length === 1) return { target: def, reason: null, axisLoss };
      return { target: null, reason: "no-variant-match", axisLoss };
    }
    const matches = variants.filter((v) => {
      const vp = v.variantProperties || {};
      return shared.every((s) => normVariantValue(vp[s.canon]) === s.want);
    });
    if (matches.length === 0) return { target: null, reason: "no-variant-match", axisLoss };
    if (matches.length === 1) return { target: matches[0], reason: null, axisLoss };
    const otherAxes = canonAxes.filter((a) => !shared.some((s) => s.canon === a));
    const narrowed = matches.filter((v) => {
      const vp = v.variantProperties || {};
      return otherAxes.every((a) => vp[a] === defVP[a]);
    });
    if (narrowed.length === 1) return { target: narrowed[0], reason: null, axisLoss };
    return { target: null, reason: "no-variant-match", axisLoss };
  }
  var installerPageCache = /* @__PURE__ */ new Map();
  var canonAxesCache = /* @__PURE__ */ new Map();
  async function axesOfCanonSet(refId) {
    const hit = canonAxesCache.get(refId);
    if (hit) return hit;
    let axes = [];
    try {
      const node = await figma.getNodeByIdAsync(refId);
      if (node && node.type === "COMPONENT_SET") {
        const defs = node.componentPropertyDefinitions;
        axes = Object.keys(defs).filter((k) => defs[k] && defs[k].type === "VARIANT").map((k) => normAxisName(k.split("#")[0])).sort();
      }
    } catch (e) {
      axes = [];
    }
    canonAxesCache.set(refId, axes);
    return axes;
  }
  async function isSameAsCanonSet(inst, target) {
    if (!target || target.type !== "COMPONENT_SET") return false;
    const canonAxes = await axesOfCanonSet(target.id);
    if (!canonAxes.length) return false;
    let curAxes = [];
    try {
      const vp = inst.variantProperties || {};
      curAxes = Object.keys(vp).map(normAxisName).sort();
    } catch (e) {
      return false;
    }
    if (!curAxes.length || curAxes.length !== canonAxes.length) return false;
    for (let i = 0; i < curAxes.length; i++) if (curAxes[i] !== canonAxes[i]) return false;
    return true;
  }
  async function scanSwapCandidates(pool, roots) {
    assertFactsFresh();
    const sel = roots && roots.length ? normalizeSelectionRoots(roots.filter((root) => "id" in root && root.type !== "PAGE" && root.type !== "DOCUMENT")) : selectedRoots();
    const mediumVotes = [];
    const diag = {
      selectionCount: sel.length,
      instanceCount: 0,
      referencePoolSize: pool.length,
      matchedNameCount: 0,
      sameIdSkippedCount: 0,
      skippedNestedCount: 0,
      noMatchCount: 0,
      skippedInstallerRemoteCount: 0,
      skippedHandMadeCount: 0,
      handMadePreview: [],
      candidateCount: 0,
      instancesPreview: []
    };
    if (sel.length === 0) return { candidates: [], diagnostics: diag, manualCandidates: [], modules: [] };
    installerPageCache.clear();
    canonAxesCache.clear();
    const candidates = [];
    const manualCandidates = [];
    const modules = [];
    const manualSeen = /* @__PURE__ */ new Set();
    const seen = /* @__PURE__ */ new Set();
    const candidateId = (prefix, instanceId) => `${prefix}-${instanceId.replace(/[^a-zA-Z0-9]/g, "_")}`;
    for (const root of sel) {
      const insts = collectInstances(root);
      diag.instanceCount += insts.length;
      for (const inst of insts) {
        if (hasInstanceAncestor(inst)) {
          diag.skippedNestedCount++;
          continue;
        }
        const main = await inst.getMainComponentAsync();
        if (!main) {
          if (diag.instancesPreview.length < 8) diag.instancesPreview.push({ name: inst.name, mainName: "(mainComponent null)", mainTopId: "", matched: false, sameAsTarget: false });
          continue;
        }
        if (isInstallerRemotePart(main) || isDummyChromePart(inst)) {
          diag.skippedInstallerRemoteCount++;
          continue;
        }
        const compareName = main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.name : main.name;
        const currentTopId = main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.id : main.id;
        const isLegacyGuidePart = (() => {
          let remote = false;
          try {
            remote = main.remote === true;
          } catch (e) {
            remote = false;
          }
          if (remote) return true;
          if (LEGACY_INDEX[normalizeName(compareName)]) return true;
          if (inst.name && LEGACY_INDEX[normalizeName(inst.name)]) return true;
          return pool.some((pc) => pc.id === currentTopId);
        })();
        if (!isLegacyGuidePart) {
          diag.skippedHandMadeCount++;
          if (diag.handMadePreview.length < 200) diag.handMadePreview.push({ id: inst.id, name: inst.name, mainName: compareName });
          continue;
        }
        let found = findReferenceMatch(compareName, pool);
        if (!found.match && inst.name && inst.name !== compareName) {
          found = findReferenceMatch(inst.name, pool);
        }
        const target = found.match;
        const clashed = !!target && isClashingName(target.name);
        const confidence = found.matchType === "partial" || clashed ? "ambiguous" : "high";
        const matched = !!target;
        const sameAsTarget = !!target && target.id === currentTopId;
        const currentIsCanonName = CANONICAL_NAME_SET[refNameKey(compareName)] === true && !LEGACY_INDEX[normalizeName(compareName)];
        if (currentIsCanonName && (!target || normalizeName(target.name) !== normalizeName(compareName))) {
          diag.sameIdSkippedCount++;
          continue;
        }
        const nestedInstances = collectInstances(inst).slice(1);
        const nestedTargetCount = /* @__PURE__ */ new Map();
        for (const nested of nestedInstances) {
          const nestedMain = await nested.getMainComponentAsync();
          if (!nestedMain) continue;
          const nestedName = nestedMain.parent && nestedMain.parent.type === "COMPONENT_SET" ? nestedMain.parent.name : nestedMain.name;
          let nestedFound = findReferenceMatch(nestedName, pool);
          if (!nestedFound.match && nested.name && nested.name !== nestedName) nestedFound = findReferenceMatch(nested.name, pool);
          if (!nestedFound.match) continue;
          const prev = nestedTargetCount.get(nestedFound.match.id);
          nestedTargetCount.set(nestedFound.match.id, { target: nestedFound.match, count: (prev ? prev.count : 0) + 1 });
        }
        const repeatedPart = Array.from(nestedTargetCount.values()).sort((a, b) => b.count - a.count)[0];
        const isRepeatedPartModule = !!repeatedPart && repeatedPart.count >= 2 && !sameAsTarget && (!target || repeatedPart.target.id === target.id);
        const similarParts = !isRepeatedPartModule && !sameAsTarget ? countSimilarSizedParts(inst) : 0;
        const isStructuralModule = similarParts >= 2;
        const isCanonAlready = pool.some((pc) => pc.id === currentTopId);
        if (!isCanonAlready && (isRepeatedPartModule || isStructuralModule)) {
          if (!manualSeen.has(inst.id)) {
            manualSeen.add(inst.id);
            modules.push({
              id: candidateId("g", inst.id),
              instanceId: inst.id,
              instanceName: inst.name,
              currentMainName: compareName,
              currentMainPath: await describeComponentLocation(main),
              nestedCount: Math.max(nestedInstances.length, similarParts),
              repeatedPartName: isRepeatedPartModule ? repeatedPart.target.name : void 0,
              repeatedPartCount: isRepeatedPartModule ? repeatedPart.count : void 0,
              multiPartNote: isStructuralModule ? `\uCC44\uC6C0\xB7\uD14D\uC2A4\uD2B8\uB97C \uAC00\uC9C4 \uBD80\uD488 \uBAA8\uC591 ${similarParts}\uAC1C\uAC00 \uB098\uB780\uD788 \uB4E4\uC5B4 \uC788\uC5B4 \uD558\uB098\uC758 \uCEF4\uD3EC\uB10C\uD2B8\uB85C \uAD50\uCCB4\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uB0B4\uBD80 \uBD80\uD488 \uB2E8\uC704\uB85C \uC7AC\uAD6C\uC131\uD558\uC138\uC694.` : void 0,
              parts: await collectModuleParts(inst, pool, (m) => mediumVotes.push(m))
            });
          }
          continue;
        }
        const verdict = isCanonAlready ? null : lookupLegacyDecision([compareName, inst.name], legacyVariantProps(inst));
        if (verdict && (verdict.kind === "decided" || verdict.kind === "not-a-part")) {
          if (verdict.kind === "decided") mediumVotes.push(mediumFromAxes(verdict.axes));
          const wanted = verdict.canonSets.map((n) => normalizeName(n));
          if (!manualSeen.has(inst.id)) {
            manualSeen.add(inst.id);
            let ranked = [];
            let decidedMissing = false;
            if (verdict.kind === "decided") {
              ranked = pinDecidedSuggestion(verdict, rankSuggestions(inst.name && inst.name !== compareName ? `${compareName} ${inst.name}` : compareName, pool), pool);
              decidedMissing = !pool.some((pc) => wanted.indexOf(normalizeName(pc.name)) >= 0);
            }
            manualCandidates.push({
              id: candidateId("m", inst.id),
              instanceId: inst.id,
              instanceName: inst.name,
              currentMainName: compareName,
              currentMainPath: await describeComponentLocation(main),
              suggestions: ranked,
              decision: verdict,
              decidedMissing
            });
          }
          continue;
        }
        if (matched) diag.matchedNameCount++;
        if (sameAsTarget) diag.sameIdSkippedCount++;
        if (diag.instancesPreview.length < 8) {
          diag.instancesPreview.push({ name: inst.name, mainName: compareName, mainTopId: currentTopId, matched, sameAsTarget });
        }
        if (!matched) {
          diag.noMatchCount++;
          if (pool.length > 0 && !manualSeen.has(inst.id)) {
            manualSeen.add(inst.id);
            const nestedCount = nestedInstances.length;
            if (nestedCount >= MODULE_NESTED_THRESHOLD) {
              modules.push({
                id: candidateId("g", inst.id),
                instanceId: inst.id,
                instanceName: inst.name,
                currentMainName: compareName,
                currentMainPath: await describeComponentLocation(main),
                nestedCount,
                parts: await collectModuleParts(inst, pool, (m) => mediumVotes.push(m))
              });
            } else {
              manualCandidates.push({
                id: candidateId("m", inst.id),
                instanceId: inst.id,
                instanceName: inst.name,
                currentMainName: compareName,
                currentMainPath: await describeComponentLocation(main),
                suggestions: rankSuggestions(inst.name && inst.name !== compareName ? `${compareName} ${inst.name}` : compareName, pool),
                decision: verdict || void 0
              });
            }
          }
          continue;
        }
        if (sameAsTarget) continue;
        const sameAsCanonSet = await isSameAsCanonSet(inst, target);
        if (sameAsCanonSet) {
          diag.sameIdSkippedCount++;
          continue;
        }
        const key = inst.id + ":" + target.id;
        if (seen.has(key)) continue;
        seen.add(key);
        const path = await describeComponentLocation(main);
        candidates.push({
          id: candidateId("s", inst.id),
          instanceId: inst.id,
          instanceName: inst.name,
          currentMainId: currentTopId,
          currentMainName: compareName,
          currentMainPath: path,
          suggestedId: target.id,
          suggestedKey: target.key,
          suggestedType: target.type,
          suggestedName: target.name,
          suggestedSource: target.sourceFileName,
          confidence,
          demoteReason: clashed ? "\uC774 \uD30C\uC77C\uC5D0 \uAC19\uC740 \uC774\uB984\uC758 \uBD80\uD488\uC774 \uB458 \uC774\uC0C1\uC774\uB77C \uC5B4\uB290 \uAC83\uC774 \uAE30\uC900\uC778\uC9C0 \uAC00\uB9B4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4 \u2014 \uBC14\uB014 \uBAA8\uC2B5\uC744 \uBCF4\uACE0 \uBC14\uAFD4\uC8FC\uC138\uC694." : void 0
        });
      }
    }
    diag.candidateCount = candidates.length;
    const guess = detectMedium(sel, mediumVotes);
    diag.medium = guess.medium;
    diag.mediumWhy = guess.why;
    return { candidates, diagnostics: diag, manualCandidates, modules };
  }
  async function describeComponentLocation(comp) {
    let cur = comp;
    let pageName = "";
    while (cur) {
      if (cur.type === "PAGE") {
        pageName = cur.name;
        break;
      }
      cur = cur.parent;
    }
    if (pageName) return pageName;
    let remote = false;
    try {
      remote = comp.remote === true;
    } catch (e) {
      remote = false;
    }
    return remote ? "\uB77C\uC774\uBE0C\uB7EC\uB9AC(\uB2E4\uB978 \uD30C\uC77C)" : "(\uC678\uBD80)";
  }
  async function loadReferenceNode(ref) {
    try {
      const n = await figma.getNodeByIdAsync(ref.id);
      if (n && (n.type === "COMPONENT" || n.type === "COMPONENT_SET")) return n;
    } catch (e) {
    }
    if (ref.key) {
      try {
        if (ref.type === "COMPONENT_SET") return await figma.importComponentSetByKeyAsync(ref.key);
        return await figma.importComponentByKeyAsync(ref.key);
      } catch (e) {
        return null;
      }
    }
    return null;
  }
  async function loadSuggestedNode(candidate) {
    return loadReferenceNode({ id: candidate.suggestedId, key: candidate.suggestedKey, type: candidate.suggestedType });
  }
  function variantLabel(vp) {
    if (!vp) return "";
    return Object.keys(vp).map((k) => `${k}=${vp[k]}`).join(" \xB7 ");
  }
  async function getVariantOptions(ref, legacyInstanceId, medium, decidedAxes) {
    const node = await loadReferenceNode(ref);
    if (!node) {
      return { ok: false, reason: "\uC815\uBCF8 \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.", setId: ref.id, setName: "", hasVariants: false, options: [], pickedId: null, matchedAxes: [], unmatchedAxes: [] };
    }
    if (node.type === "COMPONENT") {
      const c = node;
      return { ok: true, setId: c.id, setName: c.name, hasVariants: false, options: [{ id: c.id, key: c.key, label: c.name, values: {} }], pickedId: c.id, matchedAxes: [], unmatchedAxes: [] };
    }
    const set = node;
    let variants = set.children.filter((c) => c.type === "COMPONENT");
    let hiddenByMedium = 0;
    if (medium) {
      const kept = variants.filter((v) => {
        const m = mediumFromAxes(v.variantProperties || {});
        return !m || m === medium;
      });
      if (kept.length) {
        hiddenByMedium = variants.length - kept.length;
        variants = kept;
      }
    }
    const options = variants.map((v) => ({ id: v.id, key: v.key, label: variantLabel(v.variantProperties) || v.name, values: v.variantProperties || {} }));
    if (variants.length === 0) {
      return { ok: false, reason: "\uC815\uBCF8 \uC138\uD2B8\uC5D0 \uBCC0\uD615\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.", setId: set.id, setName: set.name, hasVariants: false, options: [], pickedId: null, matchedAxes: [], unmatchedAxes: [] };
    }
    const inst = await figma.getNodeByIdAsync(legacyInstanceId);
    const legacyVP = inst && inst.type === "INSTANCE" ? inst.variantProperties || {} : {};
    let legacyNames = inst && "name" in inst ? String(inst.name) : "";
    if (inst && inst.type === "INSTANCE") {
      const main = await inst.getMainComponentAsync();
      if (main) legacyNames += " " + main.name + " " + (main.parent && main.parent.type === "COMPONENT_SET" ? main.parent.name : "");
    }
    const nameTokens = tokenizeName(legacyNames.replace(/=/g, " ")).map(normVariantValue);
    const setDefault = set.defaultVariant || variants[0];
    const axes = Object.keys(setDefault.variantProperties || {});
    const defaultSurvived = variants.some((v) => v.id === setDefault.id);
    const legacyByNorm = {};
    for (const k of Object.keys(legacyVP)) legacyByNorm[normAxisName(k)] = legacyVP[k];
    const decidedByNorm = {};
    for (const k of Object.keys(decidedAxes || {})) decidedByNorm[normAxisName(k)] = decidedAxes[k];
    const want = {};
    const matchedAxes = [];
    const unmatchedAxes = [];
    const axisSource = {};
    for (const axis of axes) {
      const values = Array.from(new Set(variants.map((v) => (v.variantProperties || {})[axis]).filter(Boolean)));
      const fromDecision = decidedByNorm[normAxisName(axis)];
      if (fromDecision) {
        const hit = values.find((v) => normVariantValue(v) === normVariantValue(fromDecision));
        if (hit) {
          want[axis] = hit;
          matchedAxes.push(axis);
          axisSource[axis] = "decision";
          continue;
        }
      }
      const fromVP = legacyByNorm[normAxisName(axis)];
      if (fromVP) {
        const hit = values.find((v) => normVariantValue(v) === normVariantValue(fromVP));
        if (hit) {
          want[axis] = hit;
          matchedAxes.push(axis);
          axisSource[axis] = "legacy";
          continue;
        }
      }
      const byName = values.filter((v) => nameTokens.indexOf(normVariantValue(v)) >= 0);
      if (byName.length === 1) {
        want[axis] = byName[0];
        matchedAxes.push(axis);
        axisSource[axis] = "name";
        continue;
      }
      unmatchedAxes.push(axis);
    }
    const defVP = defaultSurvived ? setDefault.variantProperties || {} : {};
    const rank = { decision: 0, legacy: 1, name: 2, default: 3 };
    const ordered = matchedAxes.slice().sort((a, b) => rank[axisSource[a]] - rank[axisSource[b]]);
    const guessedAxes = [];
    const keptAxes = [];
    let pool = variants.slice();
    for (const axis of ordered) {
      const next = pool.filter((v) => (v.variantProperties || {})[axis] === want[axis]);
      if (next.length > 0) {
        pool = next;
        keptAxes.push(axis);
        continue;
      }
      delete want[axis];
      axisSource[axis] = "default";
      guessedAxes.push(axis);
    }
    for (const axis of axes) {
      if (keptAxes.indexOf(axis) >= 0) continue;
      const distinct = Array.from(new Set(pool.map((v) => (v.variantProperties || {})[axis]).filter(Boolean)));
      if (distinct.length <= 1) {
        axisSource[axis] = "only";
        continue;
      }
      const byDefault = defVP[axis] ? pool.filter((v) => (v.variantProperties || {})[axis] === defVP[axis]) : [];
      if (byDefault.length > 0) {
        pool = byDefault;
        want[axis] = defVP[axis];
      }
      axisSource[axis] = "default";
      if (guessedAxes.indexOf(axis) < 0) guessedAxes.push(axis);
    }
    const picked = pool.length > 0 ? pool[0] : null;
    const confident = guessedAxes.length === 0 && pool.length === 1;
    return {
      ok: true,
      setId: set.id,
      setName: set.name,
      hasVariants: true,
      options,
      pickedId: picked ? picked.id : null,
      matchedAxes: keptAxes,
      unmatchedAxes,
      axisSource,
      guessedAxes,
      confident,
      hiddenByMedium
    };
  }
  async function exportPreviewBytes(node) {
    try {
      const w = "width" in node ? node.width : 0;
      const h = "height" in node ? node.height : 0;
      const longest = Math.max(w, h, 1);
      const scale = Math.max(0.25, Math.min(2, 320 / longest));
      return await node.exportAsync({ format: "PNG", constraint: { type: "SCALE", value: scale } });
    } catch (e) {
      return null;
    }
  }
  async function exportNodePreview(nodeId) {
    const n = await figma.getNodeByIdAsync(nodeId);
    if (!n || !("exportAsync" in n)) return null;
    return exportPreviewBytes(n);
  }
  async function exportReferencePreview(ref) {
    const node = await loadReferenceNode(ref);
    if (!node) return null;
    if (node.type === "COMPONENT_SET") {
      const first = node.children.filter((c) => c.type === "COMPONENT")[0];
      return first ? exportPreviewBytes(first) : null;
    }
    return exportPreviewBytes(node);
  }
  async function resolveSwapTarget(candidate, mode, legacyVP) {
    const node = await loadSuggestedNode(candidate);
    if (!node) return { target: null, reason: "resolve-failed", variantReset: false, axisLoss: 0 };
    if (node.type === "COMPONENT") {
      return { target: node, reason: null, variantReset: false, axisLoss: 0 };
    }
    const set = node;
    const pick = pickVariantTarget(set, legacyVP);
    if (pick.target) {
      return { target: pick.target, reason: null, variantReset: false, axisLoss: pick.axisLoss };
    }
    if (mode === "lenient") {
      const fallback = set.defaultVariant || set.children.filter((c) => c.type === "COMPONENT")[0] || null;
      if (fallback) return { target: fallback, reason: null, variantReset: true, axisLoss: pick.axisLoss };
      return { target: null, reason: "resolve-failed", variantReset: false, axisLoss: pick.axisLoss };
    }
    return { target: null, reason: pick.reason || "no-variant-match", variantReset: false, axisLoss: pick.axisLoss };
  }
  var ROLLBACK_FRAME_MARK = "s1-inspector-swap-backup";
  var rollbackFrameId = "";
  var rollbackFrameNode = null;
  async function getRollbackFrame() {
    if (rollbackFrameId) {
      const existing = await figma.getNodeByIdAsync(rollbackFrameId);
      if (existing && existing.type === "FRAME") {
        rollbackFrameNode = existing;
        return rollbackFrameNode;
      }
    }
    for (const node of figma.currentPage.children) {
      if (node.type === "FRAME" && node.getPluginData(ROLLBACK_FRAME_MARK) === "1") {
        rollbackFrameId = node.id;
        rollbackFrameNode = node;
        return rollbackFrameNode;
      }
    }
    const frame = figma.createFrame();
    frame.name = "\uAC80\uC218\uAE30 \uB418\uB3CC\uB9AC\uAE30 \uBC31\uC5C5";
    frame.visible = false;
    frame.setPluginData(ROLLBACK_FRAME_MARK, "1");
    rollbackFrameId = frame.id;
    rollbackFrameNode = frame;
    return frame;
  }
  async function discardSwapRollback(rollback) {
    const backup = await figma.getNodeByIdAsync(rollback.backupNodeId);
    if (backup) backup.remove();
    if (rollbackFrameId) {
      const frame = await figma.getNodeByIdAsync(rollbackFrameId);
      if (frame && frame.type === "FRAME" && frame.children.length === 0) {
        frame.remove();
        rollbackFrameId = "";
        rollbackFrameNode = null;
      }
    }
  }
  async function cleanupSwapBackups() {
    if (rollbackFrameNode && !rollbackFrameNode.removed) {
      rollbackFrameNode.remove();
    } else if (rollbackFrameId) {
      const frame = await figma.getNodeByIdAsync(rollbackFrameId);
      if (frame) frame.remove();
    }
    rollbackFrameNode = null;
    rollbackFrameId = "";
    for (const page of figma.root.children) {
      try {
        for (const node of Array.from(page.children)) {
          if (node.type === "FRAME" && node.getPluginData(ROLLBACK_FRAME_MARK) === "1") node.remove();
        }
      } catch (e) {
      }
    }
  }
  function collectTextsWithPath(root) {
    const out = [];
    const walk2 = (node, path) => {
      if (node.type === "TEXT") out.push({ key: path.join("/"), node });
      if ("children" in node) {
        const kids = node.children;
        const nameSeen = {};
        for (const k of kids) {
          const base = k.name || k.type;
          const idx = nameSeen[base] = nameSeen[base] === void 0 ? 0 : nameSeen[base] + 1;
          walk2(k, path.concat(`${base}#${idx}`));
        }
      }
    };
    walk2(root, []);
    return out;
  }
  function captureTextOverrides(inst) {
    const map = /* @__PURE__ */ new Map();
    for (const t of collectTextsWithPath(inst)) {
      if (!map.has(t.key)) map.set(t.key, t.node.characters);
    }
    return map;
  }
  async function loadFontsForText(node) {
    const fn = node.fontName;
    if (fn === figma.mixed) {
      const len = node.characters.length;
      const seen = /* @__PURE__ */ new Set();
      for (let i = 0; i < len; i++) {
        const f = node.getRangeFontName(i, i + 1);
        if (f !== figma.mixed) seen.add(JSON.stringify(f));
      }
      for (const s of seen) await figma.loadFontAsync(JSON.parse(s));
    } else {
      await figma.loadFontAsync(fn);
    }
  }
  async function restoreTextOverrides(inst, captured) {
    if (captured.size === 0) return { restored: 0, unpreserved: [] };
    const used = /* @__PURE__ */ new Set();
    let restored = 0;
    for (const { key, node } of collectTextsWithPath(inst)) {
      if (!captured.has(key) || used.has(key)) continue;
      const chars = captured.get(key);
      used.add(key);
      if (node.characters === chars) {
        restored++;
        continue;
      }
      try {
        await loadFontsForText(node);
        node.characters = chars;
        restored++;
      } catch (e) {
        used.delete(key);
      }
    }
    const unpreserved = [];
    for (const [key, chars] of captured) {
      if (!used.has(key) && chars.trim() !== "") unpreserved.push(chars);
    }
    return { restored, unpreserved };
  }
  async function applySwap(candidate, mode = "lenient") {
    const inst = await figma.getNodeByIdAsync(candidate.instanceId);
    if (!inst || inst.type !== "INSTANCE") {
      return { ok: false, result: "failed", reason: "\uC778\uC2A4\uD134\uC2A4\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC74C" };
    }
    if (hasInstanceAncestor(inst)) {
      return { ok: false, result: "failed", reason: "\uB2E4\uB978 \uCEF4\uD3EC\uB10C\uD2B8 \uC548\uC5D0 \uD3EC\uD568\uB41C \uBD80\uD488\uC774\uB77C \uAC1C\uBCC4 \uAD50\uCCB4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    }
    const legacyVP = inst.variantProperties || null;
    const res = await resolveSwapTarget(candidate, mode, legacyVP);
    if (!res.target) {
      if (res.reason === "no-variant-match") {
        return { ok: false, result: "demoted", reason: "\uC815\uBCF8\uC5D0 \uAC19\uC740 \uC0C1\uD0DC(\uBCC0\uD615) \uC870\uD569\uC774 \uC5C6\uC5B4 \uC790\uB3D9 \uAD50\uCCB4\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.", axisLoss: res.axisLoss };
      }
      return { ok: false, result: "failed", reason: "\uAE30\uC900 \uCEF4\uD3EC\uB10C\uD2B8\uB97C import\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uAE30\uC900 \uD30C\uC77C\uC5D0\uC11C \uCEF4\uD3EC\uB10C\uD2B8\uAC00 publish\uB418\uC5C8\uB294\uC9C0 \uD655\uC778\uD574\uC8FC\uC138\uC694." };
    }
    const parent = inst.parent;
    if (!parent || !("children" in parent)) return { ok: false, result: "failed", reason: "\uAD50\uCCB4 \uC804 \uC704\uCE58\uB97C \uC800\uC7A5\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    const backup = inst.clone();
    const rollback = {
      instanceId: inst.id,
      backupNodeId: backup.id,
      originalParentId: parent.id,
      originalIndex: Array.from(parent.children).findIndex((child) => child.id === inst.id),
      originalX: inst.x,
      originalY: inst.y,
      originalVisible: inst.visible
    };
    const captured = captureTextOverrides(inst);
    try {
      const backupFrame = await getRollbackFrame();
      backup.visible = false;
      backupFrame.appendChild(backup);
    } catch (e) {
      try {
        backup.remove();
      } catch (e2) {
      }
      return { ok: false, result: "failed", reason: `\uAD50\uCCB4 \uC804 \uC0C1\uD0DC\uB97C \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${String(e && e.message || e)}` };
    }
    try {
      inst.swapComponent(res.target);
    } catch (e) {
      await discardSwapRollback(rollback);
      return { ok: false, result: "failed", reason: String(e && e.message || e) };
    }
    let unpreserved = [];
    try {
      const pres = await restoreTextOverrides(inst, captured);
      unpreserved = pres.unpreserved;
    } catch (e) {
    }
    const fitted = await fitInstanceToMode(inst);
    return { ok: true, result: "swapped", variantReset: res.variantReset, axisLoss: res.axisLoss, unpreserved, rollback, modeFitted: fitted.changed ? fitted.mode : void 0 };
  }
  async function fitInstanceToMode(target, contextNode) {
    const collections = await loadCollectionsCached();
    const semantic = collections.filter((col) => col.name === SEMANTIC_COLOR_COLLECTION)[0];
    if (!semantic) return { changed: 0, mode: "" };
    const wantModeId = contextNode ? pinnedModeId(contextNode, semantic.id, true) || semantic.defaultModeId : pinnedModeId(target, semantic.id, false) || semantic.defaultModeId;
    const found = semantic.modes.filter((m) => m.modeId === wantModeId)[0];
    const wantName = found ? found.name : "";
    const nodes = [target];
    try {
      target.findAll((n) => n.type === "INSTANCE").forEach((n) => nodes.push(n));
    } catch (e) {
    }
    let changed = 0;
    for (const node of nodes) {
      const pins = node.explicitVariableModes;
      const pinned = pins ? pins[semantic.id] : void 0;
      if (pinned === wantModeId) continue;
      if (pinned) {
        try {
          node.clearExplicitVariableModeForCollection(semantic.id);
          changed++;
        } catch (e) {
        }
      }
      let resolved;
      try {
        const table = node.resolvedVariableModes;
        resolved = table ? table[semantic.id] : void 0;
      } catch (e) {
      }
      if (resolved === void 0) {
        resolved = pinnedModeId(node, semantic.id, true) || semantic.defaultModeId;
      }
      if (resolved !== wantModeId) {
        try {
          node.setExplicitVariableModeForCollection(semantic.id, wantModeId);
          changed++;
        } catch (e) {
        }
      }
    }
    return { changed, mode: wantName };
  }
  async function swapInstanceTo(inst, candidate, mode) {
    const res = await resolveSwapTarget(candidate, mode, inst.variantProperties || null);
    if (!res.target) {
      if (res.reason === "no-variant-match") {
        return { ok: false, result: "demoted", reason: "\uC815\uBCF8\uC5D0 \uAC19\uC740 \uC0C1\uD0DC(\uBCC0\uD615) \uC870\uD569\uC774 \uC5C6\uC5B4 \uC790\uB3D9 \uAD50\uCCB4\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.", axisLoss: res.axisLoss };
      }
      return { ok: false, result: "failed", reason: "\uAE30\uC900 \uCEF4\uD3EC\uB10C\uD2B8\uB97C import\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uAE30\uC900 \uD30C\uC77C\uC5D0\uC11C \uCEF4\uD3EC\uB10C\uD2B8\uAC00 publish\uB418\uC5C8\uB294\uC9C0 \uD655\uC778\uD574\uC8FC\uC138\uC694." };
    }
    const captured = captureTextOverrides(inst);
    try {
      inst.swapComponent(res.target);
    } catch (e) {
      return { ok: false, result: "failed", reason: String(e && e.message || e) };
    }
    let unpreserved = [];
    try {
      unpreserved = (await restoreTextOverrides(inst, captured)).unpreserved;
    } catch (e) {
    }
    const fitted = await fitInstanceToMode(inst);
    return { ok: true, result: "swapped", variantReset: res.variantReset, axisLoss: res.axisLoss, unpreserved, modeFitted: fitted.changed ? fitted.mode : void 0 };
  }
  async function detachModule(moduleInstanceId, pool) {
    const moduleNode = await figma.getNodeByIdAsync(moduleInstanceId);
    if (!moduleNode || moduleNode.type !== "INSTANCE") {
      return { ok: false, reason: "\uBB36\uC74C\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uAC80\uC0AC\uD574\uC8FC\uC138\uC694." };
    }
    const moduleInst = moduleNode;
    const parent = moduleInst.parent;
    if (!parent || !("children" in parent)) return { ok: false, reason: "\uBB36\uC74C\uC758 \uC704\uCE58\uB97C \uC800\uC7A5\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    const backup = moduleInst.clone();
    const rollback = {
      instanceId: moduleInst.id,
      backupNodeId: backup.id,
      originalParentId: parent.id,
      originalIndex: Array.from(parent.children).findIndex((child) => child.id === moduleInst.id),
      originalX: moduleInst.x,
      originalY: moduleInst.y,
      originalVisible: moduleInst.visible
    };
    try {
      const backupFrame = await getRollbackFrame();
      backup.visible = false;
      backupFrame.appendChild(backup);
    } catch (e) {
      try {
        backup.remove();
      } catch (e2) {
      }
      return { ok: false, reason: `\uBB36\uC74C\uC744 \uD480\uAE30 \uC804 \uC0C1\uD0DC\uB97C \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${String(e && e.message || e)}` };
    }
    let frame;
    try {
      frame = moduleInst.detachInstance();
    } catch (e) {
      await discardSwapRollback(rollback);
      return { ok: false, reason: `\uBB36\uC74C\uC744 \uD480\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4: ${String(e && e.message || e)}` };
    }
    return { ok: true, frame, moduleNodeId: frame.id, parts: await collectModuleParts(frame, pool), rollback: __spreadProps(__spreadValues({}, rollback), { instanceId: frame.id }) };
  }
  async function applyModulePartSwap(args) {
    const part = await figma.getNodeByIdAsync(args.candidate.instanceId);
    if (!part || part.type !== "INSTANCE") {
      return { ok: false, result: "failed", reason: "\uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC544\uB2C8\uB77C \uAD50\uCCB4\uD560 \uC218 \uC5C6\uB294 \uC870\uAC01\uC785\uB2C8\uB2E4." };
    }
    if (!hasInstanceAncestor(part)) {
      const r = await applySwap(args.candidate, "lenient");
      return { ok: r.ok, result: r.result, reason: r.reason, variantReset: r.variantReset, axisLoss: r.axisLoss, unpreserved: r.unpreserved, rollback: r.rollback, modeFitted: r.modeFitted };
    }
    if (!args.allowDetach) {
      const attempt = await swapInstanceTo(part, args.candidate, "lenient");
      if (attempt.ok) return { ok: true, result: "swapped", variantReset: attempt.variantReset, axisLoss: attempt.axisLoss, unpreserved: attempt.unpreserved, modeFitted: attempt.modeFitted };
      if (attempt.result === "demoted") return { ok: false, result: "demoted", reason: attempt.reason };
      return { ok: false, result: "blocked", reason: attempt.reason || "\uBB36\uC74C \uC548\uC5D0 \uC788\uB294 \uBD80\uD488\uC774\uB77C \uADF8\uB300\uB85C\uB294 \uAD50\uCCB4\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4." };
    }
    const detached = await detachModule(args.moduleInstanceId, args.pool);
    if (!detached.ok || !detached.frame) {
      return { ok: false, result: "failed", reason: detached.reason };
    }
    const frame = detached.frame;
    const rollback = detached.rollback;
    let target = resolveByPath(frame, args.partPath);
    if (!target || target.type !== "INSTANCE") {
      const byId = await figma.getNodeByIdAsync(args.candidate.instanceId);
      target = byId && "type" in byId && byId.type === "INSTANCE" ? byId : null;
    }
    const rollbackAfterDetach = rollback;
    if (!target) {
      return { ok: false, result: "failed", reason: "\uBB36\uC74C\uC740 \uD480\uC5C8\uC9C0\uB9CC \uAD50\uCCB4\uD560 \uBD80\uD488\uC744 \uB2E4\uC2DC \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.", detached: true, moduleNodeId: frame.id, rollback: rollbackAfterDetach, parts: await collectModuleParts(frame, args.pool) };
    }
    const swapped = await swapInstanceTo(target, args.candidate, "lenient");
    return {
      ok: swapped.ok,
      result: swapped.ok ? "swapped" : swapped.result,
      reason: swapped.reason,
      variantReset: swapped.variantReset,
      axisLoss: swapped.axisLoss,
      unpreserved: swapped.unpreserved,
      modeFitted: swapped.modeFitted,
      detached: true,
      moduleNodeId: frame.id,
      rollback: rollbackAfterDetach,
      parts: await collectModuleParts(frame, args.pool)
    };
  }
  async function importComponentCopy(candidate) {
    const inst = await figma.getNodeByIdAsync(candidate.instanceId);
    const legacyVP = inst && inst.type === "INSTANCE" ? inst.variantProperties || null : null;
    const res = await resolveSwapTarget(candidate, "lenient", legacyVP);
    if (!res.target) {
      return { ok: false, reason: "\uAE30\uC900 \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uAE30\uC900 \uD30C\uC77C\uC5D0\uC11C publish \uB418\uC5C8\uB294\uC9C0 \uD655\uC778\uD574\uC8FC\uC138\uC694." };
    }
    let copy;
    try {
      copy = res.target.createInstance();
    } catch (e) {
      return { ok: false, reason: String(e && e.message || e) };
    }
    const page = figma.currentPage;
    page.appendChild(copy);
    const box = inst && "absoluteBoundingBox" in inst ? inst.absoluteBoundingBox : null;
    const GAP = 40;
    if (box) {
      copy.x = box.x;
      copy.y = box.y - copy.height - GAP;
    } else {
      copy.x = figma.viewport.center.x;
      copy.y = figma.viewport.center.y;
    }
    const setName = res.target.parent && res.target.parent.type === "COMPONENT_SET" ? res.target.parent.name : res.target.name;
    copy.name = `${setName} (\uAC00\uC838\uC634)`;
    if (inst && "type" in inst) {
      try {
        await fitInstanceToMode(copy, inst);
      } catch (e) {
      }
    }
    page.selection = [copy];
    figma.viewport.scrollAndZoomIntoView([copy]);
    return { ok: true, nodeId: copy.id, name: copy.name, variantReset: res.variantReset };
  }
  async function rollbackSwap(rollback) {
    const node = await figma.getNodeByIdAsync(rollback.instanceId);
    if (!node || !("parent" in node) || node.type === "PAGE" || node.type === "DOCUMENT") {
      return { ok: false, reason: "\uB418\uB3CC\uB9B4 \uD56D\uBAA9\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    }
    const backup = await figma.getNodeByIdAsync(rollback.backupNodeId);
    if (!backup || backup.type !== "INSTANCE") return { ok: false, reason: "\uAD50\uCCB4 \uC804 \uBC31\uC5C5\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    const originalParent = await figma.getNodeByIdAsync(rollback.originalParentId);
    const parent = originalParent && "children" in originalParent ? originalParent : node.parent;
    if (!parent || !("children" in parent)) return { ok: false, reason: "\uC6D0\uB798 \uC704\uCE58\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." };
    try {
      const index = Math.max(0, Math.min(rollback.originalIndex, parent.children.length));
      backup.visible = rollback.originalVisible;
      parent.insertChild(index, backup);
      try {
        backup.x = rollback.originalX;
        backup.y = rollback.originalY;
      } catch (e) {
      }
      node.remove();
      if (rollbackFrameId) {
        const frame = await figma.getNodeByIdAsync(rollbackFrameId);
        if (frame && frame.type === "FRAME" && frame.children.length === 0) {
          frame.remove();
          rollbackFrameId = "";
          rollbackFrameNode = null;
        }
      }
      return { ok: true, instanceId: backup.id };
    } catch (e) {
      return { ok: false, reason: String(e && e.message || e) };
    }
  }
  function collectPageReference(preferredPage) {
    const fileName = figma.root.name;
    const seen = {};
    const out = [];
    REFERENCE_NAME_CLASHES = [];
    const push = (list) => {
      for (const c of list) {
        const norm = refNameKey(c.name);
        if (!CANONICAL_NAME_SET[norm]) continue;
        if (!seen[norm]) {
          seen[norm] = true;
          out.push(c);
        } else if (REFERENCE_NAME_CLASHES.indexOf(norm) < 0) REFERENCE_NAME_CLASHES.push(norm);
      }
    };
    const firstPage = preferredPage || figma.currentPage;
    try {
      push(collectComponents(firstPage, fileName));
    } catch (e) {
    }
    for (const page of figma.root.children) {
      if (page.id === firstPage.id) continue;
      try {
        push(collectComponents(page, fileName));
      } catch (e) {
      }
    }
    return out;
  }
  async function buildImprovedCopy() {
    const sel = figma.currentPage.selection;
    if (sel.length !== 1 || sel[0].type !== "FRAME") {
      return { ok: false, code: "need-single-frame", reason: "\uAC1C\uC120\uC548\uC744 \uB9CC\uB4E4 \uD654\uBA74 \uD504\uB808\uC784\uC744 \uD558\uB098\uB9CC \uC120\uD0DD\uD574\uC8FC\uC138\uC694." };
    }
    const src = sel[0];
    const pool = collectPageReference();
    if (pool.length === 0) {
      return { ok: false, code: "need-install", reason: "\uC774 \uD398\uC774\uC9C0\uC5D0 \uC815\uBCF8 \uCEF4\uD3EC\uB10C\uD2B8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. [\uC124\uCE58] \uD0ED\uC744 \uBA3C\uC800 \uC2E4\uD589\uD574\uC8FC\uC138\uC694." };
    }
    const clone = src.clone();
    try {
      clone.name = src.name + " \u2014 \uAC1C\uC120\uC548";
      figma.currentPage.appendChild(clone);
      const box = src.absoluteBoundingBox;
      if (box) {
        clone.x = box.x + box.width + 200;
        clone.y = box.y;
      } else {
        clone.x = src.x + src.width + 200;
        clone.y = src.y;
      }
      const { candidates, diagnostics, manualCandidates, modules } = await scanSwapCandidates(pool, [clone]);
      let autoSwapped = 0, ambiguous = 0, failed = 0, axisLoss = 0, textUnpreserved = 0;
      const ambiguousList = [];
      const failedList = [];
      for (const c of candidates) {
        if (c.confidence !== "high") {
          ambiguous++;
          ambiguousList.push(__spreadProps(__spreadValues({}, c), { demoteReason: c.demoteReason || "\uC774\uB984\uC774 \uBD80\uBD84\uC801\uC73C\uB85C\uB9CC \uC77C\uCE58\uD574 \uD655\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4." }));
          continue;
        }
        const r = await applySwap(c, "strict");
        if (r.result === "swapped") {
          autoSwapped++;
          if (r.axisLoss && r.axisLoss > 0) axisLoss++;
          if (r.unpreserved && r.unpreserved.length) textUnpreserved += r.unpreserved.length;
        } else if (r.result === "demoted") {
          ambiguous++;
          ambiguousList.push(__spreadProps(__spreadValues({}, c), { confidence: "ambiguous", demoteReason: r.reason || "\uC815\uBCF8\uC5D0 \uAC19\uC740 \uC0C1\uD0DC(\uBCC0\uD615) \uC870\uD569\uC774 \uC5C6\uC2B5\uB2C8\uB2E4." }));
        } else {
          failed++;
          failedList.push(__spreadProps(__spreadValues({}, c), { demoteReason: r.reason || "\uAD50\uCCB4\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4." }));
        }
      }
      return {
        ok: true,
        summary: {
          cloned: true,
          cloneId: clone.id,
          cloneName: clone.name,
          sourceName: src.name,
          autoSwapped,
          ambiguous,
          failed,
          axisLoss,
          textUnpreserved,
          manualNeeded: manualCandidates.length,
          decidedCount: manualCandidates.filter((c) => c.decision && c.decision.kind === "decided").length,
          undecidedCount: manualCandidates.filter((c) => !c.decision || c.decision.kind === "undecided" || c.decision.kind === "ambiguous").length,
          notAPartCount: manualCandidates.filter((c) => c.decision && c.decision.kind === "not-a-part").length,
          moduleNeeded: modules.length,
          skippedNested: diagnostics.skippedNestedCount,
          alreadyCanonical: diagnostics.sameIdSkippedCount,
          noMatch: diagnostics.noMatchCount,
          totalInstances: diagnostics.instanceCount,
          referencePoolSize: pool.length,
          medium: diagnostics.medium,
          mediumWhy: diagnostics.mediumWhy
        },
        ambiguousCandidates: ambiguousList,
        failedCandidates: failedList,
        manualCandidates,
        modules
      };
    } catch (e) {
      try {
        clone.remove();
      } catch (e2) {
      }
      throw e;
    }
  }
  var REFERENCE_STORAGE_KEY = "s1-component-audit:reference-pool";
  async function loadReference() {
    try {
      const saved = await figma.clientStorage.getAsync(REFERENCE_STORAGE_KEY);
      if (!saved || !saved.pool || saved.pool.length === 0) return null;
      const valid = [];
      for (const c of saved.pool) {
        if (c.key) {
          valid.push(c);
          continue;
        }
        const n = await figma.getNodeByIdAsync(c.id);
        if (n && (n.type === "COMPONENT" || n.type === "COMPONENT_SET")) {
          valid.push(c);
        }
      }
      if (valid.length === 0) return null;
      return { pool: valid, rootNames: saved.rootNames || [], sourceFileName: saved.sourceFileName };
    } catch (e) {
      return null;
    }
  }
  async function saveReference(pool, rootNames, sourceFileName) {
    try {
      await figma.clientStorage.setAsync(REFERENCE_STORAGE_KEY, { pool, rootNames, sourceFileName });
    } catch (e) {
    }
  }
  async function clearReference() {
    try {
      await figma.clientStorage.deleteAsync(REFERENCE_STORAGE_KEY);
    } catch (e) {
    }
  }

  // plugins/figma-vars-installer/src/code.ts
  var CURRENT_GUIDE_FINGERPRINT = "dfe6984b770fef5465ce23c7b1c0649494f310554d6c64f21042286e269d116e";
  var GUIDE_VERSION_KEY = "s1-guide-fingerprint";
  var GUIDE_PAGE_KEY = "s1-guide-page-id";
  var GUIDE_PAGE_NAME = "S-1 UX Guide";
  figma.showUI(__html__, { width: 440, height: 800, title: "S-1 S/W UX Guide \uC124\uCE58/\uAC80\uC218\uAE30 0.2Ver" });
  var auditSessionRootIds = [];
  var swapRollbackById = /* @__PURE__ */ new Map();
  void cleanupSwapBackups();
  var CANCEL_INSTALL = false;
  var CANCELLED = "__INSTALL_CANCELLED__";
  function throwIfCancelled() {
    if (CANCEL_INSTALL) throw new Error(CANCELLED);
  }
  figma.ui.onmessage = async (msg) => {
    if (msg.type === "install") {
      await runInstall({
        foundation: msg.foundation === true,
        semantic: msg.semantic === true,
        textStyles: msg.textStyles === true,
        components: msg.components === true
      }, { stampCompleteGuide: true });
    } else if (msg.type === "install-cancel") {
      CANCEL_INSTALL = true;
    } else if (msg.type === "update-guide") {
      await installLatestGuideOnNewPage();
    } else if (msg.type === "reinstall-clean") {
      await removeInstalledComponents();
    } else if (msg.type.indexOf("pattern:") === 0) {
      await handlePatternMessage(msg.type.slice(8), msg.payload);
    } else if (msg.type.indexOf("audit:") === 0) {
      await handleAuditMessage(msg.type.slice(6), msg.payload);
    } else if (msg.type === "cancel") {
      figma.closePlugin();
    }
  };
  async function handleAuditMessage(type, payload) {
    try {
      if (type === "selection-state") {
        await postAuditSelectionState(payload && payload.requestId);
      } else if (type === "selection-summary") {
        postAuditSelectionSummary();
      } else if (type === "inspect-selection") {
        const requestedPhase = payload && payload.phase === "details" ? "details" : "component";
        if (requestedPhase === "component") {
          await cleanupSwapBackups();
          swapRollbackById.clear();
        }
        let selected = [];
        if (requestedPhase === "details" && auditSessionRootIds.length > 0) {
          for (const id of auditSessionRootIds) {
            const node = await figma.getNodeByIdAsync(id);
            if (node && "type" in node && node.type !== "PAGE" && node.type !== "DOCUMENT") selected.push(node);
          }
        }
        if (selected.length === 0) selected = Array.from(figma.currentPage.selection);
        if (selected.length === 0) {
          figma.ui.postMessage({ type: "audit:inspection-result", payload: { ok: false, message: "Figma\uC5D0\uC11C \uAC80\uC0AC\uD560 \uC601\uC5ED\uC744 \uBA3C\uC800 \uC120\uD0DD\uD558\uC138\uC694." } });
          return;
        }
        if (requestedPhase === "component") auditSessionRootIds = selected.map((node) => node.id);
        await figma.ui.postMessage({ type: "audit:inspection-progress", payload: { current: 0, completed: [], total: 12, pct: 4 } });
        clearV2Cache();
        const installState = await getAuditInstallState();
        const guidePage = await getReferenceGuidePage();
        const pool = collectPageReference(guidePage || void 0);
        if (!installState.installed) {
          figma.ui.postMessage({ type: "audit:inspection-result", payload: { ok: false, code: "need-install", message: `\uAC80\uC218 \uAE30\uC900 \uC124\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4: ${installState.missing.join(" \xB7 ")}` } });
          return;
        }
        const componentScan = await scanSwapCandidates(pool, selected);
        const componentCount = componentScan.candidates.length + componentScan.manualCandidates.length + componentScan.modules.length;
        const componentItem = {
          id: 0,
          count: componentCount,
          status: componentCount ? "warning" : "pass",
          coverage: "partial"
        };
        await figma.ui.postMessage({ type: "audit:inspection-progress", payload: { current: 1, completed: [0], total: 12, pct: 18 } });
        const contexts = await detectScreenContext(selected);
        const context = contexts[0] || null;
        const modeMixed = contexts.length > 1 && contexts.some((c) => c.mode !== contexts[0].mode);
        const narrowMode = !modeMixed && context && context.mode ? context.mode : void 0;
        const color = await audit(selected, narrowMode);
        await figma.ui.postMessage({ type: "audit:inspection-progress", payload: { current: 2, completed: [0, 1], total: 12, pct: 34, scanned: color.stats.scanned } });
        const facts = await auditChecklistFacts(color.issues, selected, context);
        for (let current = 3; current < 12; current++) {
          const completed = Array.from({ length: current }, (_, i) => i);
          await figma.ui.postMessage({
            type: "audit:inspection-progress",
            payload: { current, completed, total: 12, pct: Math.min(96, 34 + current * 5), scanned: color.stats.scanned }
          });
          await new Promise((resolve) => setTimeout(resolve, 60));
        }
        await figma.ui.postMessage({ type: "audit:inspection-progress", payload: { current: null, completed: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], total: 12, pct: 100, scanned: color.stats.scanned } });
        figma.ui.postMessage({
          type: "audit:inspection-result",
          payload: {
            ok: true,
            phase: "details",
            selection: auditSelectionSummary(selected),
            checklist: [componentItem, ...facts.items],
            component: componentScan,
            colorIssues: color.issues,
            colorDetails: facts.colorDetails,
            textIssues: facts.textIssues,
            shadowIssues: facts.shadowIssues,
            modeIssues: facts.modeIssues,
            platformIssues: facts.platformIssues,
            screen: context,
            screenAll: contexts,
            modeMixed,
            stats: color.stats
          }
        });
      } else if (type === "scan") {
        const res = await audit();
        figma.ui.postMessage({ type: "audit:scan-result", payload: res });
      } else if (type === "select-node") {
        const n = await figma.getNodeByIdAsync(payload.nodeId);
        if (n && "type" in n) {
          figma.currentPage.selection = [n];
          figma.viewport.scrollAndZoomIntoView([n]);
        }
      } else if (type === "apply-one") {
        const pairInfo = { paired: 0 };
        const ok = await applyOne(payload.issue, payload.suggestionIndex, pairInfo);
        figma.ui.postMessage({
          type: "audit:apply-result",
          payload: { issueId: payload.issue.id, suggestionIndex: payload.suggestionIndex, ok, paired: pairInfo.paired }
        });
      } else if (type === "apply-text-style") {
        const res = await applyTextStyleFix(payload.styleName, payload.targetIds || []);
        if (res.reason) figma.notify(res.reason);
        else figma.notify(`${res.ok}\uAC74 \uC815\uB9AC${res.fail ? ` \xB7 ${res.fail}\uAC74 \uC2E4\uD328` : ""}`);
        figma.ui.postMessage({
          type: "audit:apply-text-style-result",
          payload: { issueId: payload.issueId, ok: res.ok, fail: res.fail, reason: res.reason, styleName: payload.styleName }
        });
      } else if (type === "apply-high") {
        const count = await applyHighConfidence(payload.issues);
        figma.notify(`${count}\uAC74 \uC790\uB3D9 \uC801\uC6A9 \uC644\uB8CC`);
        figma.ui.postMessage({ type: "audit:apply-high-result", payload: { count } });
      } else if (type === "apply-multi") {
        const res = await applyMulti(payload.picks);
        figma.notify(`${res.ok}\uAC74 \uC801\uC6A9${res.fail ? ` \xB7 ${res.fail}\uAC74 \uC2E4\uD328` : ""}`);
        figma.ui.postMessage({ type: "audit:apply-multi-result", payload: res });
      } else if (type === "set-mode") {
        const res = await setVariablesMode(payload.mode);
        let notify;
        if (res.message) notify = res.message;
        else if (payload.mode === "clear") notify = `${res.cleared || 0}\uAC74 \uBAA8\uB4DC override \uC81C\uAC70 (\uC804\uCCB4 \uCEEC\uB809\uC158 \xB7 \uC790\uC190 \uD3EC\uD568)`;
        else notify = `${res.count}\uAC1C \uB178\uB4DC ${payload.mode} \uBAA8\uB4DC \uC801\uC6A9${res.skipped ? ` \xB7 ${res.skipped}\uAC1C skip` : ""}`;
        figma.notify(notify);
        figma.ui.postMessage({ type: "audit:set-mode-result", payload: __spreadProps(__spreadValues({}, res), { message: notify }) });
      } else if (type === "register-reference") {
        const sel = figma.currentPage.selection;
        if (sel.length === 0) {
          figma.ui.postMessage({ type: "audit:register-reference-result", payload: { ok: false, message: "\uAE30\uC900\uC73C\uB85C \uB4F1\uB85D\uD560 \uD398\uC774\uC9C0/\uD504\uB808\uC784\uC744 \uBA3C\uC800 \uC120\uD0DD\uD558\uC138\uC694" } });
        } else {
          const fileName = figma.root.name || "(unsaved)";
          const all = [];
          const rootNames = [];
          for (const root of sel) {
            rootNames.push(root.name);
            all.push(...collectComponents(root, fileName));
          }
          const dedup = /* @__PURE__ */ new Map();
          for (const c of all) {
            const k = c.name.toLowerCase();
            if (!dedup.has(k)) dedup.set(k, c);
          }
          const pool = Array.from(dedup.values());
          const withoutKey = pool.filter((p) => !p.key).length;
          await saveReference(pool, rootNames, fileName);
          figma.ui.postMessage({ type: "audit:register-reference-result", payload: { ok: true, pool, rootNames, sourceFileName: fileName, withoutKey } });
        }
      } else if (type === "clear-reference") {
        await clearReference();
        figma.ui.postMessage({ type: "audit:reference-cleared" });
      } else if (type === "scan-swap") {
        const res = await scanSwapCandidates(payload.pool || []);
        figma.ui.postMessage({ type: "audit:scan-swap-result", payload: res });
      } else if (type === "build-improved") {
        const res = await buildImprovedCopy();
        if (!res.ok) {
          figma.notify(res.reason);
          figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: false, code: res.code, message: res.reason } });
        } else {
          const node = await figma.getNodeByIdAsync(res.summary.cloneId);
          if (node) {
            figma.currentPage.selection = [node];
            figma.viewport.scrollAndZoomIntoView([node]);
          }
          const s = res.summary;
          let colorIssues = [];
          let colorStats = { scanned: 0, issuesCount: 0, highCount: 0 };
          if (node && "type" in node) {
            const ca = await audit(node);
            colorIssues = ca.issues;
            colorStats = ca.stats;
          }
          figma.notify(`\uAC80\uC218 \uC644\uB8CC \u2014 \uC790\uB3D9\uAD50\uCCB4 ${s.autoSwapped} \xB7 \uD655\uC778\uD544\uC694 ${s.ambiguous}${s.manualNeeded ? ` \xB7 \uC218\uB3D9\uB9E4\uD551 ${s.manualNeeded}` : ""}${s.moduleNeeded ? ` \xB7 \uBAA8\uB4C8 ${s.moduleNeeded}` : ""} \xB7 \uC0C9\uC0C1 ${colorIssues.length}`);
          figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: true, summary: s, candidates: res.ambiguousCandidates, failed: res.failedCandidates, manual: res.manualCandidates, modules: res.modules, colorIssues, colorStats } });
        }
      } else if (type === "apply-swap") {
        const res = await applySwap(payload.candidate, "lenient");
        if (res.ok && res.rollback) swapRollbackById.set(payload.candidate.id, res.rollback);
        const unpreservedCount = res.unpreserved ? res.unpreserved.length : 0;
        const fittedLabel = res.modeFitted === "Dark" ? "\uB2E4\uD06C" : res.modeFitted === "Light" ? "\uB77C\uC774\uD2B8" : "";
        if (res.ok && fittedLabel) figma.notify(`\uAD50\uCCB4 \uD6C4 ${fittedLabel} \uD654\uBA74\uC5D0 \uB9DE\uCDC4\uC2B5\uB2C8\uB2E4`);
        figma.ui.postMessage({ type: "audit:apply-swap-result", payload: { id: payload.candidate.id, ok: res.ok, result: res.result, reason: res.reason, variantReset: res.variantReset, axisLoss: res.axisLoss, unpreservedCount, modeFitted: fittedLabel } });
      } else if (type === "apply-part-swap") {
        const guidePage = await getReferenceGuidePage();
        const pool = collectPageReference(guidePage || void 0);
        const res = await applyModulePartSwap({
          candidate: payload.candidate,
          moduleInstanceId: payload.moduleInstanceId,
          partPath: payload.partPath || [],
          allowDetach: payload.allowDetach === true,
          pool
        });
        if (res.rollback) swapRollbackById.set(res.detached ? payload.moduleId : payload.candidate.id, res.rollback);
        if (res.detached && res.moduleNodeId) {
          auditSessionRootIds = auditSessionRootIds.map((id) => id === payload.moduleInstanceId ? res.moduleNodeId : id);
        }
        const partFitted = res.modeFitted === "Dark" ? "\uB2E4\uD06C" : res.modeFitted === "Light" ? "\uB77C\uC774\uD2B8" : "";
        if (res.ok && partFitted) figma.notify(`\uAD50\uCCB4 \uD6C4 ${partFitted} \uD654\uBA74\uC5D0 \uB9DE\uCDC4\uC2B5\uB2C8\uB2E4`);
        figma.ui.postMessage({
          type: "audit:apply-part-swap-result",
          payload: {
            id: payload.candidate.id,
            moduleId: payload.moduleId,
            ok: res.ok,
            result: res.result,
            reason: res.reason,
            variantReset: res.variantReset,
            unpreservedCount: res.unpreserved ? res.unpreserved.length : 0,
            detached: res.detached === true,
            moduleNodeId: res.moduleNodeId,
            parts: res.parts
          }
        });
      } else if (type === "detach-module") {
        const guidePage = await getReferenceGuidePage();
        const pool = collectPageReference(guidePage || void 0);
        const res = await detachModule(payload.moduleInstanceId, pool);
        if (res.ok && res.rollback) swapRollbackById.set(payload.moduleId, res.rollback);
        if (res.ok && res.moduleNodeId) {
          auditSessionRootIds = auditSessionRootIds.map((id) => id === payload.moduleInstanceId ? res.moduleNodeId : id);
        }
        figma.ui.postMessage({
          type: "audit:detach-module-result",
          payload: { moduleId: payload.moduleId, ok: res.ok, reason: res.reason, moduleNodeId: res.moduleNodeId, parts: res.parts }
        });
      } else if (type === "variant-options") {
        const info = await getVariantOptions(payload.ref, payload.instanceId, payload.medium || null, payload.decidedAxes || null);
        figma.ui.postMessage({ type: "audit:variant-options-result", payload: __spreadValues({ requestId: payload.requestId }, info) });
      } else if (type === "preview") {
        const bytes = payload.ref ? await exportReferencePreview(payload.ref) : await exportNodePreview(payload.nodeId);
        figma.ui.postMessage({ type: "audit:preview-result", payload: { requestId: payload.requestId, ok: !!bytes, bytes } });
      } else if (type === "import-component") {
        const res = await importComponentCopy(payload.candidate);
        figma.ui.postMessage({ type: "audit:import-component-result", payload: __spreadValues({ id: payload.candidate.id }, res) });
      } else if (type === "undo-swap") {
        const saved = swapRollbackById.get(payload.id);
        if (!saved) {
          figma.ui.postMessage({ type: "audit:undo-swap-result", payload: { id: payload.id, ok: false, reason: "\uB418\uB3CC\uB9B4 \uAE30\uB85D\uC774 \uC5C6\uC2B5\uB2C8\uB2E4." } });
        } else {
          const res = await rollbackSwap(saved);
          if (res.ok) {
            swapRollbackById.delete(payload.id);
            if (res.instanceId) auditSessionRootIds = auditSessionRootIds.map((id) => id === saved.instanceId ? res.instanceId : id);
          }
          figma.ui.postMessage({ type: "audit:undo-swap-result", payload: { id: payload.id, ok: res.ok, reason: res.reason, instanceId: res.instanceId } });
        }
      } else if (type === "apply-swap-multi") {
        const list = payload.candidates;
        const applied = [];
        const failures = [];
        let resetCount = 0;
        let unpreservedTotal = 0;
        let modeFittedCount = 0;
        let modeFittedLabel = "";
        for (const c of list) {
          if (c.confidence !== "high" || c.demoteReason) {
            failures.push({ id: c.id, reason: "\uD655\uC778\uC774 \uD544\uC694\uD55C \uD56D\uBAA9\uC774\uB77C \uC77C\uAD04 \uAD50\uCCB4\uC5D0\uC11C \uC81C\uC678\uD588\uC2B5\uB2C8\uB2E4." });
            continue;
          }
          const r = await applySwap(c, "lenient");
          if (r.ok) {
            applied.push(c.id);
            if (r.rollback) swapRollbackById.set(c.id, r.rollback);
            if (r.variantReset) resetCount++;
            if (r.unpreserved) unpreservedTotal += r.unpreserved.length;
            if (r.modeFitted) {
              modeFittedCount++;
              modeFittedLabel = r.modeFitted === "Dark" ? "\uB2E4\uD06C" : "\uB77C\uC774\uD2B8";
            }
          } else failures.push({ id: c.id, reason: r.reason || "unknown" });
        }
        figma.notify(`${applied.length}\uAC74 \uAD50\uCCB4 \uC644\uB8CC${resetCount ? ` \xB7 ${resetCount}\uAC74 \uC0C1\uD0DC \uB9AC\uC14B` : ""}${modeFittedCount ? ` \xB7 ${modeFittedCount}\uAC74 ${modeFittedLabel} \uD654\uBA74\uC5D0 \uB9DE\uCDA4` : ""}${unpreservedTotal ? ` \xB7 \uD14D\uC2A4\uD2B8 ${unpreservedTotal}\uAC74 \uBCF4\uC874\uC548\uB428` : ""}${failures.length ? ` \xB7 ${failures.length}\uAC74 \uC2E4\uD328` : ""}`);
        figma.ui.postMessage({ type: "audit:apply-swap-multi-result", payload: { applied, fail: failures.length, failures, variantResetCount: resetCount, unpreservedTotal, modeFittedCount, modeFittedLabel } });
      } else if (type === "resize") {
        const w = Math.max(420, Math.min(1400, Math.round(payload.w)));
        const h = Math.max(480, Math.min(1200, Math.round(payload.h)));
        figma.ui.resize(w, h);
      }
    } catch (e) {
      const message = String(e && e.message || e);
      if (type === "selection-state") {
        figma.ui.postMessage({ type: "audit:selection-state-error", payload: { requestId: payload && payload.requestId, message } });
        return;
      }
      if (type === "build-improved") {
        figma.ui.postMessage({ type: "audit:build-improved-result", payload: { ok: false, message } });
      }
      if (type === "inspect-selection") {
        figma.ui.postMessage({ type: "audit:inspection-result", payload: { ok: false, message } });
      }
      figma.ui.postMessage({ type: "audit:error", payload: { message } });
    }
  }
  function auditSelectionSummary(selectionOverride) {
    const selected = selectionOverride ? Array.from(selectionOverride) : Array.from(figma.currentPage.selection);
    const names = selected.slice(0, 2).map((node) => node.name);
    const label = selected.length === 0 ? "\uC120\uD0DD \uC5C6\uC74C" : selected.length === 1 ? names[0] : `${names[0]} \uC678 ${selected.length - 1}\uAC1C`;
    return { count: selected.length, names, label };
  }
  function postAuditSelectionSummary() {
    figma.ui.postMessage({ type: "audit:selection-summary", payload: auditSelectionSummary() });
  }
  async function postAuditSelectionState(requestId) {
    postAuditSelectionSummary();
    const fast = await getAuditInstallState(true);
    await figma.ui.postMessage({
      type: "audit:selection-state",
      payload: __spreadValues(__spreadValues({ requestId }, auditSelectionSummary()), fast)
    });
    if (fast.installed && !guideStateCache) {
      const full = await getAuditInstallState();
      await figma.ui.postMessage({
        type: "audit:selection-state",
        payload: __spreadValues(__spreadValues({ requestId }, auditSelectionSummary()), full)
      });
    }
  }
  async function getStampedGuidePage() {
    if (figma.root.getPluginData(GUIDE_VERSION_KEY) !== CURRENT_GUIDE_FINGERPRINT) return null;
    const pageId = figma.root.getPluginData(GUIDE_PAGE_KEY);
    if (!pageId) return null;
    const node = await figma.getNodeByIdAsync(pageId);
    if (!node || node.type !== "PAGE") return null;
    if (node.getPluginData(GUIDE_VERSION_KEY) !== CURRENT_GUIDE_FINGERPRINT) return null;
    return node;
  }
  var guideStateCache = null;
  function clearGuideStateCache() {
    guideStateCache = null;
  }
  async function getAuditInstallState(fastOnly = false) {
    if (guideStateCache) return guideStateCache;
    const content = await getGuideContentMissing();
    const stamped = await getStampedGuidePage();
    if (fastOnly) {
      return {
        installed: content.blocking.length === 0,
        missing: content.blocking,
        partial: content.partial,
        currentGuide: !!stamped && content.partial.length === 0,
        valueDrift: []
      };
    }
    const valueDrift = content.blocking.length ? [] : await getGuideValueDrift();
    guideStateCache = {
      installed: content.blocking.length === 0,
      missing: content.blocking,
      partial: content.partial,
      currentGuide: !!stamped && valueDrift.length === 0 && content.partial.length === 0,
      valueDrift
    };
    return guideStateCache;
  }
  async function getGuideValueDrift() {
    const drift = [];
    const near = (a, b) => Math.abs(a - b) <= 0.5 / 255;
    const sameColor = (got, want) => {
      if (!got || !want || typeof got !== "object" || typeof want !== "object") return false;
      if (got.type === "VARIABLE_ALIAS" || want.type === "VARIABLE_ALIAS") {
        return got.type === "VARIABLE_ALIAS" && want.type === "VARIABLE_ALIAS" && got.id === want.id;
      }
      const ga = typeof got.a === "number" ? got.a : 1;
      const wa = typeof want.a === "number" ? want.a : 1;
      return near(got.r, want.r) && near(got.g, want.g) && near(got.b, want.b) && Math.abs(ga - wa) <= 0.01;
    };
    const sameNumber = (got, want) => {
      if (got && typeof got === "object") {
        return got.type === "VARIABLE_ALIAS" && !!want && want.type === "VARIABLE_ALIAS" && got.id === want.id;
      }
      return typeof got === "number" && typeof want === "number" && Math.abs(got - want) < 1e-3;
    };
    const modeIdByName = (col, name) => {
      const hit = col.modes.filter((m) => m.name === name)[0];
      return hit ? hit.modeId : null;
    };
    try {
      const cols = await figma.variables.getLocalVariableCollectionsAsync();
      const byName = new Map(cols.map((c) => [c.name, c]));
      const foundation = byName.get(FOUNDATION_COLLECTION);
      const semanticColor = byName.get(SEMANTIC_COLOR_COLLECTION);
      const semanticNumber = byName.get(SEMANTIC_NUMBER_COLLECTION);
      if (!foundation) return drift;
      const fColor = await loadExistingVarMap(FOUNDATION_COLLECTION, "COLOR");
      const fNumber = await loadExistingVarMap(FOUNDATION_COLLECTION, "FLOAT");
      const fDefault = foundation.modes.length ? foundation.modes[0].modeId : null;
      if (fDefault) {
        for (const key of Object.keys(FOUNDATION_COLOR)) {
          const v = fColor[key];
          if (!v) continue;
          if (!sameColor(v.valuesByMode[fDefault], hexToRgb(FOUNDATION_COLOR[key]))) drift.push(key);
        }
        for (const key of Object.keys(FOUNDATION_NUMBER)) {
          const v = fNumber[key];
          if (!v) continue;
          if (!sameNumber(v.valuesByMode[fDefault], FOUNDATION_NUMBER[key])) drift.push(key);
        }
      }
      if (semanticColor) {
        const lightId = modeIdByName(semanticColor, LIGHT_MODE);
        const darkId = modeIdByName(semanticColor, DARK_MODE);
        const sColor = await loadExistingVarMap(SEMANTIC_COLOR_COLLECTION, "COLOR");
        for (const key of Object.keys(SEMANTIC_COLOR)) {
          const v = sColor[key];
          if (!v) continue;
          const entry = SEMANTIC_COLOR[key];
          if (lightId && !sameColor(v.valuesByMode[lightId], resolveColorRef(entry.light, fColor))) {
            drift.push(key);
            continue;
          }
          if (darkId && !sameColor(v.valuesByMode[darkId], resolveColorRef(entry.dark, fColor))) drift.push(key);
        }
      }
      if (semanticNumber) {
        const defaultId = semanticNumber.modes.length ? semanticNumber.modes[0].modeId : null;
        const sNumber = await loadExistingVarMap(SEMANTIC_NUMBER_COLLECTION, "FLOAT");
        if (defaultId) {
          for (const key of Object.keys(SEMANTIC_NUMBER)) {
            const v = sNumber[key];
            if (!v) continue;
            if (!sameNumber(v.valuesByMode[defaultId], resolveNumberRef(SEMANTIC_NUMBER[key], fNumber))) drift.push(key);
          }
        }
      }
    } catch (e) {
      console.warn("[installer] \uAC12 \uB300\uC870 \uC2E4\uD328(\uAC80\uC218\uB294 \uADF8\uB300\uB85C \uC9C4\uD589):", e);
      return [];
    }
    return drift.slice(0, 40);
  }
  async function getGuideContentMissing() {
    const missing = [];
    const collections = await figma.variables.getLocalVariableCollectionsAsync();
    const collectionByName = new Map(collections.map((collection) => [collection.name, collection]));
    const shadowVariableNames = [];
    const raisedLayers = parseCssShadow(SEMANTIC_SHADOW["shadow/raised"].light);
    for (let index = 0; index < raisedLayers.length; index++) {
      for (const field of ["color", "offset-y", "blur", "spread"]) {
        shadowVariableNames.push(shadowVarName("shadow/raised", index, field));
      }
    }
    const expectedVariableNames = /* @__PURE__ */ new Map([
      [FOUNDATION_COLLECTION, [...Object.keys(FOUNDATION_COLOR), ...Object.keys(FOUNDATION_NUMBER)]],
      [SEMANTIC_COLOR_COLLECTION, Object.keys(SEMANTIC_COLOR)],
      [SEMANTIC_NUMBER_COLLECTION, Object.keys(SEMANTIC_NUMBER)],
      [SEMANTIC_SHADOW_COLLECTION, shadowVariableNames]
    ]);
    let incompleteVariables = false;
    let noColorBase = false;
    const missingVarNames = [];
    const namesByCollectionId = /* @__PURE__ */ new Map();
    try {
      const allVars = await figma.variables.getLocalVariablesAsync();
      for (const v of allVars) {
        let set = namesByCollectionId.get(v.variableCollectionId);
        if (!set) {
          set = /* @__PURE__ */ new Set();
          namesByCollectionId.set(v.variableCollectionId, set);
        }
        set.add(v.name);
      }
    } catch (e) {
    }
    for (const [name, expectedNames] of expectedVariableNames) {
      const collection = collectionByName.get(name);
      if (!collection) {
        incompleteVariables = true;
        missingVarNames.push(`${name} \uC804\uCCB4`);
        if (name === FOUNDATION_COLLECTION || name === SEMANTIC_COLOR_COLLECTION) noColorBase = true;
        break;
      }
      const installedNames = namesByCollectionId.get(collection.id) || /* @__PURE__ */ new Set();
      const lack = expectedNames.filter((expectedName) => !installedNames.has(expectedName));
      if (lack.length) {
        incompleteVariables = true;
        for (const one of lack) missingVarNames.push(one);
        break;
      }
      if ((name === SEMANTIC_COLOR_COLLECTION || name === SEMANTIC_SHADOW_COLLECTION) && (!collection.modes.some((mode) => mode.name === LIGHT_MODE) || !collection.modes.some((mode) => mode.name === DARK_MODE))) {
        incompleteVariables = true;
        break;
      }
    }
    const listOf = (names, max) => names.length ? `(${names.slice(0, max).join(" \xB7 ")}${names.length > max ? ` \uC678 ${names.length - max}\uAC1C` : ""})` : "";
    if (incompleteVariables) missing.push(`\uC0C9\xB7\uC218\uCE58 \uAE30\uC900${listOf(missingVarNames, 3)}`);
    const localTextStyleNames = new Set((await figma.getLocalTextStylesAsync()).map((style) => style.name));
    const missingTextStyles = TEXT_STYLES.filter((style) => !localTextStyleNames.has(style.name)).map((style) => style.name);
    if (missingTextStyles.length) missing.push(`\uAE00\uC790 \uC2A4\uD0C0\uC77C${listOf(missingTextStyles, 3)}`);
    const installedComponentNames = /* @__PURE__ */ new Set();
    try {
      const found = figma.root.findAllWithCriteria({ types: ["COMPONENT_SET", "COMPONENT"] });
      for (const node of found) installedComponentNames.add(normalizeAuditName(node.name));
    } catch (e) {
      for (const component of collectComponents(figma.root, figma.root.name)) {
        installedComponentNames.add(normalizeAuditName(component.name));
      }
    }
    const missingComponents = [];
    for (const category of COMPONENT_CATEGORIES) {
      for (const name of category.members) {
        if (!installedComponentNames.has(normalizeAuditName(name))) missingComponents.push(name);
      }
    }
    if (missingComponents.length) missing.push(`\uCEF4\uD3EC\uB10C\uD2B8 ${missingComponents.length}\uAC1C${listOf(missingComponents, 5)}`);
    const noComponents = missingComponents.length >= COMPONENT_CATEGORIES.reduce((sum, c) => sum + c.members.length, 0);
    const blocking = missing.filter(() => false).concat(
      noColorBase ? [`\uC0C9\xB7\uC218\uCE58 \uAE30\uC900${listOf(missingVarNames, 3)}`] : [],
      noComponents ? ["\uC815\uBCF8 \uBD80\uD488(\uC774 \uD30C\uC77C\uC5D0 \uD558\uB098\uB3C4 \uC5C6\uC2B5\uB2C8\uB2E4)"] : []
    );
    return { blocking, partial: missing };
  }
  function normalizeAuditName(name) {
    return (name || "").toLowerCase().replace(/[\s_\-\/]+/g, "");
  }
  figma.on("selectionchange", () => {
    postAuditSelectionSummary();
  });
  figma.on("close", () => {
    void cleanupSwapBackups();
  });
  (async () => {
    const saved = await loadReference();
    if (saved) {
      figma.ui.postMessage({ type: "audit:reference-loaded", payload: { pool: saved.pool, rootNames: saved.rootNames, sourceFileName: saved.sourceFileName, restored: true } });
    }
  })();
  function hexToRgb(hex) {
    const n = parseInt(hex.replace("#", ""), 16);
    return {
      r: (n >> 16 & 255) / 255,
      g: (n >> 8 & 255) / 255,
      b: (n & 255) / 255,
      a: 1
    };
  }
  function rgbaStringToRgb(rgba) {
    const m = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!m) return { r: 0, g: 0, b: 0, a: 1 };
    return {
      r: parseInt(m[1]) / 255,
      g: parseInt(m[2]) / 255,
      b: parseInt(m[3]) / 255,
      a: m[4] !== void 0 ? parseFloat(m[4]) : 1
    };
  }
  function post(type, payload) {
    figma.ui.postMessage(__spreadValues({ type }, payload));
  }
  async function getOrCreateCollection(name) {
    const all = await figma.variables.getLocalVariableCollectionsAsync();
    const existing = all.find((c) => c.name === name);
    if (existing) return existing;
    return figma.variables.createVariableCollection(name);
  }
  async function getOrCreateVariable(name, collection, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const existing = all.find(
      (v) => v.name === name && v.variableCollectionId === collection.id
    );
    if (existing) return existing;
    return figma.variables.createVariable(name, collection, resolvedType);
  }
  async function pruneCollection(collection, validNames, resolvedType) {
    const all = await figma.variables.getLocalVariablesAsync(resolvedType);
    const removed = [];
    for (const v of all) {
      if (v.variableCollectionId !== collection.id) continue;
      if (validNames.has(v.name)) continue;
      removed.push(v.name);
      try {
        v.remove();
      } catch (e) {
      }
    }
    return removed;
  }
  function ensureMode(collection, modeName) {
    const found = collection.modes.find((m) => m.name === modeName);
    if (found) return found.modeId;
    return collection.addMode(modeName);
  }
  function setupLightDarkModes(collection) {
    const first = collection.modes[0];
    if (first.name !== LIGHT_MODE && first.name !== DARK_MODE) {
      collection.renameMode(first.modeId, LIGHT_MODE);
    }
    const lightId = ensureMode(collection, LIGHT_MODE);
    const darkId = ensureMode(collection, DARK_MODE);
    const allowed = /* @__PURE__ */ new Set([lightId, darkId]);
    const extras = collection.modes.filter((m) => !allowed.has(m.modeId));
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return { lightId, darkId };
  }
  function colorScopes(path) {
    if (/^color\/[a-z-]+\/bg\//.test(path)) return ["FRAME_FILL", "SHAPE_FILL"];
    if (/^color\/[a-z-]+\/border\//.test(path)) return ["STROKE_COLOR"];
    if (/^color\/[a-z-]+\/label\//.test(path)) return ["TEXT_FILL"];
    if (/^color\/[a-z-]+\/icon\//.test(path)) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/bg/") || path.startsWith("color/surface/")) {
      return ["FRAME_FILL", "SHAPE_FILL"];
    }
    if (path.startsWith("color/text/")) return ["TEXT_FILL"];
    if (path.startsWith("color/border/")) return ["STROKE_COLOR"];
    if (path.startsWith("color/icon/")) return ["SHAPE_FILL", "STROKE_COLOR"];
    if (path.startsWith("color/action/")) return ["FRAME_FILL", "SHAPE_FILL", "TEXT_FILL"];
    if (path.startsWith("color/status/")) return ["FRAME_FILL", "TEXT_FILL", "STROKE_COLOR"];
    if (path === "color/overlay") return ["FRAME_FILL"];
    return ["ALL_SCOPES"];
  }
  function numberScopes(path) {
    if (path.startsWith("spacing/")) return ["GAP"];
    if (path.startsWith("sizing/")) return ["WIDTH_HEIGHT"];
    if (path.startsWith("radius/")) return ["CORNER_RADIUS"];
    if (path.startsWith("border-width/")) return ["STROKE_FLOAT"];
    if (path.startsWith("font-size/")) return ["FONT_SIZE"];
    if (path.startsWith("font-weight/")) return ["FONT_WEIGHT"];
    if (path.startsWith("line-height/")) return ["LINE_HEIGHT"];
    return ["ALL_SCOPES"];
  }
  function resolveColorRef(ref, foundationColorMap) {
    if (ref.startsWith("rgba")) return rgbaStringToRgb(ref);
    if (ref.startsWith("#")) return hexToRgb(ref);
    const target = foundationColorMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation color alias not found: ${ref}`);
      return { r: 1, g: 0, b: 1, a: 1 };
    }
    return figma.variables.createVariableAlias(target);
  }
  function resolveNumberRef(ref, foundationNumberMap) {
    if (typeof ref === "number") return ref;
    const target = foundationNumberMap[ref];
    if (!target) {
      console.warn(`[SW Installer] Foundation number alias not found: ${ref}`);
      return 0;
    }
    return figma.variables.createVariableAlias(target);
  }
  function setupSingleMode(collection, modeName) {
    const first = collection.modes[0];
    if (first.name !== modeName) {
      collection.renameMode(first.modeId, modeName);
    }
    const extras = collection.modes.filter((m) => m.modeId !== first.modeId);
    for (const m of extras) {
      try {
        collection.removeMode(m.modeId);
      } catch (e) {
      }
    }
    return first.modeId;
  }
  async function loadExistingVarMap(collectionName, resolvedType) {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const col = cols.find((c) => c.name === collectionName);
    const map = {};
    if (!col) return map;
    const vars = await figma.variables.getLocalVariablesAsync(resolvedType);
    for (const v of vars) {
      if (v.variableCollectionId === col.id) map[v.name] = v;
    }
    return map;
  }
  async function installFoundation() {
    post("progress", { step: "Foundation collection \uC900\uBE44 \uC911\u2026", pct: 3 });
    const fc = await getOrCreateCollection(FOUNDATION_COLLECTION);
    const fDefaultId = setupSingleMode(fc, "Default");
    const colorMap = {};
    const fcColorKeys = Object.keys(FOUNDATION_COLOR);
    for (let i = 0; i < fcColorKeys.length; i++) {
      const path = fcColorKeys[i];
      const v = await getOrCreateVariable(path, fc, "COLOR");
      v.setValueForMode(fDefaultId, hexToRgb(FOUNDATION_COLOR[path]));
      v.scopes = colorScopes(path);
      colorMap[path] = v;
      if (i % 20 === 0) {
        post("progress", { step: `Foundation Color: ${path}`, pct: 3 + Math.round(i / fcColorKeys.length * 22) });
      }
    }
    const removedColor = await pruneCollection(fc, new Set(fcColorKeys), "COLOR");
    post("progress", { step: "Foundation Number \uC900\uBE44 \uC911\u2026", pct: 28 });
    const numberMap = {};
    const fcNumberKeys = Object.keys(FOUNDATION_NUMBER);
    for (let i = 0; i < fcNumberKeys.length; i++) {
      const path = fcNumberKeys[i];
      const v = await getOrCreateVariable(path, fc, "FLOAT");
      v.setValueForMode(fDefaultId, FOUNDATION_NUMBER[path]);
      v.scopes = numberScopes(path);
      numberMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Foundation Number: ${path}`, pct: 28 + Math.round(i / fcNumberKeys.length * 15) });
      }
    }
    const removedNumber = await pruneCollection(fc, new Set(fcNumberKeys), "FLOAT");
    return {
      colorMap,
      numberMap,
      removed: [...removedColor, ...removedNumber],
      count: fcColorKeys.length + fcNumberKeys.length
    };
  }
  async function installSemantic(foundationColorMap, foundationNumberMap) {
    post("progress", { step: "Semantic Color collection \uC900\uBE44 \uC911\u2026", pct: 50 });
    const scc = await getOrCreateCollection(SEMANTIC_COLOR_COLLECTION);
    const { lightId: sLightId, darkId: sDarkId } = setupLightDarkModes(scc);
    const scColorKeys = Object.keys(SEMANTIC_COLOR);
    const semanticColorMap = {};
    for (let i = 0; i < scColorKeys.length; i++) {
      const path = scColorKeys[i];
      const entry = SEMANTIC_COLOR[path];
      const v = await getOrCreateVariable(path, scc, "COLOR");
      v.setValueForMode(sLightId, resolveColorRef(entry.light, foundationColorMap));
      v.setValueForMode(sDarkId, resolveColorRef(entry.dark, foundationColorMap));
      v.scopes = colorScopes(path);
      semanticColorMap[path] = v;
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Color: ${path}`, pct: 50 + Math.round(i / scColorKeys.length * 22) });
      }
    }
    const removedSemanticColor = await pruneCollection(scc, new Set(scColorKeys), "COLOR");
    post("progress", { step: "Semantic Number collection \uC900\uBE44 \uC911\u2026", pct: 73 });
    const scn = await getOrCreateCollection(SEMANTIC_NUMBER_COLLECTION);
    const scnDefaultId = setupSingleMode(scn, "Default");
    const scNumberKeys = Object.keys(SEMANTIC_NUMBER);
    for (let i = 0; i < scNumberKeys.length; i++) {
      const path = scNumberKeys[i];
      const v = await getOrCreateVariable(path, scn, "FLOAT");
      v.setValueForMode(scnDefaultId, resolveNumberRef(SEMANTIC_NUMBER[path], foundationNumberMap));
      v.scopes = numberScopes(path);
      if (i % 10 === 0) {
        post("progress", { step: `Semantic Number: ${path}`, pct: 73 + Math.round(i / scNumberKeys.length * 13) });
      }
    }
    const removedSemanticNumber = await pruneCollection(scn, new Set(scNumberKeys), "FLOAT");
    return {
      semanticColorMap,
      scc,
      lightModeId: sLightId,
      darkModeId: sDarkId,
      lightModeNamed: true,
      removed: [...removedSemanticColor, ...removedSemanticNumber],
      count: scColorKeys.length + scNumberKeys.length
    };
  }
  var SHADOW_TOKENS_WITH_VARS = ["shadow/raised"];
  async function installShadow() {
    post("progress", { step: "Semantic Shadow collection \uC900\uBE44 \uC911\u2026", pct: 86 });
    const col = await getOrCreateCollection(SEMANTIC_SHADOW_COLLECTION);
    const { lightId, darkId } = setupLightDarkModes(col);
    const map = {};
    const validColor = /* @__PURE__ */ new Set();
    const validFloat = /* @__PURE__ */ new Set();
    for (const token of SHADOW_TOKENS_WITH_VARS) {
      const entry = SEMANTIC_SHADOW[token];
      if (!entry) throw new Error(`[installShadow] SEMANTIC_SHADOW \uC5D0 '${token}' \uC774 \uC5C6\uC2B5\uB2C8\uB2E4.`);
      const light = parseCssShadow(entry.light);
      const dark = parseCssShadow(entry.dark);
      if (light.length !== dark.length) {
        throw new Error(
          `[installShadow] '${token}' \uC758 \uB77C\uC774\uD2B8(${light.length}\uACB9)\uC640 \uB2E4\uD06C(${dark.length}\uACB9) \uACB9 \uC218\uAC00 \uB2E4\uB985\uB2C8\uB2E4. Figma \uB294 \uACB9 \uC218\uB97C \uBAA8\uB4DC\uB85C \uBC14\uAFC0 \uC218 \uC5C6\uC73C\uBBC0\uB85C \uC591\uCABD\uC744 \uAC19\uAC8C \uB9DE\uCDB0\uC57C \uD569\uB2C8\uB2E4.`
        );
      }
      for (let i = 0; i < light.length; i++) {
        const colorName = shadowVarName(token, i, "color");
        const cv = await getOrCreateVariable(colorName, col, "COLOR");
        cv.setValueForMode(lightId, light[i].color);
        cv.setValueForMode(darkId, dark[i].color);
        cv.scopes = ["EFFECT_COLOR"];
        map[colorName] = cv;
        validColor.add(colorName);
        const floatFields = [
          ["offset-y", "offsetY"],
          ["blur", "blur"],
          ["spread", "spread"]
        ];
        for (const [suffix, key] of floatFields) {
          const name = shadowVarName(token, i, suffix);
          const fv = await getOrCreateVariable(name, col, "FLOAT");
          fv.setValueForMode(lightId, light[i][key]);
          fv.setValueForMode(darkId, dark[i][key]);
          fv.scopes = ["EFFECT_FLOAT"];
          map[name] = fv;
          validFloat.add(name);
        }
      }
    }
    const removedColor = await pruneCollection(col, validColor, "COLOR");
    const removedFloat = await pruneCollection(col, validFloat, "FLOAT");
    return {
      shadowVarMap: map,
      removed: [...removedColor, ...removedFloat],
      count: Object.keys(map).length
    };
  }
  async function loadExistingSemantic() {
    const cols = await figma.variables.getLocalVariableCollectionsAsync();
    const scc = cols.find((c) => c.name === SEMANTIC_COLOR_COLLECTION);
    if (!scc) return null;
    const light = scc.modes.find((m) => m.name === LIGHT_MODE);
    const dark = scc.modes.find((m) => m.name === DARK_MODE);
    const lightModeId = light ? light.modeId : scc.modes[0].modeId;
    const lightModeNamed = !!light;
    const darkModeId = dark ? dark.modeId : lightModeId;
    const semanticColorMap = await loadExistingVarMap(SEMANTIC_COLOR_COLLECTION, "COLOR");
    return { semanticColorMap, scc, lightModeId, darkModeId, lightModeNamed };
  }
  async function runInstall(sel, options = {}) {
    CANCEL_INSTALL = false;
    try {
      if (!sel.foundation && !sel.semantic && !sel.textStyles && !sel.components) {
        throw new Error("\uC124\uCE58\uD560 \uD56D\uBAA9\uC744 \uD558\uB098 \uC774\uC0C1 \uC120\uD0DD\uD558\uC138\uC694.");
      }
      post("progress", { step: "\uC900\uBE44 \uC911\u2026", pct: 2 });
      const removedAll = [];
      let foundationCount = 0;
      let semanticCount = 0;
      let textStyleCount = 0;
      let componentCount = 0;
      let componentAdded = [];
      let componentSkipped = [];
      let componentFailed = [];
      let componentNoRunner = [];
      let componentDegraded = [];
      let componentRawPaints = [];
      let foundationColorMap = {};
      let foundationNumberMap = {};
      if (sel.foundation) {
        const r = await installFoundation();
        foundationColorMap = r.colorMap;
        foundationNumberMap = r.numberMap;
        foundationCount = r.count;
        removedAll.push(...r.removed);
      } else {
        foundationColorMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "COLOR");
        foundationNumberMap = await loadExistingVarMap(FOUNDATION_COLLECTION, "FLOAT");
      }
      throwIfCancelled();
      let semanticColorMap = {};
      let scc = null;
      let lightModeId = "";
      let darkModeId = "";
      let lightModeNamed = true;
      if (sel.semantic) {
        if (Object.keys(foundationColorMap).length === 0) {
          throw new Error("Semantic \uC124\uCE58\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        const r = await installSemantic(foundationColorMap, foundationNumberMap);
        semanticColorMap = r.semanticColorMap;
        scc = r.scc;
        lightModeId = r.lightModeId;
        darkModeId = r.darkModeId;
        lightModeNamed = r.lightModeNamed;
        semanticCount = r.count;
        removedAll.push(...r.removed);
      } else {
        const loaded = await loadExistingSemantic();
        if (loaded) {
          semanticColorMap = loaded.semanticColorMap;
          scc = loaded.scc;
          lightModeId = loaded.lightModeId;
          darkModeId = loaded.darkModeId;
          lightModeNamed = loaded.lightModeNamed;
        }
      }
      throwIfCancelled();
      let shadowVarMap = {};
      let shadowCollectionId = "";
      let shadowLightModeId = "";
      let shadowDarkModeId = "";
      if (sel.semantic || sel.components) {
        if (sel.semantic) {
          const r = await installShadow();
          shadowVarMap = r.shadowVarMap;
          semanticCount += r.count;
          removedAll.push(...r.removed);
        } else {
          const sColor = await loadExistingVarMap(SEMANTIC_SHADOW_COLLECTION, "COLOR");
          const sFloat = await loadExistingVarMap(SEMANTIC_SHADOW_COLLECTION, "FLOAT");
          shadowVarMap = __spreadValues(__spreadValues({}, sColor), sFloat);
        }
        const shadowCol = (await figma.variables.getLocalVariableCollectionsAsync()).find((c) => c.name === SEMANTIC_SHADOW_COLLECTION);
        if (shadowCol) {
          shadowCollectionId = shadowCol.id;
          const l = shadowCol.modes.find((m) => m.name === LIGHT_MODE);
          const d = shadowCol.modes.find((m) => m.name === DARK_MODE);
          shadowLightModeId = l ? l.modeId : shadowCol.modes[0].modeId;
          shadowDarkModeId = d ? d.modeId : shadowLightModeId;
        }
      }
      throwIfCancelled();
      let textStyleMap = {};
      if (sel.textStyles || sel.components) {
        post("progress", { step: "Text Styles \uC124\uCE58 \uC911\u2026", pct: 88 });
        textStyleMap = await installTextStyles((step, pct) => post("progress", { step, pct }), 88, 94);
        textStyleCount = Object.keys(textStyleMap).length;
      } else {
        try {
          const local = await figma.getLocalTextStylesAsync();
          for (const st of local) textStyleMap[st.name] = st;
        } catch (e) {
        }
      }
      throwIfCancelled();
      if (sel.components) {
        if (!scc || !lightModeId) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Semantic Color V2 \uAC00 \uD544\uC694\uD569\uB2C8\uB2E4. Semantic \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        if (Object.keys(foundationNumberMap).length === 0) {
          throw new Error("\uCEF4\uD3EC\uB10C\uD2B8 \uC138\uD2B8 \uC0DD\uC131\uC5D0\uB294 Foundation \uC774 \uD544\uC694\uD569\uB2C8\uB2E4. Foundation \uB3C4 \uD568\uAED8 \uC120\uD0DD\uD558\uAC70\uB098 \uBA3C\uC800 \uC124\uCE58\uD558\uC138\uC694.");
        }
        post("progress", { step: "\uCEF4\uD3EC\uB10C\uD2B8 \uC0DD\uC131 \uC911\u2026", pct: 92 });
        const compResult = await buildAllComponents(
          {
            semanticColor: semanticColorMap,
            foundationColor: foundationColorMap,
            foundationNumber: foundationNumberMap,
            textStyles: textStyleMap,
            semanticColorCollectionId: scc.id,
            semanticLightModeId: lightModeId,
            semanticLightModeNamed: lightModeNamed,
            semanticDarkModeId: darkModeId,
            shadowVars: shadowVarMap,
            semanticShadowCollectionId: shadowCollectionId || void 0,
            semanticShadowLightModeId: shadowLightModeId || void 0,
            semanticShadowDarkModeId: shadowDarkModeId || void 0
          },
          (step, pct) => post("progress", { step, pct }),
          () => CANCEL_INSTALL
        );
        componentCount = compResult.created;
        componentAdded = compResult.added;
        componentSkipped = compResult.skipped;
        componentFailed = compResult.failed;
        componentNoRunner = compResult.noRunner;
        componentDegraded = compResult.degraded;
        componentRawPaints = compResult.rawPaints;
      }
      throwIfCancelled();
      let sheetSections = [];
      let sheetSwatches = 0;
      let sheetStyles = 0;
      let sheetNumbers = 0;
      let sheetSkipped = [];
      let sheetError = "";
      try {
        const semanticNumberMap = await loadExistingVarMap(SEMANTIC_NUMBER_COLLECTION, "FLOAT");
        const sheet = await buildTokenSheets(
          {
            semanticColor: semanticColorMap,
            foundationColor: foundationColorMap,
            foundationNumber: foundationNumberMap,
            semanticNumber: semanticNumberMap,
            textStyles: textStyleMap,
            semanticColorCollectionId: scc ? scc.id : "",
            semanticLightModeId: lightModeId,
            semanticLightModeNamed: lightModeNamed,
            semanticDarkModeId: darkModeId,
            shadowVars: shadowVarMap,
            semanticShadowCollectionId: shadowCollectionId || void 0,
            semanticShadowLightModeId: shadowLightModeId || void 0,
            semanticShadowDarkModeId: shadowDarkModeId || void 0
          },
          (step, pct) => post("progress", { step, pct })
        );
        sheetSections = sheet.sections;
        sheetSwatches = sheet.swatches;
        sheetStyles = sheet.styles;
        sheetNumbers = sheet.numbers;
        sheetSkipped = sheet.skipped;
      } catch (e) {
        const reason = e instanceof Error ? e.message : String(e);
        if (reason === CANCELLED) throw e;
        console.error("[installer] \uD1A0\uD070 \uACAC\uBCF8 \uC2DC\uD2B8 \uC0DD\uC131 \uC2E4\uD328:", reason);
        sheetError = reason;
      }
      const componentProblems = componentFailed.length + componentNoRunner.length + componentDegraded.length;
      if (options.updateFlow && componentProblems > 0) {
        throw new Error(`\uCD5C\uC2E0 \uAC00\uC774\uB4DC \uCEF4\uD3EC\uB10C\uD2B8 \uC124\uCE58\uAC00 \uC644\uB8CC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4: ${componentProblems}\uAC1C \uC2E4\uD328 \uB610\uB294 \uB204\uB77D`);
      }
      if (options.stampCompleteGuide && componentProblems === 0) {
        const contentMissing = (await getGuideContentMissing()).partial;
        if (contentMissing.length && options.updateFlow) {
          throw new Error(`\uCD5C\uC2E0 \uAC00\uC774\uB4DC \uC124\uCE58\uAC00 \uC644\uB8CC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4: ${contentMissing.join(" \xB7 ")}`);
        }
        if (contentMissing.length === 0) {
          figma.currentPage.setPluginData(GUIDE_VERSION_KEY, CURRENT_GUIDE_FINGERPRINT);
          figma.root.setPluginData(GUIDE_VERSION_KEY, CURRENT_GUIDE_FINGERPRINT);
          figma.root.setPluginData(GUIDE_PAGE_KEY, figma.currentPage.id);
        }
      }
      fitInstalledIntoView();
      clearGuideStateCache();
      post("progress", { step: "\uC644\uB8CC", pct: 100 });
      post("done", {
        foundationCount,
        semanticCount,
        textStyleCount,
        componentCount,
        componentAdded,
        componentSkipped,
        componentFailed,
        componentNoRunner,
        componentDegraded,
        componentRawPaints,
        sheetSections,
        sheetSwatches,
        sheetStyles,
        sheetNumbers,
        sheetSkipped,
        sheetError,
        removedCount: removedAll.length,
        removedNames: removedAll,
        guideUpdated: options.updateFlow === true
      });
      return "ok";
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === CANCELLED) {
        post("cancelled", { newPage: options.updateFlow === true });
        return "cancelled";
      }
      post("error", { message: msg });
      return "error";
    }
  }
  function fitInstalledIntoView() {
    try {
      const kids = figma.currentPage.children;
      if (!Array.isArray(kids) || kids.length === 0) return;
      figma.viewport.scrollAndZoomIntoView(kids);
    } catch (e) {
      console.warn("[installer] \uC124\uCE58 \uD6C4 \uD654\uBA74 \uB9DE\uCD94\uAE30 \uC2E4\uD328(\uC124\uCE58 \uC790\uCCB4\uB294 \uC815\uC0C1):", e);
    }
  }
  function uniqueGuidePageName() {
    const used = new Set(figma.root.children.map((page) => page.name));
    if (!used.has(GUIDE_PAGE_NAME)) return GUIDE_PAGE_NAME;
    let index = 2;
    while (used.has(`${GUIDE_PAGE_NAME} ${index}`)) index++;
    return `${GUIDE_PAGE_NAME} ${index}`;
  }
  async function autoSwapPatternScreens() {
    const out = { applied: 0, skipped: 0 };
    try {
      const page = figma.root.children.find((p) => p.name === PATTERN_PAGE_NAME);
      if (!page) return out;
      await page.loadAsync();
      const roots = Array.from(page.children);
      if (!roots.length) return out;
      const guidePage = await getReferenceGuidePage();
      const pool = collectPageReference(guidePage || void 0);
      const scan = await scanSwapCandidates(pool, roots);
      for (const c of scan.candidates) {
        if (c.confidence !== "high" || c.demoteReason) {
          out.skipped++;
          continue;
        }
        const r = await applySwap(c, "lenient");
        if (r.ok) {
          out.applied++;
          if (r.rollback) swapRollbackById.set(c.id, r.rollback);
        } else {
          out.skipped++;
        }
      }
      out.skipped += scan.manualCandidates.length + scan.modules.length;
    } catch (e) {
      console.warn("[installer] \uD328\uD134 \uD654\uBA74 \uC790\uB3D9 \uAD50\uCCB4 \uC2E4\uD328(\uC124\uCE58 \uC790\uCCB4\uB294 \uC815\uC0C1):", e);
    }
    return out;
  }
  async function getInstalledGuidePage() {
    const pageId = figma.root.getPluginData(GUIDE_PAGE_KEY);
    if (pageId) {
      try {
        const node = await figma.getNodeByIdAsync(pageId);
        if (node && node.type === "PAGE") return node;
      } catch (e) {
      }
    }
    try {
      for (const page of figma.root.children) {
        if (page.name === GUIDE_PAGE_NAME) return page;
      }
      for (const page of figma.root.children) {
        if (page.name.indexOf(GUIDE_PAGE_NAME) === 0) return page;
      }
    } catch (e) {
    }
    return null;
  }
  async function getReferenceGuidePage() {
    const stamped = await getStampedGuidePage();
    if (stamped) return stamped;
    return await getInstalledGuidePage();
  }
  async function installLatestGuideOnNewPage() {
    const previousPage = figma.currentPage;
    const existingGuide = await getInstalledGuidePage();
    const page = existingGuide || figma.createPage();
    const createdPage = !existingGuide;
    if (createdPage) page.name = uniqueGuidePageName();
    await page.loadAsync();
    figma.currentPage = page;
    const result = await runInstall(
      { foundation: true, semantic: true, textStyles: true, components: true },
      { stampCompleteGuide: true, updateFlow: true }
    );
    if (result !== "ok") {
      try {
        figma.currentPage = previousPage;
      } catch (e) {
      }
      if (createdPage) {
        try {
          page.remove();
        } catch (e) {
        }
      }
      figma.ui.postMessage({
        type: result === "cancelled" ? "audit:guide-update-cancelled" : "audit:guide-update-failed",
        payload: {}
      });
      return;
    }
    const swapped = await autoSwapPatternScreens();
    figma.ui.postMessage({
      type: "audit:guide-update-done",
      payload: {
        pageName: page.name,
        swappedCount: swapped.applied,
        swapSkipped: swapped.skipped,
        reusedPage: !createdPage
      }
    });
  }
  var PATTERN_PAGE_NAME = "S-1 S/W UX Pattern";
  async function collectComponentSets(names) {
    const want = new Set(names);
    const found = {};
    const scan = async (page) => {
      await page.loadAsync();
      for (const node of page.findAllWithCriteria({ types: ["COMPONENT_SET"] })) {
        if (want.has(node.name) && !found[node.name]) found[node.name] = node;
      }
    };
    const stamped = await getReferenceGuidePage();
    if (stamped) await scan(stamped);
    for (const page of figma.root.children) {
      if (Object.keys(found).length === want.size) break;
      if (stamped && page.id === stamped.id) continue;
      await scan(page);
    }
    return found;
  }
  async function postPatternList() {
    const needed = /* @__PURE__ */ new Set();
    for (const p of PATTERNS) for (const r of p.requires) needed.add(r);
    const sets = await collectComponentSets(Array.from(needed));
    const items = PATTERNS.map((p) => {
      const missing = p.requires.filter((r) => !sets[r]);
      return {
        id: p.id,
        label: p.label,
        desc: p.desc,
        screenCount: p.screens.length,
        section: p.section,
        ready: missing.length === 0,
        missing
      };
    });
    post("pattern:list", { payload: { items, pageName: PATTERN_PAGE_NAME } });
  }
  async function getOrCreatePatternPage() {
    const existing = figma.root.children.find((p) => p.name === PATTERN_PAGE_NAME);
    if (existing) {
      await existing.loadAsync();
      return existing;
    }
    const page = figma.createPage();
    page.name = PATTERN_PAGE_NAME;
    await page.loadAsync();
    return page;
  }
  async function runPatternBuild(ids) {
    const chosen = PATTERNS.filter((p) => ids.indexOf(p.id) >= 0);
    if (chosen.length === 0) {
      post("pattern:error", { payload: { message: "\uB9CC\uB4E4 \uD328\uD134\uC744 \uD558\uB098 \uC774\uC0C1 \uC120\uD0DD\uD574 \uC8FC\uC138\uC694." } });
      return;
    }
    try {
      post("pattern:progress", { payload: { step: "\uD544\uC694\uD55C \uBD80\uD488\uC744 \uD655\uC778\uD558\uB294 \uC911\u2026", pct: 4 } });
      const needed = /* @__PURE__ */ new Set();
      for (const p of chosen) for (const r of p.requires) needed.add(r);
      const sets = await collectComponentSets(Array.from(needed));
      const [foundationColor, semanticColor] = await Promise.all([
        loadExistingVarMap(FOUNDATION_COLLECTION, "COLOR"),
        loadExistingVarMap(SEMANTIC_COLOR_COLLECTION, "COLOR")
      ]);
      const textStyleList = await figma.getLocalTextStylesAsync();
      const textStyles = {};
      for (const s of textStyleList) textStyles[s.name] = s;
      const maps = {
        // Semantic 을 나중에 펼쳐 같은 이름이면 Semantic 이 이긴다(색은 Semantic 경유가 원칙).
        colorVars: __spreadValues(__spreadValues({}, foundationColor), semanticColor),
        textStyles,
        sets
      };
      const page = await getOrCreatePatternPage();
      await figma.setCurrentPageAsync(page);
      try {
        const bgVar = maps.colorVars["color/bg/level-2"];
        if (bgVar) {
          const base = { type: "SOLID", color: { r: 0, g: 0, b: 0 } };
          page.backgrounds = [figma.variables.setBoundVariableForPaint(base, "color", bgVar)];
        }
      } catch (e) {
      }
      const results = [];
      const warnings = [];
      let unitBase = 8;
      const unitSpan = 88 / chosen.length;
      for (const def of chosen) {
        const built = await buildPattern(def, page, maps, (done, total, label) => {
          const pct = Math.round(unitBase + unitSpan * done / Math.max(total, 1));
          post("pattern:progress", {
            payload: { step: label ? `${def.label} \u2014 ${label}` : `${def.label} \uC815\uB9AC \uC911\u2026`, pct }
          });
        });
        results.push({ label: def.label, screens: built.screenCount, sectionId: built.sectionId });
        warnings.push(...built.warnings.map((w) => `${def.label}: ${w}`));
        unitBase += unitSpan;
      }
      const first = await figma.getNodeByIdAsync(results[0].sectionId);
      if (first && first.type === "SECTION") {
        figma.currentPage.selection = [first];
        figma.viewport.scrollAndZoomIntoView([first]);
      }
      post("pattern:done", { payload: { pageName: page.name, results, warnings } });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      post("pattern:error", { payload: { message } });
    }
  }
  async function handlePatternMessage(type, payload) {
    if (type === "list") {
      await postPatternList();
    } else if (type === "build") {
      await runPatternBuild(payload && payload.ids || []);
    }
  }
  async function removeInstalledComponents() {
    try {
      const page = figma.currentPage;
      const total = COMPONENT_CATEGORIES.length;
      let removedSections = 0;
      for (let i = 0; i < total; i++) {
        const cat = COMPONENT_CATEGORIES[i];
        post("progress", { step: `${cat.name} \uC0AD\uC81C \uC911\u2026`, pct: Math.round((i + 1) / (total + 1) * 100) });
        await new Promise((r) => setTimeout(r, 0));
        let found = [];
        try {
          const r = page.findAll((n) => n.type === "SECTION" && n.name === cat.name);
          if (Array.isArray(r)) found = r;
        } catch (e) {
        }
        for (const n of found) {
          try {
            n.remove();
            removedSections++;
          } catch (e) {
          }
        }
      }
      post("progress", { step: "\uB0A8\uC740 \uB178\uB4DC \uC815\uB9AC \uC911\u2026", pct: 100 });
      await new Promise((r) => setTimeout(r, 0));
      const names = /* @__PURE__ */ new Set();
      for (const cat of COMPONENT_CATEGORIES) {
        for (const m of cat.members) {
          names.add(m);
          names.add(`${m} \u2014 Spec Light`);
          names.add(`${m} \u2014 Spec Dark`);
        }
      }
      let removedTopLevel = 0;
      let topNodes = [];
      try {
        if (Array.isArray(page.children)) topNodes = page.children.slice();
      } catch (e) {
      }
      for (const n of topNodes) {
        if (!names.has(n.name)) continue;
        try {
          n.remove();
          removedTopLevel++;
        } catch (e) {
        }
      }
      post("clean-done", { removedSections, removedTopLevel });
      if (removedSections + removedTopLevel > 0) {
        figma.notify(`\uAE30\uC874 \uCEF4\uD3EC\uB10C\uD2B8\uB97C \uC0AD\uC81C\uD588\uC2B5\uB2C8\uB2E4(\uC139\uC158 ${removedSections}\uAC1C) \u2014 [\uC120\uD0DD \uD56D\uBAA9 \uC124\uCE58]\uB85C \uB2E4\uC2DC \uC124\uCE58\uD558\uC138\uC694.`);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      post("error", { message: `\uC7AC\uC124\uCE58 \uC900\uBE44(\uC0AD\uC81C) \uC911 \uC624\uB958: ${msg}` });
    }
  }
})();
