# S1 UI 라이브러리 — React Native (Expo) 묶음

> 자동 생성물입니다. 이 폴더의 파일을 손으로 고치지 마세요 — 다음 배포 때 사라집니다.
> **React Native (Expo) 에 필요한 것만 담은 묶음입니다.** 다른 툴 것까지 필요하면 전체 묶음(`s1-ui-dev-package.zip`)을 받으세요.

- 버전: **0.21.0**
- 정본 지문: `3e26c0547b60cfb2fc29649fe95b8cc4ef8ca58f55c652f2054ecf68713f6f51`
- 승인 컴포넌트: **32종** (input, button, checkbox, radio, toggle, chip, dropdown, select, filter-chip, tab, pagination, textarea, multi-toggle, modal, table, mobile-bottom-nav, mobile-header, time-picker, date-picker, gnb, gnb-sub-menu-item, gnb-sub-menu, assist-button, text-button, modal-content, bottom-sheet-option, bottom-sheet, list-row, expandable-card, data-tag, divider, lnb)
- 토큰: **499개**

## 이 묶음에 들어있는 것

컴포넌트 32종 전부 · 이름 붙은 텍스트 스타일 21종(S1Type) · 아이콘 26개(S1Icons) · 사용 설명서(README.md) · 타입 정의(index.d.ts) · 바로 여는 Expo 예제 앱(platform/react-native-sample) · 조합을 한 화면에 늘어놓는 갤러리(S1Gallery) · RN 에 못 옮긴 CSS 목록(coverage.json).

## 시작하기

1. 압축을 풀면 나오는 `s1-ui` 폴더에서 `platform/react-native` 폴더를 프로젝트에 넣습니다(예: `src/s1-ui`). `react-native-svg` 를 설치합니다(`npx expo install react-native-svg`).
2. **`platform/react-native-sample` 을 `npm install` · `npx expo start` 로 열면 승인된 조합이 한 화면에 보입니다** — PC·Mobile 모두 담겨 있습니다.
3. 앱 맨 위를 `S1Provider` 로 감쌉니다 — 다크 모드와 서체(Pretendard)가 여기서 정해집니다.
4. 부품은 이름으로 부릅니다 — `S1Button` 처럼 `S1` 로 시작하고, 화면은 `breakName="pc" | "mobile"` 로 고릅니다.
5. 쓰는 법과 RN 에서 원리상 다른 점은 `platform/react-native/README.md` 에 있습니다.

## 내 배포본이 최신인지 확인

디자인가이드 다운로드 화면의 지문과 위 정본 지문이 같아야 최신입니다.
