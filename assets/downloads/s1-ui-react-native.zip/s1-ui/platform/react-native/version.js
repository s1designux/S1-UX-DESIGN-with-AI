/* 자동 생성물 — 손으로 고치지 마세요. 정본을 고치고 `npm run tokens:reconcile` 또는 `npm run ui:build` 를 실행하세요. */
export const S1_VERSION = "0.27.0";
export const S1_RELEASED_AT = "2026-10-21";
export const S1_CANONICAL_FINGERPRINT = "c3fb428a5ffa425a7f95b8fcf50050c830ae5e130edfe7cfdad8ae820dfe46c4";
