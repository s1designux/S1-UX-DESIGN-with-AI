/* 자동 생성물 — 손으로 고치지 마세요. 정본을 고치고 `npm run tokens:reconcile` 또는 `npm run ui:build` 를 실행하세요. */
/* S1Footer — 승인된 배포본 마크업을 그대로 옮긴 React Native 부품.
   마크업을 새로 쓰지 않는다. dist/examples/footer*.html 의 승인 인스턴스에서 옮긴 것이다.
   치수·색은 이 파일에 없다 — specs/footer.js 의 표(배포본 CSS 를 캐스케이드까지 계산한 결과)에서 온다. */
import { useId, useState } from "react";
import { El, N, Root, useSvgColor, attrProps, nestedFrom, propsOf } from "../engine.js";
import { scopeOf, slot } from "../runtime.js";
import SPEC from "../specs/footer.js";
import Svg, { Path } from "react-native-svg";

export const BREAKS = ["pc"];
export const DEFAULT_BREAK = "pc";
export const VARIANTS = ["pc","mobile"];
export const SIZES = [];
export const MODES = [];
export const PARTS = ["content","links","link","company","copyright","logo"];

function assertAllowed(label, value, allowed) {
  if (value === undefined || allowed.length === 0 || allowed.includes(value)) return;
  throw new Error(`[s1-ui] footer: 승인되지 않은 ${label} "${value}". 쓸 수 있는 값: ${allowed.join(", ")}`);
}

/* 같은 화면·모드에 구조가 다른 템플릿이 여럿이면, 루트 속성이 가장 많이 맞는 것을 고른다(안 준 속성은 따지지 않는다). */
function pickGroup(current, groups) {
  let best = groups[0];
  let bestScore = -1;
  for (const group of groups) {
    let score = 0;
    let ok = true;
    for (const [name, values] of Object.entries(group.values)) {
      const value = current?.[name];
      if (value === undefined || values.length === 0) continue;
      if (values.includes(String(value))) score += 1; else ok = false;
    }
    if (ok && score > bestScore) { best = group; bestScore = score; }
  }
  return best.index;
}

function pickTemplate(breakName, mode, current) {
  if (breakName === "pc") {
    return pickGroup(current, [{"index":0,"values":{"data-platform":["pc"]}},{"index":1,"values":{"data-platform":["mobile"]}}]);
  }
  return 0;
}

export default function S1Footer({ variant, parts, partProps, style, outer, omit, lifted: initialLifted, forceState, ...rest }) {
  const uid = useId();
  const partScope = scopeOf(parts);
  assertAllowed("variant", variant, VARIANTS);
  const tpl = pickTemplate(DEFAULT_BREAK, undefined, { "data-platform": variant });
  const svgColor = useSvgColor();
  const controller = undefined;
  const lifted = initialLifted;

  if (tpl === 0) {
    return (
      <Root t={SPEC.templates[tpl]} k="n0" a={{ "data-s1-component": "footer", "data-platform": "pc" }} controller={controller} partProps={partProps} style={style} outer={outer} omit={omit} lifted={lifted} forceState={forceState} {...rest}>
        <El k="n1" a={{ "data-s1-part": "content", ...(slot(partScope, "content").attrs ?? {}) }}>
          <El k="n2" a={{ "data-s1-part": "links", ...(slot(partScope, "links").attrs ?? {}) }}>
            <El k="n3" a={{  }}>
              <El k="n4" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
                {slot(partScope, "link").content ?? "이용약관"}
              </El>
            </El>
            <El k="n5" a={{  }}>
              <El k="n6" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
                {slot(partScope, "link").content ?? "개인정보 처리방침"}
              </El>
            </El>
            <El k="n7" a={{  }}>
              <El k="n8" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
                {slot(partScope, "link").content ?? "위치기반 서비스 이용약관"}
              </El>
            </El>
          </El>
          <El k="n9" a={{ "data-s1-part": "company", ...(slot(partScope, "company").attrs ?? {}) }}>
            {slot(partScope, "company").content ?? "(주)에스원 사업자등록번호 208-81-13302 대표이사 정해린 04511 서울특별시 중구 세종대로 7길 25 에스원 빌딩"}
          </El>
          <El k="n10" a={{ "data-s1-part": "copyright", ...(slot(partScope, "copyright").attrs ?? {}) }}>
            {slot(partScope, "copyright").content ?? "© S-1 Corp. All Rights Reserved."}
          </El>
        </El>
        <El k="n11" a={{ "data-s1-part": "logo", ...(slot(partScope, "logo").attrs ?? {}) }}>
          <Svg viewBox="0 0 42 16" fill={svgColor} focusable="false" width="100%" height="100%">
            <Path d="M32.6826 14.3262H41.5254V16H30.6992V10.2461H32.6826V14.3262ZM10.1426 15.9902H8.32129V7.07812H7.39258C7.30419 11.1554 5.68825 13.0125 3.70117 13.0127C1.65723 13.0127 0 11.0554 0 6.73047C0 2.41216 1.65721 0.448242 3.70117 0.448242C5.52602 0.448409 7.03869 2.01912 7.34277 5.42676H8.32129V0.172852H10.1426V15.9902ZM12.9111 15.9902H11.084V0.173828H12.9111V15.9902ZM28.084 15.2305H15.084V13.5811H28.084V15.2305ZM41.2891 0.182617V13.0557H39.46V11.2832H36.459V9.64453H39.46V0.182617H41.2891ZM38.8672 8.87891H35.3379V12.1885H33.3799V8.87891H29.7305V7.3291H38.8672V8.87891ZM22.6143 2.46875C22.6143 4.89881 24.005 8.20501 27.7148 9.30078V11.0654C27.6961 11.063 23.8792 10.5615 21.583 6.69531C19.2775 10.5711 15.4512 11.0654 15.4512 11.0654V9.30078C19.1607 8.21325 20.5518 4.89883 20.5518 2.46875V0.551758H22.6143V2.46875ZM3.70215 2.41211C2.66837 2.41211 1.83011 3.41277 1.83008 6.7334C1.83008 10.0732 2.66835 11.0557 3.70215 11.0557C4.73624 11.0556 5.57422 10.0731 5.57422 6.7334C5.57418 3.41295 4.73622 2.41222 3.70215 2.41211ZM34.3525 0C36.6151 0 38.4492 1.17983 38.4492 3.41797C38.449 5.69092 36.615 6.83496 34.3525 6.83496C32.0903 6.83485 30.2561 5.69081 30.2559 3.41797C30.2559 1.17994 32.0901 0 34.3525 0ZM34.3486 1.57227C33.1672 1.57227 32.2091 2.36269 32.209 3.44043C32.209 4.51861 33.1671 5.30859 34.3486 5.30859C35.5303 5.3084 36.4883 4.51026 36.4883 3.44043C36.4882 2.35834 35.5302 1.57246 34.3486 1.57227Z" />
          </Svg>
        </El>
      </Root>
    );
  }
  if (tpl === 1) {
    return (
      <Root t={SPEC.templates[tpl]} k="n0" a={{ "data-s1-component": "footer", "data-platform": "mobile" }} controller={controller} partProps={partProps} style={style} outer={outer} omit={omit} lifted={lifted} forceState={forceState} {...rest}>
        <El k="n1" a={{ "data-s1-part": "links", ...(slot(partScope, "links").attrs ?? {}) }}>
          <El k="n2" a={{  }}>
            <El k="n3" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
              {slot(partScope, "link").content ?? "이용약관"}
            </El>
          </El>
          <El k="n4" a={{  }}>
            <El k="n5" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
              {slot(partScope, "link").content ?? "개인정보 처리방침"}
            </El>
          </El>
          <El k="n6" a={{  }}>
            <El k="n7" a={{ "data-s1-part": "link", ...(slot(partScope, "link").attrs ?? {}) }}>
              {slot(partScope, "link").content ?? "위치기반 서비스 이용약관"}
            </El>
          </El>
        </El>
        <El k="n8" a={{ "data-s1-part": "copyright", ...(slot(partScope, "copyright").attrs ?? {}) }}>
          {slot(partScope, "copyright").content ?? "© S-1 Corp. All Rights Reserved."}
        </El>
      </Root>
    );
  }
  throw new Error("[s1-ui] footer: 그릴 템플릿을 고르지 못했습니다.");
}
